﻿<#
.SYNOPSIS
    Runs all three deployment scripts in sequence: runbooks -> VM script ->
    Function App.

.DESCRIPTION
    Order matters -- deploy in the order that causes the least disruption
    if anything is polling mid-deploy:
      1. Runbooks       (no running runbooks affected; publish is atomic).
      2. VM script      (scheduled task picks up new file on next tick).
      3. Function App   (poller pauses during cold-start after deploy).

.PARAMETER CoreResourceGroup
    Resource group with the VM and Function App.  Default: iis-core

.PARAMETER MonitorResourceGroup
    Resource group with the Automation Account.  Default: iis-core-monitor

.PARAMETER FunctionAppName
    Default: iisheals-func

.PARAMETER AutomationAccount
    Default: iisheals-auto

.PARAMETER VMName
    Default: iisheals-vm

.PARAMETER SkipRunbooks
    Skip runbook deployment.

.PARAMETER SkipVMScript
    Skip VM script deployment.

.PARAMETER SkipFunctionApp
    Skip Function App deployment.

.EXAMPLE
    .\Deploy-All.ps1

.EXAMPLE
    .\Deploy-All.ps1 -CoreResourceGroup 'hardened-rg' `
                    -MonitorResourceGroup 'hardened-mon-rg' `
                    -FunctionAppName 'hardenedfunc' `
                    -AutomationAccount 'hardened-auto' `
                    -VMName 'hardened-vm'
#>
[CmdletBinding()]
param(
    [string]$CoreResourceGroup    = 'iis-core',
    [string]$MonitorResourceGroup = 'iis-core-monitor',
    [string]$FunctionAppName      = 'iisheals-func',
    [string]$AutomationAccount    = 'iisheals-auto',
    [string]$VMName               = 'iisheals-vm',
    [switch]$SkipRunbooks,
    [switch]$SkipVMScript,
    [switch]$SkipFunctionApp
)

$ErrorActionPreference = 'Stop'

# Resolve script directory using multiple fallbacks.  $PSScriptRoot is auto-
# populated by PowerShell for file-based execution (PS 3+); $PSCommandPath and
# $MyInvocation.MyCommand.Path are secondary fallbacks.
$ScriptDir = $PSScriptRoot
if (-not $ScriptDir -and $PSCommandPath)             { $ScriptDir = Split-Path -Parent $PSCommandPath }
if (-not $ScriptDir -and $MyInvocation.MyCommand.Path) { $ScriptDir = Split-Path -Parent $MyInvocation.MyCommand.Path }
if (-not $ScriptDir -or -not (Test-Path $ScriptDir)) {
    throw "Cannot determine script directory.  Run this script as a file: pwsh -File .\Deploy-All.ps1  (not via pipe or Invoke-Expression)."
}

Write-Host "[DIAG] Deploy-All.ps1 version: 2026-04-21b   ScriptDir: $ScriptDir" -ForegroundColor DarkGray

# Verify each child script is present before we start.
$runbooksScript    = Join-Path $ScriptDir 'Deploy-Runbooks.ps1'
$vmScriptScript    = Join-Path $ScriptDir 'Deploy-VMScript.ps1'
$functionAppScript = Join-Path $ScriptDir 'Deploy-FunctionApp.ps1'
foreach ($s in @($runbooksScript, $vmScriptScript, $functionAppScript)) {
    if (-not (Test-Path $s)) { throw "Missing child script: $s" }
}

function Write-Header($text) {
    Write-Host ''
    Write-Host '============================================================' -ForegroundColor Magenta
    Write-Host " $text" -ForegroundColor Magenta
    Write-Host '============================================================' -ForegroundColor Magenta
}

$overallStart = Get-Date

if (-not $SkipRunbooks) {
    Write-Header '1/3  DEPLOY RUNBOOKS'
    & $runbooksScript `
        -AutomationAccount $AutomationAccount `
        -ResourceGroup     $MonitorResourceGroup
    if ($LASTEXITCODE -ne 0 -and $null -ne $LASTEXITCODE) {
        throw "Deploy-Runbooks.ps1 exited with code $LASTEXITCODE"
    }
} else {
    Write-Host '[SKIP] Runbooks' -ForegroundColor DarkYellow
}

if (-not $SkipVMScript) {
    Write-Header '2/3  DEPLOY VM SCRIPT (Send-PerfToEventHub.ps1)'
    & $vmScriptScript `
        -VMName        $VMName `
        -ResourceGroup $CoreResourceGroup
    if ($LASTEXITCODE -ne 0 -and $null -ne $LASTEXITCODE) {
        throw "Deploy-VMScript.ps1 exited with code $LASTEXITCODE"
    }
} else {
    Write-Host '[SKIP] VM script' -ForegroundColor DarkYellow
}

if (-not $SkipFunctionApp) {
    Write-Header '3/3  DEPLOY FUNCTION APP'
    & $functionAppScript `
        -FunctionAppName $FunctionAppName `
        -ResourceGroup   $CoreResourceGroup
    if ($LASTEXITCODE -ne 0 -and $null -ne $LASTEXITCODE) {
        throw "Deploy-FunctionApp.ps1 exited with code $LASTEXITCODE"
    }
} else {
    Write-Host '[SKIP] Function App' -ForegroundColor DarkYellow
}

$elapsed = [int]((Get-Date) - $overallStart).TotalSeconds
Write-Header "DEPLOYMENT COMPLETE (${elapsed}s)"
Write-Host ''
Write-Host 'Verify with the following KQL against your Log Analytics workspace:' -ForegroundColor Cyan
Write-Host ''
Write-Host '  AgentEvents_CL' -ForegroundColor Gray
Write-Host '  | where TimeGenerated > ago(15m)' -ForegroundColor Gray
Write-Host '  | project TimeGenerated, IssueType, RunbookExecuted, RetryCount, IsHealthy' -ForegroundColor Gray
Write-Host ''
