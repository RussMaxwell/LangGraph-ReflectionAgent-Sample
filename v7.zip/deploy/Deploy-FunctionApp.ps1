﻿<#
.SYNOPSIS
    Deploys the IIS Auto-Healing Function App to an existing Azure Function App.

.DESCRIPTION
    Packages the ../function-app directory into a ZIP and publishes it via
    Azure CLI's zip-deploy.  Safe for private-endpoint environments because
    it goes through ARM / Kudu over whichever path the CLI host can reach
    (public endpoint, Private DNS, or VPN/Bastion).

    Does NOT touch infrastructure, app settings, managed identity, or DCRs.
    Code-only replacement.

.PARAMETER FunctionAppName
    Name of the existing Function App.  Default: iisheals-func

.PARAMETER ResourceGroup
    Resource group containing the Function App.  Default: iis-core

.PARAMETER BuildRemote
    If $true, uses `func azure functionapp publish --build remote` (requires
    `func` CLI and reachable SCM endpoint).  If $false (default), uses
    `az functionapp deployment source config-zip` which works with just the
    Azure CLI.

.EXAMPLE
    .\Deploy-FunctionApp.ps1

.EXAMPLE
    .\Deploy-FunctionApp.ps1 -FunctionAppName 'hardenedfunc' -ResourceGroup 'hardened-rg'

.NOTES
    Prereqs:
      - Azure CLI installed and `az login` completed.
      - Caller identity has Contributor (or Website Contributor) on the Function App.
      - If -BuildRemote $true: Azure Functions Core Tools (func) v4+ installed,
        and the Function App's SCM endpoint reachable from this host.
#>
[CmdletBinding()]
param(
    [string]$FunctionAppName = 'iisheals-func',
    [string]$ResourceGroup   = 'iis-core',
    [bool]  $BuildRemote     = $false
)

$ErrorActionPreference = 'Stop'
$ProgressPreference    = 'SilentlyContinue'

$ScriptDir  = if ($PSScriptRoot) { $PSScriptRoot } elseif ($PSCommandPath) { Split-Path -Parent $PSCommandPath } else { throw 'Cannot determine script directory. Run this script from a file, not via pipe/stdin.' }
$PackageDir = Resolve-Path (Join-Path $ScriptDir '..\function-app')

Write-Host "[INFO] Function App : $FunctionAppName" -ForegroundColor Cyan
Write-Host "[INFO] Resource Group: $ResourceGroup"  -ForegroundColor Cyan
Write-Host "[INFO] Source        : $PackageDir"     -ForegroundColor Cyan
Write-Host ''

# --- 1. Preflight -----------------------------------------------------------
if (-not (Get-Command az -ErrorAction SilentlyContinue)) {
    throw 'Azure CLI (az) not found on PATH.'
}

$acct = az account show --query name -o tsv 2>$null
if (-not $acct) { throw 'Not logged in.  Run: az login' }
Write-Host "[OK]   Authenticated to subscription: $acct" -ForegroundColor Green

$appState = az functionapp show --name $FunctionAppName --resource-group $ResourceGroup --query state -o tsv 2>$null
if (-not $appState) {
    throw "Function App '$FunctionAppName' not found in '$ResourceGroup'."
}
Write-Host "[OK]   Function App state: $appState" -ForegroundColor Green

# --- 2. Build deployment artifact -------------------------------------------
if ($BuildRemote) {
    if (-not (Get-Command func -ErrorAction SilentlyContinue)) {
        throw "Azure Functions Core Tools (func) not found. Install from https://aka.ms/azfunc-install or rerun with -BuildRemote `$false."
    }
    Write-Host '[INFO] Publishing via func azure functionapp publish --build remote...' -ForegroundColor Cyan
    Push-Location $PackageDir
    try {
        func azure functionapp publish $FunctionAppName --build remote
        if ($LASTEXITCODE -ne 0) { throw "func publish failed (exit $LASTEXITCODE)." }
    } finally {
        Pop-Location
    }
    Write-Host "[OK]   Function App '$FunctionAppName' published." -ForegroundColor Green
    return
}

# --- 2b. Zip-deploy path (no func CLI required) -----------------------------
$ZipPath = Join-Path $env:TEMP "iisheals-func-$(Get-Date -Format 'yyyyMMddHHmmss').zip"

Write-Host "[INFO] Creating deployment ZIP: $ZipPath" -ForegroundColor Cyan

# Exclude __pycache__, .python_packages, local.settings.json -- those must NOT ship.
$stagingDir = Join-Path $env:TEMP "iisheals-stage-$(Get-Date -Format 'yyyyMMddHHmmss')"
New-Item -ItemType Directory -Force -Path $stagingDir | Out-Null
try {
    Copy-Item -Path (Join-Path $PackageDir '*') -Destination $stagingDir -Recurse -Force
    Get-ChildItem -Path $stagingDir -Recurse -Directory -Filter '__pycache__'    | Remove-Item -Recurse -Force
    Get-ChildItem -Path $stagingDir -Recurse -Directory -Filter '.python_packages'| Remove-Item -Recurse -Force
    Get-ChildItem -Path $stagingDir -Recurse -File      -Filter 'local.settings.json' | Remove-Item -Force

    Compress-Archive -Path (Join-Path $stagingDir '*') -DestinationPath $ZipPath -Force
    Write-Host "[OK]   ZIP size: $([math]::Round((Get-Item $ZipPath).Length / 1MB, 2)) MB" -ForegroundColor Green
} finally {
    Remove-Item -Recurse -Force $stagingDir -ErrorAction SilentlyContinue
}

# --- 3. Deploy --------------------------------------------------------------
# NOTE: Requires WEBSITE_RUN_FROM_PACKAGE=1 OR SCM_DO_BUILD_DURING_DEPLOYMENT=1
#       to be set on the Function App for Python remote-build behavior. Most
#       existing deployments already have SCM_DO_BUILD_DURING_DEPLOYMENT=1.
Write-Host '[INFO] Deploying ZIP via az functionapp deployment source config-zip...' -ForegroundColor Cyan
Write-Host '       (this invokes Kudu remote build -- ~3-5 minutes for first deploy)' -ForegroundColor DarkGray

az functionapp deployment source config-zip `
    --resource-group $ResourceGroup `
    --name           $FunctionAppName `
    --src            $ZipPath `
    --build-remote   true `
    --timeout        600
if ($LASTEXITCODE -ne 0) { throw "az deployment failed (exit $LASTEXITCODE)." }

Remove-Item -Force $ZipPath -ErrorAction SilentlyContinue

# --- 4. Verify --------------------------------------------------------------
Start-Sleep -Seconds 5
$functions = az functionapp function list --name $FunctionAppName --resource-group $ResourceGroup --query "[].name" -o tsv
Write-Host ''
Write-Host "[OK]   Deployed functions:" -ForegroundColor Green
$functions -split "`n" | Where-Object { $_ } | ForEach-Object { Write-Host "       - $_" }
Write-Host ''
Write-Host "[DONE] Function App code updated.  IISMonitorPoller will pick up the new KQL on the next timer tick (< 60s)." -ForegroundColor Green
