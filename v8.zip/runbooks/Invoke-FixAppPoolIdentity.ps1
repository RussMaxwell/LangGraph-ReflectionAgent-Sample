<#
.SYNOPSIS
    Resets an IIS application pool's identity to the lab baseline (LocalSystem) and verifies it starts.
.DESCRIPTION
    Sets the processModel identityType to LocalSystem, clears any stored userName and
    password, recycles the pool, and confirms it reaches the Started state.

    Why LocalSystem and not ApplicationPoolIdentity: this lab's chaos app (chaos-app/)
    self-modifies IIS configuration from inside its own worker process (see
    scripts/setup-iis.ps1). That requires LocalSystem privilege; under
    ApplicationPoolIdentity the chaos scenarios can't write applicationHost.config and
    the test harness silently no-ops. LocalSystem matches the baseline set by
    setup-iis.ps1 so chaos -> heal -> chaos cycles are repeatable. For a real
    production server, change this to ApplicationPoolIdentity.
.PARAMETER VMName
    Name of the virtual machine.
.PARAMETER ResourceGroup
    Azure Resource Group the VM belongs to.
.PARAMETER AppPoolName
    IIS application pool to fix. Defaults to DefaultAppPool.
#>
param(
    [Parameter(Mandatory = $true)]
    [string]$VMName,

    [Parameter(Mandatory = $true)]
    [string]$ResourceGroup,

    [Parameter(Mandatory = $false)]
    [string]$AppPoolName = "DefaultAppPool"
)

$result = @{
    Success      = $false
    Action       = "FixAppPoolIdentity"
    Detail       = ""
    ErrorMessage = ""
}

try {
    Write-Output "[$VMName/$ResourceGroup] Fixing identity for app pool '$AppPoolName'."

    Import-Module WebAdministration -ErrorAction Stop
    Write-Output "WebAdministration module loaded."

    # Verify the pool exists. Get-WebAppPoolState is proxied to the
    # WinPSCompatSession where the IIS: drive exists; the generic IIS:\ path
    # cmdlets (Get-Item, Set-ItemProperty) run in the PS7 caller and fail.
    $null = Get-WebAppPoolState -Name $AppPoolName -ErrorAction Stop

    $pmFilter = "system.applicationHost/applicationPools/add[@name='$AppPoolName']/processModel"
    $appcmd   = "$env:SystemRoot\System32\inetsrv\appcmd.exe"

    $currentIdentity = (Get-WebConfigurationProperty -pspath 'MACHINE/WEBROOT/APPHOST' -filter $pmFilter -name identityType -ErrorAction Stop).Value
    Write-Output "Current identityType for '$AppPoolName': $currentIdentity"

    # Use appcmd.exe for the Set operations. Set-WebConfigurationProperty goes
    # through the WinPSCompatSession, which mis-serialises identityType enum names
    # across the PS7<->PS5.1 boundary. appcmd.exe is a native binary with no
    # remoting layer, so the enum name is passed verbatim to the IIS config API.
    $setIdentity = & $appcmd set apppool "$AppPoolName" /processModel.identityType:LocalSystem 2>&1
    if ($LASTEXITCODE -ne 0) { throw "appcmd set identityType failed (exit $LASTEXITCODE): $setIdentity" }
    Write-Output "identityType set to LocalSystem. ($setIdentity)"

    $clearUser = & $appcmd set apppool "$AppPoolName" /processModel.userName:"" 2>&1
    if ($LASTEXITCODE -ne 0) { throw "appcmd clear userName failed (exit $LASTEXITCODE): $clearUser" }
    $clearPass = & $appcmd set apppool "$AppPoolName" /processModel.password:"" 2>&1
    if ($LASTEXITCODE -ne 0) { throw "appcmd clear password failed (exit $LASTEXITCODE): $clearPass" }
    Write-Output "userName and password fields cleared."

    # Apply the config change: Restart-WebAppPool only works on a running pool —
    # if rapid-fail protection has already stopped it, Restart throws
    # "You have to start stopped object before restarting it." Branch on state
    # and use Start-WebAppPool for Stopped pools.
    $stateBefore = (Get-WebAppPoolState -Name $AppPoolName -ErrorAction Stop).Value
    Write-Output "App pool '$AppPoolName' state before restart: $stateBefore."
    if ($stateBefore -eq 'Stopped') {
        Start-WebAppPool -Name $AppPoolName -ErrorAction Stop
        Write-Output "App pool '$AppPoolName' started."
    }
    else {
        Restart-WebAppPool -Name $AppPoolName -ErrorAction Stop
        Write-Output "App pool '$AppPoolName' recycled."
    }

    # Wait for the pool to start (up to 30 seconds, poll every 2 seconds)
    $maxWaitSeconds = 30
    $pollIntervalSeconds = 2
    $elapsed = 0
    $started = $false

    while ($elapsed -lt $maxWaitSeconds) {
        Start-Sleep -Seconds $pollIntervalSeconds
        $elapsed += $pollIntervalSeconds

        $state = (Get-WebAppPoolState -Name $AppPoolName -ErrorAction Stop).Value
        Write-Output "Poll at ${elapsed}s — pool state: $state."

        if ($state -eq "Started") {
            $started = $true
            break
        }
    }

    if ($started) {
        $result.Success = $true
        $result.Detail  = "App pool '$AppPoolName' identity reset to LocalSystem. Pool confirmed Started after ${elapsed}s."
        Write-Output $result.Detail
    }
    else {
        $finalState = (Get-WebAppPoolState -Name $AppPoolName -ErrorAction SilentlyContinue).Value
        $result.Detail       = "Identity was updated but pool did not reach Started state within ${maxWaitSeconds}s. Last state: $finalState."
        $result.ErrorMessage = $result.Detail
        Write-Output "FAILURE: $($result.Detail)"
    }
}
catch {
    $result.ErrorMessage = $_.Exception.Message
    $result.Detail       = "Exception during identity fix: $($_.Exception.Message)"
    Write-Output "ERROR: $($result.Detail)"
}

Write-Output "Runbook complete. Success=$($result.Success)"
$result
