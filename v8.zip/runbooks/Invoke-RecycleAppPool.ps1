<#
.SYNOPSIS
    Recycles the specified IIS application pool and waits for it to reach the Started state.
.DESCRIPTION
    Imports WebAdministration, recycles the target app pool, then polls every 2 seconds
    (up to 30 seconds) until the pool reports a Started state.
.PARAMETER VMName
    Name of the virtual machine (used for logging / upstream orchestration).
.PARAMETER ResourceGroup
    Azure Resource Group the VM belongs to.
.PARAMETER AppPoolName
    IIS application pool to recycle. Defaults to DefaultAppPool.
#>
param(
    [Parameter(Mandatory = $true)]
    [string]$VMName,

    [Parameter(Mandatory = $true)]
    [string]$ResourceGroup,

    [Parameter(Mandatory = $false)]
    [string]$AppPoolName = "DefaultAppPool"
)

$result = @{
    Success      = $false
    Action       = "RecycleAppPool"
    Detail       = ""
    ErrorMessage = ""
}

try {
    Write-Output "[$VMName/$ResourceGroup] Starting app-pool recycle for '$AppPoolName'."

    Import-Module WebAdministration -ErrorAction Stop
    Write-Output "WebAdministration module loaded."

    # Confirm the pool exists before attempting a recycle. Get-WebAppPoolState
    # is proxied to the WinPSCompatSession; Get-Item on IIS:\ would fail in PS7.
    $currentState = (Get-WebAppPoolState -Name $AppPoolName -ErrorAction Stop).Value
    Write-Output "App pool '$AppPoolName' found. Current state: $currentState."

    # A pool stopped by rapid-fail protection — or by an administrator (manual Stop
    # via IIS Manager / Stop-WebAppPool) — cannot be recycled.  Restart-WebAppPool
    # is a no-op on a Stopped pool and leaves it stopped.  Start-WebAppPool must be
    # used explicitly to bring it back.  For a running pool, use the normal recycle
    # path so the worker process is refreshed gracefully.
    if ($currentState -eq 'Stopped') {
        Write-Output "Pool is Stopped (rapid-fail or administratively stopped). Using Start-WebAppPool."
        # Ensure autoStart=true so the pool survives future W3SVC restarts. A manual
        # Stop does not normally flip autoStart, but some tools/IIS configurations do;
        # forcing true here is harmless on already-enabled pools.
        try {
            Set-WebConfigurationProperty -pspath 'MACHINE/WEBROOT/APPHOST' -filter "system.applicationHost/applicationPools/add[@name='$AppPoolName']" -name autoStart -value $true -ErrorAction SilentlyContinue
        } catch {
            Write-Output "Could not set autoStart on '$AppPoolName' (continuing): $($_.Exception.Message)"
        }
        Start-WebAppPool -Name $AppPoolName -ErrorAction Stop
        Write-Output "Start-WebAppPool command issued for '$AppPoolName'."
    }
    else {
        Restart-WebAppPool -Name $AppPoolName -ErrorAction Stop
        Write-Output "Restart-WebAppPool command issued for '$AppPoolName'."
    }

    # Poll for Started state — up to 30 seconds, checking every 2 seconds
    $maxWaitSeconds = 30
    $pollIntervalSeconds = 2
    $elapsed = 0
    $started = $false

    while ($elapsed -lt $maxWaitSeconds) {
        Start-Sleep -Seconds $pollIntervalSeconds
        $elapsed += $pollIntervalSeconds

        $currentState = (Get-WebAppPoolState -Name $AppPoolName -ErrorAction Stop).Value
        Write-Output "Poll at ${elapsed}s — pool state: $currentState."

        if ($currentState -eq "Started") {
            $started = $true
            break
        }
    }

    if ($started) {
        $result.Success = $true
        $result.Detail  = "App pool '$AppPoolName' recycled and confirmed Started after ${elapsed}s."
        Write-Output $result.Detail
    }
    else {
        $finalState = (Get-WebAppPoolState -Name $AppPoolName -ErrorAction SilentlyContinue).Value
        $result.Detail       = "App pool '$AppPoolName' did not reach Started state within ${maxWaitSeconds}s. Last observed state: $finalState."
        $result.ErrorMessage = $result.Detail
        Write-Output "FAILURE: $($result.Detail)"
    }
}
catch {
    $result.ErrorMessage = $_.Exception.Message
    $result.Detail       = "Exception during app-pool recycle: $($_.Exception.Message)"
    Write-Output "ERROR: $($result.Detail)"
}

Write-Output "Runbook complete. Success=$($result.Success)"
$result
