<#
.SYNOPSIS
    Full IIS reset + explicit app-pool restart. Used as the escalation runbook
    when Invoke-RecycleAppPool didn't restore health.
.DESCRIPTION
    1. iisreset /restart
    2. Verifies W3SVC is Running
    3. Forces autoStart=true on $AppPoolName
    4. Explicitly starts the pool if it isn't Started (iisreset preserves
       administratively-stopped pool state, so a manual Stop survives a reset
       unless we kick the pool back up here)
    5. Polls the pool until it reaches Started or a timeout
.PARAMETER VMName
    Name of the virtual machine.
.PARAMETER ResourceGroup
    Azure Resource Group the VM belongs to.
.PARAMETER AppPoolName
    IIS application pool to force-start after iisreset. Defaults to DefaultAppPool.
#>
param(
    [Parameter(Mandatory = $true)]
    [string]$VMName,

    [Parameter(Mandatory = $true)]
    [string]$ResourceGroup,

    [Parameter(Mandatory = $false)]
    [string]$AppPoolName = "DefaultAppPool"
)

$result = @{
    Success      = $false
    Action       = "RestartIIS"
    Detail       = ""
    ErrorMessage = ""
}

try {
    Write-Output "[$VMName/$ResourceGroup] Initiating full IIS restart (pool='$AppPoolName')."

    $iisResetOutput = & iisreset /restart 2>&1
    $exitCode = $LASTEXITCODE
    $outputText = ($iisResetOutput | Out-String).Trim()

    Write-Output "iisreset output:`n$outputText"
    Write-Output "iisreset exit code: $exitCode"

    if ($exitCode -ne 0) {
        $result.Detail       = "iisreset exited with code $exitCode. Output: $outputText"
        $result.ErrorMessage = $result.Detail
        Write-Output "FAILURE: $($result.Detail)"
        Write-Output "Runbook complete. Success=$($result.Success)"
        return $result
    }

    Write-Output "iisreset completed successfully. Verifying W3SVC service state."
    Start-Sleep -Seconds 3

    $svc = Get-Service -Name W3SVC -ErrorAction Stop
    Write-Output "W3SVC service status: $($svc.Status)"

    if ($svc.Status -ne 'Running') {
        $result.Detail       = "iisreset succeeded but W3SVC is not Running (status: $($svc.Status))."
        $result.ErrorMessage = $result.Detail
        Write-Output "FAILURE: $($result.Detail)"
        Write-Output "Runbook complete. Success=$($result.Success)"
        return $result
    }

    # --- App pool recovery -----------------------------------------------
    # iisreset preserves administratively-stopped pool state: a manually
    # Stop-WebAppPool'd pool stays Stopped after W3SVC restarts. Explicitly
    # reset autoStart=true and start the pool here.
    Import-Module WebAdministration -ErrorAction Stop

    # Confirm the pool exists. Get-WebAppPoolState is proxied to the
    # WinPSCompatSession; Test-Path on IIS:\ would fail in PS7.
    $poolExists = $true
    try {
        $null = Get-WebAppPoolState -Name $AppPoolName -ErrorAction Stop
    } catch {
        $poolExists = $false
    }
    if (-not $poolExists) {
        $result.Detail       = "W3SVC is Running but app pool '$AppPoolName' does not exist."
        $result.ErrorMessage = $result.Detail
        Write-Output "FAILURE: $($result.Detail)"
        Write-Output "Runbook complete. Success=$($result.Success)"
        return $result
    }

    # Ensure autoStart=true so future W3SVC restarts recover the pool too.
    try {
        Set-WebConfigurationProperty -pspath 'MACHINE/WEBROOT/APPHOST' -filter "system.applicationHost/applicationPools/add[@name='$AppPoolName']" -name autoStart -value $true -ErrorAction SilentlyContinue
        Write-Output "Ensured autoStart=true on '$AppPoolName'."
    } catch {
        Write-Output "Could not set autoStart on '$AppPoolName' (continuing): $($_.Exception.Message)"
    }

    $poolState = (Get-WebAppPoolState -Name $AppPoolName -ErrorAction Stop).Value
    Write-Output "App pool '$AppPoolName' current state: $poolState."

    if ($poolState -ne 'Started') {
        Write-Output "Starting app pool '$AppPoolName'..."
        Start-WebAppPool -Name $AppPoolName -ErrorAction Stop
    }

    # Poll until pool reaches Started or we time out.
    $maxWaitSeconds = 30
    $elapsed        = 0
    while ($elapsed -lt $maxWaitSeconds) {
        Start-Sleep -Seconds 3
        $elapsed += 3
        $poolState = (Get-WebAppPoolState -Name $AppPoolName -ErrorAction Stop).Value
        Write-Output "Poll at ${elapsed}s — pool state: $poolState."
        if ($poolState -eq 'Started') { break }
    }

    if ($poolState -eq 'Started') {
        $result.Success = $true
        $result.Detail  = "IIS restarted and app pool '$AppPoolName' confirmed Started after ${elapsed}s."
        Write-Output $result.Detail
    }
    else {
        $result.Detail       = "iisreset + W3SVC OK, but app pool '$AppPoolName' did not reach Started within ${maxWaitSeconds}s (last state: $poolState)."
        $result.ErrorMessage = $result.Detail
        Write-Output "FAILURE: $($result.Detail)"
    }
}
catch {
    $result.ErrorMessage = $_.Exception.Message
    $result.Detail       = "Exception during IIS restart: $($_.Exception.Message)"
    Write-Output "ERROR: $($result.Detail)"
}

Write-Output "Runbook complete. Success=$($result.Success)"
$result
