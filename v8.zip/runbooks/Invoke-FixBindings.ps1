<#
.SYNOPSIS
    Ensures the Default Web Site has an HTTP binding on port 80 and that any
    Stopped IIS site is started.
.DESCRIPTION
    Imports WebAdministration, checks whether the Default Web Site already
    has an HTTP :80 binding. If missing, creates one. Then enumerates all
    sites and starts any that are in Stopped state — IIS auto-stops a site
    that has no bindings and does not always auto-start it when bindings are
    re-added, so an explicit Start-Website is required for full recovery.
    Verifies the binding exists after the fix. Runs as an Azure Automation
    runbook on a Hybrid Runbook Worker.
#>

param(
    [Parameter(Mandatory = $true)]
    [string]$VMName,

    [Parameter(Mandatory = $true)]
    [string]$ResourceGroup,

    [Parameter(Mandatory = $false)]
    [string]$AppPoolName = "DefaultAppPool"
)

$result = @{
    Success      = $false
    Action       = "FixBindings"
    Detail       = ""
    ErrorMessage = ""
}

try {
    Write-Output "[$VMName] Starting FixBindings runbook."
    Write-Output "[$VMName] Resource Group: $ResourceGroup | AppPool context: $AppPoolName"

    # --- Import WebAdministration module ---
    Write-Output "[$VMName] Importing WebAdministration module..."
    Import-Module WebAdministration -ErrorAction Stop
    Write-Output "[$VMName] WebAdministration module loaded."

    $siteName = "Default Web Site"

    # --- Check existing bindings ---
    Write-Output "[$VMName] Retrieving bindings for '$siteName'..."
    $bindings = Get-WebBinding -Name $siteName -ErrorAction Stop
    Write-Output "[$VMName] Found $($bindings.Count) binding(s) on '$siteName'."

    foreach ($b in $bindings) {
        Write-Output "[$VMName]   Binding: Protocol=$($b.protocol) BindingInfo=$($b.bindingInformation)"
    }

    # Look for an HTTP binding on port 80 (any IP)
    $httpBinding = $bindings | Where-Object {
        $_.protocol -eq 'http' -and $_.bindingInformation -match ':80:'
    }

    if ($httpBinding) {
        Write-Output "[$VMName] HTTP :80 binding already exists. No action needed."
        $result.Success = $true
        $result.Detail  = "HTTP port 80 binding already present on '$siteName'. No changes made."
    } else {
        Write-Output "[$VMName] HTTP :80 binding is MISSING. Adding binding..."

        New-WebBinding -Name $siteName -Protocol http -Port 80 -IPAddress "*" -ErrorAction Stop
        Write-Output "[$VMName] New-WebBinding command completed."

        # --- Verify the binding was created ---
        Write-Output "[$VMName] Verifying binding was created..."
        $verifyBindings = Get-WebBinding -Name $siteName -ErrorAction Stop
        $verifyHttp = $verifyBindings | Where-Object {
            $_.protocol -eq 'http' -and $_.bindingInformation -match ':80:'
        }

        if ($verifyHttp) {
            Write-Output "[$VMName] Verification passed: HTTP :80 binding now exists."
            $result.Success = $true
            $result.Detail  = "HTTP port 80 binding was missing and has been added to '$siteName'. Verified successfully."
        } else {
            throw "Binding was added but verification failed. HTTP :80 binding not found after creation."
        }
    }

    # --- Start any Stopped sites ---
    # Required because IIS auto-stops a site when its last binding is removed
    # and does not always auto-start it when a binding is re-added. Without
    # this step, restoring the binding leaves the site Stopped and HTTP_OK
    # health checks continue to fail.
    Write-Output "[$VMName] Checking for Stopped sites..."
    $stoppedSites = @(Get-Website -ErrorAction Stop | Where-Object { $_.State -eq 'Stopped' })
    if ($stoppedSites.Count -eq 0) {
        Write-Output "[$VMName] No Stopped sites found."
    }
    else {
        foreach ($s in $stoppedSites) {
            Write-Output "[$VMName] Starting Stopped site '$($s.Name)'..."
            try {
                Start-Website -Name $s.Name -ErrorAction Stop
                $newState = (Get-Website -Name $s.Name -ErrorAction SilentlyContinue).State
                Write-Output "[$VMName]   Site '$($s.Name)' now in state: $newState."
                if ($newState -ne 'Started') {
                    Write-Output "[$VMName]   WARNING: Site '$($s.Name)' did not reach Started state."
                }
            }
            catch {
                Write-Output "[$VMName]   ERROR starting site '$($s.Name)': $($_.Exception.Message)"
            }
        }
        $result.Detail = ($result.Detail + " Started $($stoppedSites.Count) Stopped site(s).").Trim()
    }

} catch {
    $result.Success      = $false
    $result.ErrorMessage = $_.Exception.Message
    Write-Output "[$VMName] ERROR during FixBindings: $($_.Exception.Message)"
}

Write-Output "[$VMName] Runbook result: Success=$($result.Success) | Action=$($result.Action)"
Write-Output ($result | ConvertTo-Json -Depth 3)

return $result
