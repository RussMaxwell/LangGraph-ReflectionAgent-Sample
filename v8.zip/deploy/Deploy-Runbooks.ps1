﻿<#
.SYNOPSIS
    Uploads and publishes the 5 updated PowerShell runbooks to an existing
    Azure Automation Account.

.DESCRIPTION
    For each .ps1 file in ../runbooks, replaces draft content and publishes
    the runbook.  Uses ARM management plane -- works with private endpoints
    as long as the caller can reach the Automation Account (public endpoint,
    Private DNS via VPN/Bastion, or inside the VNet).

    Does NOT touch Hybrid Worker registration, runbook schedules, or RBAC.
    Content-only replacement.

.PARAMETER AutomationAccount
    Name of the existing Automation Account.  Default: iisheals-auto

.PARAMETER ResourceGroup
    Resource group containing the Automation Account.  Default: iis-core-monitor

.EXAMPLE
    .\Deploy-Runbooks.ps1

.EXAMPLE
    .\Deploy-Runbooks.ps1 -AutomationAccount 'hardened-auto' -ResourceGroup 'hardened-mon-rg'

.NOTES
    Prereqs:
      - Azure CLI installed and `az login` completed.
      - Caller identity has Automation Contributor on the Automation Account.

    Runbooks deployed (5):
      - Invoke-FixAppPoolIdentity.ps1
      - Invoke-FixBindings.ps1
      - Invoke-FixPermissions.ps1
      - Invoke-RecycleAppPool.ps1
      - Invoke-RestartIIS.ps1
#>
[CmdletBinding()]
param(
    [string]$AutomationAccount = 'iisheals-auto',
    [string]$ResourceGroup     = 'iis-core-monitor'
)

$ErrorActionPreference = 'Stop'

$ScriptDir   = if ($PSScriptRoot) { $PSScriptRoot } elseif ($PSCommandPath) { Split-Path -Parent $PSCommandPath } else { throw 'Cannot determine script directory. Run this script from a file, not via pipe/stdin.' }
$RunbooksDir = Resolve-Path (Join-Path $ScriptDir '../runbooks')

Write-Host "[INFO] Automation Account: $AutomationAccount" -ForegroundColor Cyan
Write-Host "[INFO] Resource Group    : $ResourceGroup"     -ForegroundColor Cyan
Write-Host "[INFO] Runbooks source   : $RunbooksDir"       -ForegroundColor Cyan
Write-Host ''

# --- Preflight --------------------------------------------------------------
if (-not (Get-Command az -ErrorAction SilentlyContinue)) {
    throw 'Azure CLI (az) not found on PATH.'
}

$acct = az account show --query name -o tsv 2>$null
if (-not $acct) { throw 'Not logged in.  Run: az login' }
Write-Host "[OK]   Authenticated to subscription: $acct" -ForegroundColor Green

# 'az automation' lives in the 'automation' CLI extension.  Auto-install if missing.
$extInstalled = az extension list --query "[?name=='automation'].name" -o tsv 2>$null
if (-not $extInstalled) {
    Write-Host "[INFO] Installing Azure CLI 'automation' extension..." -ForegroundColor Cyan
    az extension add --name automation --only-show-errors 2>&1 | Out-Null
    if ($LASTEXITCODE -ne 0) {
        throw "Failed to install 'automation' extension.  In offline/restricted environments, install manually: az extension add --name automation"
    }
    Write-Host "[OK]   'automation' extension installed." -ForegroundColor Green
} else {
    Write-Host "[OK]   'automation' extension present." -ForegroundColor Green
}

$aa = az automation account show --name $AutomationAccount --resource-group $ResourceGroup --query name -o tsv 2>$null
if (-not $aa) {
    throw "Automation Account '$AutomationAccount' not found in '$ResourceGroup'."
}
Write-Host "[OK]   Automation Account reachable: $aa" -ForegroundColor Green
Write-Host ''

# --- Upload and publish each runbook ---------------------------------------
$runbooks = Get-ChildItem -Path $RunbooksDir -Filter '*.ps1' -File
if ($runbooks.Count -eq 0) {
    throw "No .ps1 files found in $RunbooksDir."
}

$failed = @()
foreach ($rb in $runbooks) {
    $name = $rb.BaseName
    Write-Host "[INFO] Uploading $name..." -ForegroundColor Cyan

    # replace-content works for both new and existing runbooks on recent az versions;
    # if the runbook doesn't exist yet, create it first.
    $exists = az automation runbook show `
        --resource-group          $ResourceGroup `
        --automation-account-name $AutomationAccount `
        --name                    $name `
        --query name -o tsv 2>$null

    if (-not $exists) {
        Write-Host "       Runbook not found -- creating..." -ForegroundColor DarkYellow
        az automation runbook create `
            --resource-group          $ResourceGroup `
            --automation-account-name $AutomationAccount `
            --name                    $name `
            --type                    PowerShell `
            --output none
        if ($LASTEXITCODE -ne 0) {
            Write-Host "[FAIL] Could not create $name" -ForegroundColor Red
            $failed += $name
            continue
        }
    }

    az automation runbook replace-content `
        --resource-group          $ResourceGroup `
        --automation-account-name $AutomationAccount `
        --name                    $name `
        --content                 "@$($rb.FullName)" `
        --output none
    if ($LASTEXITCODE -ne 0) {
        Write-Host "[FAIL] replace-content failed for $name" -ForegroundColor Red
        $failed += $name
        continue
    }

    az automation runbook publish `
        --resource-group          $ResourceGroup `
        --automation-account-name $AutomationAccount `
        --name                    $name `
        --output none
    if ($LASTEXITCODE -ne 0) {
        Write-Host "[FAIL] publish failed for $name" -ForegroundColor Red
        $failed += $name
        continue
    }

    Write-Host "[OK]   $name published" -ForegroundColor Green
}

Write-Host ''
if ($failed.Count -gt 0) {
    Write-Host "[DONE] Deployed $($runbooks.Count - $failed.Count) of $($runbooks.Count) runbooks.  Failures:" -ForegroundColor Red
    $failed | ForEach-Object { Write-Host "       - $_" -ForegroundColor Red }
    exit 1
}
Write-Host "[DONE] All $($runbooks.Count) runbooks deployed and published." -ForegroundColor Green
