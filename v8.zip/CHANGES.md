# Changes bundled in this package

Period covered: **2026-04-19 → 2026-04-21** (based on file modification times).

---

## Function App (`function-app/`)

Full source ships — the package replaces whatever's running.  Files modified in the window:

| File | Purpose of changes |
|---|---|
| `IISMonitorPoller/__init__.py` | (1) Added `site_stopped` KQL detector + priority slot 2; (2) added `http_5xx_flood` detector; (3) **2026-04-21**: lowered `w3svc_stopped` `RowCount` threshold from `>= 3` to `>= 2` so both detectors reach their bar on the same poll and priority rank 1 wins cleanly. |
| `IISHealingOrchestratorInternal/__init__.py` | Added `_ISSUE_TO_ALERT_NAME` entries for `site_stopped` and `http_5xx_flood`. |
| `agents/classify_agent.py` | Added substring mappings: `"site stopped" → site_stopped`, `"site state" → site_stopped`, plus 5xx flood mappings. |
| `agents/profiles.py` | Added profiles for `site_stopped` (MECHANICAL → `Invoke-FixBindings`) and `http_5xx_flood` (REASONED_WITH_VETO → `Invoke-RecycleAppPool`). |
| `agents/confirm_agent.py` | Confirm-check handler additions aligned with new profiles. |
| `agents/orchestrator.py` | Wiring for new issue types through the single-path graph. |
| `tools/poller_state.py` | Minor adjustments for new priority list. |

Rest of function-app is unchanged vs prior deploy, but ships in full because `func` / zip-deploy replaces the whole app.

---

## Runbooks (`runbooks/`) — 5 files

| Runbook | Change |
|---|---|
| `Invoke-FixBindings.ps1` | Now auto-starts IIS sites in `Stopped` state (needed for the new `site_stopped` path). |
| `Invoke-RestartIIS.ps1` | PS7-compat tweaks for Hybrid Worker execution. |
| `Invoke-RecycleAppPool.ps1` | PS7-compat tweaks. |
| `Invoke-FixAppPoolIdentity.ps1` | PS7-compat tweaks. |
| `Invoke-FixPermissions.ps1` | PS7-compat tweaks. |

Other runbooks (`Invoke-RestartW3SVC.ps1`, `Invoke-ClearIISLogs.ps1`, `Invoke-ClearASPNETCache.ps1`, `Invoke-RestartWorkerProcess.ps1`, `Invoke-EnableIIS.ps1`, `Invoke-CaptureBaseline.ps1`) were not modified in this window and are **not** in the package.

---

## VM script (`vm-scripts/`) — 1 file

| Script | Change |
|---|---|
| `Send-PerfToEventHub.ps1` | Added synthetic-row emitters for: (a) `Current Connections = 0` when W3SVC is not Running (feeds `w3svc_stopped`), (b) `Site State = 0` per site for any non-Started site (feeds `site_stopped`), (c) `Pool Identity Status = 0` for non-Started pools on SpecificUser identity (feeds `app_pool_identity`). |

Deployed to `C:\Scripts\Send-PerfToEventHub.ps1` on the VM.  The existing `SendPerfToEventHub` scheduled task (runs every 60s as SYSTEM) is untouched and will pick up the new file on its next run.

---

## Not shipped (would require infra changes)

The following exist in the upstream repo but are **excluded** because they require infrastructure changes not safe for a drop-in code update:

- `infra/` Bicep templates
- `scripts/deploy.sh` (full-stack provisioning)
- New DCR columns / LAW schema changes (none in this window)
- Event Hub / ADX table additions (none in this window)

If any of the above need updating later, coordinate a separate window.
