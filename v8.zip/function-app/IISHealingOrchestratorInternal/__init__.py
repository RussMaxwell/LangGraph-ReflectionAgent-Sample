"""IISHealingOrchestratorInternal -- internal HTTP trigger for ADX-detected issues.

Accepts a simple JSON payload from IISMonitorPoller and feeds it into the
LangGraph pipeline, bypassing the Azure Monitor common-alert-schema parser.

Expected body:
    {
        "issue_type":    "high_cpu",
        "issue_summary": "% Processor Time avg=91.2 (threshold: 85%)"
    }

The issue_type is mapped to an alert_name string that classify_agent's
substring matcher will resolve back to the same issue_type.  This keeps
the single-path pipeline oblivious to how the alert arrived.
"""

from __future__ import annotations

import json
import logging
import os
import time
import traceback
from datetime import datetime, timezone

import azure.functions as func

from models.healing_result import HealingResult

logger = logging.getLogger("IISHealingOrchestratorInternal")


# ---------------------------------------------------------------------------
# issue_type -> alert_name pattern that classify_agent._ALERT_TO_ISSUE will
# match back to the same issue_type.
# ---------------------------------------------------------------------------
_ISSUE_TO_ALERT_NAME: dict[str, str] = {
    "w3svc_stopped":       "IIS Current Connections = 0 (IIS Down)",
    "site_stopped":        "IIS Site Stopped (bindings missing or admin-stopped)",
    "app_pool_stopped":    "App Pool Stopped (Rapid-Fail Protection) — 503 AppOffline",
    "app_pool_crash":      "ASP.NET Application Restarts > 2",
    "log_disk_full":       "VM C: Drive Free Space < 5%",
    "binding_missing":     "IIS Failed Connection Attempts > 50",
    "high_cpu_w3wp":       "w3wp CPU > 80%",
    "memory_leak":         "w3wp Working Set > 1.5 GB",
    "worker_process_hang": "w3wp Thread Count > 200",
    "request_queue_flood": "ASP.NET Requests Queued > 100",
    "bad_http_errors":     "HTTP 404 Errors/sec > 20",
    "high_cpu":            "VM CPU > 85% sustained",
    "high_memory":         "VM Available Memory low",
    "high_disk_io":        "VM Disk Queue Length > 5",
    "http_5xx_flood":      "HTTP 5xx Errors/sec rate elevated",
    "app_pool_identity":   "App Pool Identity misconfigured",
    "bad_permissions":     "IIS_IUSRS bad permissions",
}


def _build_synthetic_alert(issue_type: str, issue_summary: str) -> dict:
    """Build a minimal alert payload dict the AlertPayload model will accept."""
    alert_name = _ISSUE_TO_ALERT_NAME.get(issue_type, f"ADX detected: {issue_type}")
    fired_dt   = datetime.now(timezone.utc).isoformat()
    return {
        "alertId":   f"adx-poller-{issue_type}-{int(time.time())}",
        "alertName": alert_name,
        "severity":  "Sev2",
        "essentials": {
            "alertId":       f"adx-poller-{issue_type}",
            "alertRule":     alert_name.lower().replace(" ", "-"),
            "severity":      "Sev2",
            "description":   issue_summary,
            "firedDateTime": fired_dt,
        },
    }


def main(req: func.HttpRequest) -> func.HttpResponse:
    """HTTP POST entry point invoked by IISMonitorPoller."""

    start_time = time.time()
    logger.info("IISHealingOrchestratorInternal triggered.")

    try:
        body = req.get_json()
    except ValueError:
        return func.HttpResponse(
            json.dumps({"error": "Request body is not valid JSON."}),
            status_code=400,
            mimetype="application/json",
        )

    issue_type    = body.get("issue_type", "unknown")
    issue_summary = body.get("issue_summary", issue_type)

    logger.info(
        "Internal trigger — issue_type=%s summary=%.120s",
        issue_type,
        issue_summary,
    )

    try:
        from models.alert_payload import AlertPayload
        from agents.orchestrator import build_graph, build_initial_state

        alert_data    = _build_synthetic_alert(issue_type, issue_summary)
        alert_payload = AlertPayload.model_validate(alert_data)

        graph = build_graph()
        final_state = graph.invoke(build_initial_state(alert_payload))

    except Exception as exc:
        logger.error("Orchestrator failed: %s\n%s", exc, traceback.format_exc())
        duration = time.time() - start_time
        error_result = HealingResult(
            AlertId=f"adx-poller-{issue_type}",
            AlertName=_ISSUE_TO_ALERT_NAME.get(issue_type, issue_type),
            Severity="Sev2",
            IssueType="orchestrator_error",
            IssueSummary=f"Orchestrator raised an exception: {exc}",
            AnalysisResult="",
            RemediationRunbook="",
            RemediationOutcome="failed",
            RemediationDetail=traceback.format_exc(),
            IsHealthy=False,
            RetryCount=0,
            RootCause="",
            NextSteps="",
            VmName=os.environ.get("VM_NAME", ""),
            VmHostname=os.environ.get("VM_HOSTNAME", ""),
            Errors=json.dumps([{"error": str(exc)}]),
            DurationSeconds=duration,
        )
        return func.HttpResponse(
            error_result.model_dump_json(indent=2),
            status_code=500,
            mimetype="application/json",
        )

    duration = time.time() - start_time
    result = HealingResult.from_agent_state(
        state=final_state,
        duration_seconds=duration,
        vm_name=os.environ.get("VM_NAME", ""),
        vm_hostname=os.environ.get("VM_HOSTNAME", ""),
    )

    logger.info(
        "Healing complete — outcome=%s healthy=%s duration=%.1fs",
        result.RemediationOutcome,
        result.IsHealthy,
        duration,
    )

    # If the pipeline restored health, advance the poller's checkpoint past
    # "now" so that residual breach rows in the 7-min detection window (rows
    # generated after the poll that triggered this heal but before the heal
    # landed) cannot re-fire the same detector on the next poll cycle.
    # Failed heals deliberately skip this — we want retries to keep firing.
    if result.IsHealthy:
        try:
            from tools.poller_state import advance_checkpoint_to_now
            advance_checkpoint_to_now()
        except Exception as exc:
            logger.warning("Checkpoint advance failed (non-fatal): %s", exc)

    return func.HttpResponse(
        result.model_dump_json(indent=2),
        status_code=200,
        mimetype="application/json",
    )
