"""IISMonitorPoller -- Timer-triggered ADX polling function.

Runs every 60 seconds. Queries the VMPerf and IISPerf ADX tables for threshold
breaches that mirror the original 15 Azure Monitor alert conditions. When a
breach is detected, fires an HTTP POST to IISHealingOrchestratorInternal and
then observes a 10-minute cooldown to prevent duplicate healing runs.

Cooldown state is persisted in Azure Table Storage (healingcooldown table) so
it survives cold starts and is shared across any scale-out instances.

Replaces: Azure Monitor scheduledQueryRules + Action Group webhook.
"""

from __future__ import annotations

import logging
import os
import time
from datetime import datetime, timedelta, timezone
from typing import Optional

import azure.functions as func
import requests
from requests.exceptions import ReadTimeout
from azure.core.exceptions import ResourceExistsError, ResourceNotFoundError
from azure.data.tables import TableServiceClient

logger = logging.getLogger("IISMonitorPoller")

# ---------------------------------------------------------------------------
# Poller state — persisted in Azure Table Storage so it survives cold starts
# and is shared across scale-out instances.
#
# Two pieces of state share one entity row:
#   LastTriggerTime  — epoch seconds of the last heal trigger. Used as a
#                      short cooldown that prevents re-firing while a pipeline
#                      is still running (pipeline-overlap guard).
#   LastCheckpoint   — ISO-8601 UTC timestamp. Watermark used in each KQL
#                      query so that rows older than the checkpoint cannot
#                      re-trigger. Advances each poll.
# ---------------------------------------------------------------------------
_COOLDOWN_TABLE         = "healingcooldown"
_COOLDOWN_PARTITION     = "state"
_COOLDOWN_ROW           = "last_trigger"
COOLDOWN_SECONDS        = 90   # pipeline-overlap guard only (stale-data handled by checkpoint)
_INGESTION_BUFFER_SEC   = 30   # upper-bound of each query = now - this (ADX ingestion lag)
_CHECKPOINT_DEFAULT_SEC = 300  # first-run default: look back 5 minutes


def _get_table_service() -> TableServiceClient:
    conn_str = os.environ.get("AzureWebJobsStorage", "")
    return TableServiceClient.from_connection_string(conn_str)


# Table client cached at module level — created once per worker process lifetime.
# This avoids the POST /Tables on every invocation that produces a noisy 409
# (table already exists) in the log stream.
_table_client = None

def _get_cooldown_client():
    global _table_client
    if _table_client is None:
        svc = _get_table_service()
        svc.create_table_if_not_exists(_COOLDOWN_TABLE)
        _table_client = svc.get_table_client(_COOLDOWN_TABLE)
    return _table_client


def _get_last_trigger_time() -> float:
    try:
        client = _get_cooldown_client()
        entity = client.get_entity(_COOLDOWN_PARTITION, _COOLDOWN_ROW)
        return float(entity.get("LastTriggerTime", 0))
    except ResourceNotFoundError:
        return 0.0
    except Exception as exc:
        logger.warning("Could not read cooldown state: %s", exc)
        return 0.0


def _set_last_trigger_time(timestamp: float) -> None:
    try:
        client = _get_cooldown_client()
        client.upsert_entity({
            "PartitionKey": _COOLDOWN_PARTITION,
            "RowKey":       _COOLDOWN_ROW,
            "LastTriggerTime": str(timestamp),
        })
    except Exception as exc:
        logger.error("Failed to persist cooldown: %s", exc)


def _get_last_checkpoint() -> datetime:
    """Return the watermark timestamp (UTC datetime) to filter ADX rows.

    On first run or on read failure, defaults to now - _CHECKPOINT_DEFAULT_SEC
    so we don't miss an ongoing breach when the function cold-starts.
    """
    try:
        client = _get_cooldown_client()
        entity = client.get_entity(_COOLDOWN_PARTITION, _COOLDOWN_ROW)
        raw    = entity.get("LastCheckpoint")
        if raw:
            return datetime.fromisoformat(str(raw).replace("Z", "+00:00"))
    except ResourceNotFoundError:
        pass
    except Exception as exc:
        logger.warning("Could not read checkpoint: %s", exc)
    return datetime.now(timezone.utc) - timedelta(seconds=_CHECKPOINT_DEFAULT_SEC)


def _set_last_checkpoint(ts: datetime) -> None:
    """Advance the watermark. Upsert is merge-mode so LastTriggerTime is preserved."""
    try:
        client = _get_cooldown_client()
        client.upsert_entity({
            "PartitionKey":   _COOLDOWN_PARTITION,
            "RowKey":         _COOLDOWN_ROW,
            "LastCheckpoint": ts.isoformat().replace("+00:00", "Z"),
        })
    except Exception as exc:
        logger.error("Failed to persist checkpoint: %s", exc)


# ---------------------------------------------------------------------------
# Priority-ordered issue types.
# When multiple conditions breach simultaneously, the first match wins.
# Severity 1 (Critical) → Severity 2 (High) → Severity 3 (Medium)
# ---------------------------------------------------------------------------
_PRIORITY: list[str] = [
    "w3svc_stopped",       # Sev 1 — IIS down
    "site_stopped",        # Sev 1 — site stopped (no bindings or admin stop) — must beat app_pool_stopped because pool fixes are no-ops when the site can't accept traffic
    "app_pool_identity",   # Sev 1 — pool Stopped + identityType=SpecificUser — very specific root-cause signal. Must beat bad_permissions because 500.19 ACCESS_DENIED is a SYMPTOM of bad credentials, not just bad ACLs; routing to FixAppPoolIdentity directly is faster than letting bad_permissions burn retries on FixPermissions first.
    "bad_permissions",     # Sev 1 — IIS 500.19 Win32=5 (ERROR_ACCESS_DENIED) — specific root-cause signal. Must beat app_pool_stopped/app_pool_crash because a broken wwwroot ACL causes the pool to crash on read, and RecycleAppPool/RestartIIS can't fix an ACL; only Invoke-FixPermissions can.
    "app_pool_stopped",    # Sev 1 — rapid-fail protection engaged; pool permanently stopped, 503s being served
    "app_pool_crash",      # Sev 1 — ASP.NET restarts
    "log_disk_full",       # Sev 1 — C: drive critical
    "high_cpu_w3wp",       # Sev 2 — w3wp CPU
    "memory_leak",         # Sev 2 — w3wp working set
    "high_memory",         # Sev 2 — VM memory
    "high_cpu",            # Sev 2 — VM CPU
    "binding_missing",     # Sev 2 — failed connections
    "request_queue_flood", # Sev 2 — ASP.NET queue
    "http_5xx_flood",      # Sev 2 — generic 5xx flood (catch-all when no specific symptom matches); REASONED_WITH_VETO so LLM can escalate for upstream causes
    "high_disk_io",        # Sev 2 — disk queue
    "worker_process_hang", # Sev 3 — w3wp threads
    "bad_http_errors",     # Sev 3 — 404 rate
]

# ---------------------------------------------------------------------------
# KQL — VMPerf breach detection
#
# Uses a 7-minute look-back window.  ADX ingestion batching is capped at 30s
# and Send-PerfToEventHub.ps1 runs every 60s, so data is queryable within
# ~90s of collection.  7 minutes is longer than the 5-minute cooldown period
# so that a breach that fired while the poller was cooling down is still
# visible when the poller comes back online.  (With a 3-minute window, any
# issue that coincides with a cooldown period would be permanently invisible:
# cooldown expires at T+5m, but ago(3m) only reaches back to T+2m.)
# InstanceName == "C:" is explicit on disk-space to avoid false positives
# from other volumes if the script is ever extended.
# ---------------------------------------------------------------------------
_VM_PERF_KQL = """\
let hostname   = '{hostname}';
let checkpoint = datetime({checkpoint});
VMPerf
| where Computer == hostname
| where TimeGenerated >= ago(7m)
// in~ is case-insensitive: Windows PerfMon path strings are lowercased by
// Get-Counter, so counter names land in ADX as e.g. "% processor time".
| where CounterName in~ (
    "% Processor Time",
    "Available MBytes",
    "% Committed Bytes In Use",
    "Pages/sec",
    "% Free Space",
    "Avg. Disk Queue Length",
    "Processor Queue Length"
  )
| summarize
    AvgValue    = avg(CounterValue),
    MaxValue    = max(CounterValue),
    // HighSamples counts how many 10-second samples exceeded 85%.
    // Requires >= 2 to fire, meaning CPU was above 85% for at least ~20 seconds.
    // A single transient 1-second spike produces at most 1 high sample and is
    // ignored.  All other counters use AvgValue/MaxValue; HighSamples is computed
    // for every group but only referenced in the CPU branch below.
    HighSamples = countif(CounterValue > 85),
    RowCount    = count(),
    // MaxTime used by the watermark filter below — ensures we only fire on
    // breaches that include at least one row newer than the checkpoint.
    MaxTime     = max(TimeGenerated)
  by CounterName, ObjectName, InstanceName
| extend
    // =~ is case-insensitive for CounterName/InstanceName (values are lowercase
    // from Get-Counter); ObjectName is set from script hardcoded strings so case
    // is already correct and == is fine there.
    IsBreached = case(
        CounterName =~ "% Processor Time"       and ObjectName == "Processor"   and HighSamples >= 2, true,
        CounterName =~ "Available MBytes"                                         and AvgValue < 512,   true,
        CounterName =~ "% Committed Bytes In Use"                                 and AvgValue > 90,    true,
        CounterName =~ "Pages/sec"              and ObjectName == "Memory"        and AvgValue > 1000,  true,
        CounterName =~ "% Free Space"           and ObjectName == "LogicalDisk"   and InstanceName =~ "C:" and AvgValue < 5, true,
        CounterName =~ "Avg. Disk Queue Length" and ObjectName == "PhysicalDisk"  and AvgValue > 5,     true,
        CounterName =~ "Processor Queue Length" and ObjectName == "System"        and AvgValue > 10,    true,
        false
    ),
    IssueType = case(
        CounterName =~ "% Processor Time"       and ObjectName == "Processor",   "high_cpu",
        CounterName =~ "Available MBytes",                                        "high_memory",
        CounterName =~ "% Committed Bytes In Use",                                "high_memory",
        CounterName =~ "Pages/sec",                                               "high_memory",
        CounterName =~ "% Free Space",                                            "log_disk_full",
        CounterName =~ "Avg. Disk Queue Length",                                  "high_disk_io",
        CounterName =~ "Processor Queue Length",                                  "high_cpu",
        "unknown"
    ),
    Summary = strcat(CounterName, " high_samples=", tostring(HighSamples), " max=", round(MaxValue, 2), " avg=", round(AvgValue, 2))
| where IsBreached and MaxTime > checkpoint
| project IssueType, Summary
"""

# ---------------------------------------------------------------------------
# KQL — IISPerf breach detection
#
# w3wp conditions filter InstanceName startswith "w3wp" to avoid matching
# any other Process counters that may be added in future.
#
# IIS-down check (Current Connections == 0) is combined with a data-presence
# guard: we require at least 3 rows in the 7-min window to distinguish a
# truly idle/down IIS from a startup lag or transient batch gap.
# With a 60s script interval and 7-min window we expect up to 7 rows when
# data is flowing normally, so RowCount >= 3 is still a conservative guard.
#
# App restarts use the same 7-min window for consistency.
# ---------------------------------------------------------------------------
_IIS_PERF_KQL = """\
let hostname   = '{hostname}';
let checkpoint = datetime({checkpoint});
// 7-minute window checks (ADX batching capped at 30s — see VMPerf comment).
// The trend threshold is evaluated over the full 7-min window; the watermark
// (MaxTime > checkpoint) ensures we only fire on breaches that include a row
// newer than the last poll.
let iis3m =
    IISPerf
    | where Computer == hostname and TimeGenerated >= ago(7m)
    | where CounterName in~ (
        "Current Connections",
        "Connection Attempts Failed",
        "Not Found Errors/sec",
        "Requests Queued",
        "% Processor Time",
        "Working Set",
        "Thread Count"
      )
    | summarize
        AvgValue = avg(CounterValue),
        MaxValue = max(CounterValue),
        SumValue = sum(CounterValue),
        RowCount = count(),
        MaxTime  = max(TimeGenerated)
      by CounterName, ObjectName, InstanceName
    | extend
        // =~ for CounterName/InstanceName (lowercased by Get-Counter on Windows).
        // ObjectName is set from script hardcoded strings — correct case, == is fine.
        //
        // EXCEPTION — Current Connections uses == (case-sensitive) intentionally:
        // Real PerfMon data stores this as "current connections" (lowercase).
        // The synthetic heartbeat (injected when W3SVC is stopped) hardcodes
        // "Current Connections" (mixed-case).  Using == here means ONLY the
        // synthetic heartbeat rows match, preventing a false positive when IIS
        // is running but idle (0 real connections).  Changing to =~ would cause
        // every idle IIS server to be misidentified as stopped.
        IsBreached = case(
            // IIS-down: require >=2 synthetic rows (~2 min persistence), matching
            // site_stopped's threshold so both detectors reach their bar on the same
            // poll when w3svc is stopped. Priority rank 1 (w3svc_stopped) then wins
            // cleanly over rank 2 (site_stopped), routing directly to Invoke-RestartW3SVC
            // instead of burning an Invoke-FixBindings attempt + retry. Case-sensitive
            // `==` above already limits matches to synthetic rows only, so there is no
            // risk of an idle-but-running IIS server producing a false positive here.
            CounterName == "Current Connections" and ObjectName == "Web Service"
                and MaxValue == 0 and RowCount >= 2,                              true,
            CounterName =~ "Connection Attempts Failed"
                and SumValue > 50,                                                true,
            CounterName =~ "Not Found Errors/sec"
                and AvgValue > 20,                                                true,
            CounterName =~ "Requests Queued"    and ObjectName == "ASP.NET"
                and AvgValue > 100,                                               true,
            // w3wp: filter InstanceName to avoid matching non-w3wp processes
            CounterName =~ "% Processor Time"   and ObjectName == "Process"
                and InstanceName startswith "w3wp" and AvgValue > 80,            true,
            CounterName =~ "Working Set"         and ObjectName == "Process"
                and InstanceName startswith "w3wp" and AvgValue > 1610612736,    true,
            CounterName =~ "Thread Count"        and ObjectName == "Process"
                and InstanceName startswith "w3wp" and AvgValue > 200,           true,
            false
        ),
        IssueType = case(
            CounterName == "Current Connections",       "w3svc_stopped",   // == intentional — see IsBreached comment
            CounterName =~ "Connection Attempts Failed","binding_missing",
            CounterName =~ "Not Found Errors/sec",      "bad_http_errors",
            CounterName =~ "Requests Queued",           "request_queue_flood",
            CounterName =~ "% Processor Time",          "high_cpu_w3wp",
            CounterName =~ "Working Set",               "memory_leak",
            CounterName =~ "Thread Count",              "worker_process_hang",
            "unknown"
        ),
        Summary = strcat(CounterName, " value=", round(AvgValue, 2))
    | where IsBreached and MaxTime > checkpoint
    | project IssueType, Summary;
// 7-minute window — ASP.NET Application Restarts
// "Application Restarts" is a monotonically-increasing running-total counter:
// once w3wp has restarted N times, every subsequent 60 s PerfMon sample reports
// CounterValue=N until w3wp itself restarts (which resets it to 0).  Summing
// the value across samples therefore produces a number proportional to (N *
// sample count), not the number of restarts in the window -- a stable pool
// that restarted 3 times 5 minutes ago will report sum ~= 21 and trip the
// > 2 threshold for the full 7-min rolling window.
//
// Using (max - min) measures the DELTA within the window instead: the number
// of restarts that actually happened between the earliest and latest samples.
// Stable pool (counter constant) -> delta=0.  Three fresh restarts -> delta=3.
// Edge case: if w3wp itself restarts mid-window (counter resets to 0), max-min
// equals the pre-reset peak, which can over-count.  That's acceptable -- the
// pool did in fact bounce recently, and Invoke-RecycleAppPool is still correct.
//
// Threshold is >= 5, matching IIS's own rapid-fail definition (5 crashes
// in 5 min triggers rapid-fail protection).  Lower thresholds false-fire on
// benign AppDomain churn: editing applicationHost.config (binding changes,
// new web app deployed, new site added) triggers AppDomain recycles that
// increment this counter by 1-2 per event.  Those are NOT crash loops and
// we don't want the pipeline burning ~5 min on RecycleAppPool/RestartIIS
// retries just because an operator tweaked a binding.
let app_restarts =
    IISPerf
    | where Computer == hostname and TimeGenerated >= ago(7m)
    | where CounterName =~ "Application Restarts" and ObjectName == "ASP.NET"
    | summarize
        RestartDelta = max(CounterValue) - min(CounterValue),
        MaxTime      = max(TimeGenerated)
    | where RestartDelta >= 5 and MaxTime > checkpoint
    | project
        IssueType = "app_pool_crash",
        Summary   = strcat("Application Restarts delta=", tostring(toint(RestartDelta)), " in last 7m");
// 7-minute window — Site stopped (synthetic row from Send-PerfToEventHub.ps1).
// Counter "Site State" is unique to that script — it does not exist in real
// PerfMon — so == match is unambiguous. RowCount >= 2 requires the stopped
// state to persist across at least 2 polls (~2 minutes), filtering transient
// states during graceful site restarts.
let site_stopped =
    IISPerf
    | where Computer == hostname and TimeGenerated >= ago(7m)
    | where CounterName == "Site State" and ObjectName == "Web Service" and CounterValue == 0
    | summarize
        StoppedSites = make_set(InstanceName),
        RowCount     = count(),
        MaxTime      = max(TimeGenerated)
    | where RowCount >= 2 and MaxTime > checkpoint
    | project
        IssueType = "site_stopped",
        Summary   = strcat("Site(s) in Stopped state: ", tostring(StoppedSites), " (", tostring(RowCount), " polls)");
// 7-minute window — Pool identity-status synthetic row (Send-PerfToEventHub.ps1).
// The script emits Pool Identity Status=0 ONLY for pools that are both
// non-Started AND configured with identityType=SpecificUser (bad/stale custom
// credentials being the dominant cause of pool-start failure in production).
// RowCount >= 1 — this signal combination is already so specific that one
// sample is high-confidence:  production pools that legitimately run under
// SpecificUser stay Started, so non-Started + SpecificUser together is
// effectively a root-cause fingerprint.  The threshold used to be >= 2 to
// filter brief Starting/Stopping transitions, but those are sub-second and
// almost never land on a 60-s sampling boundary, while app_pool_stopped
// (threshold >= 3 AppOffline rows) can fire on the very first poll after
// rapid-fail engages — racing this detector and winning via the
// higher-volume-but-symptom-class HTTPERR signal.  Routing directly to
// Invoke-FixAppPoolIdentity on the first sample skips the RecycleAppPool
// / RestartIIS / FixPermissions retries that would otherwise burn ~3-5 min
// chasing the symptom.
let pool_identity =
    IISPerf
    | where Computer == hostname and TimeGenerated >= ago(7m)
    | where CounterName == "Pool Identity Status"
      and ObjectName == "Web Service Application Pool"
      and CounterValue == 0
    | summarize
        AffectedPools = make_set(InstanceName),
        RowCount      = count(),
        MaxTime       = max(TimeGenerated)
    | where RowCount >= 1 and MaxTime > checkpoint
    | project
        IssueType = "app_pool_identity",
        Summary   = strcat("App pool(s) stopped with SpecificUser identity: ", tostring(AffectedPools), " (", tostring(RowCount), " polls) — bad credentials likely");
union iis3m, app_restarts, site_stopped, pool_identity
"""


# ---------------------------------------------------------------------------
# KQL — IISHttpErrors breach detection
#
# IISHttpErrors is populated from HTTP.sys HTTPERR log entries via an ADX
# update policy (Send-PerfToEventHub.ps1 tails the HTTPERR log alongside
# the W3C access log).  When IIS rapid-fail protection permanently stops an
# app pool after 5 crashes in 5 minutes, HTTP.sys serves every subsequent
# request with a 503 Reason='AppOffline'.  At that point:
#   - The IISPerf "Application Restarts" counter stops incrementing (no more
#     restarts can occur) so app_pool_crash detection goes silent after 10m.
#   - IISHttpErrors AppOffline rows continue accumulating — the only live
#     signal that the pool is stuck stopped and users are seeing 503s.
#
# Threshold: >= 3 AppOffline rows in 7 minutes.  A single stray AppOffline
# can appear during a normal graceful recycle; 3+ in 7 minutes means no
# new worker process started — rapid-fail protection is engaged.
# ---------------------------------------------------------------------------
_HTTP_ERR_KQL = """\
let hostname   = '{hostname}';
let checkpoint = datetime({checkpoint});
// HTTP.sys 503 reasons we treat as "pool stopped, users seeing 503s":
//   AppOffline     — rapid-fail protection stopped the pool (5 crashes / 5m)
//   Disabled       — app pool manually stopped / disabled by an operator
//   AppPoolStopped — same outcome, different HTTP.sys wording
// All three are fixed by the same runbook (Invoke-RecycleAppPool -> Start-WebAppPool).
// Graceful-recycle reasons like AppShutdown are intentionally excluded.
IISHttpErrors
| where Computer == hostname
| where TimeGenerated >= ago(7m)
| where StatusCode == 503 and Reason in ("AppOffline", "Disabled", "AppPoolStopped")
| summarize
    RowCount   = count(),
    Reasons    = make_set(Reason),
    MaxTime    = max(TimeGenerated)
| where RowCount >= 3 and MaxTime > checkpoint
| project
    IssueType = "app_pool_stopped",
    Summary   = strcat("IISHttpErrors 503 count=", tostring(RowCount), " reasons=", tostring(Reasons), " in last 7m — app pool is stopped")
"""


# ---------------------------------------------------------------------------
# KQL — IISLogsParsed breach detection (5xx responses)
#
# Two signals are derived from the same table:
#
# 1) bad_permissions — specific 500.19 Win32Status=5 rows.
#    sc-status 500 / sc-substatus 19 = "Internal Server Error - config data
#    invalid".  Win32Status 5 = ERROR_ACCESS_DENIED.  Together that combination
#    means IIS's worker process could not read web.config (or another required
#    file) because of an ACL problem — exactly the state the bad_permissions
#    chaos scenario produces.  Routing this to 'bad_permissions' (mechanical
#    strategy, Invoke-FixPermissions) is a direct symptom→fix mapping, no LLM
#    reasoning required.  Threshold 3 in 7 min — anything more than a single
#    stray 500.19 is not a transient.
#
# 2) http_5xx_flood — catch-all for any other 5xx burst.
#    Higher threshold (>=10) because generic 5xx rates can be noisy; this
#    feeds the REASONED_WITH_VETO profile so the LLM can distinguish "fix
#    locally" from "upstream cause, escalate_only".  Intentionally EXCLUDES
#    the 500.19/Win32=5 rows the bad_permissions detector claims — otherwise
#    both detectors fire for the same event and only priority ordering
#    prevents the wrong one from winning.  Belt-and-suspenders.
# ---------------------------------------------------------------------------
_IIS_LOGS_KQL = """\
let hostname   = '{hostname}';
let checkpoint = datetime({checkpoint});
let bad_perms =
    IISLogsParsed
    | where Computer == hostname and TimeGenerated >= ago(7m)
    | where StatusCode == 500 and SubStatus == 19 and Win32Status == 5
    | summarize
        RowCount = count(),
        MaxTime  = max(TimeGenerated)
    | where RowCount >= 3 and MaxTime > checkpoint
    | project
        IssueType = "bad_permissions",
        Summary   = strcat("IIS 500.19 Win32=5 (ACCESS_DENIED) count=", tostring(RowCount), " in last 7m — wwwroot ACL broken");
let five_xx_flood =
    IISLogsParsed
    | where Computer == hostname and TimeGenerated >= ago(7m)
    | where StatusCode >= 500 and StatusCode < 600
    // Exclude the rows claimed by bad_perms so the two detectors never
    // both fire on the same underlying event.
    | where not(StatusCode == 500 and SubStatus == 19 and Win32Status == 5)
    | summarize
        RowCount    = count(),
        StatusCodes = make_set(StatusCode),
        MaxTime     = max(TimeGenerated)
    | where RowCount >= 10 and MaxTime > checkpoint
    | project
        IssueType = "http_5xx_flood",
        Summary   = strcat("IIS 5xx flood count=", tostring(RowCount), " codes=", tostring(StatusCodes), " in last 7m");
union bad_perms, five_xx_flood
"""


def _query_breaches(kql: str) -> list[dict]:
    """Execute KQL and return breach rows. Returns [] on error."""
    from tools.adx_client import query_adx
    try:
        return query_adx(kql)
    except Exception as exc:
        logger.error("ADX query failed: %s", exc)
        return []


def _check_data_present(hostname: str) -> bool:
    """Return True if VMPerf or IISPerf contain any rows for this host in the last 15 minutes.

    Used to distinguish "pipeline is down" (genuinely 0 rows) from "pipeline is
    healthy but no thresholds are currently breached" (breach queries return 0
    rows because everything is within normal limits).
    15-minute window gives ample headroom over the 7-minute breach-detection
    window and the 5-minute cooldown.
    """
    from tools.adx_client import query_adx
    kql = f"""\
let hostname = '{hostname}';
union
    (VMPerf  | where Computer == hostname and TimeGenerated >= ago(15m) | count | project n=Count),
    (IISPerf | where Computer == hostname and TimeGenerated >= ago(15m) | count | project n=Count)
| summarize total=sum(n)
| project HasData=(total > 0)
"""
    try:
        rows = query_adx(kql)
        return bool(rows[0].get("HasData", False)) if rows else False
    except Exception as exc:
        logger.warning("Data-presence check failed: %s", exc)
        return False  # treat as unknown — caller will not warn falsely


def _pick_top_breach(breaches: list[dict]) -> Optional[dict]:
    """Return the highest-priority breach from the combined results."""
    breach_map = {b["IssueType"]: b for b in breaches}
    for issue_type in _PRIORITY:
        if issue_type in breach_map:
            return breach_map[issue_type]
    return breaches[0] if breaches else None


def _trigger_healing(issue_type: str, issue_summary: str) -> None:
    """POST to IISHealingOrchestratorInternal on the same Function App."""
    hostname = os.environ.get("WEBSITE_HOSTNAME", "localhost:7071")
    scheme   = "https" if "localhost" not in hostname else "http"
    url      = f"{scheme}://{hostname}/api/IISHealingOrchestratorInternal"

    logger.info("Triggering healing — issue_type=%s url=%s", issue_type, url)
    try:
        resp = requests.post(
            url,
            json={"issue_type": issue_type, "issue_summary": issue_summary},
            timeout=10,
        )
        logger.info("Healing trigger response: HTTP %s", resp.status_code)
    except ReadTimeout:
        # Expected — the healing pipeline runs for several minutes. The 10-second
        # read timeout fires before the orchestrator responds, but the request was
        # received and processing has started.
        logger.info("Healing triggered — orchestrator is running (read timeout expected).")
    except requests.RequestException as exc:
        logger.error("Failed to trigger healing: %s", exc)


def main(timer: func.TimerRequest) -> None:
    """Timer trigger entry point — fires every 60 seconds."""
    if timer.past_due:
        logger.warning("Timer is past due — skipping this cycle.")
        return

    hostname = os.environ.get("VM_HOSTNAME", "")
    if not hostname:
        logger.error("VM_HOSTNAME env var not set — cannot poll.")
        return

    # ── Cooldown check (pipeline-overlap guard — prevents re-firing while a
    # pipeline is still in flight. Stale-data suppression is handled by the
    # watermark filter in each KQL, not by this cooldown). ─────────────────
    last_trigger = _get_last_trigger_time()
    elapsed      = time.time() - last_trigger
    if elapsed < COOLDOWN_SECONDS:
        logger.info(
            "Cooldown active — %.0fs remaining, skipping poll.",
            COOLDOWN_SECONDS - elapsed,
        )
        return

    # ── Watermark: read checkpoint, compute upper bound with ingestion lag ──
    # Query window is (checkpoint, upper_bound]. The -30s upper bound leaves
    # a buffer for rows still being ingested; on the next poll those rows
    # will fall inside the new window and be evaluated then.
    now_utc        = datetime.now(timezone.utc)
    upper_bound    = now_utc - timedelta(seconds=_INGESTION_BUFFER_SEC)
    checkpoint     = _get_last_checkpoint()
    checkpoint_kql = checkpoint.isoformat().replace("+00:00", "Z")
    logger.info("Watermark: checkpoint=%s upper_bound=%s", checkpoint_kql, upper_bound.isoformat())

    # ── Query ADX ─────────────────────────────────────────────────────────
    vm_breaches       = _query_breaches(_VM_PERF_KQL.format(hostname=hostname, checkpoint=checkpoint_kql))
    iis_breaches      = _query_breaches(_IIS_PERF_KQL.format(hostname=hostname, checkpoint=checkpoint_kql))
    http_err_breaches = _query_breaches(_HTTP_ERR_KQL.format(hostname=hostname, checkpoint=checkpoint_kql))
    iis_logs_breaches = _query_breaches(_IIS_LOGS_KQL.format(hostname=hostname, checkpoint=checkpoint_kql))
    all_breaches      = vm_breaches + iis_breaches + http_err_breaches + iis_logs_breaches

    # Advance the watermark regardless of whether we triggered. Next poll
    # will only see rows with TimeGenerated > upper_bound.
    _set_last_checkpoint(upper_bound)

    if not all_breaches:
        # Both breach queries returned 0 rows.  This is the NORMAL outcome when
        # the VM is healthy — the breach-detection KQL only emits rows for
        # counters that exceed their thresholds, so a healthy host always returns
        # nothing.  Only warn if a separate data-presence check also finds no
        # rows, which means the pipeline itself is down (Event Hub → ADX stopped,
        # Send-PerfToEventHub.ps1 not running, ADX data connection broken, etc.).
        if not _check_data_present(hostname):
            logger.warning(
                "No data found in VMPerf or IISPerf for host '%s' in the last 15 minutes. "
                "Send-PerfToEventHub.ps1 may not be running or the ADX data connection "
                "may be broken.",
                hostname,
            )
        else:
            logger.info(
                "Poll complete — metrics are within normal thresholds for host '%s'. "
                "No healing action required.",
                hostname,
            )
        return

    logger.info(
        "Breaches detected: %s",
        [b.get("IssueType") for b in all_breaches],
    )

    top          = _pick_top_breach(all_breaches)
    issue_type   = top.get("IssueType", "unknown")
    issue_summary = top.get("Summary", issue_type)

    # ── Persist cooldown before triggering to block concurrent polls ───────
    _set_last_trigger_time(time.time())

    _trigger_healing(issue_type, issue_summary)
