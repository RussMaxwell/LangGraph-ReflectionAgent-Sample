"""Azure VM and HTTP health-check client using DefaultAzureCredential."""

import os
import time
from typing import Dict, Any

import urllib.request
import urllib.error

from azure.identity import DefaultAzureCredential
from azure.mgmt.compute import ComputeManagementClient


def _get_client() -> ComputeManagementClient:
    resource_id = os.environ.get("AUTOMATION_ACCOUNT_RESOURCE_ID", "")
    subscription_id = resource_id.split("/")[2] if resource_id else os.environ["AZURE_SUBSCRIPTION_ID"]
    return ComputeManagementClient(
        credential=DefaultAzureCredential(),
        subscription_id=subscription_id,
    )


def _get_resource_group() -> str:
    return os.environ["RESOURCE_GROUP_NAME"]


def get_vm_status(vm_name: str) -> str:
    """Return the power state of an Azure VM.

    Args:
        vm_name: The name of the virtual machine.

    Returns:
        The power state display string (e.g. "VM running", "VM deallocated"),
        or "Unknown" if the power state cannot be determined.
    """
    client = _get_client()
    instance_view = client.virtual_machines.instance_view(
        resource_group_name=_get_resource_group(),
        vm_name=vm_name,
    )
    for status in instance_view.statuses:
        if status.code and status.code.startswith("PowerState/"):
            return status.display_status or status.code
    return "Unknown"


def check_http_health(
    hostname: str,
    port: int = 80,
    path: str = "/default.aspx",
) -> Dict[str, Any]:
    """Perform an HTTP GET health check against a host.

    Args:
        hostname: The hostname or IP address to check.
        port: The TCP port (default 80).
        path: The URL path (default /default.aspx).

    Returns:
        A dict with keys:
            - status_code: HTTP status code (0 if connection failed).
            - response_time_ms: Round-trip time in milliseconds.
            - is_healthy: True if status code is 200.
    """
    scheme = "https" if port == 443 else "http"
    url = f"{scheme}://{hostname}:{port}{path}"

    start = time.perf_counter()
    try:
        req = urllib.request.Request(url, method="GET")
        with urllib.request.urlopen(req, timeout=10) as resp:
            status_code = resp.status
    except urllib.error.HTTPError as exc:
        status_code = exc.code
    except (urllib.error.URLError, OSError):
        status_code = 0
    elapsed_ms = round((time.perf_counter() - start) * 1000, 2)

    return {
        "status_code": status_code,
        "response_time_ms": elapsed_ms,
        "is_healthy": status_code == 200,
    }
