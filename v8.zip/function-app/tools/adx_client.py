"""Azure Data Explorer (ADX/Kusto) query client using DefaultAzureCredential.

Handles all ADX queries:
  IISLogsParsed        — Parsed W3C fields (auto-populated from IISLogs via update policy)
  IISLogs              — Raw W3C log lines (staging table, prefer IISLogsParsed)
  VMPerf               — VM performance counters ingested via Send-PerfToEventHub.ps1
  IISPerf              — IIS/ASP.NET counters ingested via Send-PerfToEventHub.ps1
  PerformanceBaseline  — Baseline snapshots + summary ingested via Invoke-CaptureBaseline → Event Hub → ADX
"""

import os
from datetime import timedelta
from typing import Any, Dict, List, Optional

from azure.identity import DefaultAzureCredential
from azure.kusto.data import KustoClient, KustoConnectionStringBuilder, ClientRequestProperties


def _get_client() -> KustoClient:
    cluster_uri = os.environ["ADX_CLUSTER_URI"]
    kcsb = KustoConnectionStringBuilder.with_azure_token_credential(
        cluster_uri,
        DefaultAzureCredential(),
    )
    return KustoClient(kcsb)


def _get_database() -> str:
    return os.environ["ADX_DATABASE"]


def query_adx(kql: str) -> List[Dict[str, Any]]:
    """Execute an arbitrary KQL query against the ADX database.

    Args:
        kql: KQL query string.

    Returns:
        List of rows, each as a dict mapping column name to value.
    """
    client   = _get_client()
    database = _get_database()

    props = ClientRequestProperties()
    props.set_option(
        ClientRequestProperties.request_timeout_option_name,
        timedelta(seconds=30),
    )

    response = client.execute(database, kql, properties=props)

    rows: List[Dict[str, Any]] = []
    for result_table in response.primary_results:
        for row in result_table:
            rows.append(
                {col.column_name: row[col.column_name] for col in result_table.columns}
            )
    return rows


def query_iis_logs(hostname: str, minutes: int = 30) -> List[Dict[str, Any]]:
    """Query the IISLogsParsed ADX table for a specific host.

    Returns pre-parsed W3C log fields (Method, UriStem, StatusCode,
    TimeTakenMs, ClientIP, UserAgent, etc.) from the IISLogsParsed table,
    which is auto-populated from IISLogs via an ADX update policy.

    Args:
        hostname: The VM Computer name to filter on.
        minutes: How many minutes of data to retrieve (default 30).

    Returns:
        List of parsed IIS log rows ordered newest-first.
    """
    kql = f"""
IISLogsParsed
| where Computer == '{hostname}'
| where TimeGenerated >= ago({minutes}m)
| order by TimeGenerated desc
"""
    return query_adx(kql)


def query_vm_perf(hostname: str, minutes: int = 30) -> List[Dict[str, Any]]:
    """Query the VMPerf ADX table for a specific host.

    Columns: TimeGenerated, Computer, ObjectName, CounterName, InstanceName, CounterValue
    Populated by Send-PerfToEventHub.ps1 running as a scheduled task on the VM.

    Args:
        hostname: The VM Computer name to filter on.
        minutes: How many minutes of data to retrieve (default 30).

    Returns:
        List of VM performance metric rows ordered newest-first.
    """
    kql = f"""
VMPerf
| where Computer == '{hostname}'
| where TimeGenerated >= ago({minutes}m)
| order by TimeGenerated desc
"""
    return query_adx(kql)


def query_iis_perf(hostname: str, minutes: int = 30) -> List[Dict[str, Any]]:
    """Query the IISPerf ADX table for a specific host.

    Columns: TimeGenerated, Computer, ObjectName, CounterName, InstanceName, CounterValue
    Populated by Send-PerfToEventHub.ps1 running as a scheduled task on the VM.

    Args:
        hostname: The VM Computer name to filter on.
        minutes: How many minutes of data to retrieve (default 30).

    Returns:
        List of IIS performance metric rows ordered newest-first.
    """
    kql = f"""
IISPerf
| where Computer == '{hostname}'
| where TimeGenerated >= ago({minutes}m)
| order by TimeGenerated desc
"""
    return query_adx(kql)


def query_latest_counter(
    table: str, hostname: str, counter_name: str
) -> Optional[float]:
    """Return the most recent CounterValue for a given counter from VMPerf or IISPerf.

    Args:
        table: "VMPerf" or "IISPerf".
        hostname: The VM Computer name.
        counter_name: The CounterName value to look up.

    Returns:
        The most recent CounterValue as a float, or None if no data found.
    """
    kql = f"""
{table}
| where Computer == '{hostname}'
| where CounterName == '{counter_name}'
| order by TimeGenerated desc
| take 1
| project CounterValue
"""
    rows = query_adx(kql)
    if rows:
        val = rows[0].get("CounterValue")
        return float(val) if val is not None else None
    return None


def query_baseline_summary(hostname: str) -> List[Dict[str, Any]]:
    """Return the most recent baseline summary from the PerformanceBaseline ADX table.

    Returns one row per summary metric (MetricName/MetricValue) from the latest
    capture run, identified by the most recent CaptureId with RecordType='Summary'.

    Args:
        hostname: The VM Computer name to filter on.

    Returns:
        List of summary metric rows ordered by MetricName.
    """
    kql = f"""
let latest_capture = toscalar(
    PerformanceBaseline
    | where Computer == '{hostname}'
    | where RecordType == 'Summary'
    | summarize arg_max(TimeGenerated, CaptureId)
    | project CaptureId
);
PerformanceBaseline
| where CaptureId == latest_capture
| where RecordType == 'Summary'
| project MetricName, MetricValue
| order by MetricName asc
"""
    return query_adx(kql)


def query_baseline_snapshots(
    hostname: str, capture_id: Optional[str] = None, minutes: int = 120
) -> List[Dict[str, Any]]:
    """Return baseline counter snapshots from the PerformanceBaseline ADX table.

    If capture_id is provided, returns all snapshots for that capture run.
    Otherwise returns snapshots from the last N minutes.

    Args:
        hostname: The VM Computer name to filter on.
        capture_id: Optional CaptureId to filter a specific baseline run.
        minutes: How many minutes of data to retrieve if no capture_id (default 120).

    Returns:
        List of snapshot rows ordered by WindowIndex, then MetricName.
    """
    if capture_id:
        kql = f"""
PerformanceBaseline
| where Computer == '{hostname}'
| where CaptureId == '{capture_id}'
| where RecordType == 'Snapshot'
| order by WindowIndex asc, MetricName asc
"""
    else:
        kql = f"""
PerformanceBaseline
| where Computer == '{hostname}'
| where RecordType == 'Snapshot'
| where TimeGenerated >= ago({minutes}m)
| order by TimeGenerated desc, MetricName asc
"""
    return query_adx(kql)
