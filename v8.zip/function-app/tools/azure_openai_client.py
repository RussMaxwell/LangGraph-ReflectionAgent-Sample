import os
from langchain_openai import AzureChatOpenAI
from azure.identity import DefaultAzureCredential, get_bearer_token_provider

def _get_token_provider():
    return get_bearer_token_provider(
        DefaultAzureCredential(),
        "https://cognitiveservices.azure.com/.default"
    )

def get_reasoning_llm() -> AzureChatOpenAI:
    """Tier 1 — o4-mini medium reasoning. Used by analyze_agent (deep RCA)."""
    return AzureChatOpenAI(
        azure_deployment=os.environ["AZURE_OPENAI_O4_MINI_DEPLOYMENT"],
        azure_endpoint=os.environ["AZURE_OPENAI_ENDPOINT"],
        azure_ad_token_provider=_get_token_provider(),
        api_version="2024-12-01-preview",
        model_kwargs={"reasoning_effort": "medium"},
        temperature=1,
        max_tokens=4096,
    )

def get_fast_llm() -> AzureChatOpenAI:
    """Tier 2 — gpt-4o-mini. Used by judge_agent for REASONED / REASONED_WITH_VETO strategies."""
    return AzureChatOpenAI(
        azure_deployment=os.environ["AZURE_OPENAI_GPT4O_MINI_DEPLOYMENT"],
        azure_endpoint=os.environ["AZURE_OPENAI_ENDPOINT"],
        azure_ad_token_provider=_get_token_provider(),
        api_version="2024-12-01-preview",
        temperature=0,
        max_tokens=2048,
    )
