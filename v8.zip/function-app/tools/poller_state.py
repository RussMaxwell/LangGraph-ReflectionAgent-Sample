"""Shared Table Storage helpers for IISMonitorPoller's cooldown/checkpoint.

The poller writes `LastCheckpoint` during every poll cycle to mark how far
it has consumed the breach-detection KQL windows (see IISMonitorPoller/
__init__.py:_set_last_checkpoint).  The orchestrator writes to the same
key *after* a pipeline completes with IsHealthy=True, advancing the
checkpoint past any residual breach rows that were generated between
the poll that fired the heal and the heal actually landing.

Without this, rows produced during the ~30-90 s healing window would be
newer than the poll's checkpoint (which was advanced to `now - 30 s`
before the pipeline even started), and the next poll would fire the same
detector again even though the system is already healthy.
"""
from __future__ import annotations

import logging
import os
from datetime import datetime, timedelta, timezone

from azure.data.tables import TableServiceClient

logger = logging.getLogger("poller_state")

_COOLDOWN_TABLE     = "healingcooldown"
_COOLDOWN_PARTITION = "state"
_COOLDOWN_ROW       = "last_trigger"

_client = None


def _get_client():
    global _client
    if _client is None:
        conn = os.environ.get("AzureWebJobsStorage", "")
        svc  = TableServiceClient.from_connection_string(conn)
        svc.create_table_if_not_exists(_COOLDOWN_TABLE)
        _client = svc.get_table_client(_COOLDOWN_TABLE)
    return _client


_POST_HEAL_SAFETY_BUFFER_SEC = 60


def advance_checkpoint_to_now() -> None:
    """Write LastCheckpoint = now + safety buffer to the cooldown table.

    The buffer (60 s) absorbs two sources of residual breach rows that would
    otherwise refire the detector on the next poll even though the system
    is already healthy:

    1.  ADX ingestion lag (~30 s) can surface breach rows with
        TimeGenerated values slightly after the moment we wrote the
        checkpoint, so a bare `now` checkpoint isn't strictly in the future
        of every incoming row.
    2.  Real "tail" traffic: in-flight requests, IIS module-load failure
        caches, and http.sys kernel cache can continue producing 5xx/500.19
        responses for a few seconds after the runbook actually fixes the
        root cause.

    Tradeoff: a genuinely new breach that strikes within the 60 s window
    after a successful heal is silently skipped for one poll cycle
    (detected ~90 s later instead of ~30 s).  Acceptable — the system just
    finished healing; consecutive fresh breaches are rare enough that the
    extra poll cycle of latency is cheap insurance against repeated
    no-op runbook runs.

    Upsert is merge-mode, so LastTriggerTime is preserved.
    """
    try:
        future_ts = datetime.now(timezone.utc) + timedelta(seconds=_POST_HEAL_SAFETY_BUFFER_SEC)
        ts = future_ts.isoformat().replace("+00:00", "Z")
        _get_client().upsert_entity({
            "PartitionKey":   _COOLDOWN_PARTITION,
            "RowKey":         _COOLDOWN_ROW,
            "LastCheckpoint": ts,
        })
        logger.info(
            "Advanced poller checkpoint to %s (now + %ds buffer) after successful heal.",
            ts, _POST_HEAL_SAFETY_BUFFER_SEC,
        )
    except Exception as exc:
        logger.warning("Failed to advance checkpoint: %s", exc)
