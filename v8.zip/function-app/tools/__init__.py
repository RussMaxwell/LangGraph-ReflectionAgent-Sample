"""Tool modules for the IIS auto-healing function app."""

from tools.azure_openai_client import get_reasoning_llm, get_fast_llm
from tools.law_client import query_law
from tools.adx_client import (
    query_adx,
    query_iis_logs,
    query_vm_perf,
    query_iis_perf,
    query_latest_counter,
    query_baseline_summary,
    query_baseline_snapshots,
)
from tools.law_ingestion_client import write_agent_event, write_agent_error
from tools.automation_client import start_runbook
from tools.vm_client import get_vm_status, check_http_health
from tools.baseline_client import get_latest_baseline

__all__ = [
    "get_reasoning_llm",
    "get_fast_llm",
    "query_law",
    "query_adx",
    "query_iis_logs",
    "query_vm_perf",
    "query_iis_perf",
    "query_latest_counter",
    "query_baseline_summary",
    "query_baseline_snapshots",
    "write_agent_event",
    "write_agent_error",
    "start_runbook",
    "get_vm_status",
    "check_http_health",
    "get_latest_baseline",
]
