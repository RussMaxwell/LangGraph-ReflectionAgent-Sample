"""Client for retrieving performance baseline data from ADX (PerformanceBaseline table)."""

import logging
from typing import Optional

from models.baseline_summary import BaselineSummary
from tools.adx_client import query_adx

logger = logging.getLogger("baseline_client")


def get_latest_baseline(hostname: str) -> Optional[BaselineSummary]:
    """Retrieve the most recent baseline for a given VM hostname.

    Queries the PerformanceBaseline table in ADX, finds the latest capture run,
    and aggregates the per-window Snapshot rows into summary statistics.

    Args:
        hostname: The VM hostname (Computer) to look up.

    Returns:
        A BaselineSummary Pydantic model if baseline data is found, otherwise None.
    """
    kql = f"""
let latest_capture = toscalar(
    PerformanceBaseline
    | where Computer == '{hostname}'
    | where RecordType == 'Snapshot'
    | summarize arg_max(TimeGenerated, CaptureId)
    | project CaptureId
);
PerformanceBaseline
| where CaptureId == latest_capture
| where RecordType == 'Snapshot'
| summarize
    avg_val = avg(MetricValue),
    max_val = max(MetricValue),
    min_val = min(MetricValue),
    p50_val = percentile(MetricValue, 50),
    p95_val = percentile(MetricValue, 95),
    p99_val = percentile(MetricValue, 99),
    captured_at = max(TimeGenerated)
    by MetricName
"""

    try:
        rows = query_adx(kql)
    except Exception as exc:
        logger.warning("ADX baseline query failed: %s", exc)
        return None

    if not rows:
        return None

    # Build a lookup: MetricName -> {avg_val, max_val, min_val, p50_val, p95_val, p99_val}
    metrics = {row["MetricName"]: row for row in rows}

    def avg(name: str) -> Optional[float]:
        m = metrics.get(name)
        return float(m["avg_val"]) if m and m.get("avg_val") is not None else None

    def mx(name: str) -> Optional[float]:
        m = metrics.get(name)
        return float(m["max_val"]) if m and m.get("max_val") is not None else None

    def mn(name: str) -> Optional[float]:
        m = metrics.get(name)
        return float(m["min_val"]) if m and m.get("min_val") is not None else None

    def p95(name: str) -> Optional[float]:
        m = metrics.get(name)
        return float(m["p95_val"]) if m and m.get("p95_val") is not None else None

    captured_at = rows[0].get("captured_at") if rows else None

    return BaselineSummary(
        avg_cpu_percent=avg("CpuPercent"),
        max_cpu_percent=mx("CpuPercent"),
        p95_cpu_percent=p95("CpuPercent"),
        avg_w3wp_cpu_percent=avg("W3wpCpuPercent"),
        max_w3wp_cpu_percent=mx("W3wpCpuPercent"),
        avg_w3wp_working_set_mb=avg("W3wpWorkingSetBytes"),
        max_w3wp_working_set_mb=mx("W3wpWorkingSetBytes"),
        avg_memory_available_mb=avg("MemoryAvailableMB"),
        min_memory_available_mb=mn("MemoryAvailableMB"),
        avg_requests_per_sec=avg("IISGetRequestsPerSec"),
        avg_requests_queued=avg("AspNetRequestsQueued"),
        baseline_captured_at=captured_at,
        vm_hostname=hostname,
    )
