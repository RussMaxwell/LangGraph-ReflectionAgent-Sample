"""Azure Automation runbook client using DefaultAzureCredential."""

import os
import time
import uuid
from typing import Dict, Any

from azure.identity import DefaultAzureCredential
from azure.mgmt.automation import AutomationClient


_HYBRID_WORKER_GROUP = os.environ.get("HYBRID_WORKER_GROUP_NAME", "IIS-HybridWorkers")
_POLL_INTERVAL_SECONDS = 10
_MAX_WAIT_SECONDS = 300  # 5 minutes

_TERMINAL_STATUSES = frozenset({
    "Completed",
    "Failed",
    "Stopped",
    "Suspended",
})


def _get_client() -> AutomationClient:
    resource_id = os.environ["AUTOMATION_ACCOUNT_RESOURCE_ID"]
    # Resource ID format: /subscriptions/{sub}/resourceGroups/{rg}/providers/...
    subscription_id = resource_id.split("/")[2]
    return AutomationClient(
        credential=DefaultAzureCredential(),
        subscription_id=subscription_id,
    )


def _get_resource_group() -> str:
    return os.environ["AUTOMATION_RESOURCE_GROUP_NAME"]


def _get_account_name() -> str:
    return os.environ["AUTOMATION_ACCOUNT_NAME"]


def start_runbook(runbook_name: str, parameters: Dict[str, str]) -> Dict[str, Any]:
    """Start an Azure Automation runbook on the Hybrid Worker Group and wait for completion.

    The function polls the job status every 10 seconds for up to 5 minutes.

    Args:
        runbook_name: Name of the runbook to execute.
        parameters: Dictionary of runbook input parameters (all values must be strings).

    Returns:
        A dict with keys:
            - job_id: The automation job ID.
            - status: Final job status (e.g. Completed, Failed).
            - output: The job output text, or an empty string if unavailable.

    Raises:
        TimeoutError: If the job does not reach a terminal state within 5 minutes.
    """
    client = _get_client()
    resource_group = _get_resource_group()
    account_name = _get_account_name()

    job_name = f"{runbook_name}-{int(time.time())}-{uuid.uuid4().hex[:6]}"

    job_creation = client.job.create(
        resource_group_name=resource_group,
        automation_account_name=account_name,
        job_name=job_name,
        parameters={
            "properties": {
                "runbook": {"name": runbook_name},
                "parameters": parameters,
                "runOn": _HYBRID_WORKER_GROUP,
            }
        },
    )

    elapsed = 0

    while elapsed < _MAX_WAIT_SECONDS:
        time.sleep(_POLL_INTERVAL_SECONDS)
        elapsed += _POLL_INTERVAL_SECONDS

        job = client.job.get(
            resource_group_name=resource_group,
            automation_account_name=account_name,
            job_name=job_name,
        )

        status = job.status
        if status in _TERMINAL_STATUSES:
            output_text = ""
            try:
                output_text = client.job.get_output(
                    resource_group_name=resource_group,
                    automation_account_name=account_name,
                    job_name=job_name,
                )
            except Exception:
                output_text = ""

            return {
                "job_id": job_name,
                "status": status,
                "output": output_text or "",
            }

    raise TimeoutError(
        f"Runbook '{runbook_name}' job '{job_name}' did not complete "
        f"within {_MAX_WAIT_SECONDS} seconds. Last status: {status}"
    )
