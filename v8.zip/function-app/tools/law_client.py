"""Log Analytics Workspace query client using DefaultAzureCredential.

Handles generic LAW queries and alert-rule lookups.
VMPerf, IISPerf, and IISLogs queries all go to adx_client.py.
"""

import os
from datetime import timedelta
from typing import Any, Dict, List

from azure.identity import DefaultAzureCredential
from azure.monitor.query import LogsQueryClient, LogsQueryStatus


def _get_client() -> LogsQueryClient:
    return LogsQueryClient(DefaultAzureCredential())


def _get_workspace_id() -> str:
    return os.environ["LAW_WORKSPACE_CUSTOMER_ID"]


def query_law(workspace_id: str, query: str, timespan: timedelta) -> List[Dict[str, Any]]:
    """Run an arbitrary KQL query against a Log Analytics workspace.

    Args:
        workspace_id: The Log Analytics workspace ID (customer ID / GUID).
        query: The KQL query string.
        timespan: The time range for the query.

    Returns:
        A list of rows, each represented as a dict mapping column name to value.
    """
    client = _get_client()
    response = client.query_workspace(
        workspace_id=workspace_id,
        query=query,
        timespan=timespan,
    )

    if response.status == LogsQueryStatus.SUCCESS:
        rows: List[Dict[str, Any]] = []
        for table in response.tables:
            columns = [col.name for col in table.columns]
            for row in table.rows:
                rows.append(dict(zip(columns, row)))
        return rows

    if response.status == LogsQueryStatus.PARTIAL:
        rows = []
        for table in response.partial_data:
            columns = [col.name for col in table.columns]
            for row in table.rows:
                rows.append(dict(zip(columns, row)))
        return rows

    raise RuntimeError(
        f"Log Analytics query failed with status {response.status}: "
        f"{getattr(response, 'partial_error', 'unknown error')}"
    )
