"""Log Analytics ingestion client for writing custom log entries.

DCR Rule IDs are read from environment variables. If either variable is absent
(e.g. during local development without a full LAW setup) the write is skipped
with a warning rather than raising a KeyError that would crash the pipeline.
"""

import logging
import os
from typing import Dict, Any

from azure.identity import DefaultAzureCredential
from azure.monitor.ingestion import LogsIngestionClient

logger = logging.getLogger("LawIngestionClient")


def _get_client() -> LogsIngestionClient:
    return LogsIngestionClient(
        endpoint=os.environ["DCE_ENDPOINT"],
        credential=DefaultAzureCredential(),
    )


def write_agent_event(event: Dict[str, Any]) -> None:
    """Write a structured event record to the AgentEvents_CL table.

    Silently skips (with a warning) if DCR_AGENT_EVENTS_RULE_ID is not set.
    """
    rule_id = os.environ.get("DCR_AGENT_EVENTS_RULE_ID", "")
    if not rule_id:
        logger.warning("DCR_AGENT_EVENTS_RULE_ID not set — skipping AgentEvents write.")
        return
    _get_client().upload(
        rule_id=rule_id,
        stream_name="Custom-AgentEvents_CL",
        logs=[event],
    )


def write_agent_error(error: Dict[str, Any]) -> None:
    """Write a structured error record to the AgentErrors_CL table.

    Silently skips (with a warning) if DCR_AGENT_ERRORS_RULE_ID is not set.
    """
    rule_id = os.environ.get("DCR_AGENT_ERRORS_RULE_ID", "")
    if not rule_id:
        logger.warning("DCR_AGENT_ERRORS_RULE_ID not set — skipping AgentErrors write.")
        return
    _get_client().upload(
        rule_id=rule_id,
        stream_name="Custom-AgentErrors_CL",
        logs=[error],
    )
