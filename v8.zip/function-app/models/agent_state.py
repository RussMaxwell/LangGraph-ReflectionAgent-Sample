"""Shared LangGraph state passed between nodes.

The state is grouped by phase.  Each field has a single writer -- the node
named in the section header.  Downstream nodes read what upstream nodes
wrote.  Fields outside their group's writer may be present but should not be
mutated.

Field naming preserves the keys consumed by HealingResult.from_agent_state()
and the entrypoint modules, so the LAW record shape is unchanged.
"""

from __future__ import annotations

from typing import Optional

from typing_extensions import TypedDict

from models.alert_payload import AlertPayload
from models.baseline_summary import BaselineSummary
from models.issue_profile import IssueProfile


class AgentState(TypedDict, total=False):
    """State dictionary flowing through the 6-node healing graph."""

    # ── INPUT (set once by the orchestrator entrypoint) ────────────────
    alert_payload: AlertPayload

    # ── CLASSIFY ───────────────────────────────────────────────────────
    # Written by classify_agent.
    issue_type: str
    issue_summary: str
    issue_profile: Optional[IssueProfile]

    # ── GATHER ─────────────────────────────────────────────────────────
    # Written by gather_agent.  Keys are Gatherer.value strings.
    evidence: dict

    # ── JUDGE ──────────────────────────────────────────────────────────
    # Written by judge_agent.
    # decision_action: one of
    #   "remediate" | "no_action" | "escalate_only" | "remediate_and_escalate"
    decision_action: str
    decision_runbook: str       # chosen runbook (empty on no_action / escalate_only)
    decision_reasoning: str
    decision_confidence: str    # "high" | "medium" | "low"

    # ── ACT ────────────────────────────────────────────────────────────
    # Written by act_agent.
    remediation_runbook: str
    remediation_outcome: str    # "success" | "failed" | "skipped"
    remediation_detail: str

    # ── CONFIRM ────────────────────────────────────────────────────────
    # Written by confirm_agent.
    is_healthy: bool
    confirm_detail: str

    # ── ANALYZE ────────────────────────────────────────────────────────
    # Written by analyze_agent.  Preserves field names used by LAW ingestion.
    analysis_result: str
    root_cause: str
    next_steps: list[str]
    baseline_summary: Optional[BaselineSummary]

    # ── CONTROL ────────────────────────────────────────────────────────
    # retry_count is incremented by the confirm -> judge back-edge in the
    # orchestrator.  errors may be appended to by any node on failure.
    retry_count: int
    errors: list[dict]

    # ── SUMMARIZE (output) ─────────────────────────────────────────────
    # Written by summarize_agent.
    event_log_entry: dict


# Backward-compatible alias retained for any stray imports.
HealingState = AgentState
