"""Issue profile model -- per-issue configuration consumed by graph nodes.

An IssueProfile describes *everything* the pipeline needs to know about how
to handle one issue_type:

    - what evidence to collect      (gather_agent)
    - how to decide what to do      (judge_agent)
    - which runbook to run          (act_agent, escalation on retry)
    - which checks count as healthy (confirm_agent)
    - whether to run deep RCA       (analyze_agent)

All behavioural variance between issue types lives in the profile.  The graph
topology is invariant -- every issue walks the same six nodes.

Adding a new issue type = adding a new row to agents/profiles.py.  No new
agents.  No new edges.  No topology change.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum


class Gatherer(str, Enum):
    """Named evidence collectors executed by gather_agent.

    Each gatherer is a pure data-collection function.  Cheap gatherers run
    first; gatherers that trigger Hybrid-Worker runbooks (capture diagnostics)
    are last because they take longer.  Gatherers never mutate VM state.
    """

    # Cheap -- seconds or less
    SERVICE_STATE            = "service_state"            # HTTP health probe (proxy for W3SVC up/down)
    ADX_VM_PERF_5M           = "adx_vm_perf_5m"           # 5-min VMPerf window (re-validation)
    ADX_IIS_PERF_5M          = "adx_iis_perf_5m"          # 5-min IISPerf window
    ADX_HTTP_ERRORS_7M       = "adx_http_errors_7m"       # 7-min HTTPERR window (503, AppOffline, etc.)

    # Medium -- tens of seconds
    ADX_VM_PERF_30M          = "adx_vm_perf_30m"          # 30-min VMPerf (trend + baseline compare)
    ADX_IIS_PERF_30M         = "adx_iis_perf_30m"         # 30-min IISPerf
    ADX_IIS_LOGS_30M         = "adx_iis_logs_30m"         # 30-min W3C access logs
    BASELINE                 = "baseline"                 # Stored PerformanceBaseline (p50/p95/p99)

    # Future -- requires Invoke-CaptureIncidentDiagnostics runbook (not yet deployed)
    # Left here to make the registry honest about forward-looking profiles.
    CAPTURE_EVENT_LOG        = "capture_event_log"
    CAPTURE_NETSTAT          = "capture_netstat"
    CAPTURE_REQUEST_QUEUE    = "capture_request_queue"


class Strategy(str, Enum):
    """How judge_agent decides what to do.

    MECHANICAL
        No LLM.  The alert threshold already confirms the issue; judge just
        picks the profile's default_runbook (or escalation_runbook on retry).

    REASONED
        LLM call (gpt-4o-mini) that reads the gathered evidence and chooses
        between remediate / no_action.  Cannot veto; will remediate by default
        unless evidence clearly shows the alert was a false positive.

    REASONED_WITH_VETO
        LLM call (gpt-4o-mini) that can choose:
            remediate              -- run the default_runbook
            no_action              -- evidence shows no real problem
            escalate_only          -- real problem, but a recycle wouldn't fix it
                                      (e.g. downstream DB slowness -> Oracle case)
            remediate_and_escalate -- fix now, but flag upstream cause to ops
        This is the strategy for issues where the fix could make things worse
        if applied blindly.
    """

    MECHANICAL         = "mechanical"
    REASONED           = "reasoned"
    REASONED_WITH_VETO = "reasoned_with_veto"


class Check(str, Enum):
    """Named health checks executed by confirm_agent.

    A profile declares which checks must all pass for is_healthy = True.
    """

    HTTP_OK                    = "http_ok"                   # HTTP GET returns 200
    CPU_BELOW_THRESHOLD        = "cpu_below_threshold"       # VMPerf % Processor Time < 85
    DISK_FREE_ABOVE_THRESHOLD  = "disk_free_above_threshold" # VMPerf % Free Space > 5
    FIVE_XX_RATE_BELOW         = "five_xx_rate_below"        # IIS logs: <5% 5xx rate
    W3WP_RUNNING               = "w3wp_running"              # IIS Perf: worker process heartbeat


@dataclass(frozen=True)
class IssueProfile:
    """Profile describing how to handle one issue_type."""

    # What gather_agent pulls.  Order is informational; gather_agent runs them
    # in parallel where safe.
    gatherers: tuple[Gatherer, ...] = ()

    # How judge_agent decides.
    strategy: Strategy = Strategy.MECHANICAL

    # Runbook executed on the first attempt.  Empty string = no action on
    # first attempt (rare -- only for profiles that always veto or escalate).
    default_runbook: str = ""

    # Runbook executed on any retry (retry_count >= 1).  Convention: a bigger
    # hammer.  Empty string = no escalation (judge will decide).
    escalation_runbook: str = "Invoke-RestartIIS"

    # Which confirm_agent checks must all pass for is_healthy = True.
    confirmation: tuple[Check, ...] = (Check.HTTP_OK,)

    # Whether analyze_agent runs post-confirm to produce deep RCA.  Mechanical
    # issues typically set this False -- the report is self-explanatory.
    analyze: bool = False

    # Destination for escalate_* decisions.  Empty string = no paging target
    # configured; the decision is still recorded but no page is sent.
    # (Paging implementation is a downstream concern; summarize_agent reads
    # this field and includes it in the event record.)
    escalation_target: str = ""

    # Short human-readable label used in summaries and logs.
    label: str = ""
