from __future__ import annotations

from datetime import datetime
from typing import Any, Optional

from pydantic import BaseModel, Field


class AlertConditionDimension(BaseModel):
    """A single dimension from the alert condition."""

    name: str = ""
    value: str = ""


class AlertConditionAllOf(BaseModel):
    """A single condition entry inside alertContext.condition.allOf."""

    search_query: Optional[str] = Field(None, alias="searchQuery")
    metric_measure_column: Optional[str] = Field(None, alias="metricMeasureColumn")
    target_resource_types: Optional[str] = Field(None, alias="targetResourceTypes")
    operator: Optional[str] = None
    threshold: Optional[str] = None
    time_aggregation: Optional[str] = Field(None, alias="timeAggregation")
    metric_value: Optional[float] = Field(None, alias="metricValue")
    dimensions: list[AlertConditionDimension] = Field(default_factory=list)
    failing_periods: Optional[dict[str, Any]] = Field(None, alias="failingPeriods")
    link_to_search_results_ui: Optional[str] = Field(None, alias="linkToSearchResultsUI")
    link_to_filtered_search_results_ui: Optional[str] = Field(
        None, alias="linkToFilteredSearchResultsUI"
    )


class AlertCondition(BaseModel):
    """condition block inside alertContext for scheduled query rule alerts."""

    window_size: Optional[str] = Field(None, alias="windowSize")
    all_of: list[AlertConditionAllOf] = Field(default_factory=list, alias="allOf")
    window_start_time: Optional[datetime] = Field(None, alias="windowStartTime")
    window_end_time: Optional[datetime] = Field(None, alias="windowEndTime")


class AlertContext(BaseModel):
    """alertContext block from the common alert schema for Log Analytics scheduled query rules."""

    condition_type: Optional[str] = Field(None, alias="conditionType")
    condition: Optional[AlertCondition] = None


class Essentials(BaseModel):
    """essentials block from the Azure Monitor common alert schema."""

    alert_id: Optional[str] = Field(None, alias="alertId")
    alert_rule: Optional[str] = Field(None, alias="alertRule")
    severity: Optional[str] = Field(None, alias="severity")
    signal_type: Optional[str] = Field(None, alias="signalType")
    monitor_condition: Optional[str] = Field(None, alias="monitorCondition")
    monitoring_service: Optional[str] = Field(None, alias="monitoringService")
    alert_target_ids: list[str] = Field(default_factory=list, alias="alertTargetIDs")
    configuration_items: list[str] = Field(default_factory=list, alias="configurationItems")
    origin_alert_id: Optional[str] = Field(None, alias="originAlertId")
    fired_date_time: Optional[datetime] = Field(None, alias="firedDateTime")
    resolved_date_time: Optional[datetime] = Field(None, alias="resolvedDateTime")
    description: Optional[str] = None
    essentials_version: Optional[str] = Field(None, alias="essentialsVersion")
    alert_context_version: Optional[str] = Field(None, alias="alertContextVersion")


class AlertPayload(BaseModel):
    """Top-level Azure Monitor common alert schema payload."""

    schema_id: Optional[str] = Field(None, alias="schemaId")
    alert_id: Optional[str] = Field(None, alias="alertId")
    alert_name: Optional[str] = Field(None, alias="alertName")
    severity: Optional[str] = None
    signal_type: Optional[str] = Field(None, alias="signalType")
    monitor_condition: Optional[str] = Field(None, alias="monitorCondition")
    affected_resource_type: Optional[str] = Field(None, alias="affectedResourceType")
    affected_resource_name: Optional[str] = Field(None, alias="affectedResourceName")
    essentials: Optional[Essentials] = None
    alert_context: Optional[AlertContext] = Field(None, alias="alertContext")

    class Config:
        populate_by_name = True
