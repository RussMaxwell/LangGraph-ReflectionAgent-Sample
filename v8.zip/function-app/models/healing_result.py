from __future__ import annotations

from datetime import datetime
from typing import Any, Optional

from pydantic import BaseModel, Field


class HealingResult(BaseModel):
    """Maps to the AgentEvents_CL custom log table in Log Analytics.

    Every field corresponds to a column in the table so the result can be
    ingested via the Azure Monitor Ingestion SDK.
    """

    TimeGenerated: datetime = Field(
        default_factory=datetime.utcnow,
        description="UTC timestamp when the healing event was generated",
    )
    AlertId: str = Field(
        description="Unique identifier of the originating Azure Monitor alert"
    )
    AlertName: str = Field(
        description="Display name of the alert rule that fired"
    )
    Severity: str = Field(
        description="Alert severity (Sev0-Sev4)"
    )
    IssueType: str = Field(
        description="Classified issue type, e.g. high_response_time, app_pool_crash"
    )
    IssueSummary: str = Field(
        description="Short human-readable summary of the detected issue"
    )
    AnalysisResult: str = Field(
        description="Detailed analysis output produced by the diagnostic agent"
    )
    RemediationRunbook: str = Field(
        description="Name or identifier of the remediation runbook executed"
    )
    RemediationOutcome: str = Field(
        description="Outcome status: success, partial, failed, skipped"
    )
    RemediationDetail: str = Field(
        description="Detailed description of what the remediation step did"
    )
    IsHealthy: bool = Field(
        description="Whether the post-remediation health check passed"
    )
    RetryCount: int = Field(
        default=0,
        description="Number of remediation retry attempts made"
    )
    RootCause: str = Field(
        default="",
        description="Determined root cause of the issue"
    )
    NextSteps: str = Field(
        default="",
        description="JSON-encoded list of recommended follow-up actions"
    )
    VmName: str = Field(
        default="",
        description="Name of the affected virtual machine"
    )
    VmHostname: str = Field(
        default="",
        description="Hostname of the affected virtual machine"
    )
    Errors: str = Field(
        default="",
        description="JSON-encoded list of error objects encountered during healing"
    )
    DurationSeconds: float = Field(
        default=0.0,
        description="Total wall-clock duration of the healing workflow in seconds"
    )

    @classmethod
    def from_agent_state(
        cls,
        state: dict[str, Any],
        duration_seconds: float = 0.0,
        vm_name: str = "",
        vm_hostname: str = "",
    ) -> "HealingResult":
        """Build a HealingResult from the final AgentState dictionary."""
        import json

        alert: Any = state.get("alert_payload")
        alert_id = ""
        alert_name = ""
        severity = ""
        if alert is not None:
            alert_id = getattr(alert, "alert_id", "") or ""
            alert_name = getattr(alert, "alert_name", "") or ""
            severity = getattr(alert, "severity", "") or ""

        next_steps_raw = state.get("next_steps", [])
        errors_raw = state.get("errors", [])

        return cls(
            AlertId=alert_id,
            AlertName=alert_name,
            Severity=severity,
            IssueType=state.get("issue_type", ""),
            IssueSummary=state.get("issue_summary", ""),
            AnalysisResult=state.get("analysis_result", ""),
            RemediationRunbook=state.get("remediation_runbook", ""),
            RemediationOutcome=state.get("remediation_outcome", ""),
            RemediationDetail=state.get("remediation_detail", ""),
            IsHealthy=state.get("is_healthy", False),
            RetryCount=state.get("retry_count", 0),
            RootCause=state.get("root_cause", ""),
            NextSteps=json.dumps(next_steps_raw) if next_steps_raw else "",
            VmName=vm_name,
            VmHostname=vm_hostname,
            Errors=json.dumps(errors_raw) if errors_raw else "",
            DurationSeconds=duration_seconds,
        )
