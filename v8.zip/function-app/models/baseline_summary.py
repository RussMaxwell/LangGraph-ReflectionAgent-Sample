from datetime import datetime
from typing import Optional

from pydantic import BaseModel, Field


class BaselineSummary(BaseModel):
    """Baseline performance metrics captured from ADX PerformanceBaseline table."""

    p50_response_ms: Optional[float] = Field(
        default=None,
        description="Median (p50) HTTP response time in milliseconds (requires load test traffic)",
    )
    p95_response_ms: Optional[float] = Field(
        default=None,
        description="95th percentile HTTP response time in milliseconds (requires load test traffic)",
    )
    p99_response_ms: Optional[float] = Field(
        default=None,
        description="99th percentile HTTP response time in milliseconds (requires load test traffic)",
    )
    avg_cpu_percent: Optional[float] = Field(
        default=None, description="Average total CPU utilisation percentage"
    )
    max_cpu_percent: Optional[float] = Field(
        default=None, description="Maximum total CPU utilisation percentage"
    )
    p95_cpu_percent: Optional[float] = Field(
        default=None,
        description="95th percentile total CPU utilisation percentage",
    )
    avg_w3wp_cpu_percent: Optional[float] = Field(
        default=None,
        description="Average CPU percentage consumed by w3wp worker processes",
    )
    max_w3wp_cpu_percent: Optional[float] = Field(
        default=None,
        description="Maximum CPU percentage consumed by w3wp worker processes",
    )
    avg_w3wp_working_set_mb: Optional[float] = Field(
        default=None,
        description="Average working-set memory of w3wp processes in MB",
    )
    max_w3wp_working_set_mb: Optional[float] = Field(
        default=None,
        description="Maximum working-set memory of w3wp processes in MB",
    )
    avg_memory_available_mb: Optional[float] = Field(
        default=None, description="Average available physical memory in MB"
    )
    min_memory_available_mb: Optional[float] = Field(
        default=None, description="Minimum available physical memory in MB"
    )
    avg_requests_per_sec: Optional[float] = Field(
        default=None, description="Average HTTP requests per second"
    )
    avg_requests_queued: Optional[float] = Field(
        default=None,
        description="Average number of requests in the IIS queue",
    )
    baseline_captured_at: Optional[datetime] = Field(
        default=None,
        description="UTC timestamp when the baseline snapshot was captured",
    )
    vm_hostname: str = Field(
        description="Hostname of the VM this baseline was captured from"
    )
