"""Issue profile registry -- single source of truth for per-issue behaviour.

Every issue type recognised by the system has exactly one row here.  The row
says what evidence to gather, how to decide, which runbook to run, what to
check for recovery, and whether to run deep RCA.

Adding a new issue type:
    1.  Add the substring -> issue_type entry in classify_agent._ALERT_TO_ISSUE
        so an incoming alert resolves to the new key.
    2.  Add a new row to PROFILES keyed by that issue_type.
    3.  (If the issue has a new recovery signal that isn't covered by the
        existing Check enum, extend Check + confirm_agent accordingly.)

Nothing else changes.  No new agents, no new graph edges.

Strategy picks:
    MECHANICAL          -- signal is unambiguous, safe known fix exists
    REASONED            -- symptom class; LLM validates + picks the runbook
    REASONED_WITH_VETO  -- fix could make things worse if cause is upstream
                           (e.g. http_5xx_flood driven by slow Oracle DB)
"""

from __future__ import annotations

from models.issue_profile import Check, Gatherer, IssueProfile, Strategy


# ---------------------------------------------------------------------------
# Profile definitions.
# ---------------------------------------------------------------------------
PROFILES: dict[str, IssueProfile] = {

    # ── Mechanical issues -- unambiguous signal, safe known fix ────────

    "w3svc_stopped": IssueProfile(
        label              = "IIS W3SVC service stopped",
        gatherers          = (Gatherer.SERVICE_STATE,),
        strategy           = Strategy.MECHANICAL,
        default_runbook    = "Invoke-RestartW3SVC",
        escalation_runbook = "Invoke-RestartIIS",
        confirmation       = (Check.HTTP_OK,),
        analyze            = False,
    ),

    "app_pool_stopped": IssueProfile(
        label              = "App pool stopped by IIS rapid-fail protection (503 AppOffline)",
        # Pull the HTTPERR rows that drove detection so the report has context.
        gatherers          = (Gatherer.ADX_HTTP_ERRORS_7M,),
        strategy           = Strategy.MECHANICAL,
        default_runbook    = "Invoke-RecycleAppPool",
        # If recycle didn't restore health, the pool is likely stuck on a
        # config issue the recycle can't fix -- most commonly a bad app-pool
        # identity.  Invoke-FixAppPoolIdentity resets identityType to
        # ApplicationPoolIdentity and recycles, which covers both the identity
        # case and restarts the pool for any other transient cause.
        escalation_runbook = "Invoke-FixAppPoolIdentity",
        confirmation       = (Check.HTTP_OK,),
        analyze            = False,
    ),

    "app_pool_crash": IssueProfile(
        label              = "Application pool crashing repeatedly",
        gatherers          = (Gatherer.ADX_IIS_PERF_5M,),
        strategy           = Strategy.MECHANICAL,
        default_runbook    = "Invoke-RecycleAppPool",
        escalation_runbook = "Invoke-RestartIIS",
        confirmation       = (Check.HTTP_OK,),
        # RCA on repeated crashes is useful -- identifies the triggering request
        # pattern from the 30-min log window.
        analyze            = True,
    ),

    "log_disk_full": IssueProfile(
        label              = "C: drive critically low on disk space",
        gatherers          = (Gatherer.ADX_VM_PERF_5M,),
        strategy           = Strategy.MECHANICAL,
        default_runbook    = "Invoke-ClearIISLogs",
        escalation_runbook = "Invoke-RestartIIS",
        confirmation       = (Check.HTTP_OK, Check.DISK_FREE_ABOVE_THRESHOLD),
        analyze            = False,
    ),

    "binding_missing": IssueProfile(
        label              = "IIS HTTP binding missing or broken",
        gatherers          = (Gatherer.SERVICE_STATE,),
        strategy           = Strategy.MECHANICAL,
        default_runbook    = "Invoke-FixBindings",
        escalation_runbook = "Invoke-RestartIIS",
        confirmation       = (Check.HTTP_OK,),
        analyze            = False,
    ),

    "site_stopped": IssueProfile(
        # Default Web Site (or any site) is in Stopped state.  Most common cause
        # is binding removal -- IIS auto-stops a site with zero bindings -- so
        # Invoke-FixBindings handles both restoring port 80 and starting any
        # Stopped site it finds.  Distinct from app_pool_stopped: the pool may
        # be perfectly fine; the issue is that there is nothing for it to serve.
        label              = "IIS site in Stopped state (likely missing bindings)",
        gatherers          = (Gatherer.SERVICE_STATE,),
        strategy           = Strategy.MECHANICAL,
        default_runbook    = "Invoke-FixBindings",
        escalation_runbook = "Invoke-RestartIIS",
        confirmation       = (Check.HTTP_OK,),
        analyze            = False,
    ),

    "app_pool_identity": IssueProfile(
        label              = "App pool identity misconfigured",
        gatherers          = (Gatherer.SERVICE_STATE,),
        strategy           = Strategy.MECHANICAL,
        default_runbook    = "Invoke-FixAppPoolIdentity",
        escalation_runbook = "Invoke-RestartIIS",
        confirmation       = (Check.HTTP_OK,),
        analyze            = False,
    ),

    "bad_permissions": IssueProfile(
        label              = "IIS_IUSRS permissions on wwwroot incorrect",
        gatherers          = (Gatherer.SERVICE_STATE,),
        strategy           = Strategy.MECHANICAL,
        default_runbook    = "Invoke-FixPermissions",
        escalation_runbook = "Invoke-RestartIIS",
        confirmation       = (Check.HTTP_OK,),
        analyze            = False,
    ),

    # ── Performance issues -- mechanical fix, but deep RCA post-fix ────

    "high_cpu": IssueProfile(
        label              = "VM CPU utilisation critically high",
        gatherers          = (
            Gatherer.ADX_VM_PERF_30M,
            Gatherer.ADX_IIS_PERF_30M,
            Gatherer.BASELINE,
        ),
        strategy           = Strategy.MECHANICAL,
        default_runbook    = "Invoke-RecycleAppPool",
        escalation_runbook = "Invoke-RestartIIS",
        confirmation       = (Check.HTTP_OK,),
        analyze            = True,
    ),

    "high_cpu_w3wp": IssueProfile(
        label              = "w3wp worker process CPU critically high",
        gatherers          = (
            Gatherer.ADX_VM_PERF_30M,
            Gatherer.ADX_IIS_PERF_30M,
            Gatherer.BASELINE,
        ),
        strategy           = Strategy.MECHANICAL,
        default_runbook    = "Invoke-RecycleAppPool",
        escalation_runbook = "Invoke-RestartIIS",
        confirmation       = (Check.HTTP_OK,),
        analyze            = True,
    ),

    # ── Symptom-class issues -- LLM reasons over evidence ──────────────

    "memory_leak": IssueProfile(
        label              = "w3wp worker process memory abnormally high",
        gatherers          = (
            Gatherer.ADX_VM_PERF_30M,
            Gatherer.ADX_IIS_PERF_30M,
            Gatherer.BASELINE,
        ),
        strategy           = Strategy.REASONED,
        default_runbook    = "Invoke-RecycleAppPool",
        escalation_runbook = "Invoke-RestartIIS",
        confirmation       = (Check.HTTP_OK,),
        analyze            = True,
    ),

    "worker_process_hang": IssueProfile(
        label              = "w3wp worker process appears to be hanging",
        gatherers          = (
            Gatherer.ADX_IIS_PERF_30M,
            Gatherer.ADX_IIS_LOGS_30M,
            Gatherer.BASELINE,
        ),
        strategy           = Strategy.REASONED,
        default_runbook    = "Invoke-RestartWorkerProcess",
        escalation_runbook = "Invoke-RestartIIS",
        confirmation       = (Check.HTTP_OK,),
        analyze            = True,
    ),

    "request_queue_flood": IssueProfile(
        label              = "ASP.NET request queue flooding",
        gatherers          = (
            Gatherer.ADX_IIS_PERF_30M,
            Gatherer.ADX_IIS_LOGS_30M,
            Gatherer.BASELINE,
        ),
        strategy           = Strategy.REASONED,
        default_runbook    = "Invoke-RecycleAppPool",
        escalation_runbook = "Invoke-RestartIIS",
        confirmation       = (Check.HTTP_OK,),
        analyze            = True,
    ),

    "bad_http_errors": IssueProfile(
        label              = "High rate of HTTP 404 errors",
        gatherers          = (
            Gatherer.ADX_IIS_LOGS_30M,
            Gatherer.ADX_IIS_PERF_5M,
        ),
        strategy           = Strategy.REASONED,
        default_runbook    = "Invoke-RecycleAppPool",
        escalation_runbook = "Invoke-RestartIIS",
        confirmation       = (Check.HTTP_OK,),
        analyze            = True,
    ),

    "high_memory": IssueProfile(
        label              = "VM memory critically low",
        gatherers          = (
            Gatherer.ADX_VM_PERF_30M,
            Gatherer.ADX_IIS_PERF_30M,
            Gatherer.BASELINE,
        ),
        strategy           = Strategy.REASONED,
        default_runbook    = "Invoke-RecycleAppPool",
        escalation_runbook = "Invoke-RestartIIS",
        confirmation       = (Check.HTTP_OK,),
        analyze            = True,
    ),

    "high_disk_io": IssueProfile(
        label              = "VM disk I/O queue critically high",
        gatherers          = (Gatherer.ADX_VM_PERF_30M, Gatherer.BASELINE),
        strategy           = Strategy.REASONED,
        default_runbook    = "Invoke-ClearIISLogs",
        escalation_runbook = "Invoke-RestartIIS",
        confirmation       = (Check.HTTP_OK,),
        analyze            = True,
    ),

    # ── Reasoned-with-veto -- fix can make things worse ────────────────
    #
    # http_5xx_flood is a forward-looking profile.  Detection for generic 5xx
    # flooding is not yet wired into IISMonitorPoller (it currently handles
    # only 503 AppOffline via app_pool_stopped).  The profile is defined so
    # that when 5xx detection is added, no graph/agent change is needed.
    #
    # The Oracle-backend-slow case is the canonical trigger: recycling the
    # pool doesn't fix downstream DB latency and can make it worse (cold
    # connection pool, re-auth, cache misses).  Judge may return
    # escalate_only, which skips act and confirm entirely.
    "http_5xx_flood": IssueProfile(
        label              = "High rate of HTTP 5xx errors from IIS",
        gatherers          = (
            Gatherer.ADX_IIS_LOGS_30M,
            Gatherer.ADX_IIS_PERF_30M,
            Gatherer.ADX_HTTP_ERRORS_7M,
            Gatherer.BASELINE,
            # Future capture-runbook gatherers (not yet deployed):
            # Gatherer.CAPTURE_EVENT_LOG,
            # Gatherer.CAPTURE_NETSTAT,
            # Gatherer.CAPTURE_REQUEST_QUEUE,
        ),
        strategy           = Strategy.REASONED_WITH_VETO,
        default_runbook    = "Invoke-RecycleAppPool",
        escalation_runbook = "Invoke-RestartIIS",
        confirmation       = (Check.HTTP_OK, Check.FIVE_XX_RATE_BELOW),
        analyze            = True,
        escalation_target  = "oncall_webhook",
    ),

    # ── Safe fallback for uncorrelatable alerts ────────────────────────
    "unknown": IssueProfile(
        label              = "Unknown issue -- AI investigating from scratch",
        gatherers          = (
            Gatherer.ADX_VM_PERF_30M,
            Gatherer.ADX_IIS_PERF_30M,
            Gatherer.ADX_IIS_LOGS_30M,
            Gatherer.BASELINE,
        ),
        strategy           = Strategy.REASONED,
        default_runbook    = "Invoke-RestartIIS",
        escalation_runbook = "Invoke-RestartIIS",
        confirmation       = (Check.HTTP_OK,),
        analyze            = True,
    ),
}


def get_profile(issue_type: str) -> IssueProfile:
    """Return the profile for an issue_type, falling back to `unknown`."""
    return PROFILES.get(issue_type, PROFILES["unknown"])
