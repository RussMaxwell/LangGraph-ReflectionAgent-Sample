"""Analyze agent -- deep root cause analysis (o4-mini) on preserved evidence.

Runs after confirm, only when profile.analyze is True.  Reads the same
evidence dict that judge used, plus the decision / act / confirm outcomes.
Produces:
    analysis_result  -- long-form narrative (timeline + metric correlations)
    root_cause       -- 2-3 sentence definitive statement
    next_steps       -- 3-5 concrete preventive actions

Analyze runs whether the fix succeeded, failed, or was skipped (escalate_only).
A failed-fix RCA is arguably more valuable than a successful one -- the
operator needs to know why, so the next response is informed.
"""

from __future__ import annotations

import json
import logging
import os
from datetime import datetime, timezone
from typing import Any

from models.agent_state import AgentState
from models.baseline_summary import BaselineSummary
from models.issue_profile import Gatherer
from tools.azure_openai_client import get_reasoning_llm
from tools.baseline_client import get_latest_baseline
from tools.law_ingestion_client import write_agent_error

logger = logging.getLogger("AnalyzeAgent")


def analyze(state: AgentState) -> dict:
    """LangGraph node: produce deep RCA from the evidence + outcome record."""
    try:
        evidence = state.get("evidence") or {}

        issue_type       = state.get("issue_type", "unknown")
        issue_summary    = state.get("issue_summary", "")
        decision_action  = state.get("decision_action", "")
        decision_reason  = state.get("decision_reasoning", "")
        runbook          = state.get("remediation_runbook", "")
        outcome          = state.get("remediation_outcome", "")
        remediation_det  = state.get("remediation_detail", "")
        is_healthy       = state.get("is_healthy", False)
        retry_count      = state.get("retry_count", 0)

        hostname = os.environ.get("VM_HOSTNAME", "unknown")

        # Baseline may already be in evidence (if gather pulled it); otherwise
        # fetch now.  This is the only place outside gather that queries
        # baseline, and it only runs if evidence didn't have one.
        baseline_obj = _resolve_baseline(evidence, hostname)
        baseline_section = _format_baseline_section(baseline_obj)

        evidence_section = _format_evidence(evidence)

        outcome_section = (
            f"Judge decision:        {decision_action}\n"
            f"Judge reasoning:       {decision_reason}\n"
            f"Runbook executed:      {runbook or '(none)'}\n"
            f"Runbook outcome:       {outcome or '(skipped)'}\n"
            f"Runbook detail:        {remediation_det[:800]}\n"
            f"Post-fix healthy:      {is_healthy}\n"
            f"Retries:               {retry_count}\n"
        )

        prompt = (
            "You are a senior IIS infrastructure engineer producing a root "
            "cause analysis after an automated healing event.  The healing "
            "pipeline has already executed (or deliberately skipped) the fix; "
            "your job is to explain WHY the incident happened from the "
            "preserved evidence, and recommend preventive actions.\n\n"
            f"Issue type:    {issue_type}\n"
            f"Issue summary: {issue_summary}\n"
            f"VM hostname:   {hostname}\n\n"
            "--- Healing outcome ---\n"
            f"{outcome_section}\n"
            "--- Evidence collected before remediation ---\n"
            f"{evidence_section}\n"
            "--- Baseline ---\n"
            f"{baseline_section}\n\n"
            "Produce your analysis covering:\n"
            "  1. Timeline of events leading to the incident\n"
            "  2. Key metric anomalies and how they correlate\n"
            "  3. Whether the remediation was appropriate and sufficient\n"
            "  4. Definitive root cause\n"
            "  5. 3-5 concrete preventive actions\n\n"
            "Respond ONLY with a JSON object (no markdown fencing) containing:\n"
            '  "analysis_summary": "<multi-paragraph narrative covering items 1-3>",\n'
            '  "root_cause":       "<2-3 sentence definitive statement>",\n'
            '  "next_steps":       ["<action 1>", "<action 2>", ...]\n'
        )

        llm = get_reasoning_llm()
        response = llm.invoke(prompt)
        content = response.content.strip()
        if content.startswith("```"):
            content = content.split("\n", 1)[-1].rsplit("```", 1)[0].strip()

        result = json.loads(content)

        analysis_summary = str(result.get("analysis_summary", ""))
        root_cause       = str(result.get("root_cause", "Unable to determine root cause."))
        next_steps_raw   = result.get("next_steps", [])
        if not isinstance(next_steps_raw, list):
            next_steps_raw = [str(next_steps_raw)]
        next_steps = [str(s) for s in next_steps_raw]

        logger.info("AnalyzeAgent: root_cause='%.160s'", root_cause)

        return {
            "analysis_result":  analysis_summary,
            "root_cause":       root_cause,
            "next_steps":       next_steps,
            "baseline_summary": baseline_obj,
        }

    except Exception as exc:
        logger.error("AnalyzeAgent error: %s", exc, exc_info=True)
        _log_error(exc)
        return {
            "analysis_result": f"Analysis failed due to error: {exc}",
            "root_cause":      f"Automated analysis encountered an error: {exc}",
            "next_steps":      ["Review AnalyzeAgent logs for details."],
        }


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _resolve_baseline(evidence: dict[str, Any], hostname: str) -> BaselineSummary | None:
    """Return a BaselineSummary from evidence if present, else fetch fresh."""
    raw = evidence.get(Gatherer.BASELINE.value)
    if isinstance(raw, dict):
        try:
            return BaselineSummary.model_validate(raw)
        except Exception:
            pass
    try:
        return get_latest_baseline(hostname)
    except Exception as exc:
        logger.warning("AnalyzeAgent: baseline fetch failed: %s", exc)
        return None


def _format_baseline_section(baseline: BaselineSummary | None) -> str:
    if baseline is None:
        return "No baseline data available -- analyse metrics on their own."
    return (
        "Baseline (normal operating range for this server):\n"
        f"{json.dumps(baseline.model_dump(), default=str)}\n"
        "Compare live metrics against these values and highlight significant deviations."
    )


def _format_evidence(evidence: dict[str, Any]) -> str:
    """Truncated JSON view of evidence slots, one per gatherer."""
    if not evidence:
        return "(no evidence collected)"
    # analyze gets more context than judge (reasoning model, larger budget).
    char_budget = 14000
    slots = list(evidence.items())
    per_slot = max(600, char_budget // max(1, len(slots)))
    parts: list[str] = []
    for name, value in slots:
        raw = json.dumps(value, default=str)
        if len(raw) > per_slot:
            raw = raw[:per_slot] + f"... <truncated, full size {len(raw)} chars>"
        parts.append(f"[{name}]\n{raw}")
    return "\n\n".join(parts)


def _log_error(exc: Exception) -> None:
    try:
        write_agent_error({
            "TimeGenerated": datetime.now(timezone.utc).isoformat(),
            "Agent":         "AnalyzeAgent",
            "Error":         str(exc),
            "VMHostname":    os.environ.get("VM_HOSTNAME", "unknown"),
        })
    except Exception:
        pass
