"""Summarize agent -- write the final AgentEvents_CL record.

No LLM.  Assembles the event log entry from state fields, writes to Log
Analytics via the DCR, and returns the entry for the Function App HTTP
response.

Preserves the AgentEvents_CL schema used by the previous pipeline so existing
KQL dashboards and alerting continue to work unchanged.
"""

from __future__ import annotations

import json
import logging
import os
from datetime import datetime, timezone

from models.agent_state import AgentState
from models.issue_profile import IssueProfile, Strategy
from tools.law_ingestion_client import write_agent_error, write_agent_event

logger = logging.getLogger("SummarizeAgent")

_AGENT_VERSION = "3.0.0"


def summarize(state: AgentState) -> dict:
    """LangGraph node: write the final AgentEvents_CL record."""
    hostname = os.environ.get("VM_HOSTNAME", "unknown")

    try:
        alert = state.get("alert_payload")
        alert_id   = ""
        alert_name = ""
        severity   = ""
        fired_time = None
        if alert is not None:
            alert_id   = getattr(alert, "alert_id", "") or ""
            alert_name = getattr(alert, "alert_name", "") or ""
            severity   = getattr(alert, "severity", "") or ""
            if alert.essentials and alert.essentials.fired_date_time:
                fired_time = alert.essentials.fired_date_time

        profile: IssueProfile | None = state.get("issue_profile")
        issue_type    = state.get("issue_type", "unknown")
        issue_summary = state.get("issue_summary", "")

        decision_action    = state.get("decision_action", "")
        decision_reasoning = state.get("decision_reasoning", "")
        confidence         = state.get("decision_confidence", "")

        runbook     = state.get("remediation_runbook", "")
        outcome     = state.get("remediation_outcome", "")
        detail      = state.get("remediation_detail", "")

        is_healthy      = state.get("is_healthy", False)
        confirm_detail  = state.get("confirm_detail", "")
        retry_count     = state.get("retry_count", 0)

        analysis_result = state.get("analysis_result", "") or ""
        root_cause      = state.get("root_cause", "") or ""
        next_steps      = state.get("next_steps", []) or []

        # Models used (for the LAW record -- downstream cost reporting reads this).
        reasoning_model = "o4-mini" if analysis_result else "none"
        if profile is not None and profile.strategy in (Strategy.REASONED, Strategy.REASONED_WITH_VETO):
            fast_model = "gpt-4o-mini"
        else:
            fast_model = "none"

        # Fill in deterministic defaults when analyze didn't run.
        if not analysis_result:
            analysis_result = (
                "Mechanical issue -- no LLM analysis performed (profile.analyze=False)."
            )
        if not root_cause:
            strategy_name = profile.strategy.value if profile else "unknown"
            root_cause = (
                f"Known issue type '{issue_type}' handled via {strategy_name} strategy; "
                f"runbook '{runbook or '(none)'}' outcome '{outcome or '(skipped)'}'."
            )

        now = datetime.now(timezone.utc)
        total_duration_seconds = 0.0
        if fired_time:
            total_duration_seconds = round((now - fired_time).total_seconds(), 2)

        mitigation_steps = _build_mitigation_steps(
            issue_type      = issue_type,
            decision_action = decision_action,
            runbook         = runbook,
            outcome         = outcome,
            retry_count     = retry_count,
            is_healthy      = is_healthy,
            confidence      = confidence,
            decision_reason = decision_reasoning,
            confirm_detail  = confirm_detail,
        )

        event_entry = {
            "TimeGenerated":         now.isoformat(),
            "VMHostname":            hostname,
            "AlertId":               alert_id,
            "AlertName":             alert_name,
            "Severity":              severity,
            "IssueType":             issue_type,
            "IssueSummary":          issue_summary,
            "DetectionTime":         fired_time.isoformat() if fired_time else now.isoformat(),
            "AnalysisResult":        analysis_result[:4000],
            "MitigationSteps":       mitigation_steps,
            "RunbookExecuted":       runbook,
            "RemediationOutcome":    outcome,
            "RemediationDetail":     detail[:2000],
            "IsHealthy":             is_healthy,
            "RetryCount":            retry_count,
            "RootCause":             root_cause,
            "NextSteps":             json.dumps(next_steps),
            "ReasoningModel":        reasoning_model,
            "FastModel":             fast_model,
            "AgentVersion":          _AGENT_VERSION,
            "TotalDurationSeconds":  total_duration_seconds,
            # New (v3) fields -- backwards-compatible additions.
            "DecisionAction":        decision_action,
            "DecisionConfidence":    confidence,
            "Strategy":              profile.strategy.value if profile else "",
            "EscalationTarget":      profile.escalation_target if profile else "",
        }

        write_agent_event(event_entry)
        logger.info(
            "SummarizeAgent: event written for alert=%s action=%s outcome=%s healthy=%s",
            alert_id, decision_action, outcome, is_healthy,
        )
        return {"event_log_entry": event_entry}

    except Exception as exc:
        logger.error("SummarizeAgent error: %s", exc, exc_info=True)
        _log_error(exc)
        return {
            "event_log_entry": {
                "error":         str(exc),
                "TimeGenerated": datetime.now(timezone.utc).isoformat(),
            }
        }


def _build_mitigation_steps(
    *,
    issue_type: str,
    decision_action: str,
    runbook: str,
    outcome: str,
    retry_count: int,
    is_healthy: bool,
    confidence: str,
    decision_reason: str,
    confirm_detail: str,
) -> str:
    """Deterministic bullet-point summary -- no LLM."""
    lines = [
        f"- Issue classified as: {issue_type}",
        f"- Decision: {decision_action or '(unknown)'} (confidence: {confidence or 'n/a'})",
    ]
    if decision_reason:
        lines.append(f"- Judge reasoning: {decision_reason[:300]}")
    if runbook:
        lines.append(f"- Runbook executed: {runbook}")
    else:
        lines.append("- No runbook executed")
    lines.append(f"- Outcome: {outcome or '(skipped)'}")
    lines.append(f"- Retries: {retry_count}")
    lines.append(f"- Healthy after pipeline: {is_healthy}")
    if confirm_detail:
        # One-line summary of each check.
        first_line = confirm_detail.split("\n", 1)[0][:160]
        lines.append(f"- Confirmation: {first_line}")
    return "\n".join(lines)


def _log_error(exc: Exception) -> None:
    try:
        write_agent_error({
            "TimeGenerated": datetime.now(timezone.utc).isoformat(),
            "Agent":         "SummarizeAgent",
            "Error":         str(exc),
            "VMHostname":    os.environ.get("VM_HOSTNAME", "unknown"),
        })
    except Exception:
        pass
