"""Judge agent -- decide what to do given the gathered evidence.

Judge produces a decision record:
    decision_action     -- remediate | no_action | escalate_only | remediate_and_escalate
    decision_runbook    -- chosen runbook (or empty for no_action/escalate_only)
    decision_reasoning  -- short explanation (1-2 sentences)
    decision_confidence -- high | medium | low

Strategy dispatch:
    MECHANICAL          -- no LLM; picks profile.default_runbook
                           (or profile.escalation_runbook on retry)
    REASONED            -- gpt-4o-mini; may return no_action if evidence shows
                           the alert is a false positive
    REASONED_WITH_VETO  -- gpt-4o-mini; additionally may return escalate_only
                           or remediate_and_escalate for upstream-cause cases

The judge does just enough causal reasoning to choose the action.  Full RCA
happens later in analyze_agent, which reads the same evidence dict.
"""

from __future__ import annotations

import json
import logging
import os
from datetime import datetime, timezone
from typing import Any

from models.agent_state import AgentState
from models.issue_profile import IssueProfile, Strategy
from tools.azure_openai_client import get_fast_llm
from tools.law_ingestion_client import write_agent_error

logger = logging.getLogger("JudgeAgent")


_VALID_ACTIONS = {"remediate", "no_action", "escalate_only", "remediate_and_escalate"}


def judge(state: AgentState) -> dict:
    """LangGraph node: decide the action based on evidence + profile strategy."""
    profile: IssueProfile | None = state.get("issue_profile")
    if profile is None:
        # Defensive fallback -- should never happen after classify.
        return _decision(
            action="remediate",
            runbook="Invoke-RestartIIS",
            reasoning="No profile resolved; defaulting to safe IIS restart.",
            confidence="low",
        )

    retry_count = state.get("retry_count", 0)

    # Escalation on retry is a universal rule: whatever we tried the first
    # time didn't work, so use the profile's bigger hammer regardless of
    # strategy.  Mechanical profiles pre-declare their escalation_runbook;
    # reasoned profiles use it as a fallback when judge would otherwise keep
    # picking the same thing.
    if retry_count > 0:
        runbook = profile.escalation_runbook or profile.default_runbook or "Invoke-RestartIIS"
        return _decision(
            action="remediate",
            runbook=runbook,
            reasoning=(
                f"Retry {retry_count}: escalating to {runbook} "
                f"after prior attempt did not restore health."
            ),
            confidence="high" if retry_count == 1 else "medium",
        )

    # First attempt -- dispatch on strategy.
    if profile.strategy is Strategy.MECHANICAL:
        return _mechanical(profile)

    try:
        if profile.strategy is Strategy.REASONED:
            return _reasoned(state, profile, allow_veto=False)
        if profile.strategy is Strategy.REASONED_WITH_VETO:
            return _reasoned(state, profile, allow_veto=True)
    except Exception as exc:
        logger.error("JudgeAgent error: %s", exc, exc_info=True)
        _log_error(exc)
        # If the LLM call fails, default to remediate with the profile's
        # runbook -- failing open is safer than failing closed here (the
        # alert did fire).
        return _decision(
            action="remediate",
            runbook=profile.default_runbook or "Invoke-RestartIIS",
            reasoning=f"LLM decision failed ({exc}); falling back to default runbook.",
            confidence="low",
        )

    # Unknown strategy.
    return _mechanical(profile)


# ---------------------------------------------------------------------------
# Strategy implementations
# ---------------------------------------------------------------------------

def _mechanical(profile: IssueProfile) -> dict:
    runbook = profile.default_runbook or "Invoke-RestartIIS"
    return _decision(
        action="remediate",
        runbook=runbook,
        reasoning=(
            f"Mechanical issue '{profile.label}': alert threshold confirms "
            f"the breach; running known-safe runbook {runbook}."
        ),
        confidence="high",
    )


def _reasoned(state: AgentState, profile: IssueProfile, *, allow_veto: bool) -> dict:
    """LLM-driven decision with optional veto authority."""
    evidence = state.get("evidence") or {}
    issue_type    = state.get("issue_type", "unknown")
    issue_summary = state.get("issue_summary", "")

    if allow_veto:
        allowed_actions = (
            "remediate, no_action, escalate_only, remediate_and_escalate"
        )
        veto_notes = (
            "  - Use escalate_only when the evidence strongly suggests the root "
            "cause is upstream of IIS (e.g. a downstream database/service is "
            "slow or unavailable) and recycling the app pool would not fix it "
            "and could make things worse by cold-starting connection pools.\n"
            "  - Use remediate_and_escalate when the runbook will restore "
            "service temporarily but the cause will recur and requires human "
            "attention (e.g. known leaky dependency)."
        )
    else:
        allowed_actions = "remediate, no_action"
        veto_notes = ""

    # Trim evidence for token budget.  Each gatherer is already bounded, but
    # 30-minute perf windows can be large; cap the JSON representation.
    evidence_sample = _truncate_evidence(evidence, char_budget=9000)

    prompt = (
        "You are an IIS healing decision agent.\n"
        "An alert has fired; your job is to choose the correct action based "
        "on the gathered evidence.  You must pick exactly ONE action.\n\n"
        f"Issue type:     {issue_type}\n"
        f"Issue summary:  {issue_summary}\n"
        f"Default fix:    {profile.default_runbook}\n"
        f"Allowed actions: {allowed_actions}\n\n"
        "Action semantics:\n"
        "  - remediate: run the default runbook (or a better one -- see "
        "'runbook' below).  Use when evidence confirms a real IIS-local "
        "problem the runbook can fix.\n"
        "  - no_action: evidence shows the alert is a false positive or the "
        "condition has already self-resolved.\n"
        + veto_notes +
        "\n\n--- Evidence ---\n"
        f"{evidence_sample}\n\n"
        "Respond ONLY with a JSON object (no markdown fencing) containing:\n"
        '  "action":     one of the allowed actions above,\n'
        '  "runbook":    the runbook name to run (for remediate/'
        'remediate_and_escalate), or "" for no_action/escalate_only,\n'
        '  "reasoning":  1-2 sentence justification grounded in the evidence,\n'
        '  "confidence": "high" | "medium" | "low"\n'
    )

    llm = get_fast_llm()
    response = llm.invoke(prompt)
    content = response.content.strip()
    if content.startswith("```"):
        content = content.split("\n", 1)[-1].rsplit("```", 1)[0].strip()

    parsed = json.loads(content)

    action = str(parsed.get("action", "remediate")).strip()
    if action not in _VALID_ACTIONS:
        logger.warning("JudgeAgent: LLM returned invalid action '%s'; coercing to remediate.", action)
        action = "remediate"
    if action == "escalate_only" and not allow_veto:
        action = "remediate"
    if action == "remediate_and_escalate" and not allow_veto:
        action = "remediate"

    runbook = str(parsed.get("runbook", "")).strip()
    if action in ("remediate", "remediate_and_escalate"):
        if not runbook:
            runbook = profile.default_runbook or "Invoke-RestartIIS"
    else:
        runbook = ""

    return _decision(
        action     = action,
        runbook    = runbook,
        reasoning  = str(parsed.get("reasoning", "")).strip(),
        confidence = str(parsed.get("confidence", "medium")).strip().lower(),
    )


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _decision(*, action: str, runbook: str, reasoning: str, confidence: str) -> dict:
    return {
        "decision_action":     action,
        "decision_runbook":    runbook,
        "decision_reasoning":  reasoning,
        "decision_confidence": confidence,
    }


def _truncate_evidence(evidence: dict[str, Any], char_budget: int) -> str:
    """Serialise evidence to JSON, truncating each slot to fit the budget.

    We want the LLM to see *some* of every gatherer's output rather than all
    of one and none of the others.  Divide the budget evenly across slots.
    """
    if not evidence:
        return "(no evidence collected)"

    slots = list(evidence.items())
    per_slot = max(400, char_budget // max(1, len(slots)))

    parts: list[str] = []
    for name, value in slots:
        raw = json.dumps(value, default=str)
        if len(raw) > per_slot:
            raw = raw[:per_slot] + f"... <truncated, full size {len(raw)} chars>"
        parts.append(f"[{name}]\n{raw}")
    return "\n\n".join(parts)


def _log_error(exc: Exception) -> None:
    try:
        write_agent_error({
            "TimeGenerated": datetime.now(timezone.utc).isoformat(),
            "Agent":         "JudgeAgent",
            "Error":         str(exc),
            "VMHostname":    os.environ.get("VM_HOSTNAME", "unknown"),
        })
    except Exception:
        pass
