"""Act agent -- execute the runbook chosen by judge.

Pure executor.  No decision logic lives here; judge already picked the
runbook.  If the decision was no_action or escalate_only, act is a no-op that
records the reason.  Remediate_and_escalate runs the runbook AND flags the
escalation target (the paging delivery is a downstream concern -- this node
only records the intent in remediation_detail so summarize_agent surfaces it).

Contract:
    Reads  state.decision_action, state.decision_runbook, state.decision_reasoning
    Writes state.remediation_runbook, state.remediation_outcome, state.remediation_detail
"""

from __future__ import annotations

import logging
import os
from datetime import datetime, timezone

from models.agent_state import AgentState
from models.issue_profile import IssueProfile
from tools.automation_client import start_runbook
from tools.law_ingestion_client import write_agent_error

logger = logging.getLogger("ActAgent")


def act(state: AgentState) -> dict:
    """LangGraph node: execute judge's decision."""
    action   = state.get("decision_action", "remediate")
    runbook  = state.get("decision_runbook", "")
    rationale = state.get("decision_reasoning", "")

    profile: IssueProfile | None = state.get("issue_profile")
    escalation_target = profile.escalation_target if profile else ""

    # ── no_action / escalate_only: record and skip runbook ────────────
    if action == "no_action":
        return _skip(
            "no_action",
            f"Judge decision: no_action. {rationale}",
        )
    if action == "escalate_only":
        detail = (
            f"Judge decision: escalate_only. {rationale}\n"
            f"Escalation target: {escalation_target or '(none configured)'}\n"
            "No runbook executed; recycling would not fix an upstream cause."
        )
        return _skip("escalated", detail)

    # ── remediate / remediate_and_escalate: run the runbook ───────────
    if not runbook:
        return _skip(
            "failed",
            "Judge chose remediate but did not specify a runbook.",
        )

    hostname = os.environ.get("VM_HOSTNAME", "unknown")

    try:
        logger.info("ActAgent: executing runbook '%s' (action=%s)", runbook, action)
        result = start_runbook(
            runbook_name=runbook,
            parameters={
                "VMName":        os.environ.get("VM_NAME", hostname),
                "ResourceGroup": os.environ.get("RESOURCE_GROUP_NAME", ""),
            },
        )

        job_status = result.get("status", "Unknown")
        job_output = result.get("output", "")
        job_id     = result.get("job_id", "")

        if job_status == "Completed":
            outcome = "success"
            detail_lines = [
                rationale or f"Runbook {runbook} selected by judge.",
                f"Runbook '{runbook}' completed (job {job_id}).",
                f"Output: {job_output}" if job_output else "",
            ]
        else:
            outcome = "failed"
            detail_lines = [
                rationale or f"Runbook {runbook} selected by judge.",
                f"Runbook '{runbook}' finished with status '{job_status}' (job {job_id}).",
                f"Output: {job_output}" if job_output else "",
            ]

        if action == "remediate_and_escalate":
            detail_lines.append(
                f"Escalation flagged (target: {escalation_target or '(none configured)'}). "
                "Fix restored service but cause will recur -- human follow-up required."
            )

        return {
            "remediation_runbook": runbook,
            "remediation_outcome": outcome,
            "remediation_detail":  "\n".join(line for line in detail_lines if line),
        }

    except Exception as exc:
        logger.error("ActAgent error: %s", exc, exc_info=True)
        _log_error(exc)
        return {
            "remediation_runbook": runbook,
            "remediation_outcome": "failed",
            "remediation_detail":  f"Act agent encountered an error executing '{runbook}': {exc}",
        }


def _skip(outcome: str, detail: str) -> dict:
    """Record a no-op / escalation-only decision without touching Automation."""
    return {
        "remediation_runbook": "",
        "remediation_outcome": outcome,
        "remediation_detail":  detail,
    }


def _log_error(exc: Exception) -> None:
    try:
        write_agent_error({
            "TimeGenerated": datetime.now(timezone.utc).isoformat(),
            "Agent":         "ActAgent",
            "Error":         str(exc),
            "VMHostname":    os.environ.get("VM_HOSTNAME", "unknown"),
        })
    except Exception:
        pass
