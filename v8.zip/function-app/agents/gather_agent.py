"""Gather agent -- execute the profile's evidence plan in parallel.

This is the only node in the pipeline that touches ADX, baseline, or runs
capture-style runbooks.  It produces the `evidence` dict; every later node
reads from that dict rather than re-querying.

Contract:
    - Reads  state.issue_profile.gatherers
    - Writes state.evidence = { gatherer_value: <collected data> }
    - Gatherers run in parallel (ThreadPoolExecutor).  Failures in one
      gatherer log a warning and return None for that slot -- they never
      abort the whole evidence phase, because partial evidence is still
      better than none for judge / analyze.
    - No LLM.
"""

from __future__ import annotations

import logging
import os
from concurrent.futures import ThreadPoolExecutor, as_completed
from datetime import datetime, timezone
from typing import Any, Callable

from models.agent_state import AgentState
from models.issue_profile import Gatherer, IssueProfile
from tools.adx_client import query_iis_logs, query_iis_perf, query_vm_perf
from tools.baseline_client import get_latest_baseline
from tools.law_ingestion_client import write_agent_error
from tools.vm_client import check_http_health

logger = logging.getLogger("GatherAgent")


# ---------------------------------------------------------------------------
# Gatherer implementations.
# Each function signature: (hostname: str, public_host: str) -> Any
# public_host is the addressable IP/hostname for HTTP checks (may differ from
# the VM's internal hostname used in ADX 'Computer' columns).
# ---------------------------------------------------------------------------


def _gather_service_state(hostname: str, public_host: str) -> dict:
    """Cheap HTTP probe -- proxies for 'IIS is responding at all'."""
    return check_http_health(public_host)


def _gather_vm_perf_5m(hostname: str, public_host: str) -> list[dict]:
    return query_vm_perf(hostname, minutes=5)


def _gather_iis_perf_5m(hostname: str, public_host: str) -> list[dict]:
    return query_iis_perf(hostname, minutes=5)


def _gather_vm_perf_30m(hostname: str, public_host: str) -> list[dict]:
    return query_vm_perf(hostname, minutes=30)


def _gather_iis_perf_30m(hostname: str, public_host: str) -> list[dict]:
    return query_iis_perf(hostname, minutes=30)


def _gather_iis_logs_30m(hostname: str, public_host: str) -> list[dict]:
    return query_iis_logs(hostname, minutes=30)


def _gather_http_errors_7m(hostname: str, public_host: str) -> list[dict]:
    """HTTPERR rows from the last 7 minutes (503 AppOffline detection window)."""
    from tools.adx_client import query_adx
    kql = f"""
IISHttpErrors
| where Computer == '{hostname}'
| where TimeGenerated >= ago(7m)
| order by TimeGenerated desc
| take 200
"""
    return query_adx(kql)


def _gather_baseline(hostname: str, public_host: str) -> dict | None:
    """Stored PerformanceBaseline summary (p50/p95/p99), if available."""
    baseline = get_latest_baseline(hostname)
    return baseline.model_dump() if baseline else None


def _gather_not_implemented(hostname: str, public_host: str) -> dict:
    """Placeholder for capture-runbook gatherers that aren't deployed yet."""
    return {"status": "not_implemented",
            "note": "Capture runbook is a forward-looking dependency."}


_GATHERER_IMPL: dict[Gatherer, Callable[[str, str], Any]] = {
    Gatherer.SERVICE_STATE:         _gather_service_state,
    Gatherer.ADX_VM_PERF_5M:        _gather_vm_perf_5m,
    Gatherer.ADX_IIS_PERF_5M:       _gather_iis_perf_5m,
    Gatherer.ADX_VM_PERF_30M:       _gather_vm_perf_30m,
    Gatherer.ADX_IIS_PERF_30M:      _gather_iis_perf_30m,
    Gatherer.ADX_IIS_LOGS_30M:      _gather_iis_logs_30m,
    Gatherer.ADX_HTTP_ERRORS_7M:    _gather_http_errors_7m,
    Gatherer.BASELINE:              _gather_baseline,
    Gatherer.CAPTURE_EVENT_LOG:     _gather_not_implemented,
    Gatherer.CAPTURE_NETSTAT:       _gather_not_implemented,
    Gatherer.CAPTURE_REQUEST_QUEUE: _gather_not_implemented,
}


# ---------------------------------------------------------------------------
# Node entry point
# ---------------------------------------------------------------------------

def gather(state: AgentState) -> dict:
    """LangGraph node: collect all evidence declared by the profile.

    Returns a state update:
        evidence -- dict keyed by Gatherer.value
    """
    profile: IssueProfile | None = state.get("issue_profile")
    if profile is None or not profile.gatherers:
        logger.info("GatherAgent: no gatherers declared, skipping.")
        return {"evidence": {}}

    hostname    = os.environ.get("VM_HOSTNAME", "unknown")
    public_host = os.environ.get("VM_PUBLIC_IP", hostname)

    evidence: dict[str, Any] = {}

    # Parallel execution.  Failure in one gatherer shouldn't block the rest.
    with ThreadPoolExecutor(max_workers=min(8, len(profile.gatherers))) as pool:
        future_to_gatherer = {
            pool.submit(_GATHERER_IMPL[g], hostname, public_host): g
            for g in profile.gatherers
            if g in _GATHERER_IMPL
        }
        for fut in as_completed(future_to_gatherer):
            g = future_to_gatherer[fut]
            try:
                evidence[g.value] = fut.result()
            except Exception as exc:
                logger.warning("GatherAgent: gatherer '%s' failed: %s", g.value, exc)
                evidence[g.value] = None
                _log_error(g.value, exc)

    logger.info(
        "GatherAgent: collected %d/%d evidence slots for issue '%s'",
        sum(1 for v in evidence.values() if v is not None),
        len(profile.gatherers),
        state.get("issue_type", "unknown"),
    )

    return {"evidence": evidence}


def _log_error(gatherer_name: str, exc: Exception) -> None:
    try:
        write_agent_error({
            "TimeGenerated": datetime.now(timezone.utc).isoformat(),
            "Agent":         f"GatherAgent[{gatherer_name}]",
            "Error":         str(exc),
            "VMHostname":    os.environ.get("VM_HOSTNAME", "unknown"),
        })
    except Exception:
        # Error-logging failures are silent.  Never let a write_agent_error
        # failure propagate.
        pass
