# IIS Auto-Healing — Ready-for-Deployment Package

Self-contained drop for applying the last 3 days of changes (2026-04-19 → 2026-04-21) to an **existing** IIS Auto-Healing deployment.

**This package does NOT provision infrastructure.** It updates code only:
- Function App source (full replacement — `func` / zip-deploy)
- 5 runbooks in the Automation Account
- 1 VM scheduled-task script (`Send-PerfToEventHub.ps1`)

Managed identities, RBAC, private endpoints, DCRs, ADX tables, Event Hubs, alert rules, and LAW — all untouched.

---

## Package contents

```
readyfordeployment/
├── README.md                         (this file)
├── CHANGES.md                        what's new vs prior deployment
├── function-app/                     full source — ships as-is
│   ├── IISHealingOrchestratorInternal/
│   ├── IISMonitorPoller/
│   ├── agents/
│   ├── models/
│   ├── tools/
│   ├── host.json
│   ├── requirements.txt
│   └── local.settings.json.example
├── runbooks/                         5 changed .ps1 files
├── vm-scripts/
│   └── Send-PerfToEventHub.ps1
└── deploy/
    ├── Deploy-All.ps1                runs the 3 scripts below in order
    ├── Deploy-Runbooks.ps1
    ├── Deploy-VMScript.ps1
    └── Deploy-FunctionApp.ps1
```

---

## Prerequisites

The machine running the deploy must have:

1. **Azure CLI** (`az`) — v2.50+.  Log in with an identity that has:
   - `Contributor` (or `Website Contributor`) on the Function App
   - `Automation Contributor` on the Automation Account
   - `Virtual Machine Contributor` on the IIS VM
2. **PowerShell 7+** (pwsh).  Windows PowerShell 5.1 also works.
3. **Network line-of-sight** to the target resources.  In a private-endpoint environment this usually means one of:
   - A jumpbox inside the VNet with the Private DNS zones linked, or
   - A VPN / Bastion session into the VNet, or
   - A self-hosted Azure DevOps / GitHub Actions runner inside the VNet.
4. *(Optional)* **Azure Functions Core Tools** (`func` v4+).  Only needed if you want `-BuildRemote $true` for the Function App — the default path uses `az functionapp deployment source config-zip` and does **not** require `func`.

---

## Quick start

```powershell
# 1. Copy the readyfordeployment folder to the jumpbox / runner.
# 2. Open pwsh as a user who has run `az login` to the target subscription.
cd readyfordeployment\deploy

# 3. Run the master script with parameters matching the hardened environment.
#    All parameters have defaults matching the original iisheals-* naming.
.\Deploy-All.ps1 `
    -CoreResourceGroup    'your-core-rg' `
    -MonitorResourceGroup 'your-monitor-rg' `
    -FunctionAppName      'your-func-app' `
    -AutomationAccount    'your-auto-account' `
    -VMName               'your-iis-vm'
```

Takes ~5-10 minutes end-to-end (Function App remote build dominates).

### Or run pieces individually

```powershell
cd readyfordeployment\deploy

.\Deploy-Runbooks.ps1    -AutomationAccount '...' -ResourceGroup '...'
.\Deploy-VMScript.ps1    -VMName '...'            -ResourceGroup '...'
.\Deploy-FunctionApp.ps1 -FunctionAppName '...'   -ResourceGroup '...'
```

---

## Private endpoint notes

| Resource | What the script calls | Endpoint used |
|---|---|---|
| Function App code | `az functionapp deployment source config-zip` | ARM → Kudu (SCM).  SCM private endpoint must be reachable from the host. |
| Runbooks | `az automation runbook replace-content` / `publish` | ARM.  Works via public ARM endpoint; Automation Account private endpoint (if any) only affects Hybrid Worker traffic, not ARM control plane. |
| VM script | `az vm run-command invoke` | ARM → Azure Guest Agent.  Works over public ARM; VM does not need inbound connectivity. |

If the Function App SCM endpoint is fully locked to private, run `Deploy-FunctionApp.ps1` from the jumpbox / runner that has the Private DNS zone `privatelink.azurewebsites.net` resolving to the private IP.

---

## Verification

After `Deploy-All.ps1` finishes:

```kql
// 1. Function App picked up the new code (within ~60s of deploy)
AgentEvents_CL
| where TimeGenerated > ago(15m)
| project TimeGenerated, IssueType, RunbookExecuted, RetryCount, IsHealthy
| order by TimeGenerated desc

// 2. Send-PerfToEventHub.ps1 picked up the new script (within ~60s)
IISPerf
| where TimeGenerated > ago(5m)
| where CounterName in ("Current Connections", "Site State", "Pool Identity Status")
| summarize count() by CounterName
```

### Smoke test (w3svc path)

```powershell
# On the IIS VM (via Bastion or RDP)
Stop-Service W3SVC -Force

# Wait ~3 min, then check ADX / LAW:
#   AgentEvents_CL | where TimeGenerated > ago(10m)
# Expect:  IssueType=w3svc_stopped  RunbookExecuted=Invoke-RestartW3SVC  RetryCount=0  IsHealthy=true
```

---

## Rollback

Each target supports straightforward rollback without this package:

- **Runbooks:** Automation Account keeps a version history.  In the portal: Automation Account → Runbooks → *(name)* → Source control integration / Edit → prior draft → Publish.
- **Function App:** Azure keeps previous deployments.  Portal: Function App → Deployment Center → Logs → prior deployment → Redeploy.  Or redeploy a known-good package.
- **VM script:** Re-run `Deploy-VMScript.ps1` from a prior package, or RDP to VM and overwrite `C:\Scripts\Send-PerfToEventHub.ps1`.
