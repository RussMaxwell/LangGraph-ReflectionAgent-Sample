# IIS Auto-Healing — v2 (enterprise-network variant)

Self-contained variant of the base `iis-autohealing/` solution, adapted for
deployment into an enterprise-owned, pre-existing Azure VNet with private
endpoints on every service.

## Purpose

Same functional system as the base solution (deterministic + AI IIS healing
pipeline on an Azure Function App, with Automation runbooks, Event Hubs → ADX
telemetry, Log Analytics/DCRs, and Azure OpenAI) — but:

- **No VNet/subnet/NSG creation.** Plugs into an existing enterprise VNet.
- **No Azure Bastion.** VM has only a private IP; access via enterprise network.
- **Private endpoints** for Automation, Function App, Storage (blob/file/queue/
  table), AMPLS (LAW + DCE), Event Hubs, ADX, OpenAI.
- **PowerShell 5.1** runbooks only (no PS7 MSI install on the VM).
- **Function App** on S1 Standard with VNet integration + sites PE, deployed
  via `WEBSITE_RUN_FROM_PACKAGE` (SCM is private, `func publish` will not work).
- **Private DNS** zones created locally by default, or point at a pre-existing
  shared-DNS RG via `existingPrivateDnsZonesResourceGroup`.

## Prerequisites

### Before deploying (enterprise network team owns these)

- An existing VNet (default name:
  `non-prod_vnet-openshift-for-card-service-eastus2-277f`), address-space known.
- Three subnets inside that VNet, already created:
  - **vmSubnet** — for the VM NIC.
  - **peSubnet** — with `privateEndpointNetworkPolicies: Disabled`.
  - **faIntegrationSubnet** — with `Microsoft.Web/serverFarms` delegation.
- NSGs as required by enterprise policy (owned by the network team; this stack
  does not create or modify them).

### Deploy machine requirements

- `az`, `bash`, `jq`, `base64`, `zip`, `curl`.
- Azure login with at least:
  - `Contributor` on the two target RGs (`iis-core`, `iis-core-monitor`).
  - `Network Contributor` on the existing VNet (needed to create private
    endpoints referencing its subnets).
  - `Storage Blob Data Contributor` on the Function App's storage account
    (needed for `--auth-mode login` upload + user-delegation SAS).
  - `User Access Administrator` (or equivalent) if this is the first deploy
    and RBAC module needs to place role assignments.
- Network reach to the VM's private IP is **optional** — the provided
  `deploy.sh` uses `az vm run-command` (management plane) for all in-VM work.

## How to deploy

1. Fill in the enterprise-network parameters in
   `v2/infra/parameters/dev.bicepparam`:
   ```
   param existingVnetResourceGroup = '<ask-network-team>'
   param vmSubnetName              = '<subnet-name>'
   param peSubnetName              = '<subnet-name>'
   param faIntegrationSubnetName   = '<subnet-name>'
   ```
   Optionally set `existingPrivateDnsZonesResourceGroup` to the RG that holds
   the shared private DNS zones if your enterprise already maintains them.
2. Export the VM admin password:
   ```bash
   export VM_ADMIN_PASSWORD='YourP@ssw0rd!'
   ```
3. Run the deploy script:
   ```bash
   bash v2/scripts/deploy.sh
   ```

The script validates prereqs, runs a subscription-scope Bicep deployment,
creates ADX data connections after an RBAC-propagation wait, configures DCRs,
deploys the chaos app to the VM via `az vm run-command`, and finally publishes
the Function App package via `WEBSITE_RUN_FROM_PACKAGE` (briefly allowlisting
the caller's IP on the otherwise-private Function storage account, then
revoking it after the upload).

## Differences vs the base `infra/`

| Area | Base (`infra/`) | v2 (`v2/infra/`) |
|---|---|---|
| VNet | creates its own | references existing enterprise VNet |
| Subnets | creates VM + AzureBastion subnets | references vm / pe / faIntegration subnets |
| NSG | creates one | relies on enterprise NSGs |
| Bastion | deployed | removed |
| VM public IP | none (Bastion) | none (enterprise network) |
| Automation | public | `publicNetworkAccess=false` + PE |
| Runbook type | `PowerShell72` | `PowerShell` (5.1) |
| Function App plan | B1 Basic (Linux) | S1 Standard (Linux) |
| Function App public | enabled | `publicNetworkAccess=Disabled` + PE + VNet integration |
| Function Storage | public | `publicNetworkAccess=Disabled` + PE (blob/file/queue/table) |
| Function code deploy | `func azure functionapp publish` | run-from-package via SAS URL |
| Event Hubs | public | PE (servicebus zone) |
| ADX | public | PE (kusto zone) |
| OpenAI | public | PE (openai zone) |
| LAW + DCE | public | AMPLS + PE (monitor/oms/ods/agentsvc zones) |
| Private DNS | none | 13 zones created (or referenced) + vnetLinks to VNet |
| PS7 install on VM | yes | removed |

## Files changed/added vs base

New:
- `v2/infra/modules/private_dns.bicep`
- `v2/infra/modules/private_endpoints.bicep`

Rewritten:
- `v2/infra/main.bicep` — networking params, no Bastion, adds PE/DNS modules.
- `v2/infra/modules/networking.bicep` — lookup-only existing VNet+subnets.
- `v2/infra/modules/vm.bicep` — param renamed `subnetId` → `vmSubnetId`.
- `v2/infra/modules/automation.bicep` — `publicNetworkAccess=false`, runbookType `PowerShell`.
- `v2/infra/modules/functionapp.bicep` — S1, PE-friendly storage/network, VNet integration, run-from-package.
- `v2/scripts/deploy.sh` — no PS7, no Bastion, run-from-package deploy.
- `v2/infra/parameters/dev.bicepparam` — new network parameters.

Copied unchanged:
- `v2/function-app/`, all other `v2/infra/modules/*.bicep`, all runbooks,
  and supporting scripts (`setup-iis.ps1`, `Send-PerfToEventHub.ps1`,
  `load_test.sh`, `run_baseline.sh`, `teardown.sh`, `test_chaos.sh`,
  `validate_agent.sh`).
