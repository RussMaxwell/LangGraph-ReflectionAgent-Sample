"""Classify agent -- alert text -> issue_type -> IssueProfile.

No LLM.  The alert name/rule/description is matched against a priority-ordered
substring list to determine the issue_type, then the corresponding IssueProfile
is loaded from the profile registry.  The profile drives every downstream node.

Alerts whose text doesn't match any pattern fall through to the `unknown`
profile, whose strategy is REASONED and whose gatherers pull broad telemetry
so judge_agent can reason from scratch.
"""

from __future__ import annotations

import logging

from models.agent_state import AgentState
from agents.profiles import PROFILES, get_profile

logger = logging.getLogger("ClassifyAgent")


# ---------------------------------------------------------------------------
# Alert-rule substring -> issue_type.
# Evaluated in order.  First match wins.
# ---------------------------------------------------------------------------
_ALERT_TO_ISSUE: list[tuple[str, str]] = [
    # ── Mechanical ─────────────────────────────────────────────────────
    ("iis current connections",      "w3svc_stopped"),
    ("iis down",                     "w3svc_stopped"),
    ("asp.net application restarts", "app_pool_crash"),
    ("aspnet restarts",              "app_pool_crash"),
    ("app pool stopped",             "app_pool_stopped"),
    ("appoffline",                   "app_pool_stopped"),
    ("c: drive free",                "log_disk_full"),
    ("disk space",                   "log_disk_full"),
    ("free space",                   "log_disk_full"),
    ("failed connection attempts",   "binding_missing"),
    ("failed connections",           "binding_missing"),
    ("app pool identity",            "app_pool_identity"),
    ("bad permissions",              "bad_permissions"),

    # ── Performance (mechanical fix + deep RCA) ────────────────────────
    ("w3wp cpu",                     "high_cpu_w3wp"),
    ("processor queue",              "high_cpu"),
    ("processor time",               "high_cpu"),
    ("cpu high",                     "high_cpu"),
    ("vm cpu",                       "high_cpu"),

    # ── Symptom-class (reasoned) ───────────────────────────────────────
    ("w3wp working set",             "memory_leak"),
    ("w3wp memory",                  "memory_leak"),
    ("w3wp thread count",            "worker_process_hang"),
    ("w3wp threads",                 "worker_process_hang"),
    ("thread count",                 "worker_process_hang"),
    ("requests queued",              "request_queue_flood"),
    ("asp.net requests",             "request_queue_flood"),
    ("not found errors",             "bad_http_errors"),
    ("http 404",                     "bad_http_errors"),
    ("404",                          "bad_http_errors"),
    ("available memory",             "high_memory"),
    ("memory low",                   "high_memory"),
    ("memory committed",             "high_memory"),
    ("paging",                       "high_memory"),
    ("disk queue",                   "high_disk_io"),

    # ── Reasoned-with-veto (forward-looking) ───────────────────────────
    # Wire up once IISMonitorPoller emits a 5xx-flood breach.
    ("http 5xx",                     "http_5xx_flood"),
    ("5xx errors",                   "http_5xx_flood"),
    ("server errors",                "http_5xx_flood"),
]


def classify(state: AgentState) -> dict:
    """LangGraph node: resolve the alert to an issue_type and load its profile.

    Returns a state update containing:
        issue_type      -- key into PROFILES (defaults to 'unknown')
        issue_summary   -- human-readable context string
        issue_profile   -- IssueProfile row; every downstream node reads this
    """
    alert = state["alert_payload"]

    alert_name_raw: str = getattr(alert, "alert_name", "") or ""
    alert_rule: str = ""
    severity: str = getattr(alert, "severity", "") or ""
    description: str = ""

    if alert.essentials:
        alert_rule = getattr(alert.essentials, "alert_rule", "") or ""
        severity = severity or (getattr(alert.essentials, "severity", "") or "")
        description = getattr(alert.essentials, "description", "") or ""

    # Composite search text: display name + resource rule name (hyphens
    # normalised to spaces) + description.  Lowercased for case-insensitive
    # matching.
    search_text = " ".join(filter(None, [
        alert_name_raw,
        alert_rule.replace("-", " "),
        description,
    ])).lower()

    alert_display = alert_name_raw or alert_rule or "(unknown)"

    issue_type = "unknown"
    for substring, matched_issue in _ALERT_TO_ISSUE:
        if substring in search_text:
            issue_type = matched_issue
            break

    profile = get_profile(issue_type)

    issue_summary = (
        f"{profile.label} "
        f"(alert: '{alert_display}', severity: {severity})"
    )
    if description:
        issue_summary += f". {description}"

    logger.info(
        "ClassifyAgent: alert='%s' -> issue_type='%s' strategy='%s' "
        "runbook='%s' analyze=%s",
        alert_display,
        issue_type,
        profile.strategy.value,
        profile.default_runbook,
        profile.analyze,
    )

    return {
        "issue_type": issue_type,
        "issue_summary": issue_summary,
        "issue_profile": profile,
    }


# Keep the registry visible for tests / external tooling.
__all__ = ["classify", "_ALERT_TO_ISSUE", "PROFILES"]
