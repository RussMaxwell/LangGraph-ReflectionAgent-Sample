"""LangGraph orchestrator -- single-path, profile-driven healing pipeline.

══════════════════════════════════════════════════════════════════════════════
              IIS AUTO-HEALING  —  LANGGRAPH FLOW v3.0
                  Single path · profile-driven · data-variant
══════════════════════════════════════════════════════════════════════════════

Every alert walks the same six nodes.  Behavioural variance per issue_type
lives in the IssueProfile loaded by `classify` from `agents/profiles.py`.

  START
    │
    ▼
  ┌──────────┐   resolve alert text → issue_type → IssueProfile
  │ classify │   no LLM
  └────┬─────┘
       ▼
  ┌──────────┐   execute profile.gatherers in parallel
  │  gather  │   no LLM (gatherers are pure data collectors)
  └────┬─────┘
       ▼
  ┌──────────┐   dispatch on profile.strategy:
  │  judge   │     MECHANICAL          → no LLM, pick profile.default_runbook
  │          │     REASONED            → gpt-4o-mini, action ∈ {remediate, no_action}
  │          │     REASONED_WITH_VETO  → gpt-4o-mini, adds escalate_only +
  │          │                          remediate_and_escalate
  └────┬─────┘   output: decision_action + decision_runbook + reasoning
       │
       ├─── decision_action == "no_action" ──────┐
       ├─── decision_action == "escalate_only" ──┤
       ▼                                          │
  ┌──────────┐   execute runbook via Automation   │
  │   act    │   (skip for no_action/escalate_only)
  └────┬─────┘                                    │
       ▼                                          │
  ┌──────────┐   run profile.confirmation checks  │
  │ confirm  │   no LLM                           │
  └────┬─────┘                                    │
       │                                          │
       ├── !is_healthy, retry_count < 2 ──►       │
       │     retry_count += 1  →  back to judge  │  (judge re-evaluates with
       │                                          │   new retry_count, picking
       │                                          │   profile.escalation_runbook)
       │                                          │
       ├── is_healthy (or retries exhausted)      │
       ▼                                          ▼
  ┌──────────┐   if profile.analyze: o4-mini RCA on preserved evidence
  │ analyze  │   (skippable; mechanical profiles typically skip)
  └────┬─────┘
       ▼
  ┌──────────┐   write AgentEvents_CL record (no LLM)
  │summarize │
  └────┬─────┘
       ▼
      END

══════════════════════════════════════════════════════════════════════════════
Retry loops to JUDGE (not act).  Rationale: on retry, the decision itself
may change -- a different runbook, or a veto, or escalation.  Mechanical
profiles make retry cheap (no LLM): judge reads profile.escalation_runbook
and returns it deterministically.
══════════════════════════════════════════════════════════════════════════════
"""

from __future__ import annotations

import logging
from typing import Any

from langgraph.graph import END, StateGraph

from models.agent_state import AgentState

from agents.classify_agent import classify
from agents.gather_agent   import gather
from agents.judge_agent    import judge
from agents.act_agent      import act
from agents.confirm_agent  import confirm
from agents.analyze_agent  import analyze
from agents.summarize_agent import summarize

logger = logging.getLogger("HealingOrchestrator")

_MAX_RETRIES = 2


# ---------------------------------------------------------------------------
# Conditional edge functions
# ---------------------------------------------------------------------------

def _route_after_judge(state: AgentState) -> str:
    """After judge: act (runbook) or skip straight to analyze."""
    action = state.get("decision_action", "remediate")
    # no_action and escalate_only: act records the decision without running
    # anything, then we skip confirm entirely (nothing to re-check) and go
    # directly to analyze → summarize.
    if action in ("no_action", "escalate_only"):
        return "act"
    return "act"


def _route_after_act(state: AgentState) -> str:
    """After act: confirm (if a runbook actually ran) or skip to analyze.

    Skipping confirm for no_action/escalate_only avoids running health checks
    that would always fail (for escalate_only the underlying issue is still
    present) and routing into the retry loop incorrectly.
    """
    action = state.get("decision_action", "remediate")
    if action in ("no_action", "escalate_only"):
        return "analyze"
    return "confirm"


def _route_after_confirm(state: AgentState) -> str:
    """After confirm: analyze (healthy or retries exhausted) or retry."""
    if state.get("is_healthy", False):
        return "analyze"
    if state.get("retry_count", 0) < _MAX_RETRIES:
        return "retry"
    logger.info("ConfirmAgent: max retries reached (%d) — proceeding to analyze.", _MAX_RETRIES)
    return "analyze"


def _route_after_analyze(state: AgentState) -> str:
    """After analyze: always summarize.  Kept as a named edge for symmetry."""
    return "summarize"


# ---------------------------------------------------------------------------
# Retry helper (no-LLM state mutation node)
# ---------------------------------------------------------------------------

def _increment_retry(state: AgentState) -> dict:
    new_count = state.get("retry_count", 0) + 1
    logger.info("Incrementing retry_count to %d", new_count)
    return {"retry_count": new_count}


# ---------------------------------------------------------------------------
# Pre-analyze gate -- skip analyze if the profile says so
# ---------------------------------------------------------------------------

def _maybe_analyze(state: AgentState) -> dict:
    """Pass-through node that respects profile.analyze.

    LangGraph runs nodes unconditionally; this wrapper lets us keep the
    `analyze` slot in the graph while honouring the profile's opt-out, without
    a separate conditional edge.
    """
    profile = state.get("issue_profile")
    if profile is not None and not profile.analyze:
        logger.info("AnalyzeAgent: profile.analyze=False, skipping RCA.")
        return {}
    return analyze(state)


# ---------------------------------------------------------------------------
# Graph construction
# ---------------------------------------------------------------------------

def build_graph() -> Any:
    """Construct and compile the single-path healing graph."""
    graph = StateGraph(AgentState)

    # ── Nodes ──────────────────────────────────────────────────────────
    graph.add_node("classify",  classify)
    graph.add_node("gather",    gather)
    graph.add_node("judge",     judge)
    graph.add_node("act",       act)
    graph.add_node("confirm",   confirm)
    graph.add_node("analyze",   _maybe_analyze)
    graph.add_node("summarize", summarize)
    graph.add_node("retry",     _increment_retry)

    # ── Linear spine ───────────────────────────────────────────────────
    graph.set_entry_point("classify")
    graph.add_edge("classify", "gather")
    graph.add_edge("gather",   "judge")

    # ── Judge → act (always) ───────────────────────────────────────────
    # Both remediate and no_action/escalate_only flow through `act` so that
    # state.remediation_* fields are populated uniformly.
    graph.add_edge("judge", "act")

    # ── Act → confirm (for runbook runs) OR act → analyze (for skips) ──
    graph.add_conditional_edges(
        "act",
        _route_after_act,
        {"confirm": "confirm", "analyze": "analyze"},
    )

    # ── Confirm → analyze (done) OR retry ──────────────────────────────
    graph.add_conditional_edges(
        "confirm",
        _route_after_confirm,
        {"analyze": "analyze", "retry": "retry"},
    )

    # ── Retry → judge (re-decide with new retry_count) ─────────────────
    graph.add_edge("retry", "judge")

    # ── Analyze → summarize → END ──────────────────────────────────────
    graph.add_edge("analyze",   "summarize")
    graph.add_edge("summarize", END)

    return graph.compile()


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------

def run_healing_pipeline(alert_payload: dict) -> dict:
    """Compile and execute the full healing pipeline.

    Parameters
    ----------
    alert_payload : dict
        Raw Azure Monitor common alert schema payload.

    Returns
    -------
    dict
        Final AgentState after pipeline completion.
    """
    from models.alert_payload import AlertPayload

    parsed_alert = AlertPayload.model_validate(alert_payload)
    initial_state: dict = build_initial_state(parsed_alert)
    compiled_graph = build_graph()
    return dict(compiled_graph.invoke(initial_state))


def build_initial_state(parsed_alert: Any) -> dict:
    """Blank state for a fresh pipeline invocation.

    Exposed for entrypoint modules that need to invoke the graph directly
    (rather than going through run_healing_pipeline) so they can wrap
    graph.invoke() with custom error handling.
    """
    return {
        "alert_payload":       parsed_alert,

        "issue_type":          "",
        "issue_summary":       "",
        "issue_profile":       None,

        "evidence":            {},

        "decision_action":     "",
        "decision_runbook":    "",
        "decision_reasoning":  "",
        "decision_confidence": "",

        "remediation_runbook": "",
        "remediation_outcome": "",
        "remediation_detail":  "",

        "is_healthy":          False,
        "confirm_detail":      "",

        "analysis_result":     "",
        "root_cause":          "",
        "next_steps":          [],
        "baseline_summary":    None,

        "retry_count":         0,
        "errors":              [],

        "event_log_entry":     {},
    }


__all__ = ["build_graph", "run_healing_pipeline", "build_initial_state"]
