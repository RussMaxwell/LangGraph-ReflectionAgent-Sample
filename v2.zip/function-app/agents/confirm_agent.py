"""Confirm agent -- run the profile's health checks, set is_healthy.

No LLM.  The profile declares a tuple of Check values; every declared check
must pass for is_healthy = True.  If any required ADX counter is missing
(ingestion lag, for example), the check is treated as not-yet-confirmed and
we return not healthy -- the retry loop handles re-checking.

Contract:
    Reads  state.issue_profile.confirmation
    Writes state.is_healthy, state.confirm_detail
"""

from __future__ import annotations

import logging
import os
from datetime import datetime, timezone

from models.agent_state import AgentState
from models.issue_profile import Check, IssueProfile
from tools.adx_client import query_adx, query_latest_counter
from tools.law_ingestion_client import write_agent_error
from tools.vm_client import check_http_health

logger = logging.getLogger("ConfirmAgent")


# ---------------------------------------------------------------------------
# Thresholds for counter-based checks.  Kept here (not in the profile) because
# these are physical facts about IIS/Windows, not per-issue knobs.
# ---------------------------------------------------------------------------
_CPU_HEALTHY_BELOW_PCT          = 85.0
_DISK_FREE_HEALTHY_ABOVE_PCT    = 5.0
_FIVE_XX_HEALTHY_BELOW_FRACTION = 0.05  # 5% of requests


def confirm(state: AgentState) -> dict:
    """LangGraph node: run the profile's health checks.

    If the prior action was no_action or escalate_only, confirm still runs but
    its result doesn't loop back to judge -- the orchestrator routes those
    actions directly to summarize.  (See orchestrator._route_after_act.)
    """
    profile: IssueProfile | None = state.get("issue_profile")
    if profile is None or not profile.confirmation:
        return {"is_healthy": False, "confirm_detail": "No confirmation checks defined."}

    hostname    = os.environ.get("VM_HOSTNAME", "unknown")
    public_host = os.environ.get("VM_PUBLIC_IP", hostname)

    failed_checks: list[str] = []
    passed_checks: list[str] = []
    detail_lines:  list[str] = []

    for check in profile.confirmation:
        try:
            ok, line = _run_check(check, hostname, public_host)
        except Exception as exc:
            logger.warning("ConfirmAgent: check '%s' raised %s", check.value, exc)
            _log_error(check.value, exc)
            ok, line = False, f"{check.value}: error ({exc})"

        detail_lines.append(line)
        (passed_checks if ok else failed_checks).append(check.value)

    is_healthy = (len(failed_checks) == 0)

    logger.info(
        "ConfirmAgent: healthy=%s passed=%s failed=%s",
        is_healthy, passed_checks, failed_checks,
    )

    return {
        "is_healthy":     is_healthy,
        "confirm_detail": "\n".join(detail_lines),
    }


# ---------------------------------------------------------------------------
# Individual check implementations
# ---------------------------------------------------------------------------

def _run_check(check: Check, hostname: str, public_host: str) -> tuple[bool, str]:
    if check is Check.HTTP_OK:
        return _check_http_ok(public_host)
    if check is Check.CPU_BELOW_THRESHOLD:
        return _check_counter_below(
            "VMPerf", hostname, "% Processor Time", _CPU_HEALTHY_BELOW_PCT,
        )
    if check is Check.DISK_FREE_ABOVE_THRESHOLD:
        return _check_counter_above(
            "VMPerf", hostname, "% Free Space", _DISK_FREE_HEALTHY_ABOVE_PCT,
        )
    if check is Check.FIVE_XX_RATE_BELOW:
        return _check_five_xx_rate(hostname, _FIVE_XX_HEALTHY_BELOW_FRACTION)
    if check is Check.W3WP_RUNNING:
        return _check_w3wp_running(hostname)

    return False, f"{check.value}: unknown check"


def _check_http_ok(public_host: str) -> tuple[bool, str]:
    result = check_http_health(public_host)
    code   = result.get("status_code")
    ok     = code == 200
    return ok, f"http_ok: status={code}"


def _check_counter_below(table: str, hostname: str, counter: str, threshold: float) -> tuple[bool, str]:
    value = query_latest_counter(table=table, hostname=hostname, counter_name=counter)
    if value is None:
        return False, f"{counter}: no recent data (ingestion lag?)"
    return (value < threshold), f"{counter}: {value:.2f} (threshold < {threshold})"


def _check_counter_above(table: str, hostname: str, counter: str, threshold: float) -> tuple[bool, str]:
    value = query_latest_counter(table=table, hostname=hostname, counter_name=counter)
    if value is None:
        return False, f"{counter}: no recent data (ingestion lag?)"
    return (value > threshold), f"{counter}: {value:.2f} (threshold > {threshold})"


def _check_five_xx_rate(hostname: str, max_fraction: float) -> tuple[bool, str]:
    """Check 5xx/total ratio in the last 5 minutes of IISLogsParsed."""
    kql = f"""
IISLogsParsed
| where Computer == '{hostname}'
| where TimeGenerated >= ago(5m)
| summarize total = count(),
            five_xx = countif(StatusCode >= 500 and StatusCode < 600)
"""
    rows = query_adx(kql)
    if not rows:
        return False, "five_xx_rate: no recent IIS logs"
    total = rows[0].get("total") or 0
    five_xx = rows[0].get("five_xx") or 0
    if total == 0:
        # No traffic -- can't prove 5xx is low, but HTTP check will cover
        # whether IIS is serving.  Treat as pass if there's simply no load.
        return True, "five_xx_rate: no traffic in last 5 min"
    fraction = float(five_xx) / float(total)
    return (fraction < max_fraction), (
        f"five_xx_rate: {five_xx}/{total} = {fraction:.1%} "
        f"(threshold < {max_fraction:.0%})"
    )


def _check_w3wp_running(hostname: str) -> tuple[bool, str]:
    """Any recent IISPerf row for the w3wp process counts as 'running'."""
    kql = f"""
IISPerf
| where Computer == '{hostname}'
| where InstanceName contains 'w3wp'
| where TimeGenerated >= ago(3m)
| take 1
"""
    rows = query_adx(kql)
    ok = len(rows) > 0
    return ok, f"w3wp_running: {'yes' if ok else 'no heartbeat in last 3 min'}"


def _log_error(check_name: str, exc: Exception) -> None:
    try:
        write_agent_error({
            "TimeGenerated": datetime.now(timezone.utc).isoformat(),
            "Agent":         f"ConfirmAgent[{check_name}]",
            "Error":         str(exc),
            "VMHostname":    os.environ.get("VM_HOSTNAME", "unknown"),
        })
    except Exception:
        pass
