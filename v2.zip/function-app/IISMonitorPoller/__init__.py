"""IISMonitorPoller -- Timer-triggered ADX polling function.

Runs every 60 seconds. Queries the VMPerf and IISPerf ADX tables for threshold
breaches that mirror the original 15 Azure Monitor alert conditions. When a
breach is detected, fires an HTTP POST to IISHealingOrchestratorInternal and
then observes a 10-minute cooldown to prevent duplicate healing runs.

Cooldown state is persisted in Azure Table Storage (healingcooldown table) so
it survives cold starts and is shared across any scale-out instances.

Replaces: Azure Monitor scheduledQueryRules + Action Group webhook.
"""

from __future__ import annotations

import logging
import os
import time
from datetime import datetime, timezone
from typing import Optional

import azure.functions as func
import requests
from requests.exceptions import ReadTimeout
from azure.core.exceptions import ResourceExistsError, ResourceNotFoundError
from azure.data.tables import TableServiceClient

logger = logging.getLogger("IISMonitorPoller")

# ---------------------------------------------------------------------------
# Cooldown — persisted in Azure Table Storage so it survives cold starts and
# is shared across scale-out instances.
# ---------------------------------------------------------------------------
_COOLDOWN_TABLE     = "healingcooldown"
_COOLDOWN_PARTITION = "state"
_COOLDOWN_ROW       = "last_trigger"
COOLDOWN_SECONDS    = 300  # 5 minutes — covers 3 m look-back + 60 s script cycle + buffer


def _get_table_service() -> TableServiceClient:
    conn_str = os.environ.get("AzureWebJobsStorage", "")
    return TableServiceClient.from_connection_string(conn_str)


# Table client cached at module level — created once per worker process lifetime.
# This avoids the POST /Tables on every invocation that produces a noisy 409
# (table already exists) in the log stream.
_table_client = None

def _get_cooldown_client():
    global _table_client
    if _table_client is None:
        svc = _get_table_service()
        svc.create_table_if_not_exists(_COOLDOWN_TABLE)
        _table_client = svc.get_table_client(_COOLDOWN_TABLE)
    return _table_client


def _get_last_trigger_time() -> float:
    try:
        client = _get_cooldown_client()
        entity = client.get_entity(_COOLDOWN_PARTITION, _COOLDOWN_ROW)
        return float(entity.get("LastTriggerTime", 0))
    except ResourceNotFoundError:
        return 0.0
    except Exception as exc:
        logger.warning("Could not read cooldown state: %s", exc)
        return 0.0


def _set_last_trigger_time(timestamp: float) -> None:
    try:
        client = _get_cooldown_client()
        client.upsert_entity({
            "PartitionKey": _COOLDOWN_PARTITION,
            "RowKey":       _COOLDOWN_ROW,
            "LastTriggerTime": str(timestamp),
        })
    except Exception as exc:
        logger.error("Failed to persist cooldown: %s", exc)


# ---------------------------------------------------------------------------
# Priority-ordered issue types.
# When multiple conditions breach simultaneously, the first match wins.
# Severity 1 (Critical) → Severity 2 (High) → Severity 3 (Medium)
# ---------------------------------------------------------------------------
_PRIORITY: list[str] = [
    "w3svc_stopped",       # Sev 1 — IIS down
    "app_pool_stopped",    # Sev 1 — rapid-fail protection engaged; pool permanently stopped, 503s being served
    "app_pool_crash",      # Sev 1 — ASP.NET restarts
    "log_disk_full",       # Sev 1 — C: drive critical
    "high_cpu_w3wp",       # Sev 2 — w3wp CPU
    "memory_leak",         # Sev 2 — w3wp working set
    "high_memory",         # Sev 2 — VM memory
    "high_cpu",            # Sev 2 — VM CPU
    "binding_missing",     # Sev 2 — failed connections
    "request_queue_flood", # Sev 2 — ASP.NET queue
    "high_disk_io",        # Sev 2 — disk queue
    "worker_process_hang", # Sev 3 — w3wp threads
    "bad_http_errors",     # Sev 3 — 404 rate
]

# ---------------------------------------------------------------------------
# KQL — VMPerf breach detection
#
# Uses a 7-minute look-back window.  ADX ingestion batching is capped at 30s
# and Send-PerfToEventHub.ps1 runs every 60s, so data is queryable within
# ~90s of collection.  7 minutes is longer than the 5-minute cooldown period
# so that a breach that fired while the poller was cooling down is still
# visible when the poller comes back online.  (With a 3-minute window, any
# issue that coincides with a cooldown period would be permanently invisible:
# cooldown expires at T+5m, but ago(3m) only reaches back to T+2m.)
# InstanceName == "C:" is explicit on disk-space to avoid false positives
# from other volumes if the script is ever extended.
# ---------------------------------------------------------------------------
_VM_PERF_KQL = """\
let hostname = '{hostname}';
VMPerf
| where Computer == hostname
| where TimeGenerated >= ago(7m)
// in~ is case-insensitive: Windows PerfMon path strings are lowercased by
// Get-Counter, so counter names land in ADX as e.g. "% processor time".
| where CounterName in~ (
    "% Processor Time",
    "Available MBytes",
    "% Committed Bytes In Use",
    "Pages/sec",
    "% Free Space",
    "Avg. Disk Queue Length",
    "Processor Queue Length"
  )
| summarize
    AvgValue    = avg(CounterValue),
    MaxValue    = max(CounterValue),
    // HighSamples counts how many 10-second samples exceeded 85%.
    // Requires >= 2 to fire, meaning CPU was above 85% for at least ~20 seconds.
    // A single transient 1-second spike produces at most 1 high sample and is
    // ignored.  All other counters use AvgValue/MaxValue; HighSamples is computed
    // for every group but only referenced in the CPU branch below.
    HighSamples = countif(CounterValue > 85),
    RowCount    = count()
  by CounterName, ObjectName, InstanceName
| extend
    // =~ is case-insensitive for CounterName/InstanceName (values are lowercase
    // from Get-Counter); ObjectName is set from script hardcoded strings so case
    // is already correct and == is fine there.
    IsBreached = case(
        CounterName =~ "% Processor Time"       and ObjectName == "Processor"   and HighSamples >= 2, true,
        CounterName =~ "Available MBytes"                                         and AvgValue < 512,   true,
        CounterName =~ "% Committed Bytes In Use"                                 and AvgValue > 90,    true,
        CounterName =~ "Pages/sec"              and ObjectName == "Memory"        and AvgValue > 1000,  true,
        CounterName =~ "% Free Space"           and ObjectName == "LogicalDisk"   and InstanceName =~ "C:" and AvgValue < 5, true,
        CounterName =~ "Avg. Disk Queue Length" and ObjectName == "PhysicalDisk"  and AvgValue > 5,     true,
        CounterName =~ "Processor Queue Length" and ObjectName == "System"        and AvgValue > 10,    true,
        false
    ),
    IssueType = case(
        CounterName =~ "% Processor Time"       and ObjectName == "Processor",   "high_cpu",
        CounterName =~ "Available MBytes",                                        "high_memory",
        CounterName =~ "% Committed Bytes In Use",                                "high_memory",
        CounterName =~ "Pages/sec",                                               "high_memory",
        CounterName =~ "% Free Space",                                            "log_disk_full",
        CounterName =~ "Avg. Disk Queue Length",                                  "high_disk_io",
        CounterName =~ "Processor Queue Length",                                  "high_cpu",
        "unknown"
    ),
    Summary = strcat(CounterName, " high_samples=", tostring(HighSamples), " max=", round(MaxValue, 2), " avg=", round(AvgValue, 2))
| where IsBreached
| project IssueType, Summary
"""

# ---------------------------------------------------------------------------
# KQL — IISPerf breach detection
#
# w3wp conditions filter InstanceName startswith "w3wp" to avoid matching
# any other Process counters that may be added in future.
#
# IIS-down check (Current Connections == 0) is combined with a data-presence
# guard: we require at least 3 rows in the 7-min window to distinguish a
# truly idle/down IIS from a startup lag or transient batch gap.
# With a 60s script interval and 7-min window we expect up to 7 rows when
# data is flowing normally, so RowCount >= 3 is still a conservative guard.
#
# App restarts use the same 7-min window for consistency.
# ---------------------------------------------------------------------------
_IIS_PERF_KQL = """\
let hostname = '{hostname}';
// 7-minute window checks (ADX batching capped at 30s — see VMPerf comment)
let iis3m =
    IISPerf
    | where Computer == hostname and TimeGenerated >= ago(7m)
    | where CounterName in~ (
        "Current Connections",
        "Connection Attempts Failed",
        "Not Found Errors/sec",
        "Requests Queued",
        "% Processor Time",
        "Working Set",
        "Thread Count"
      )
    | summarize
        AvgValue = avg(CounterValue),
        MaxValue = max(CounterValue),
        SumValue = sum(CounterValue),
        RowCount  = count()
      by CounterName, ObjectName, InstanceName
    | extend
        // =~ for CounterName/InstanceName (lowercased by Get-Counter on Windows).
        // ObjectName is set from script hardcoded strings — correct case, == is fine.
        //
        // EXCEPTION — Current Connections uses == (case-sensitive) intentionally:
        // Real PerfMon data stores this as "current connections" (lowercase).
        // The synthetic heartbeat (injected when W3SVC is stopped) hardcodes
        // "Current Connections" (mixed-case).  Using == here means ONLY the
        // synthetic heartbeat rows match, preventing a false positive when IIS
        // is running but idle (0 real connections).  Changing to =~ would cause
        // every idle IIS server to be misidentified as stopped.
        IsBreached = case(
            // IIS-down: require >=3 data rows to rule out startup/data-lag false positives
            CounterName == "Current Connections" and ObjectName == "Web Service"
                and MaxValue == 0 and RowCount >= 3,                              true,
            CounterName =~ "Connection Attempts Failed"
                and SumValue > 50,                                                true,
            CounterName =~ "Not Found Errors/sec"
                and AvgValue > 20,                                                true,
            CounterName =~ "Requests Queued"    and ObjectName == "ASP.NET"
                and AvgValue > 100,                                               true,
            // w3wp: filter InstanceName to avoid matching non-w3wp processes
            CounterName =~ "% Processor Time"   and ObjectName == "Process"
                and InstanceName startswith "w3wp" and AvgValue > 80,            true,
            CounterName =~ "Working Set"         and ObjectName == "Process"
                and InstanceName startswith "w3wp" and AvgValue > 1610612736,    true,
            CounterName =~ "Thread Count"        and ObjectName == "Process"
                and InstanceName startswith "w3wp" and AvgValue > 200,           true,
            false
        ),
        IssueType = case(
            CounterName == "Current Connections",       "w3svc_stopped",   // == intentional — see IsBreached comment
            CounterName =~ "Connection Attempts Failed","binding_missing",
            CounterName =~ "Not Found Errors/sec",      "bad_http_errors",
            CounterName =~ "Requests Queued",           "request_queue_flood",
            CounterName =~ "% Processor Time",          "high_cpu_w3wp",
            CounterName =~ "Working Set",               "memory_leak",
            CounterName =~ "Thread Count",              "worker_process_hang",
            "unknown"
        ),
        Summary = strcat(CounterName, " value=", round(AvgValue, 2))
    | where IsBreached
    | project IssueType, Summary;
// 7-minute window — ASP.NET Application Restarts
let app_restarts =
    IISPerf
    | where Computer == hostname and TimeGenerated >= ago(7m)
    | where CounterName =~ "Application Restarts" and ObjectName == "ASP.NET"
    | summarize TotalRestarts = sum(CounterValue)
    | where TotalRestarts > 2
    | project
        IssueType = "app_pool_crash",
        Summary   = strcat("Application Restarts sum=", tostring(toint(TotalRestarts)));
union iis3m, app_restarts
"""


# ---------------------------------------------------------------------------
# KQL — IISHttpErrors breach detection
#
# IISHttpErrors is populated from HTTP.sys HTTPERR log entries via an ADX
# update policy (Send-PerfToEventHub.ps1 tails the HTTPERR log alongside
# the W3C access log).  When IIS rapid-fail protection permanently stops an
# app pool after 5 crashes in 5 minutes, HTTP.sys serves every subsequent
# request with a 503 Reason='AppOffline'.  At that point:
#   - The IISPerf "Application Restarts" counter stops incrementing (no more
#     restarts can occur) so app_pool_crash detection goes silent after 10m.
#   - IISHttpErrors AppOffline rows continue accumulating — the only live
#     signal that the pool is stuck stopped and users are seeing 503s.
#
# Threshold: >= 3 AppOffline rows in 7 minutes.  A single stray AppOffline
# can appear during a normal graceful recycle; 3+ in 7 minutes means no
# new worker process started — rapid-fail protection is engaged.
# ---------------------------------------------------------------------------
_HTTP_ERR_KQL = """\
let hostname = '{hostname}';
IISHttpErrors
| where Computer == hostname
| where TimeGenerated >= ago(7m)
| where StatusCode == 503 and Reason == "AppOffline"
| summarize RowCount = count()
| where RowCount >= 3
| project
    IssueType = "app_pool_stopped",
    Summary   = strcat("IISHttpErrors AppOffline 503 count=", tostring(RowCount), " in last 7m — rapid-fail protection likely engaged")
"""


def _query_breaches(kql: str) -> list[dict]:
    """Execute KQL and return breach rows. Returns [] on error."""
    from tools.adx_client import query_adx
    try:
        return query_adx(kql)
    except Exception as exc:
        logger.error("ADX query failed: %s", exc)
        return []


def _check_data_present(hostname: str) -> bool:
    """Return True if VMPerf or IISPerf contain any rows for this host in the last 15 minutes.

    Used to distinguish "pipeline is down" (genuinely 0 rows) from "pipeline is
    healthy but no thresholds are currently breached" (breach queries return 0
    rows because everything is within normal limits).
    15-minute window gives ample headroom over the 7-minute breach-detection
    window and the 5-minute cooldown.
    """
    from tools.adx_client import query_adx
    kql = f"""\
let hostname = '{hostname}';
union
    (VMPerf  | where Computer == hostname and TimeGenerated >= ago(15m) | count | project n=Count),
    (IISPerf | where Computer == hostname and TimeGenerated >= ago(15m) | count | project n=Count)
| summarize total=sum(n)
| project HasData=(total > 0)
"""
    try:
        rows = query_adx(kql)
        return bool(rows[0].get("HasData", False)) if rows else False
    except Exception as exc:
        logger.warning("Data-presence check failed: %s", exc)
        return False  # treat as unknown — caller will not warn falsely


def _pick_top_breach(breaches: list[dict]) -> Optional[dict]:
    """Return the highest-priority breach from the combined results."""
    breach_map = {b["IssueType"]: b for b in breaches}
    for issue_type in _PRIORITY:
        if issue_type in breach_map:
            return breach_map[issue_type]
    return breaches[0] if breaches else None


def _trigger_healing(issue_type: str, issue_summary: str) -> None:
    """POST to IISHealingOrchestratorInternal on the same Function App."""
    hostname = os.environ.get("WEBSITE_HOSTNAME", "localhost:7071")
    scheme   = "https" if "localhost" not in hostname else "http"
    url      = f"{scheme}://{hostname}/api/IISHealingOrchestratorInternal"

    logger.info("Triggering healing — issue_type=%s url=%s", issue_type, url)
    try:
        resp = requests.post(
            url,
            json={"issue_type": issue_type, "issue_summary": issue_summary},
            timeout=10,
        )
        logger.info("Healing trigger response: HTTP %s", resp.status_code)
    except ReadTimeout:
        # Expected — the healing pipeline runs for several minutes. The 10-second
        # read timeout fires before the orchestrator responds, but the request was
        # received and processing has started.
        logger.info("Healing triggered — orchestrator is running (read timeout expected).")
    except requests.RequestException as exc:
        logger.error("Failed to trigger healing: %s", exc)


def main(timer: func.TimerRequest) -> None:
    """Timer trigger entry point — fires every 60 seconds."""
    if timer.past_due:
        logger.warning("Timer is past due — skipping this cycle.")
        return

    hostname = os.environ.get("VM_HOSTNAME", "")
    if not hostname:
        logger.error("VM_HOSTNAME env var not set — cannot poll.")
        return

    # ── Cooldown check (persistent across restarts and instances) ─────────
    last_trigger = _get_last_trigger_time()
    elapsed      = time.time() - last_trigger
    if elapsed < COOLDOWN_SECONDS:
        logger.info(
            "Cooldown active — %.0fs remaining, skipping poll.",
            COOLDOWN_SECONDS - elapsed,
        )
        return

    # ── Query ADX ─────────────────────────────────────────────────────────
    vm_breaches       = _query_breaches(_VM_PERF_KQL.format(hostname=hostname))
    iis_breaches      = _query_breaches(_IIS_PERF_KQL.format(hostname=hostname))
    http_err_breaches = _query_breaches(_HTTP_ERR_KQL.format(hostname=hostname))
    all_breaches      = vm_breaches + iis_breaches + http_err_breaches

    if not all_breaches:
        # Both breach queries returned 0 rows.  This is the NORMAL outcome when
        # the VM is healthy — the breach-detection KQL only emits rows for
        # counters that exceed their thresholds, so a healthy host always returns
        # nothing.  Only warn if a separate data-presence check also finds no
        # rows, which means the pipeline itself is down (Event Hub → ADX stopped,
        # Send-PerfToEventHub.ps1 not running, ADX data connection broken, etc.).
        if not _check_data_present(hostname):
            logger.warning(
                "No data found in VMPerf or IISPerf for host '%s' in the last 15 minutes. "
                "Send-PerfToEventHub.ps1 may not be running or the ADX data connection "
                "may be broken.",
                hostname,
            )
        else:
            logger.info(
                "Poll complete — metrics are within normal thresholds for host '%s'. "
                "No healing action required.",
                hostname,
            )
        return

    logger.info(
        "Breaches detected: %s",
        [b.get("IssueType") for b in all_breaches],
    )

    top          = _pick_top_breach(all_breaches)
    issue_type   = top.get("IssueType", "unknown")
    issue_summary = top.get("Summary", issue_type)

    # ── Persist cooldown before triggering to block concurrent polls ───────
    _set_last_trigger_time(time.time())

    _trigger_healing(issue_type, issue_summary)
