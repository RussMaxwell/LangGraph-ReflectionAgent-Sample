#!/usr/bin/env bash
set -euo pipefail

###############################################################################
# run_baseline.sh - Start and monitor the baseline performance capture runbook
###############################################################################

RESOURCE_GROUP="${RESOURCE_GROUP:-iis-core-monitor}"
AUTOMATION_ACCOUNT_NAME="${AUTOMATION_ACCOUNT_NAME:-iisheal-automation}"
VM_NAME="${VM_NAME:-iisheal-vm}"
EH_NAMESPACE="${EH_NAMESPACE:-iisheal-eh}"
RUNBOOK_NAME="Invoke-CaptureBaseline"
DURATION_MINUTES="${DURATION_MINUTES:-60}"
POLL_INTERVAL_SECONDS=120

RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
CYAN='\033[0;36m'
NC='\033[0m'

info()  { echo -e "${CYAN}[INFO]${NC}  $*"; }
ok()    { echo -e "${GREEN}[OK]${NC}    $*"; }
warn()  { echo -e "${YELLOW}[WARN]${NC}  $*"; }
error() { echo -e "${RED}[ERROR]${NC} $*" >&2; }
die()   { error "$@"; exit 1; }

# ─── Check Azure CLI login ─────────────────────────────────────────────────
if ! az account show --output none 2>/dev/null; then
    die "Not logged in to Azure CLI. Run 'az login' first."
fi

# ─── Start the runbook ──────────────────────────────────────────────────────
info "Starting runbook '$RUNBOOK_NAME' on Automation Account '$AUTOMATION_ACCOUNT_NAME'..."
info "  DurationMinutes: $DURATION_MINUTES"
info "  Mode:            Perfmon capture only (use scripts/load_test.sh for external traffic)"
echo ""

JOB_OUTPUT=$(az automation runbook start \
    --resource-group "$RESOURCE_GROUP" \
    --automation-account-name "$AUTOMATION_ACCOUNT_NAME" \
    --name "$RUNBOOK_NAME" \
    --run-on "IIS-HybridWorkers" \
    --parameters VMName="$VM_NAME" ResourceGroup="$RESOURCE_GROUP" DurationMinutes="$DURATION_MINUTES" VirtualUsers="0" EventHubNamespace="$EH_NAMESPACE" \
    --output json)

JOB_ID=$(echo "$JOB_OUTPUT" | python3 -c "import sys,json; print(json.load(sys.stdin)['jobId'])" 2>/dev/null \
      || echo "$JOB_OUTPUT" | python -c "import sys,json; print(json.load(sys.stdin)['jobId'])" 2>/dev/null \
      || echo "")

if [[ -z "$JOB_ID" ]]; then
    die "Failed to start runbook or capture job ID. Output: $JOB_OUTPUT"
fi

ok "Runbook job started. Job ID: $JOB_ID"
echo ""

# ─── Poll job status ───────────────────────────────────────────────────────
info "Polling job status every $POLL_INTERVAL_SECONDS seconds..."
echo ""

ELAPSED=0
TERMINAL_STATES="Completed Failed Stopped Suspended"

while true; do
    STATUS=$(az automation job show \
        --resource-group "$RESOURCE_GROUP" \
        --automation-account-name "$AUTOMATION_ACCOUNT_NAME" \
        --job-name "$JOB_ID" \
        --query "status" \
        --output tsv 2>/dev/null || echo "Unknown")

    ELAPSED_MIN=$((ELAPSED / 60))
    echo -e "  [${ELAPSED_MIN}m elapsed] Job status: ${CYAN}${STATUS}${NC}"

    # Check if status is terminal
    for ts in $TERMINAL_STATES; do
        if [[ "$STATUS" == "$ts" ]]; then
            echo ""
            if [[ "$STATUS" == "Completed" ]]; then
                ok "Baseline capture completed successfully after ${ELAPSED_MIN} minutes."
            else
                error "Baseline capture ended with status: $STATUS"
                echo ""
                info "Fetching job output for diagnostics..."
                az automation job show \
                    --resource-group "$RESOURCE_GROUP" \
                    --automation-account-name "$AUTOMATION_ACCOUNT_NAME" \
                    --job-name "$JOB_ID" \
                    --output table 2>/dev/null || true
                exit 1
            fi

            # Print verification KQL query
            echo ""
            echo -e "${GREEN}═══════════════════════════════════════════════════════════════${NC}"
            echo -e "${GREEN}  VERIFY BASELINE DATA IN ADX${NC}"
            echo -e "${GREEN}═══════════════════════════════════════════════════════════════${NC}"
            echo ""
            echo "  Run these KQL queries in Azure Portal > iishealadx > Query (iishealdb):"
            echo ""
            echo "  1. Check snapshot rows:"
            echo ""
            echo "    PerformanceBaseline"
            echo "    | where TimeGenerated > ago(2h)"
            echo "    | where RecordType == 'Snapshot'"
            echo "    | summarize Count=count() by MetricName"
            echo "    | order by Count desc"
            echo ""
            echo "  2. Check summary row:"
            echo ""
            echo "    PerformanceBaseline"
            echo "    | where RecordType == 'Summary'"
            echo "    | project TimeGenerated, CaptureId, MetricName, MetricValue"
            echo "    | order by TimeGenerated desc"
            echo ""
            exit 0
        fi
    done

    sleep "$POLL_INTERVAL_SECONDS"
    ELAPSED=$((ELAPSED + POLL_INTERVAL_SECONDS))
done
