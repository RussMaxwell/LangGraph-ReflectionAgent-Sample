#!/usr/bin/env bash
set -euo pipefail

###############################################################################
# test_chaos.sh - Interactively trigger chaos scenarios on the IIS VM
###############################################################################

RESOURCE_GROUP="${RESOURCE_GROUP:-iis-core-monitor}"

RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
CYAN='\033[0;36m'
NC='\033[0m'

info()  { echo -e "${CYAN}[INFO]${NC}  $*"; }
ok()    { echo -e "${GREEN}[OK]${NC}    $*"; }
warn()  { echo -e "${YELLOW}[WARN]${NC}  $*"; }
error() { echo -e "${RED}[ERROR]${NC} $*" >&2; }
die()   { error "$@"; exit 1; }

# ─── Scenario names ────────────────────────────────────────────────────────
declare -a SCENARIOS
SCENARIOS[1]="Stop Default App Pool"
SCENARIOS[2]="Corrupt web.config"
SCENARIOS[3]="Fill disk with temp files"
SCENARIOS[4]="Exhaust worker process memory"
SCENARIOS[5]="Deadlock worker threads"
SCENARIOS[6]="Stop W3SVC service"
SCENARIOS[7]="Break HTTPS binding"
SCENARIOS[8]="Lock application DLL files"
SCENARIOS[9]="Corrupt IIS applicationHost.config"
SCENARIOS[10]="Disable IIS feature"

# ─── Resolve VM public IP ──────────────────────────────────────────────────
if [[ -n "${VM_PUBLIC_IP:-}" ]]; then
    info "Using VM_PUBLIC_IP from environment: $VM_PUBLIC_IP"
else
    info "VM_PUBLIC_IP not set, querying from last deployment..."
    VM_PUBLIC_IP=$(az deployment group list \
        --resource-group "$RESOURCE_GROUP" \
        --query "[0].properties.outputs.vmPublicIp.value" \
        --output tsv 2>/dev/null || echo "")

    if [[ -z "$VM_PUBLIC_IP" || "$VM_PUBLIC_IP" == "None" ]]; then
        die "Could not determine VM public IP. Set VM_PUBLIC_IP env var or ensure deployment exists in '$RESOURCE_GROUP'."
    fi
    ok "Resolved VM public IP: $VM_PUBLIC_IP"
fi

CHAOS_URL="http://$VM_PUBLIC_IP/chaos/default.aspx"

# ─── Verify connectivity ───────────────────────────────────────────────────
info "Verifying connectivity to $CHAOS_URL ..."
HTTP_CODE=$(curl -s -o /dev/null -w "%{http_code}" --max-time 10 "$CHAOS_URL" 2>/dev/null || echo "000")
if [[ "$HTTP_CODE" == "000" ]]; then
    die "Cannot reach $CHAOS_URL. Ensure the VM is running and port 80 is open."
fi
ok "Chaos endpoint reachable (HTTP $HTTP_CODE)."
echo ""

# ─── Loop through scenarios ────────────────────────────────────────────────
echo -e "${YELLOW}═══════════════════════════════════════════════════════════════${NC}"
echo -e "${YELLOW}  CHAOS TESTING - 10 Scenarios${NC}"
echo -e "${YELLOW}═══════════════════════════════════════════════════════════════${NC}"
echo ""
echo "  Each scenario will inject a fault into the IIS server."
echo "  The auto-healing agent should detect and remediate each one."
echo "  Wait for remediation before proceeding to the next scenario."
echo ""

for i in $(seq 1 10); do
    SCENARIO_NAME="${SCENARIOS[$i]}"

    echo -e "${CYAN}───────────────────────────────────────────────────────────────${NC}"
    echo -e "  Scenario ${CYAN}$i/10${NC}: ${YELLOW}$SCENARIO_NAME${NC}"
    echo -e "${CYAN}───────────────────────────────────────────────────────────────${NC}"
    echo ""

    read -p "  Press Enter to trigger scenario $i, or 'q' to quit: " USER_INPUT
    if [[ "${USER_INPUT,,}" == "q" ]]; then
        info "Exiting chaos testing."
        exit 0
    fi

    info "Triggering scenario $i: $SCENARIO_NAME ..."
    echo ""

    RESPONSE=$(curl -s --max-time 30 \
        -X POST "$CHAOS_URL" \
        -d "scenario=$i&confirmed=yes" \
        -H "Content-Type: application/x-www-form-urlencoded" \
        2>/dev/null || echo "ERROR: Request failed or timed out.")

    echo -e "  ${GREEN}Response:${NC}"
    echo "  ─────────────────────────────────────────────────"
    echo "$RESPONSE" | head -50 | sed 's/^/    /'
    echo "  ─────────────────────────────────────────────────"
    echo ""
    ok "Scenario $i triggered. Monitor the auto-healing agent for remediation."
    echo ""
done

echo ""
echo -e "${GREEN}═══════════════════════════════════════════════════════════════${NC}"
echo -e "${GREEN}  ALL SCENARIOS COMPLETE${NC}"
echo -e "${GREEN}═══════════════════════════════════════════════════════════════${NC}"
echo ""
echo "  Check the following for healing activity:"
echo "    - Function App logs"
echo "    - Automation Account job history"
echo "    - AgentEvents_CL table in Log Analytics"
echo ""
ok "Chaos testing finished."
