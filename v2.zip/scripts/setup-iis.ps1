# setup-iis.ps1 - IIS Setup Script for Auto-Healing VM
# Installs IIS, configures W3C logging, creates chaos app directory,
# and registers the IISChaosApp event log source.

# Install IIS and all relevant features
Install-WindowsFeature -Name Web-Server -IncludeManagementTools
Install-WindowsFeature -Name Web-Asp-Net45
Install-WindowsFeature -Name Web-Net-Ext45
Install-WindowsFeature -Name Web-ISAPI-Ext
Install-WindowsFeature -Name Web-ISAPI-Filter
Install-WindowsFeature -Name Web-Mgmt-Tools
Install-WindowsFeature -Name Web-Mgmt-Console
Install-WindowsFeature -Name Web-Mgmt-Service
Install-WindowsFeature -Name Web-Http-Logging
Install-WindowsFeature -Name Web-Log-Libraries
Install-WindowsFeature -Name Web-Custom-Logging
Install-WindowsFeature -Name Web-Request-Monitor
Install-WindowsFeature -Name Web-Http-Tracing
Install-WindowsFeature -Name Web-Stat-Compression
Install-WindowsFeature -Name Web-Dyn-Compression
Install-WindowsFeature -Name Web-Filtering
Install-WindowsFeature -Name Web-Basic-Auth
Install-WindowsFeature -Name Web-Windows-Auth
Install-WindowsFeature -Name Web-Scripting-Tools

# Import WebAdministration module
Import-Module WebAdministration

# Enable W3C logging on Default Web Site
Set-WebConfigurationProperty `
    -Filter "system.applicationHost/sites/site[@name='Default Web Site']/logFile" `
    -Name "logFormat" `
    -Value "W3C" `
    -PSPath "IIS:\"

Set-WebConfigurationProperty `
    -Filter "system.applicationHost/sites/site[@name='Default Web Site']/logFile" `
    -Name "logExtFileFlags" `
    -Value "Date,Time,ClientIP,UserName,SiteName,ComputerName,ServerIP,Method,UriStem,UriQuery,HttpStatus,Win32Status,BytesSent,BytesRecv,TimeTaken,ServerPort,UserAgent,Cookie,Referer,ProtocolVersion,Host,HttpSubStatus" `
    -PSPath "IIS:\"

# Create chaos directory
$chaosPath = "C:\inetpub\wwwroot\chaos"
if (-not (Test-Path $chaosPath)) {
    New-Item -ItemType Directory -Path $chaosPath -Force
}

# Create a dedicated app pool for the chaos app running as LocalSystem.
# LocalSystem is required so chaos scenarios can control services (W3SVC),
# modify IIS configuration via ServerManager, and change file permissions —
# all of which fail under the default ApplicationPoolIdentity.
if (-not (Test-Path "IIS:\AppPools\ChaosAppPool")) {
    New-WebAppPool -Name "ChaosAppPool"
}
# Set each processModel property individually — the hash-value form of
# Set-ItemProperty does not reliably apply identityType on all IIS versions.
Set-ItemProperty "IIS:\AppPools\ChaosAppPool" -Name processModel.identityType -Value 0  # LocalSystem
Set-ItemProperty "IIS:\AppPools\ChaosAppPool" -Name processModel.userName     -Value ""
Set-ItemProperty "IIS:\AppPools\ChaosAppPool" -Name processModel.password     -Value ""

# Set up chaos virtual directory as an IIS application under ChaosAppPool
New-WebApplication -Name "chaos" -Site "Default Web Site" -PhysicalPath $chaosPath -ApplicationPool "ChaosAppPool" -Force

# Register IISChaosApp event log source
if (-not [System.Diagnostics.EventLog]::SourceExists("IISChaosApp")) {
    New-EventLog -LogName Application -Source IISChaosApp
}

# Restart IIS to apply all changes
iisreset /restart
