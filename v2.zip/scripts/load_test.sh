#!/usr/bin/env bash
# ---------------------------------------------------------------------------
# load_test.sh -- External load test for IIS auto-healing baseline capture
#
# Simulates concurrent unique users hitting the root page from outside the VM.
# Each virtual user has a distinct browser fingerprint (user-agent, session,
# referrer, accept-language) so IIS W3C logs and ADX telemetry show realistic
# multi-user traffic patterns.
#
# Run this alongside scripts/run_baseline.sh so the baseline captures metrics
# under representative external load.
#
# Usage:
#   export VM_PUBLIC_IP=<ip>
#   bash scripts/load_test.sh                     # defaults: 20 users, 60 min
#   bash scripts/load_test.sh -u 50 -d 30         # 50 users, 30 min
#   bash scripts/load_test.sh --users 10 --duration 5 --ramp-up 60
# ---------------------------------------------------------------------------
set -euo pipefail

# ---------------------------------------------------------------------------
# Defaults (override via flags or env vars)
# ---------------------------------------------------------------------------
TARGET_IP="${VM_PUBLIC_IP:-}"
VIRTUAL_USERS="${LOAD_TEST_USERS:-20}"
DURATION_MIN="${LOAD_TEST_DURATION:-60}"
RAMP_UP_SEC="${LOAD_TEST_RAMP_UP:-30}"       # seconds to stagger user starts
MIN_DELAY=3                                   # min seconds between requests per user
MAX_DELAY=8                                   # max seconds between requests per user
REPORT_INTERVAL=30                            # seconds between summary prints
LOG_DIR=""
QUIET=false

# ---------------------------------------------------------------------------
# Parse arguments
# ---------------------------------------------------------------------------
usage() {
    cat <<EOF
Usage: $(basename "$0") [OPTIONS]

Simulate concurrent unique users hitting the IIS root page.

Options:
  -t, --target IP       VM public IP (or set VM_PUBLIC_IP env var)
  -u, --users N         Number of virtual users (default: 20)
  -d, --duration MIN    Test duration in minutes (default: 60)
  -r, --ramp-up SEC     Seconds to stagger user starts (default: 30)
  --min-delay SEC       Min pause between requests per user (default: 3)
  --max-delay SEC       Max pause between requests per user (default: 8)
  -o, --output DIR      Directory for CSV logs (default: auto-created in /tmp)
  -q, --quiet           Suppress per-request output, only show summaries
  -h, --help            Show this help
EOF
    exit 0
}

while [[ $# -gt 0 ]]; do
    case "$1" in
        -t|--target)   TARGET_IP="$2"; shift 2 ;;
        -u|--users)    VIRTUAL_USERS="$2"; shift 2 ;;
        -d|--duration) DURATION_MIN="$2"; shift 2 ;;
        -r|--ramp-up)  RAMP_UP_SEC="$2"; shift 2 ;;
        --min-delay)   MIN_DELAY="$2"; shift 2 ;;
        --max-delay)   MAX_DELAY="$2"; shift 2 ;;
        -o|--output)   LOG_DIR="$2"; shift 2 ;;
        -q|--quiet)    QUIET=true; shift ;;
        -h|--help)     usage ;;
        *) echo "Unknown option: $1"; usage ;;
    esac
done

if [[ -z "$TARGET_IP" ]]; then
    echo "ERROR: VM public IP not set. Use -t <ip> or: export VM_PUBLIC_IP=<ip>"
    exit 1
fi

TARGET_URL="http://${TARGET_IP}/"

# ---------------------------------------------------------------------------
# Setup logging
# ---------------------------------------------------------------------------
if [[ -z "$LOG_DIR" ]]; then
    LOG_DIR=$(mktemp -d "${TMPDIR:-/tmp}/load_test_XXXXXX")
fi
mkdir -p "$LOG_DIR"

RESULTS_CSV="${LOG_DIR}/requests.csv"
SUMMARY_FILE="${LOG_DIR}/summary.txt"
echo "timestamp,user_id,user_agent_tag,referrer,session_id,http_status,response_time_ms,response_size" > "$RESULTS_CSV"

# ---------------------------------------------------------------------------
# 50 user-agent strings -- same pool as the baseline script for consistency,
# but each virtual user is assigned a sticky UA for the session lifetime
# (real users don't change browsers mid-session).
# ---------------------------------------------------------------------------
USER_AGENTS=(
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36"
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:125.0) Gecko/20100101 Firefox/125.0"
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 14_4_1) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.4 Safari/605.1.15"
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/123.0.0.0 Safari/537.36 Edg/123.0.0.0"
    "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36"
    "Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:125.0) Gecko/20100101 Firefox/125.0"
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 14_4_1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36"
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36 OPR/108.0.0.0"
    "Mozilla/5.0 (iPhone; CPU iPhone OS 17_4_1 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.4 Mobile/15E148 Safari/604.1"
    "Mozilla/5.0 (iPad; CPU OS 17_4_1 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.4 Mobile/15E148 Safari/604.1"
    "Mozilla/5.0 (Linux; Android 14; Pixel 8 Pro) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Mobile Safari/537.36"
    "Mozilla/5.0 (Linux; Android 14; SM-S928U) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Mobile Safari/537.36"
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36 Vivaldi/6.7.3329.35"
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36 Brave/124"
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 14_4_1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36 Edg/124.0.0.0"
    "Mozilla/5.0 (X11; Linux x86_64; rv:125.0) Gecko/20100101 Firefox/125.0"
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:124.0) Gecko/20100101 Firefox/124.0"
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 14.4; rv:125.0) Gecko/20100101 Firefox/125.0"
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/121.0.0.0 Safari/537.36"
    "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/123.0.0.0 Safari/537.36"
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 14_3) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.3 Safari/605.1.15"
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36"
    "Mozilla/5.0 (Linux; Android 14; SM-A546B) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Mobile Safari/537.36"
    "Mozilla/5.0 (iPhone; CPU iPhone OS 17_3_1 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.3 Mobile/15E148 Safari/604.1"
    "Mozilla/5.0 (Windows NT 10.0; WOW64; Trident/7.0; rv:11.0) like Gecko"
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36 SamsungBrowser/24.0"
    "Mozilla/5.0 (Linux; Android 14; Pixel 7a) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Mobile Safari/537.36"
    "Mozilla/5.0 (X11; CrOS x86_64 14541.0.0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36"
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36 Whale/3.25.232.19"
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 14_4_1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36 OPR/108.0.0.0"
    "Mozilla/5.0 (Windows NT 10.0; ARM64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36"
    "Mozilla/5.0 (Linux; Android 13; RMX3630) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Mobile Safari/537.36"
    "Mozilla/5.0 (iPad; CPU OS 17_4 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) CriOS/124.0.6367.88 Mobile/15E148 Safari/604.1"
    "Mozilla/5.0 (iPhone; CPU iPhone OS 17_4_1 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) CriOS/124.0.6367.88 Mobile/15E148 Safari/604.1"
    "Mozilla/5.0 (Linux; Android 14; moto g84 5G) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Mobile Safari/537.36"
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/118.0.0.0 Safari/537.36"
    "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36"
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 13_6_6) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/16.6 Safari/605.1.15"
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:123.0) Gecko/20100101 Firefox/123.0"
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 14.4; rv:124.0) Gecko/20100101 Firefox/124.0"
    "Mozilla/5.0 (X11; Fedora; Linux x86_64; rv:125.0) Gecko/20100101 Firefox/125.0"
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/119.0.0.0 Safari/537.36"
    "Mozilla/5.0 (Linux; Android 14; V2322) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Mobile Safari/537.36"
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 14_2) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.2 Safari/605.1.15"
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36 AtContent/95.5.5462.0"
    "Mozilla/5.0 (Linux; Android 13; 22101316G) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Mobile Safari/537.36"
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36 UCBrowser/15.5.6.10432"
    "Mozilla/5.0 (Linux; Android 14; CPH2579) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Mobile Safari/537.36"
    "Mozilla/5.0 (X11; Linux aarch64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36"
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36 Yowser/2.5"
)

UA_TAGS=(
    "Chrome-Win" "Firefox-Win" "Safari-Mac" "Edge-Win" "Chrome-Linux"
    "Firefox-Ubuntu" "Chrome-Mac" "Opera-Win" "Safari-iPhone" "Safari-iPad"
    "Chrome-Pixel8" "Chrome-Galaxy" "Vivaldi-Win" "Brave-Win" "Edge-Mac"
    "Firefox-Linux" "Firefox-Win-124" "Firefox-Mac" "Chrome-Win-121" "Chrome-Linux-123"
    "Safari-Mac-17.3" "Chrome-Win-120" "Chrome-Galaxy-A54" "Safari-iPhone-17.3" "IE11-Win"
    "Samsung-Browser" "Chrome-Pixel7a" "Chrome-ChromeOS" "Whale-Win" "Opera-Mac"
    "Chrome-Win-ARM" "Chrome-Realme" "CriOS-iPad" "CriOS-iPhone" "Chrome-Moto"
    "Chrome-Win-118" "Chrome-Linux-122" "Safari-Mac-16.6" "Firefox-Win-123" "Firefox-Mac-124"
    "Firefox-Fedora" "Chrome-Win-119" "Chrome-Vivo" "Safari-Mac-17.2" "Chrome-Win-AtContent"
    "Chrome-Xiaomi" "UCBrowser-Win" "Chrome-Oppo" "Chrome-Linux-ARM" "Chrome-Win-Yowser"
)

REFERRERS=(
    "https://www.google.com/search?q=iis+hosting+services"
    "https://www.bing.com/search?q=managed+iis+enterprise"
    "https://www.linkedin.com/feed"
    "https://twitter.com/contoso_infra/status/12345"
    "https://www.reddit.com/r/sysadmin/comments/abc123"
    "https://news.ycombinator.com/item?id=98765"
    "https://mail.google.com/"
    "https://outlook.office365.com/"
    "https://teams.microsoft.com/"
    "https://slack.com/messages"
    "https://www.facebook.com/contoso.infra"
    "https://www.instagram.com/contoso_infrastructure"
    "https://newsletter.contoso.com/issue/42"
    "https://partner.microsoft.com/solutions"
    "https://azure.microsoft.com/solutions/iis"
    ""    # direct visit (no referrer)
    ""    # direct visit
    ""    # direct visit (weighted -- direct is common)
    ""    # direct visit
    "https://techcommunity.microsoft.com/blog/iis-management"
    "https://stackoverflow.com/questions/12345/iis-hosting"
    "https://www.youtube.com/watch?v=contoso_demo"
    "https://contoso-infra.medium.com/best-practices"
    "https://dzone.com/articles/iis-performance"
    "https://dev.to/contoso/enterprise-iis"
)

ACCEPT_LANGS=(
    "en-US,en;q=0.9"
    "en-GB,en;q=0.9"
    "en-US,en;q=0.9,es;q=0.8"
    "en-US,en;q=0.9,fr;q=0.8"
    "en-US,en;q=0.9,de;q=0.8"
    "en-US,en;q=0.9,ja;q=0.8"
    "en-US,en;q=0.9,zh-CN;q=0.8"
    "en-US,en;q=0.9,pt-BR;q=0.8"
    "en-AU,en;q=0.9"
    "en-CA,en;q=0.9"
    "en-IN,en;q=0.9,hi;q=0.8"
    "fr-FR,fr;q=0.9,en;q=0.8"
    "de-DE,de;q=0.9,en;q=0.8"
    "es-ES,es;q=0.9,en;q=0.8"
    "pt-BR,pt;q=0.9,en;q=0.8"
)

# ---------------------------------------------------------------------------
# Counters (shared via temp files since bash subshells can't share vars)
# ---------------------------------------------------------------------------
COUNTER_DIR=$(mktemp -d "${TMPDIR:-/tmp}/lt_counters_XXXXXX")
: > "${COUNTER_DIR}/total"
: > "${COUNTER_DIR}/success"
: > "${COUNTER_DIR}/errors"
CHILD_PIDS=()

# ---------------------------------------------------------------------------
# Cleanup on exit
# ---------------------------------------------------------------------------
cleanup() {
    echo ""
    echo "Stopping virtual users..."
    for pid in "${CHILD_PIDS[@]}"; do
        kill "$pid" 2>/dev/null || true
    done
    wait 2>/dev/null || true
    print_final_summary
    rm -rf "$COUNTER_DIR"
    echo "Logs saved to: ${LOG_DIR}/"
}
trap cleanup EXIT INT TERM

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------
rand_between() {
    local min=$1 max=$2
    echo $(( RANDOM % (max - min + 1) + min ))
}

generate_session_id() {
    # Produce a GUID-like string using /dev/urandom
    local hex
    hex=$(od -An -tx1 -N16 /dev/urandom 2>/dev/null | tr -d ' \n' || printf '%04x%04x%04x%04x' $RANDOM $RANDOM $RANDOM $RANDOM)
    echo "${hex:0:8}-${hex:8:4}-${hex:12:4}-${hex:16:4}-${hex:20:12}"
}

increment_counter() {
    local file="${COUNTER_DIR}/$1"
    # Append a line per increment — count lines instead of read/write an integer.
    # This avoids needing flock (unavailable on Git Bash for Windows).
    echo "1" >> "$file"
}

read_counter() {
    wc -l < "${COUNTER_DIR}/$1" 2>/dev/null | tr -d ' ' || echo "0"
}

# ---------------------------------------------------------------------------
# Virtual user loop -- runs as a background process
# ---------------------------------------------------------------------------
run_virtual_user() {
    local user_id=$1
    local deadline=$2
    local ua="${USER_AGENTS[$((user_id % ${#USER_AGENTS[@]}))]}"
    local ua_tag="${UA_TAGS[$((user_id % ${#UA_TAGS[@]}))]}"
    local accept_lang="${ACCEPT_LANGS[$((user_id % ${#ACCEPT_LANGS[@]}))]}"
    local session_id
    session_id=$(generate_session_id)

    # Each user gets a sticky cookie jar for the session
    local cookie_jar="${LOG_DIR}/cookies_user${user_id}.txt"

    while [[ $(date +%s) -lt $deadline ]]; do
        local ref_idx
        ref_idx=$(rand_between 0 $(( ${#REFERRERS[@]} - 1 )))
        local referrer="${REFERRERS[$ref_idx]}"
        local page_variant
        page_variant=$(rand_between 1 3)

        # Build URL with unique query params per request
        local url="${TARGET_URL}?sid=${session_id}&ref=$(basename "${referrer:-direct}" | cut -c1-10)&v=${page_variant}&_t=$(date +%s%N)"

        # Build curl args
        local curl_args=(
            -s -o /dev/null
            -w "%{http_code}|%{time_total}|%{size_download}"
            --max-time 30
            -H "User-Agent: ${ua}"
            -H "Accept: text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8"
            -H "Accept-Language: ${accept_lang}"
            -H "Cache-Control: no-cache"
            -H "X-Session-ID: ${session_id}"
            -b "$cookie_jar" -c "$cookie_jar"
        )
        if [[ -n "$referrer" ]]; then
            curl_args+=(-H "Referer: ${referrer}")
        fi

        local result
        result=$(curl "${curl_args[@]}" "$url" 2>/dev/null || echo "000|0.000|0")

        local http_status response_time_sec response_size
        IFS='|' read -r http_status response_time_sec response_size <<< "$result"
        local response_time_ms
        response_time_ms=$(echo "$response_time_sec * 1000" | bc 2>/dev/null || echo "0")

        # Log to CSV
        echo "$(date -u +%Y-%m-%dT%H:%M:%S.%3NZ),${user_id},${ua_tag},${referrer:-direct},${session_id},${http_status},${response_time_ms},${response_size}" >> "$RESULTS_CSV"

        # Update counters
        increment_counter "total"
        if [[ "$http_status" -ge 200 && "$http_status" -lt 400 ]]; then
            increment_counter "success"
        else
            increment_counter "errors"
        fi

        if [[ "$QUIET" != "true" ]]; then
            printf "  [User %3d] %-20s -> %s  %sms\n" "$user_id" "$ua_tag" "$http_status" "${response_time_ms%.*}"
        fi

        # Random delay before next request (simulate human think time)
        local delay
        delay=$(rand_between "$MIN_DELAY" "$MAX_DELAY")
        sleep "$delay"
    done
}

# ---------------------------------------------------------------------------
# Summary printer
# ---------------------------------------------------------------------------
print_summary() {
    local elapsed=$1
    local total success errors
    total=$(read_counter "total")
    success=$(read_counter "success")
    errors=$(read_counter "errors")
    local rps="0"
    if [[ "$elapsed" -gt 0 ]]; then
        rps=$(echo "scale=1; $total / $elapsed" | bc 2>/dev/null || echo "?")
    fi
    local rate="0"
    if [[ "$total" -gt 0 ]]; then
        rate=$(echo "scale=1; $success * 100 / $total" | bc 2>/dev/null || echo "?")
    fi

    printf "\n  --- %s | Elapsed: %dm%02ds | Users: %d | Requests: %s | RPS: %s | Success: %s%% | Errors: %s ---\n\n" \
        "$(date +%H:%M:%S)" \
        $((elapsed / 60)) $((elapsed % 60)) \
        "$VIRTUAL_USERS" "$total" "$rps" "$rate" "$errors"
}

print_final_summary() {
    local total success errors
    total=$(read_counter "total")
    success=$(read_counter "success")
    errors=$(read_counter "errors")

    echo ""
    echo "============================================"
    echo "  LOAD TEST COMPLETE"
    echo "============================================"
    echo "  Target:          ${TARGET_URL}"
    echo "  Virtual Users:   ${VIRTUAL_USERS}"
    echo "  Duration:        ${DURATION_MIN} minutes"
    echo "  Total Requests:  ${total}"
    echo "  Successful:      ${success}"
    echo "  Errors:          ${errors}"
    if [[ "$total" -gt 0 ]]; then
        echo "  Success Rate:    $(echo "scale=1; $success * 100 / $total" | bc 2>/dev/null || echo "?")%"
    fi
    echo "  Results CSV:     ${RESULTS_CSV}"
    echo "============================================"

    # Write summary to file
    cat > "$SUMMARY_FILE" <<SUMEOF
Load Test Summary
=================
Target:         ${TARGET_URL}
Virtual Users:  ${VIRTUAL_USERS}
Duration:       ${DURATION_MIN} minutes
Total Requests: ${total}
Successful:     ${success}
Errors:         ${errors}
Results CSV:    ${RESULTS_CSV}
Completed:      $(date -u +%Y-%m-%dT%H:%M:%SZ)

Unique session IDs generated: ${VIRTUAL_USERS}
User-agent variants used:     $(( VIRTUAL_USERS > ${#USER_AGENTS[@]} ? ${#USER_AGENTS[@]} : VIRTUAL_USERS ))
Referrer sources:             ${#REFERRERS[@]}
SUMEOF
}

# ---------------------------------------------------------------------------
# Pre-flight check
# ---------------------------------------------------------------------------
echo "============================================"
echo "  IIS EXTERNAL LOAD TEST"
echo "============================================"
echo "  Target:        ${TARGET_URL}"
echo "  Virtual Users: ${VIRTUAL_USERS}"
echo "  Duration:      ${DURATION_MIN} minutes"
echo "  Ramp-up:       ${RAMP_UP_SEC} seconds"
echo "  Request Delay: ${MIN_DELAY}-${MAX_DELAY}s per user"
echo "  Log Directory: ${LOG_DIR}/"
echo "============================================"
echo ""
echo "Pre-flight: checking connectivity..."

preflight_status=$(curl -s -o /dev/null -w "%{http_code}" --max-time 10 "${TARGET_URL}" 2>/dev/null || echo "000")
if [[ "$preflight_status" -lt 200 || "$preflight_status" -ge 400 ]]; then
    echo "ERROR: ${TARGET_URL} returned HTTP ${preflight_status}. Is the VM running and IIS serving?"
    exit 1
fi
echo "OK: ${TARGET_URL} returned HTTP ${preflight_status}"
echo ""

# ---------------------------------------------------------------------------
# Launch virtual users with ramp-up stagger
# ---------------------------------------------------------------------------
DURATION_SEC=$((DURATION_MIN * 60))
START_EPOCH=$(date +%s)
DEADLINE=$((START_EPOCH + DURATION_SEC))

if [[ "$VIRTUAL_USERS" -gt 1 && "$RAMP_UP_SEC" -gt 0 ]]; then
    STAGGER_MS=$(( (RAMP_UP_SEC * 1000) / (VIRTUAL_USERS - 1) ))
else
    STAGGER_MS=0
fi

echo "Launching ${VIRTUAL_USERS} virtual users..."
for (( i=1; i<=VIRTUAL_USERS; i++ )); do
    run_virtual_user "$i" "$DEADLINE" &
    CHILD_PIDS+=($!)
    printf "  Started user %d/%d  (PID %d, UA: %s)\n" "$i" "$VIRTUAL_USERS" "${CHILD_PIDS[-1]}" "${UA_TAGS[$(( (i-1) % ${#UA_TAGS[@]} ))]}"

    if [[ "$STAGGER_MS" -gt 0 && "$i" -lt "$VIRTUAL_USERS" ]]; then
        sleep "$(echo "scale=3; $STAGGER_MS / 1000" | bc 2>/dev/null || echo "0.1")"
    fi
done

echo ""
echo "All users running. Summaries every ${REPORT_INTERVAL}s. Press Ctrl+C to stop early."
echo ""

# ---------------------------------------------------------------------------
# Periodic summary loop
# ---------------------------------------------------------------------------
while [[ $(date +%s) -lt $DEADLINE ]]; do
    sleep "$REPORT_INTERVAL"
    elapsed=$(( $(date +%s) - START_EPOCH ))
    print_summary "$elapsed"
done

# Wait for stragglers
wait 2>/dev/null || true
