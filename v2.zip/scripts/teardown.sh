#!/usr/bin/env bash
set -euo pipefail

###############################################################################
# teardown.sh - Tear down the IIS Auto-Healing infrastructure
#
# Deletes both resource groups:
#   iis-core         — VM, networking, Function App
#   iis-core-monitor — LAW, ADX, Event Hubs, Automation, OpenAI, alerts
###############################################################################

CORE_RG="${CORE_RG:-iis-core}"
MONITOR_RG="${MONITOR_RG:-iis-core-monitor}"

RED='\033[0;31m'; GREEN='\033[0;32m'; YELLOW='\033[1;33m'; CYAN='\033[0;36m'; NC='\033[0m'
info()  { echo -e "${CYAN}[INFO]${NC}  $*"; }
ok()    { echo -e "${GREEN}[OK]${NC}    $*"; }
warn()  { echo -e "${YELLOW}[WARN]${NC}  $*"; }
die()   { echo -e "${RED}[ERROR]${NC} $*" >&2; exit 1; }

# ── Check Azure CLI login ───────────────────────────────────────────────────────
if ! az account show --output none 2>/dev/null; then
    die "Not logged in to Azure CLI. Run 'az login' first."
fi

# ── Check which RGs actually exist ────────────────────────────────────────────
CORE_EXISTS=false; MONITOR_EXISTS=false
az group show --name "$CORE_RG"    --output none 2>/dev/null && CORE_EXISTS=true    || true
az group show --name "$MONITOR_RG" --output none 2>/dev/null && MONITOR_EXISTS=true || true

[[ "$CORE_EXISTS" == "false" && "$MONITOR_EXISTS" == "false" ]] \
  && die "Neither '$CORE_RG' nor '$MONITOR_RG' exists. Nothing to tear down."

# ── Show what will be deleted ──────────────────────────────────────────────────
echo ""
echo -e "${RED}══════════════════════════════════════════════════════════════════${NC}"
echo -e "${RED}  WARNING: DESTRUCTIVE OPERATION${NC}"
echo -e "${RED}══════════════════════════════════════════════════════════════════${NC}"
echo ""
echo "  This will permanently delete the following resource groups"
echo "  and ALL resources contained within them:"
echo ""

if [[ "$CORE_EXISTS" == "true" ]]; then
    echo "    $CORE_RG"
    az resource list --resource-group "$CORE_RG" \
        --query "[].{Name:name, Type:type}" \
        --output table 2>/dev/null || warn "Could not list resources in $CORE_RG."
    echo ""
fi

if [[ "$MONITOR_EXISTS" == "true" ]]; then
    echo "    $MONITOR_RG"
    az resource list --resource-group "$MONITOR_RG" \
        --query "[].{Name:name, Type:type}" \
        --output table 2>/dev/null || warn "Could not list resources in $MONITOR_RG."
    echo ""
fi

# ── Require explicit confirmation ──────────────────────────────────────────────
echo "  Type 'delete' to confirm permanent deletion of the above resources."
echo ""
read -p "  Confirmation: " CONFIRM

[[ "$CONFIRM" != "delete" ]] && die "Confirmation did not match. Aborting."

# ── Delete resource groups (async, both in parallel) ──────────────────────────
echo ""
if [[ "$CORE_EXISTS" == "true" ]]; then
    info "Deleting '$CORE_RG' (async)..."
    az group delete --name "$CORE_RG" --yes --no-wait
    ok "Deletion initiated for '$CORE_RG'."
fi

if [[ "$MONITOR_EXISTS" == "true" ]]; then
    info "Deleting '$MONITOR_RG' (async)..."
    az group delete --name "$MONITOR_RG" --yes --no-wait
    ok "Deletion initiated for '$MONITOR_RG'."
fi

echo ""
echo "  Monitor progress with:"
echo "    az group show --name $CORE_RG    --query 'properties.provisioningState' 2>/dev/null || echo 'Deleted'"
echo "    az group show --name $MONITOR_RG --query 'properties.provisioningState' 2>/dev/null || echo 'Deleted'"
echo ""
ok "Teardown initiated."
