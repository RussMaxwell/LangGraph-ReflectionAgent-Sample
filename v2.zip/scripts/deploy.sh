#!/usr/bin/env bash
set -euo pipefail

###############################################################################
# v2 deploy.sh - Full deployment for IIS Auto-Healing (enterprise-network variant)
#
# Differences vs scripts/deploy.sh:
#   - No Bastion output consumption (VM has only a private IP).
#   - No PowerShell 7 MSI install on the VM (runbooks are PS 5.1 only).
#   - Function App deployment uses run-from-package:
#       1) zip v2/function-app/
#       2) temp-allow caller IP on the (otherwise private) function storage account
#       3) upload to the 'function-packages' container
#       4) generate user-delegation SAS valid 10 years
#       5) set WEBSITE_RUN_FROM_PACKAGE to the SAS URL
#       6) revoke caller-IP allowance
#       7) restart Function App
#     `func azure functionapp publish` is NOT used — SCM is private and would fail.
#
# Prereqs for the deploy machine:
#   * Network reach to the VM's private IP (jumphost / VPN / ExpressRoute)
#     OR willingness to skip steps 5, 5d, 5e, 8 (they use az vm run-command, which
#     goes via the Azure management plane and does not require VM reach).
#   * RBAC: Storage Blob Data Contributor on the function's storage account
#     (needed for `--auth-mode login` upload and user-delegation SAS).
#   * RBAC: Network Contributor on the enterprise VNet (needed for PE creation).
#   * az, base64, jq, zip on PATH.
#
# Usage:
#   export VM_ADMIN_PASSWORD='YourP@ssw0rd!'
#   bash v2/scripts/deploy.sh
#
# Optional overrides:
#   export DEPLOY_LOCATION='eastus2'
#   export SUBSCRIPTION_ID='...'
###############################################################################

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_ROOT="$(cd "$SCRIPT_DIR/.." && pwd)"   # this is .../iis-autohealing/v2

DEPLOY_LOCATION="${DEPLOY_LOCATION:-eastus2}"
CORE_RG="iis-core"
MONITOR_RG="iis-core-monitor"

# ── Colour helpers ─────────────────────────────────────────────────────────────
RED='\033[0;31m'; GREEN='\033[0;32m'; YELLOW='\033[1;33m'; CYAN='\033[0;36m'; NC='\033[0m'
info()  { echo -e "${CYAN}[INFO]${NC}  $*"; }
ok()    { echo -e "${GREEN}[OK]${NC}    $*"; }
warn()  { echo -e "${YELLOW}[WARN]${NC}  $*"; }
die()   { echo -e "${RED}[ERROR]${NC} $*" >&2; exit 1; }

# ── 1. Prerequisites ───────────────────────────────────────────────────────────
info "Checking prerequisites..."

[[ -z "${VM_ADMIN_PASSWORD:-}" ]] && die "VM_ADMIN_PASSWORD is not set. Export it before running."
command -v az     >/dev/null 2>&1 || die "Azure CLI (az) not found."
command -v base64 >/dev/null 2>&1 || die "base64 not found."
command -v zip    >/dev/null 2>&1 || die "zip not found (install with: apt-get install zip OR winget install GnuWin32.Zip)."

if ! command -v jq &>/dev/null; then
    info "jq not found — attempting to install..."
    if command -v apt-get &>/dev/null; then
        sudo apt-get install -y jq
    elif command -v brew &>/dev/null; then
        brew install jq
    elif command -v winget &>/dev/null; then
        winget install jqlang.jq --silent
    else
        die "jq not found and could not be auto-installed. Install manually: https://stedolan.github.io/jq/download/"
    fi
    command -v jq &>/dev/null || die "jq installation failed."
    ok "jq installed."
fi

if ! az account show --output none 2>/dev/null; then
    warn "Not logged in. Launching az login..."
    az login --output none
fi
ok "Azure CLI authenticated."

if [[ -n "${SUBSCRIPTION_ID:-}" ]]; then
    az account set --subscription "$SUBSCRIPTION_ID"
    ok "Subscription set to $SUBSCRIPTION_ID."
fi

az account show --query "{Subscription:name, Id:id}" --output table

info "Ensuring Bicep CLI is installed..."
az bicep install 2>/dev/null || true
ok "Bicep CLI ready: $(az bicep version --only-show-errors 2>&1 | head -1)"

echo ""

# ── 2. Deploy infrastructure (subscription scope) ─────────────────────────────
info "Deploying infrastructure at subscription scope (this takes ~20-30 minutes)..."
info "  Core RG     : $CORE_RG"
info "  Monitor RG  : $MONITOR_RG"
info "  Location    : $DEPLOY_LOCATION"
echo ""

DEPLOYMENT_NAME="iis-autohealing-v2-$(date +%Y%m%d%H%M%S)"

az deployment sub create \
    --name           "$DEPLOYMENT_NAME" \
    --location       "$DEPLOY_LOCATION" \
    --template-file  "$PROJECT_ROOT/infra/main.bicep" \
    --parameters     "$PROJECT_ROOT/infra/parameters/dev.bicepparam" \
    --parameters     adminPassword="$VM_ADMIN_PASSWORD" \
    --output none || true

PROV_STATE=$(az deployment sub show \
    --name "$DEPLOYMENT_NAME" \
    --query "properties.provisioningState" \
    --output tsv 2>/dev/null || echo "NotFound")

[[ "$PROV_STATE" != "Succeeded" ]] \
  && die "Deployment did not succeed (state: $PROV_STATE). Check the Azure portal for details."

ok "Infrastructure deployment complete."

# ── 3. Capture deployment outputs ─────────────────────────────────────────────
info "Capturing deployment outputs..."
OUTPUTS=$(az deployment sub show \
    --name   "$DEPLOYMENT_NAME" \
    --query  "properties.outputs" \
    --output json)

get_out() { echo "$OUTPUTS" | jq -r ".$1.value // empty"; }

VM_NAME=$(get_out vmName)
VM_IP=$(get_out vmPrivateIp)
LAW_ID=$(get_out lawWorkspaceId)
LAW_CUSTOMER_ID=$(get_out lawWorkspaceCustomerId)
DCE_ENDPOINT=$(get_out dceEndpoint)
FUNC_APP_NAME=$(get_out functionAppName)
FUNC_APP_HOST=$(get_out functionAppHostname)
FA_STORAGE=$(get_out storageAccountName)
AUTO_ACCOUNT=$(get_out automationAccountName)
OPENAI_ENDPOINT=$(get_out openaiEndpoint)
OPENAI_NAME=$(get_out openaiName)
ADX_URI=$(get_out adxClusterUri)
ADX_DB=$(get_out adxDatabaseName)
EH_NAMESPACE=$(get_out eventHubNamespaceName)

ok "Outputs captured."

# ── 4. Deploy ADX data connections (after RBAC propagation delay) ─────────────
info "Waiting 150 seconds for RBAC role assignments to propagate..."
sleep 150

ADX_NAME=$(get_out adxClusterName)

info "Looking up ADX and Event Hub resource IDs..."
ADX_CLUSTER_ID=$(az kusto cluster show \
    --name "$ADX_NAME" --resource-group "$MONITOR_RG" \
    --query id --output tsv)
IISLOGS_EH_ID=$(az eventhubs eventhub show \
    --name iislogs-eh --namespace-name "$EH_NAMESPACE" --resource-group "$MONITOR_RG" \
    --query id --output tsv)
VMPERF_EH_ID=$(az eventhubs eventhub show \
    --name vmperf-eh --namespace-name "$EH_NAMESPACE" --resource-group "$MONITOR_RG" \
    --query id --output tsv)
IISPERF_EH_ID=$(az eventhubs eventhub show \
    --name iisperf-eh --namespace-name "$EH_NAMESPACE" --resource-group "$MONITOR_RG" \
    --query id --output tsv)
BASELINE_EH_ID=$(az eventhubs eventhub show \
    --name baseline-eh --namespace-name "$EH_NAMESPACE" --resource-group "$MONITOR_RG" \
    --query id --output tsv)

ADX_URI="https://${ADX_NAME}.${DEPLOY_LOCATION}.kusto.windows.net"
info "Ensuring ADX tables exist in '$ADX_DB'..."

create_adx_table() {
    local csl="$1"
    az rest --method post \
        --uri "${ADX_URI}/v1/rest/mgmt" \
        --body "{\"db\":\"${ADX_DB}\",\"csl\":\"${csl}\"}" \
        --headers "Content-Type=application/json" \
        --resource "https://kusto.kusto.windows.net" \
        --output none 2>/dev/null || true
}

create_adx_table ".create-merge table IISLogs (TimeGenerated:datetime, Computer:string, FilePath:string, LogType:string, RawData:string)"
create_adx_table ".create-merge table VMPerf (TimeGenerated:datetime, Computer:string, ObjectName:string, CounterName:string, InstanceName:string, CounterValue:real)"
create_adx_table ".create-merge table IISPerf (TimeGenerated:datetime, Computer:string, ObjectName:string, CounterName:string, InstanceName:string, CounterValue:real)"
create_adx_table ".create-merge table PerformanceBaseline (TimeGenerated:datetime, Computer:string, RecordType:string, MetricName:string, MetricValue:real, CaptureId:string, WindowIndex:int)"

create_adx_table ".create-or-alter table IISLogs ingestion json mapping 'IISLogsMapping' '[{\"column\":\"TimeGenerated\",\"path\":\"$.TimeGenerated\",\"datatype\":\"datetime\"},{\"column\":\"Computer\",\"path\":\"$.Computer\",\"datatype\":\"string\"},{\"column\":\"FilePath\",\"path\":\"$.FilePath\",\"datatype\":\"string\"},{\"column\":\"LogType\",\"path\":\"$.LogType\",\"datatype\":\"string\"},{\"column\":\"RawData\",\"path\":\"$.RawData\",\"datatype\":\"string\"}]'"
create_adx_table ".create-or-alter table VMPerf ingestion json mapping 'VMPerfMapping' '[{\"column\":\"TimeGenerated\",\"path\":\"$.TimeGenerated\",\"datatype\":\"datetime\"},{\"column\":\"Computer\",\"path\":\"$.Computer\",\"datatype\":\"string\"},{\"column\":\"ObjectName\",\"path\":\"$.ObjectName\",\"datatype\":\"string\"},{\"column\":\"CounterName\",\"path\":\"$.CounterName\",\"datatype\":\"string\"},{\"column\":\"InstanceName\",\"path\":\"$.InstanceName\",\"datatype\":\"string\"},{\"column\":\"CounterValue\",\"path\":\"$.CounterValue\",\"datatype\":\"real\"}]'"
create_adx_table ".create-or-alter table IISPerf ingestion json mapping 'IISPerfMapping' '[{\"column\":\"TimeGenerated\",\"path\":\"$.TimeGenerated\",\"datatype\":\"datetime\"},{\"column\":\"ObjectName\",\"path\":\"$.ObjectName\",\"datatype\":\"string\"},{\"column\":\"CounterName\",\"path\":\"$.CounterName\",\"datatype\":\"string\"},{\"column\":\"InstanceName\",\"path\":\"$.InstanceName\",\"datatype\":\"string\"},{\"column\":\"CounterValue\",\"path\":\"$.CounterValue\",\"datatype\":\"real\"}]'"
create_adx_table ".create-or-alter table PerformanceBaseline ingestion json mapping 'BaselineMapping' '[{\"column\":\"TimeGenerated\",\"path\":\"$.TimeGenerated\",\"datatype\":\"datetime\"},{\"column\":\"Computer\",\"path\":\"$.Computer\",\"datatype\":\"string\"},{\"column\":\"RecordType\",\"path\":\"$.RecordType\",\"datatype\":\"string\"},{\"column\":\"MetricName\",\"path\":\"$.MetricName\",\"datatype\":\"string\"},{\"column\":\"MetricValue\",\"path\":\"$.MetricValue\",\"datatype\":\"real\"},{\"column\":\"CaptureId\",\"path\":\"$.CaptureId\",\"datatype\":\"string\"},{\"column\":\"WindowIndex\",\"path\":\"$.WindowIndex\",\"datatype\":\"int\"}]'"

create_adx_table ".create-merge table IISLogsParsed (TimeGenerated:datetime, Computer:string, SiteName:string, ServerIP:string, Method:string, UriStem:string, UriQuery:string, Port:int, Username:string, ClientIP:string, HttpVersion:string, UserAgent:string, Cookie:string, Referer:string, Host:string, StatusCode:int, SubStatus:int, Win32Status:int, TimeTakenMs:int, BytesSent:int, BytesReceived:int)"
create_adx_table ".create-or-alter function ParseIISLogs() { IISLogs | where (isempty(LogType) or LogType != 'HTTPERR') and RawData !startswith \"#\" and isnotempty(RawData) | parse RawData with LogDate:string \" \" LogTime:string \" \" SiteName:string \" \" Computer2:string \" \" ServerIP:string \" \" Method:string \" \" UriStem:string \" \" UriQuery:string \" \" Port:int \" \" Username:string \" \" ClientIP:string \" \" HttpVersion:string \" \" UserAgent:string \" \" Cookie:string \" \" Referer:string \" \" Host:string \" \" StatusCode:int \" \" SubStatus:int \" \" Win32Status:int \" \" TimeTakenMs:int \" \" BytesSent:int \" \" BytesReceived:int | project TimeGenerated, Computer, SiteName, ServerIP, Method, UriStem, UriQuery, Port, Username, ClientIP, HttpVersion, UserAgent=replace_string(UserAgent, \"+\", \" \"), Cookie, Referer, Host, StatusCode, SubStatus, Win32Status, TimeTakenMs, BytesSent, BytesReceived }"

create_adx_table ".create-merge table IISHttpErrors (TimeGenerated:datetime, Computer:string, ClientIP:string, ClientPort:int, ServerIP:string, Port:int, HttpVersion:string, Method:string, UriStem:string, StatusCode:int, SiteId:int, Reason:string, QueueName:string)"
create_adx_table ".create-or-alter function ParseHttpErrors() { IISLogs | where LogType == 'HTTPERR' and isnotempty(RawData) | parse RawData with LogDate:string \" \" LogTime:string \" \" ClientIP:string \" \" ClientPort_s:string \" \" ServerIP:string \" \" Port_s:string \" \" HttpVersion:string \" \" Method:string \" \" UriStem:string \" \" StreamId:string \" \" StreamIdEx:string \" \" StatusCode:int \" \" SiteId_s:string \" \" Reason:string \" \" QueueName:string \" \" Transport:string | project TimeGenerated, Computer, ClientIP, ClientPort=toint(ClientPort_s), ServerIP, Port=toint(Port_s), HttpVersion, Method, UriStem, StatusCode, SiteId=toint(SiteId_s), Reason, QueueName }"

az rest --method post \
    --uri "${ADX_URI}/v1/rest/mgmt" \
    --body "{\"db\":\"${ADX_DB}\",\"csl\":\".alter table IISLogsParsed policy update @'[{\\\"IsEnabled\\\": true, \\\"Source\\\": \\\"IISLogs\\\", \\\"Query\\\": \\\"ParseIISLogs()\\\", \\\"IsTransactional\\\": false, \\\"PropagateIngestionProperties\\\": true}]'\"}" \
    --headers "Content-Type=application/json" \
    --resource "https://kusto.kusto.windows.net" \
    --output none 2>/dev/null || true

az rest --method post \
    --uri "${ADX_URI}/v1/rest/mgmt" \
    --body "{\"db\":\"${ADX_DB}\",\"csl\":\".alter table IISHttpErrors policy update @'[{\\\"IsEnabled\\\": true, \\\"Source\\\": \\\"IISLogs\\\", \\\"Query\\\": \\\"ParseHttpErrors()\\\", \\\"IsTransactional\\\": false, \\\"PropagateIngestionProperties\\\": true}]'\"}" \
    --headers "Content-Type=application/json" \
    --resource "https://kusto.kusto.windows.net" \
    --output none 2>/dev/null || true

for _tbl in IISLogs VMPerf IISPerf; do
    _tmpf=$(mktemp --suffix=.json)
    cat > "$_tmpf" << EOF
{"db":"${ADX_DB}","csl":".alter table ${_tbl} policy ingestionbatching '{\"MaximumBatchingTimeSpan\":\"00:00:30\",\"MaximumNumberOfItems\":500,\"MaximumRawDataSizeMB\":1024}'"}
EOF
    az rest --method post \
        --uri "${ADX_URI}/v1/rest/mgmt" \
        --body "@${_tmpf}" \
        --headers "Content-Type=application/json" \
        --resource "https://kusto.kusto.windows.net" \
        --output none 2>/dev/null || true
    rm "$_tmpf"
done

ok "ADX tables, mappings, IISLogsParsed and IISHttpErrors update policies verified."

info "Deploying ADX Event Hub data connections..."
ADX_CONN_TEMPLATE=$(cygpath -w "$PROJECT_ROOT/infra/modules/adx_connections.bicep" 2>/dev/null \
    || echo "$PROJECT_ROOT/infra/modules/adx_connections.bicep")

_adx_conn_max_attempts=4
_adx_conn_attempt=0
while true; do
    _adx_conn_attempt=$(( _adx_conn_attempt + 1 ))
    info "ADX connections deployment attempt ${_adx_conn_attempt}/${_adx_conn_max_attempts}..."
    if MSYS_NO_PATHCONV=1 az deployment group create \
        --resource-group "$MONITOR_RG" \
        --template-file  "$ADX_CONN_TEMPLATE" \
        --parameters \
            location="$DEPLOY_LOCATION" \
            adxClusterName="$ADX_NAME" \
            adxClusterId="$ADX_CLUSTER_ID" \
            adxDatabaseName="$ADX_DB" \
            iisLogsEventHubId="$IISLOGS_EH_ID" \
            iisLogsConsumerGroupName="adx-consumer" \
            vmPerfEventHubId="$VMPERF_EH_ID" \
            vmPerfConsumerGroupName="adx-consumer" \
            iisPerfEventHubId="$IISPERF_EH_ID" \
            iisPerfConsumerGroupName="adx-consumer" \
            baselineEventHubId="$BASELINE_EH_ID" \
            baselineConsumerGroupName="adx-consumer" \
        --output none 2>&1; then
        ok "ADX data connections deployed (iislogs, vmperf, iisperf, baseline)."
        break
    fi
    if [[ $_adx_conn_attempt -ge $_adx_conn_max_attempts ]]; then
        die "ADX data connections failed after ${_adx_conn_max_attempts} attempts. RBAC may need more time — re-run deploy.sh."
    fi
    warn "ADX connections attempt ${_adx_conn_attempt} failed (RBAC likely not yet propagated). Waiting 60 s before retry..."
    sleep 60
done

# ── 4c. Create Agent Logging DCRs ────────────────────────────────────────────
info "Configuring agent logging Data Collection Rules..."

DCE_ID=$(az monitor data-collection endpoint list \
    --resource-group "$MONITOR_RG" \
    --query "[?starts_with(name,'iisheal')].id | [0]" --output tsv 2>/dev/null)

[[ -z "$DCE_ID" ]] && die "Could not find Data Collection Endpoint in $MONITOR_RG"
ok "DCE resource ID: $DCE_ID"

FUNC_MI_PRINCIPAL=$(az functionapp identity show \
    --name "$FUNC_APP_NAME" --resource-group "$CORE_RG" \
    --query principalId --output tsv 2>/dev/null)

[[ -z "$FUNC_MI_PRINCIPAL" ]] && die "Function App managed identity not found."
ok "Function App MI principal: $FUNC_MI_PRINCIPAL"

SUBSCRIPTION_ID=$(az account show --query id --output tsv)

upsert_agent_dcr() {
    local dcr_name="$1" dcr_body_file="$2"
    local win_path
    win_path=$(cygpath -w "$dcr_body_file")
    MSYS_NO_PATHCONV=1 az rest --method PUT \
        --uri "https://management.azure.com/subscriptions/${SUBSCRIPTION_ID}/resourceGroups/${MONITOR_RG}/providers/Microsoft.Insights/dataCollectionRules/${dcr_name}?api-version=2023-03-11" \
        --body "@${win_path}" \
        --headers "Content-Type=application/json" \
        --output none
    az monitor data-collection rule show \
        --name "$dcr_name" --resource-group "$MONITOR_RG" \
        --query immutableId --output tsv
}

_tmp_dcr=$(mktemp --suffix=.json)
cat > "$_tmp_dcr" << DCREOF
{
  "location": "${DEPLOY_LOCATION}",
  "properties": {
    "dataCollectionEndpointId": "${DCE_ID}",
    "streamDeclarations": {
      "Custom-AgentEvents_CL": {
        "columns": [
          { "name": "TimeGenerated",        "type": "datetime" },
          { "name": "VMHostname",           "type": "string"   },
          { "name": "AlertId",              "type": "string"   },
          { "name": "AlertName",            "type": "string"   },
          { "name": "Severity",             "type": "string"   },
          { "name": "IssueType",            "type": "string"   },
          { "name": "IssueSummary",         "type": "string"   },
          { "name": "DetectionTime",        "type": "datetime" },
          { "name": "AnalysisResult",       "type": "string"   },
          { "name": "MitigationSteps",      "type": "string"   },
          { "name": "RunbookExecuted",      "type": "string"   },
          { "name": "RemediationOutcome",   "type": "string"   },
          { "name": "RemediationDetail",    "type": "string"   },
          { "name": "IsHealthy",            "type": "boolean"  },
          { "name": "RetryCount",           "type": "int"      },
          { "name": "RootCause",            "type": "string"   },
          { "name": "NextSteps",            "type": "string"   },
          { "name": "ReasoningModel",       "type": "string"   },
          { "name": "FastModel",            "type": "string"   },
          { "name": "AgentVersion",         "type": "string"   },
          { "name": "TotalDurationSeconds", "type": "real"     },
          { "name": "DecisionAction",       "type": "string"   },
          { "name": "DecisionConfidence",   "type": "string"   },
          { "name": "Strategy",             "type": "string"   },
          { "name": "EscalationTarget",     "type": "string"   }
        ]
      }
    },
    "destinations": {
      "logAnalytics": [
        {
          "workspaceResourceId": "${LAW_ID}",
          "name": "law-destination"
        }
      ]
    },
    "dataFlows": [
      {
        "streams": ["Custom-AgentEvents_CL"],
        "destinations": ["law-destination"],
        "transformKql": "source",
        "outputStream": "Custom-AgentEvents_CL"
      }
    ]
  }
}
DCREOF
DCR_EVENTS_ID=$(upsert_agent_dcr "iisheal-dcr-agent-events" "$_tmp_dcr")
rm "$_tmp_dcr"
ok "  DCR iisheal-dcr-agent-events (immutableId: $DCR_EVENTS_ID)"

_tmp_dcr=$(mktemp --suffix=.json)
cat > "$_tmp_dcr" << DCREOF
{
  "location": "${DEPLOY_LOCATION}",
  "properties": {
    "dataCollectionEndpointId": "${DCE_ID}",
    "streamDeclarations": {
      "Custom-AgentErrors_CL": {
        "columns": [
          { "name": "TimeGenerated", "type": "datetime" },
          { "name": "VMHostname",    "type": "string"   },
          { "name": "Agent",         "type": "string"   },
          { "name": "Error",         "type": "string"   }
        ]
      }
    },
    "destinations": {
      "logAnalytics": [
        {
          "workspaceResourceId": "${LAW_ID}",
          "name": "law-destination"
        }
      ]
    },
    "dataFlows": [
      {
        "streams": ["Custom-AgentErrors_CL"],
        "destinations": ["law-destination"],
        "transformKql": "source",
        "outputStream": "Custom-AgentErrors_CL"
      }
    ]
  }
}
DCREOF
DCR_ERRORS_ID=$(upsert_agent_dcr "iisheal-dcr-agent-errors" "$_tmp_dcr")
rm "$_tmp_dcr"
ok "  DCR iisheal-dcr-agent-errors (immutableId: $DCR_ERRORS_ID)"

METRICS_PUBLISHER_ROLE="3913510d-42f4-4e42-8a64-420c390055eb"

assign_dcr_role() {
    local dcr_name="$1"
    local dcr_scope
    dcr_scope=$(az monitor data-collection rule show \
        --name "$dcr_name" --resource-group "$MONITOR_RG" \
        --query id --output tsv)

    MSYS_NO_PATHCONV=1 az role assignment create \
        --assignee-object-id "$FUNC_MI_PRINCIPAL" \
        --assignee-principal-type ServicePrincipal \
        --role "$METRICS_PUBLISHER_ROLE" \
        --scope "$dcr_scope" \
        --output none 2>/dev/null || true
    ok "  Monitoring Metrics Publisher → $dcr_name"
}

assign_dcr_role "iisheal-dcr-agent-events"
assign_dcr_role "iisheal-dcr-agent-errors"

info "Setting agent logging app settings on '$FUNC_APP_NAME'..."
az functionapp config appsettings set \
    --name "$FUNC_APP_NAME" \
    --resource-group "$CORE_RG" \
    --settings \
        "DCR_AGENT_EVENTS_RULE_ID=$DCR_EVENTS_ID" \
        "DCR_AGENT_ERRORS_RULE_ID=$DCR_ERRORS_ID" \
    --output none
ok "Agent logging DCRs configured and app settings applied."

info "Updating AgentEvents_CL and AgentErrors_CL table schemas..."
LAW_WS_RG=$(echo "$LAW_ID" | sed 's|.*/resourceGroups/\([^/]*\)/.*|\1|')
LAW_WS_NAME=$(basename "$LAW_ID")

upsert_law_table() {
    local table_name="$1" body_file="$2"
    local win_path
    win_path=$(cygpath -w "$body_file")
    MSYS_NO_PATHCONV=1 az rest --method PUT \
        --uri "https://management.azure.com/subscriptions/${SUBSCRIPTION_ID}/resourceGroups/${LAW_WS_RG}/providers/Microsoft.OperationalInsights/workspaces/${LAW_WS_NAME}/tables/${table_name}?api-version=2022-10-01" \
        --body "@${win_path}" \
        --headers "Content-Type=application/json" \
        --output none 2>&1 || true
}

_tmp_tbl=$(mktemp --suffix=.json)
cat > "$_tmp_tbl" << 'TBLEOF'
{
  "properties": {
    "retentionInDays": 30,
    "schema": {
      "name": "AgentEvents_CL",
      "columns": [
        {"name": "TimeGenerated",        "type": "datetime"},
        {"name": "VMHostname",           "type": "string"},
        {"name": "AlertId",              "type": "string"},
        {"name": "AlertName",            "type": "string"},
        {"name": "Severity",             "type": "string"},
        {"name": "IssueType",            "type": "string"},
        {"name": "IssueSummary",         "type": "string"},
        {"name": "DetectionTime",        "type": "datetime"},
        {"name": "AnalysisResult",       "type": "string"},
        {"name": "MitigationSteps",      "type": "string"},
        {"name": "RunbookExecuted",      "type": "string"},
        {"name": "RemediationOutcome",   "type": "string"},
        {"name": "RemediationDetail",    "type": "string"},
        {"name": "IsHealthy",            "type": "boolean"},
        {"name": "RetryCount",           "type": "int"},
        {"name": "RootCause",            "type": "string"},
        {"name": "NextSteps",            "type": "string"},
        {"name": "ReasoningModel",       "type": "string"},
        {"name": "FastModel",            "type": "string"},
        {"name": "AgentVersion",         "type": "string"},
        {"name": "TotalDurationSeconds", "type": "real"},
        {"name": "DecisionAction",       "type": "string"},
        {"name": "DecisionConfidence",   "type": "string"},
        {"name": "Strategy",             "type": "string"},
        {"name": "EscalationTarget",     "type": "string"}
      ]
    }
  }
}
TBLEOF
upsert_law_table "AgentEvents_CL" "$_tmp_tbl"
rm "$_tmp_tbl"

_tmp_tbl=$(mktemp --suffix=.json)
cat > "$_tmp_tbl" << 'TBLEOF'
{
  "properties": {
    "retentionInDays": 30,
    "schema": {
      "name": "AgentErrors_CL",
      "columns": [
        {"name": "TimeGenerated", "type": "datetime"},
        {"name": "VMHostname",    "type": "string"},
        {"name": "Agent",         "type": "string"},
        {"name": "Error",         "type": "string"}
      ]
    }
  }
}
TBLEOF
upsert_law_table "AgentErrors_CL" "$_tmp_tbl"
rm "$_tmp_tbl"
ok "LAW table schemas verified."

# ── 5. Deploy chaos web app files ─────────────────────────────────────────────
# az vm run-command uses the Azure management plane — works regardless of
# whether the deploy machine has direct network reach to the VM's private IP.
info "Deploying chaos web app files to VM '$VM_NAME'..."

deploy_file() {
    local src="$1" dst="$2"
    local b64
    b64=$(base64 -w 0 "$src" 2>/dev/null || base64 "$src" | tr -d '\n')
    local tmp_ps
    tmp_ps=$(mktemp "${TMPDIR:-/tmp}/deploy_XXXXXX.ps1")
    cat > "$tmp_ps" << DEPLOYEOF
\$b64 = '${b64}'
\$dir = [System.IO.Path]::GetDirectoryName('${dst}')
if (-not (Test-Path \$dir)) { New-Item -ItemType Directory -Force -Path \$dir | Out-Null }
[System.IO.File]::WriteAllBytes('${dst}', [System.Convert]::FromBase64String(\$b64))
Write-Output 'OK'
DEPLOYEOF
    az vm run-command invoke \
        --resource-group "$CORE_RG" \
        --name           "$VM_NAME" \
        --command-id     RunPowerShellScript \
        --scripts        @"$tmp_ps" \
        --output none
    rm -f "$tmp_ps"
    ok "  $(basename "$src")  →  $dst"
}

# chaos-app lives in the original project root; reference it relative to v2/.
CHAOS_ROOT="$(cd "$PROJECT_ROOT/.." && pwd)/chaos-app"

deploy_file "$CHAOS_ROOT/default.aspx"          'C:\inetpub\wwwroot\default.aspx'
deploy_file "$CHAOS_ROOT/default.aspx.cs"       'C:\inetpub\wwwroot\default.aspx.cs'
deploy_file "$CHAOS_ROOT/Web.config"            'C:\inetpub\wwwroot\Web.config'
deploy_file "$CHAOS_ROOT/chaos/default.aspx"    'C:\inetpub\wwwroot\chaos\default.aspx'
deploy_file "$CHAOS_ROOT/chaos/default.aspx.cs" 'C:\inetpub\wwwroot\chaos\default.aspx.cs'
deploy_file "$CHAOS_ROOT/chaos/Web.config"      'C:\inetpub\wwwroot\chaos\Web.config'

info "Restarting IIS..."
az vm run-command invoke \
    --resource-group "$CORE_RG" \
    --name           "$VM_NAME" \
    --command-id     RunPowerShellScript \
    --scripts        "iisreset /restart" \
    --output none
ok "IIS restarted — chaos app is live."

# ── 5b. (PowerShell 7 install removed) ────────────────────────────────────────
# v2 runbooks use Windows PowerShell 5.1 only; no PS7 install on the VM.

# ── 5d. Deploy baseline capture script ────────────────────────────────────────
BASELINE_ROOT="$(cd "$PROJECT_ROOT/.." && pwd)/baseline"
info "Deploying baseline capture script to VM '$VM_NAME'..."
deploy_file "$BASELINE_ROOT/run_baseline.ps1" 'C:\iis-autohealing\baseline\run_baseline.ps1'
ok "Baseline script deployed (used by Invoke-CaptureBaseline runbook)."

# ── 5e. Deploy perf-to-EventHub scheduled task ────────────────────────────────
info "Deploying Send-PerfToEventHub.ps1 to VM '$VM_NAME'..."
deploy_file "$PROJECT_ROOT/scripts/Send-PerfToEventHub.ps1" 'C:\Scripts\Send-PerfToEventHub.ps1'

info "Registering perf-collection scheduled task (runs every 60 s as SYSTEM)..."
az vm run-command invoke \
    --resource-group "$CORE_RG" \
    --name           "$VM_NAME" \
    --command-id     RunPowerShellScript \
    --scripts "schtasks.exe /Delete /TN 'SendPerfToEventHub' /F 2>\$null; schtasks.exe /Create /TN 'SendPerfToEventHub' /SC MINUTE /MO 1 /TR \"powershell.exe -NonInteractive -NoProfile -WindowStyle Hidden -File C:\Scripts\Send-PerfToEventHub.ps1 -EventHubNamespace ${EH_NAMESPACE}\" /RU SYSTEM /RL HIGHEST /F; schtasks.exe /Run /TN 'SendPerfToEventHub'" \
    --output none
ok "Perf-collection scheduled task registered on VM (every 60 s → Event Hub '$EH_NAMESPACE')."

# ── 6. Deploy Function App code via run-from-package ──────────────────────────
# The Function App's SCM site is on a private endpoint; `func publish` would fail.
# Instead:
#   1. zip v2/function-app/
#   2. temp-allow caller IP on FA storage (storage public access is Disabled by default)
#   3. az storage blob upload (auth-mode login; needs Storage Blob Data Contributor)
#   4. user-delegation SAS (no account keys)
#   5. WEBSITE_RUN_FROM_PACKAGE = SAS URL
#   6. revoke caller-IP allowance and restart
info "Packaging Function App code..."
FUNC_ZIP="/tmp/functionapp-$(date +%s).zip"
(cd "$PROJECT_ROOT/function-app" && zip -r "$FUNC_ZIP" . -x "*.pyc" "__pycache__/*" ".venv/*" ".python_packages/*" >/dev/null)
ok "Zip created: $FUNC_ZIP ($(wc -c < "$FUNC_ZIP") bytes)"

CALLER_IP=$(curl -s https://api.ipify.org)
[[ -z "$CALLER_IP" ]] && die "Could not detect caller IP via api.ipify.org."
info "Caller IP: $CALLER_IP — temporarily allowing on '$FA_STORAGE'..."

az storage account network-rule add \
    --account-name "$FA_STORAGE" \
    --resource-group "$CORE_RG" \
    --ip-address "$CALLER_IP" \
    --output none 2>/dev/null || true

# Storage also needs publicNetworkAccess=Enabled briefly for the IP rule to apply.
# Bicep sets it to Disabled; flip to Enabled with default=Deny so only our IP works.
az storage account update \
    --name "$FA_STORAGE" \
    --resource-group "$CORE_RG" \
    --public-network-access Enabled \
    --default-action Deny \
    --output none

info "Waiting 15 s for storage network rule propagation..."
sleep 15

BLOB_NAME="functionapp-$(date +%s).zip"
info "Ensuring 'function-packages' container exists..."
az storage container create \
    --name function-packages \
    --account-name "$FA_STORAGE" \
    --auth-mode login \
    --output none 2>/dev/null || true

info "Uploading $BLOB_NAME to $FA_STORAGE/function-packages..."
az storage blob upload \
    --account-name "$FA_STORAGE" \
    --container-name function-packages \
    --name "$BLOB_NAME" \
    --file "$FUNC_ZIP" \
    --auth-mode login \
    --overwrite \
    --output none

info "Generating 10-year user-delegation SAS..."
SAS_EXPIRY=$(date -u -d '+3650 days' +%Y-%m-%dT%H:%MZ 2>/dev/null || date -u -v+3650d +%Y-%m-%dT%H:%MZ)
SAS=$(az storage blob generate-sas \
    --account-name "$FA_STORAGE" \
    --container-name function-packages \
    --name "$BLOB_NAME" \
    --permissions r \
    --expiry "$SAS_EXPIRY" \
    --auth-mode login \
    --as-user \
    --full-uri false \
    --output tsv)

PKG_URL="https://${FA_STORAGE}.blob.core.windows.net/function-packages/${BLOB_NAME}?${SAS}"

info "Setting WEBSITE_RUN_FROM_PACKAGE on '$FUNC_APP_NAME'..."
az functionapp config appsettings set \
    --name "$FUNC_APP_NAME" \
    --resource-group "$CORE_RG" \
    --settings "WEBSITE_RUN_FROM_PACKAGE=$PKG_URL" \
    --output none

info "Revoking caller-IP network rule..."
az storage account network-rule remove \
    --account-name "$FA_STORAGE" \
    --resource-group "$CORE_RG" \
    --ip-address "$CALLER_IP" \
    --output none 2>/dev/null || true

az storage account update \
    --name "$FA_STORAGE" \
    --resource-group "$CORE_RG" \
    --public-network-access Disabled \
    --output none

info "Restarting Function App..."
az functionapp restart --name "$FUNC_APP_NAME" --resource-group "$CORE_RG" --output none
rm -f "$FUNC_ZIP"
ok "Function App code deployed via run-from-package."

# ── 7. Upload and publish runbooks ─────────────────────────────────────────────
info "Uploading runbooks to Automation Account '$AUTO_ACCOUNT' (RG: $MONITOR_RG)..."
RUNBOOK_COUNT=0

for rb_file in "$PROJECT_ROOT/runbooks"/*.ps1; do
    [[ -f "$rb_file" ]] || { warn "No runbook files found."; break; }
    rb_name=$(basename "$rb_file" .ps1)
    info "  Uploading: $rb_name"

    az automation runbook replace-content \
        --resource-group          "$MONITOR_RG" \
        --automation-account-name "$AUTO_ACCOUNT" \
        --name                    "$rb_name" \
        --content @"$rb_file" \
        --output none 2>/dev/null || {
            warn "  '$rb_name' not found — creating..."
            az automation runbook create \
                --resource-group          "$MONITOR_RG" \
                --automation-account-name "$AUTO_ACCOUNT" \
                --name                    "$rb_name" \
                --type                    PowerShell \
                --output none
            az automation runbook replace-content \
                --resource-group          "$MONITOR_RG" \
                --automation-account-name "$AUTO_ACCOUNT" \
                --name                    "$rb_name" \
                --content @"$rb_file" \
                --output none
        }

    az automation runbook publish \
        --resource-group          "$MONITOR_RG" \
        --automation-account-name "$AUTO_ACCOUNT" \
        --name                    "$rb_name" \
        --output none

    ok "  Published: $rb_name"
    RUNBOOK_COUNT=$((RUNBOOK_COUNT + 1))
done
ok "Uploaded and published $RUNBOOK_COUNT runbook(s)."

# ── 8. Register Hybrid Runbook Worker ─────────────────────────────────────────
info "Registering VM as Hybrid Runbook Worker..."

VM_ID=$(az vm show --resource-group "$CORE_RG" --name "$VM_NAME" --query id --output tsv)
WORKER_GROUP="IIS-HybridWorkers"

EXISTING_WORKERS=$(az automation hrwg hrw list \
    --resource-group "$MONITOR_RG" \
    --automation-account-name "$AUTO_ACCOUNT" \
    --hybrid-runbook-worker-group-name "$WORKER_GROUP" \
    --query "length(@)" --output tsv 2>/dev/null || echo "0")

if [[ "$EXISTING_WORKERS" -gt 0 ]]; then
    ok "Hybrid Worker already registered ($EXISTING_WORKERS worker(s) in '$WORKER_GROUP')."
else
    WORKER_ID=$(od -An -tx4 -N16 /dev/urandom | tr -d ' \n' \
        | sed 's/\(.\{8\}\)\(.\{4\}\)\(.\{4\}\)\(.\{4\}\)\(.\{12\}\)/\1-\2-\3-\4-\5/')

    MSYS_NO_PATHCONV=1 az automation hrwg hrw create \
        --resource-group "$MONITOR_RG" \
        --automation-account-name "$AUTO_ACCOUNT" \
        --hybrid-runbook-worker-group-name "$WORKER_GROUP" \
        --hybrid-runbook-worker-id "$WORKER_ID" \
        --vm-resource-id "$VM_ID" \
        --output none
    ok "Hybrid Worker registered (ID: $WORKER_ID)."
fi

HW_EXT=$(az vm extension list --resource-group "$CORE_RG" --vm-name "$VM_NAME" \
    --query "[?name=='HybridWorkerForWindows'].provisioningState" --output tsv 2>/dev/null || echo "")

if [[ "$HW_EXT" == "Succeeded" ]]; then
    ok "HybridWorkerForWindows extension already installed."
else
    info "Installing HybridWorkerForWindows extension on VM (this takes ~1 minute)..."
    AA_URL=$(az automation account show \
        --resource-group "$MONITOR_RG" --name "$AUTO_ACCOUNT" \
        --query automationHybridServiceUrl --output tsv 2>/dev/null)

    MSYS_NO_PATHCONV=1 az vm extension set \
        --resource-group "$CORE_RG" \
        --vm-name "$VM_NAME" \
        --name HybridWorkerForWindows \
        --publisher Microsoft.Azure.Automation.HybridWorker \
        --version 1.1 \
        --settings "{\"AutomationAccountURL\":\"${AA_URL}\"}" \
        --output none
    ok "HybridWorkerForWindows extension installed."
fi
echo ""

# ── 9. Summary ────────────────────────────────────────────────────────────────
echo -e "${GREEN}══════════════════════════════════════════════════════════════════${NC}"
echo -e "${GREEN}  v2 DEPLOYMENT SUMMARY${NC}"
echo -e "${GREEN}══════════════════════════════════════════════════════════════════${NC}"
echo ""
printf "  %-28s %s\n" "Core RG:"               "$CORE_RG"
printf "  %-28s %s\n" "Monitor RG:"             "$MONITOR_RG"
printf "  %-28s %s\n" "VM Name:"                "$VM_NAME"
printf "  %-28s %s\n" "VM Private IP:"          "$VM_IP"
printf "  %-28s %s\n" "VM access:"              "enterprise internal network only (no Bastion)"
printf "  %-28s %s\n" "Main site (from VNet):"  "http://$VM_IP/"
printf "  %-28s %s\n" "Chaos console (from VNet):" "http://$VM_IP/chaos/"
printf "  %-28s %s\n" "Function App:"           "$FUNC_APP_NAME"
printf "  %-28s %s\n" "Function Storage:"       "$FA_STORAGE"
printf "  %-28s %s\n" "Automation Account:"     "$AUTO_ACCOUNT"
printf "  %-28s %s\n" "OpenAI Endpoint:"        "$OPENAI_ENDPOINT"
printf "  %-28s %s\n" "ADX Cluster:"            "$ADX_URI"
printf "  %-28s %s\n" "ADX Database:"           "$ADX_DB"
printf "  %-28s %s\n" "Event Hub Namespace:"    "$EH_NAMESPACE"
printf "  %-28s %s\n" "LAW Workspace ID:"       "$LAW_ID"
printf "  %-28s %s\n" "Runbooks Deployed:"      "$RUNBOOK_COUNT"
echo ""
ok "Deployment complete."
