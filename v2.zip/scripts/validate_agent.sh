#!/usr/bin/env bash
set -euo pipefail

###############################################################################
# validate_agent.sh - Validate that all IIS auto-healing components are live
#
# Checks:
#   1. LAW custom tables  (AgentEvents_CL, AgentErrors_CL, alert-tier perf)
#   2. ADX tables         (IISLogs, IISLogsParsed, VMPerf, IISPerf, PerformanceBaseline)
#   3. ADX data connections (4 Event Hub → ADX pipelines)
#   4. Function App       (reachable, functions loaded)
#   5. Agent DCRs         (AgentEvents + AgentErrors DCRs exist, RBAC assigned)
#   6. Automation Account (runbooks published, Hybrid Worker registered)
#   7. Azure OpenAI       (o4-mini + gpt-4o-mini deployments)
#
# Usage:
#   bash scripts/validate_agent.sh
#
# Optional overrides:
#   export CORE_RG='iis-core'
#   export MONITOR_RG='iis-core-monitor'
###############################################################################

CORE_RG="${CORE_RG:-iis-core}"
MONITOR_RG="${MONITOR_RG:-iis-core-monitor}"

RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
CYAN='\033[0;36m'
NC='\033[0m'

info()  { echo -e "${CYAN}[INFO]${NC}  $*"; }
ok()    { echo -e "${GREEN}[OK]${NC}    $*"; }
warn()  { echo -e "${YELLOW}[WARN]${NC}  $*"; }
error() { echo -e "${RED}[ERROR]${NC} $*" >&2; }
die()   { error "$@"; exit 1; }

PASS_COUNT=0
FAIL_COUNT=0
WARN_COUNT=0

record_pass() { PASS_COUNT=$((PASS_COUNT + 1)); }
record_fail() { FAIL_COUNT=$((FAIL_COUNT + 1)); }
record_warn() { WARN_COUNT=$((WARN_COUNT + 1)); }

# ─── Prerequisites ─────────────────────────────────────────────────────────
command -v az >/dev/null 2>&1 || die "Azure CLI (az) not found."

# Locate jq — winget installs it outside PATH on Windows
if command -v jq &>/dev/null; then
    JQ="jq"
else
    # Search common winget / chocolatey / manual install paths
    for candidate in \
        "${LOCALAPPDATA:-}"/Microsoft/WinGet/Packages/jqlang.jq_*/jq.exe \
        "${HOME:-}"/AppData/Local/Microsoft/WinGet/Packages/jqlang.jq_*/jq.exe \
        "/c/ProgramData/chocolatey/bin/jq.exe" \
        "/mingw64/bin/jq.exe"; do
        if [[ -x "$candidate" ]]; then
            JQ="$candidate"
            break
        fi
    done
fi
[[ -z "${JQ:-}" ]] && die "jq is required. Install: winget install jqlang.jq"
ok "jq found: $JQ"

if ! az account show --output none 2>/dev/null; then
    die "Not logged in to Azure CLI. Run 'az login' first."
fi

# ─── Auto-discover resource names from subscription deployment ─────────────
info "Discovering resources from latest subscription deployment..."

# Find the most recent iis-autohealing deployment
DEPLOYMENT_NAME=$(az deployment sub list \
    --query "sort_by([?starts_with(name,'iis-autohealing')], &properties.timestamp) | [-1].name" \
    --output tsv 2>/dev/null || echo "")

if [[ -z "$DEPLOYMENT_NAME" ]]; then
    die "No iis-autohealing deployment found. Run deploy.sh first."
fi

OUTPUTS=$(az deployment sub show \
    --name "$DEPLOYMENT_NAME" \
    --query "properties.outputs" \
    --output json 2>/dev/null || echo "{}")

get_out() { echo "$OUTPUTS" | "$JQ" -r ".$1.value // empty"; }

VM_NAME=$(get_out vmName)
VM_IP=$(get_out vmPublicIp)
LAW_ID=$(get_out lawWorkspaceId)
LAW_CUSTOMER_ID=$(get_out lawWorkspaceCustomerId)
DCE_ENDPOINT=$(get_out dceEndpoint)
FUNC_APP_NAME=$(get_out functionAppName)
FUNC_APP_HOST=$(get_out functionAppHostname)
AUTO_ACCOUNT=$(get_out automationAccountName)
OPENAI_NAME=$(get_out openaiName)
ADX_CLUSTER_NAME=$(get_out adxClusterName)
ADX_DB=$(get_out adxDatabaseName)
EH_NAMESPACE=$(get_out eventHubNamespaceName)

# Derive ADX URI — az returns "East US 2" but Kusto URIs need "eastus2"
ADX_LOCATION_RAW=$(az kusto cluster show --name "$ADX_CLUSTER_NAME" --resource-group "$MONITOR_RG" \
    --query location --output tsv 2>/dev/null || echo "eastus2")
ADX_LOCATION=$(echo "$ADX_LOCATION_RAW" | tr '[:upper:]' '[:lower:]' | tr -d ' ')
ADX_URI="https://${ADX_CLUSTER_NAME}.${ADX_LOCATION}.kusto.windows.net"

# Get VM OS hostname (used in LAW perf table names — different from Azure resource name)
VM_HOSTNAME=$(az vm show --resource-group "$CORE_RG" --name "$VM_NAME" \
    --query "osProfile.computerName" --output tsv 2>/dev/null || echo "$VM_NAME")

echo ""
echo -e "${CYAN}=================================================================${NC}"
echo -e "${CYAN}  IIS AUTO-HEALING AGENT VALIDATION${NC}"
echo -e "${CYAN}=================================================================${NC}"
echo ""
info "Deployment:         $DEPLOYMENT_NAME"
info "Core RG:            $CORE_RG"
info "Monitor RG:         $MONITOR_RG"
info "VM:                 $VM_NAME ($VM_IP)"
info "Function App:       $FUNC_APP_NAME"
info "Automation Account: $AUTO_ACCOUNT"
info "OpenAI:             $OPENAI_NAME"
info "ADX Cluster:        $ADX_URI"
info "ADX Database:       $ADX_DB"
info "Event Hub NS:       $EH_NAMESPACE"
echo ""

# ─── Helper: Query LAW table row count (last 24h) ─────────────────────────
# NOTE: --workspace requires the customer ID (GUID), not the resource ID path
query_law_count() {
    local table="$1"
    az monitor log-analytics query \
        --workspace "$LAW_CUSTOMER_ID" \
        --analytics-query "${table} | where TimeGenerated > ago(24h) | count" \
        --query "[0].Count" --output tsv 2>/dev/null || echo "ERROR"
}

# ─── Helper: Query ADX table row count ────────────────────────────────────
query_adx_count() {
    local table="$1"
    local csl="${table} | count"
    local result
    result=$(az rest --method post \
        --uri "${ADX_URI}/v1/rest/query" \
        --body "{\"db\":\"${ADX_DB}\",\"csl\":\"${csl}\"}" \
        --headers "Content-Type=application/json" \
        --resource "https://kusto.kusto.windows.net" \
        --output json 2>/dev/null \
        | "$JQ" -r '.Tables[0].Rows[0][0] // "ERROR"' 2>/dev/null \
        || echo "ERROR")
    echo "$result"
}

# ═══════════════════════════════════════════════════════════════════════════
# 1. LOG ANALYTICS TABLES
# ═══════════════════════════════════════════════════════════════════════════
echo -e "${CYAN}── 1. Log Analytics Tables (last 24h) ─────────────────────────${NC}"
echo ""
printf "  %-35s %s\n" "TABLE" "ROWS"
printf "  %-35s %s\n" "───────────────────────────────────" "─────────"

LAW_TABLES=("AgentEvents_CL" "AgentErrors_CL" "VMPerf_${VM_HOSTNAME}_CL" "IISPerf_${VM_HOSTNAME}_CL")

for table in "${LAW_TABLES[@]}"; do
    COUNT=$(query_law_count "$table")
    if [[ "$COUNT" == "ERROR" || -z "$COUNT" ]]; then
        printf "  %-35s ${RED}%-10s${NC}\n" "$table" "ERROR"
        record_fail
    elif [[ "$COUNT" == "0" ]]; then
        printf "  %-35s ${YELLOW}%-10s${NC}\n" "$table" "$COUNT"
        record_warn
    else
        printf "  %-35s ${GREEN}%-10s${NC}\n" "$table" "$COUNT"
        record_pass
    fi
done
echo ""

# ═══════════════════════════════════════════════════════════════════════════
# 2. ADX TABLES
# ═══════════════════════════════════════════════════════════════════════════
echo -e "${CYAN}── 2. ADX Tables (all time) ───────────────────────────────────${NC}"
echo ""
printf "  %-35s %s\n" "TABLE" "ROWS"
printf "  %-35s %s\n" "───────────────────────────────────" "─────────"

ADX_TABLES=("IISLogs" "IISLogsParsed" "VMPerf" "IISPerf" "PerformanceBaseline")

for table in "${ADX_TABLES[@]}"; do
    COUNT=$(query_adx_count "$table")
    if [[ "$COUNT" == "ERROR" || -z "$COUNT" ]]; then
        printf "  %-35s ${RED}%-10s${NC}\n" "$table" "ERROR"
        record_fail
    elif [[ "$COUNT" == "0" ]]; then
        printf "  %-35s ${YELLOW}%-10s${NC}\n" "$table" "$COUNT"
        record_warn
    else
        printf "  %-35s ${GREEN}%-10s${NC}\n" "$table" "$COUNT"
        record_pass
    fi
done
echo ""

# ═══════════════════════════════════════════════════════════════════════════
# 3. ADX DATA CONNECTIONS (Event Hub → ADX pipelines)
# ═══════════════════════════════════════════════════════════════════════════
echo -e "${CYAN}── 3. ADX Data Connections ────────────────────────────────────${NC}"
echo ""

EXPECTED_CONNECTIONS=("iislogs-connection" "vmperf-connection" "iisperf-connection" "baseline-connection")
ACTUAL_CONNECTIONS=$(az kusto data-connection list \
    --cluster-name "$ADX_CLUSTER_NAME" \
    --database-name "$ADX_DB" \
    --resource-group "$MONITOR_RG" \
    --query "[].name" --output tsv 2>/dev/null || echo "ERROR")

if [[ "$ACTUAL_CONNECTIONS" == "ERROR" ]]; then
    printf "  ${RED}Failed to query ADX data connections.${NC}\n"
    record_fail
else
    for conn in "${EXPECTED_CONNECTIONS[@]}"; do
        if echo "$ACTUAL_CONNECTIONS" | grep -qi "$conn"; then
            printf "  %-35s ${GREEN}%s${NC}\n" "$conn" "EXISTS"
            record_pass
        else
            printf "  %-35s ${RED}%s${NC}\n" "$conn" "MISSING"
            record_fail
        fi
    done
fi
echo ""

# ═══════════════════════════════════════════════════════════════════════════
# 4. FUNCTION APP
# ═══════════════════════════════════════════════════════════════════════════
echo -e "${CYAN}── 4. Function App ────────────────────────────────────────────${NC}"
echo ""

FUNC_URL="https://${FUNC_APP_HOST:-$FUNC_APP_NAME.azurewebsites.net}"

# Check the app is reachable (the healing endpoint returns 404 on GET, which is fine)
HTTP_CODE=$(curl -s -o /dev/null -w "%{http_code}" --max-time 15 \
    "$FUNC_URL/api/IISHealingOrchestrator" 2>/dev/null || echo "000")

if [[ "$HTTP_CODE" == "000" ]]; then
    printf "  %-35s ${RED}%s${NC}\n" "Endpoint reachable:" "NO (timeout/DNS)"
    record_fail
elif [[ "$HTTP_CODE" == "404" || "$HTTP_CODE" == "200" || "$HTTP_CODE" == "401" ]]; then
    printf "  %-35s ${GREEN}%s${NC}\n" "Endpoint reachable:" "YES (HTTP $HTTP_CODE)"
    record_pass
else
    printf "  %-35s ${YELLOW}%s${NC}\n" "Endpoint reachable:" "HTTP $HTTP_CODE"
    record_warn
fi

# Verify Python version and key app settings
LINUX_FX=$(az functionapp config show \
    --name "$FUNC_APP_NAME" --resource-group "$CORE_RG" \
    --query "linuxFxVersion" --output tsv 2>/dev/null || echo "UNKNOWN")

if [[ "$LINUX_FX" == "PYTHON|3.12" ]]; then
    printf "  %-35s ${GREEN}%s${NC}\n" "Runtime:" "$LINUX_FX"
    record_pass
else
    printf "  %-35s ${RED}%s${NC}\n" "Runtime:" "$LINUX_FX (expected PYTHON|3.12)"
    record_fail
fi

# Check critical app settings exist
SETTINGS_JSON=$(az functionapp config appsettings list \
    --name "$FUNC_APP_NAME" --resource-group "$CORE_RG" \
    --output json 2>/dev/null || echo "[]")

check_setting() {
    local name="$1"
    local val
    val=$(echo "$SETTINGS_JSON" | "$JQ" -r \
        --arg k "$name" \
        '.[] | select(.name==$k) | .value // empty' 2>/dev/null \
        | head -c 40)
    if [[ -n "$val" ]]; then
        printf "  %-35s ${GREEN}%s${NC}\n" "$name:" "SET ($val)"
        record_pass
    else
        printf "  %-35s ${RED}%s${NC}\n" "$name:" "MISSING"
        record_fail
    fi
}

check_setting "DCE_ENDPOINT"
check_setting "DCR_AGENT_EVENTS_RULE_ID"
check_setting "DCR_AGENT_ERRORS_RULE_ID"
check_setting "AZURE_OPENAI_ENDPOINT"
check_setting "ADX_CLUSTER_URI"
check_setting "SCM_DO_BUILD_DURING_DEPLOYMENT"
echo ""

# ═══════════════════════════════════════════════════════════════════════════
# 5. AGENT DCRs (Data Collection Rules)
# ═══════════════════════════════════════════════════════════════════════════
echo -e "${CYAN}── 5. Agent Logging DCRs ──────────────────────────────────────${NC}"
echo ""

for dcr_name in "iisheal-dcr-agent-events" "iisheal-dcr-agent-errors"; do
    DCR_STATE=$(az monitor data-collection rule show \
        --name "$dcr_name" --resource-group "$MONITOR_RG" \
        --query "provisioningState" --output tsv 2>/dev/null || echo "NOT_FOUND")

    if [[ "$DCR_STATE" == "Succeeded" ]]; then
        IMMUTABLE=$(az monitor data-collection rule show \
            --name "$dcr_name" --resource-group "$MONITOR_RG" \
            --query "immutableId" --output tsv 2>/dev/null)
        printf "  %-35s ${GREEN}%s${NC}\n" "$dcr_name:" "OK ($IMMUTABLE)"
        record_pass
    elif [[ "$DCR_STATE" == "NOT_FOUND" ]]; then
        printf "  %-35s ${RED}%s${NC}\n" "$dcr_name:" "NOT FOUND"
        record_fail
    else
        printf "  %-35s ${YELLOW}%s${NC}\n" "$dcr_name:" "$DCR_STATE"
        record_warn
    fi
done
echo ""

# ═══════════════════════════════════════════════════════════════════════════
# 6. AUTOMATION ACCOUNT
# ═══════════════════════════════════════════════════════════════════════════
echo -e "${CYAN}── 6. Automation Account ──────────────────────────────────────${NC}"
echo ""

# Check runbooks
EXPECTED_RUNBOOKS=(
    "Invoke-RecycleAppPool" "Invoke-RestartIIS" "Invoke-ClearIISLogs"
    "Invoke-FixAppPoolIdentity" "Invoke-EnableIIS" "Invoke-RestartW3SVC"
    "Invoke-FixBindings" "Invoke-ClearASPNETCache" "Invoke-FixPermissions"
    "Invoke-RestartWorkerProcess" "Invoke-CaptureBaseline"
)

ACTUAL_RUNBOOKS=$(az automation runbook list \
    --resource-group "$MONITOR_RG" \
    --automation-account-name "$AUTO_ACCOUNT" \
    --query "[].name" --output tsv 2>/dev/null || echo "ERROR")

if [[ "$ACTUAL_RUNBOOKS" == "ERROR" ]]; then
    printf "  ${RED}Failed to query runbooks.${NC}\n"
    record_fail
else
    MISSING_RB=0
    for rb in "${EXPECTED_RUNBOOKS[@]}"; do
        if ! echo "$ACTUAL_RUNBOOKS" | grep -q "$rb"; then
            printf "  %-35s ${RED}%s${NC}\n" "Runbook $rb:" "MISSING"
            MISSING_RB=$((MISSING_RB + 1))
        fi
    done
    if [[ "$MISSING_RB" -eq 0 ]]; then
        printf "  %-35s ${GREEN}%s${NC}\n" "Runbooks (${#EXPECTED_RUNBOOKS[@]}):" "ALL PRESENT"
        record_pass
    else
        record_fail
    fi
fi

# Check Hybrid Worker
WORKER_GROUP="IIS-HybridWorkers"
WORKER_COUNT=$(az automation hrwg hrw list \
    --resource-group "$MONITOR_RG" \
    --automation-account-name "$AUTO_ACCOUNT" \
    --hybrid-runbook-worker-group-name "$WORKER_GROUP" \
    --query "length(@)" --output tsv 2>/dev/null || echo "0")

if [[ "$WORKER_COUNT" -gt 0 ]]; then
    printf "  %-35s ${GREEN}%s${NC}\n" "Hybrid Worker ($WORKER_GROUP):" "$WORKER_COUNT worker(s)"
    record_pass
else
    printf "  %-35s ${RED}%s${NC}\n" "Hybrid Worker ($WORKER_GROUP):" "NONE"
    record_fail
fi

# Recent job history
JOB_COUNT=$(az automation job list \
    --resource-group "$MONITOR_RG" \
    --automation-account-name "$AUTO_ACCOUNT" \
    --query "length(@)" --output tsv 2>/dev/null || echo "0")
printf "  %-35s %s\n" "Total jobs (all time):" "$JOB_COUNT"
echo ""

# ═══════════════════════════════════════════════════════════════════════════
# 7. AZURE OPENAI
# ═══════════════════════════════════════════════════════════════════════════
echo -e "${CYAN}── 7. Azure OpenAI Deployments ────────────────────────────────${NC}"
echo ""

OPENAI_DEPS=$(az cognitiveservices account deployment list \
    --resource-group "$MONITOR_RG" \
    --name "$OPENAI_NAME" \
    --query "[].{Name:name, Model:properties.model.name, Status:properties.provisioningState}" \
    --output json 2>/dev/null || echo "[]")

if [[ "$OPENAI_DEPS" == "[]" ]]; then
    printf "  ${RED}No OpenAI deployments found.${NC}\n"
    record_fail
else
    EXPECTED_MODELS=("o4-mini" "gpt-4o-mini")
    for model in "${EXPECTED_MODELS[@]}"; do
        STATUS=$(echo "$OPENAI_DEPS" | "$JQ" -r \
            --arg m "$model" \
            '(.[] | select(.Name==$m) | .Status) // "NOT_FOUND"' 2>/dev/null \
            || echo "ERROR")

        if [[ "$STATUS" == "Succeeded" ]]; then
            printf "  %-35s ${GREEN}%s${NC}\n" "$model:" "DEPLOYED"
            record_pass
        elif [[ "$STATUS" == "NOT_FOUND" ]]; then
            printf "  %-35s ${RED}%s${NC}\n" "$model:" "NOT FOUND"
            record_fail
        else
            printf "  %-35s ${YELLOW}%s${NC}\n" "$model:" "$STATUS"
            record_warn
        fi
    done
fi
echo ""

# ═══════════════════════════════════════════════════════════════════════════
# RESULTS SUMMARY
# ═══════════════════════════════════════════════════════════════════════════
echo -e "${CYAN}=================================================================${NC}"
echo -e "${CYAN}  VALIDATION RESULTS${NC}"
echo -e "${CYAN}=================================================================${NC}"
echo ""
TOTAL=$((PASS_COUNT + FAIL_COUNT + WARN_COUNT))
printf "  ${GREEN}%-12s${NC} %d\n" "PASS" "$PASS_COUNT"
printf "  ${YELLOW}%-12s${NC} %d\n" "WARN" "$WARN_COUNT"
printf "  ${RED}%-12s${NC} %d\n" "FAIL" "$FAIL_COUNT"
printf "  %-12s %d\n" "TOTAL" "$TOTAL"
echo ""

if [[ "$FAIL_COUNT" -eq 0 && "$WARN_COUNT" -eq 0 ]]; then
    ok "All $TOTAL checks passed. System is fully operational."
elif [[ "$FAIL_COUNT" -eq 0 ]]; then
    warn "$PASS_COUNT/$TOTAL passed, $WARN_COUNT warnings. System is operational but some data may be missing."
else
    error "$FAIL_COUNT/$TOTAL checks failed. Review issues above."
    exit 1
fi
