using '../main.bicep'

param coreRgName            = 'iis-core'
param monitorRgName         = 'iis-core-monitor'
param location              = 'eastus2'
param projectPrefix         = 'iisheals'
param adminUsername         = 'azureadmin'
param adminPassword         = readEnvironmentVariable('VM_ADMIN_PASSWORD', '')
param vmHostname            = 'iishealvm'
param openaiLocation        = 'eastus2'

// ADX: Dev SKU for development (~$60/month, no SLA, single node)
// For production change to: Standard_D11_v2 / Standard / 2
param adxSkuName    = 'Dev(No SLA)_Standard_D11_v2'
param adxSkuTier    = 'Basic'
param adxCapacity   = 1

// ─── Enterprise-network integration ──────────────────────────────────────────
// The VNet and subnets below already exist and are owned by the network team.
// Fill in the RG + subnet names before deploying.
param existingVnetName                    = 'non-prod_vnet-openshift-for-card-service-eastus2-277f'
param existingVnetResourceGroup           = ''  // TODO: fill in before deploy
param vmSubnetName                        = ''  // TODO: fill in (must exist in VNet above)
param peSubnetName                        = ''  // TODO: fill in (must have privateEndpointNetworkPolicies=Disabled)
param faIntegrationSubnetName             = ''  // TODO: fill in (must have Microsoft.Web/serverFarms delegation)

// Optional: if the enterprise provides shared private DNS zones in a central RG,
// set this param. Empty means "create zones locally in monitorRg".
param existingPrivateDnsZonesResourceGroup = ''
