targetScope = 'subscription'

// =============================================================================
// IIS Auto-Healing — v2 (enterprise-network variant) — Subscription entry point
//
// Differences vs infra/main.bicep:
//   - Plugs into an existing enterprise VNet (no VNet/subnet/NSG creation).
//   - No Azure Bastion. VM has only a private IP and is reached over the
//     enterprise internal network (jumphost / VPN / ExpressRoute).
//   - All services reachable only via private endpoints + private DNS.
//   - Automation publicNetworkAccess=Disabled; runbooks use Windows PS 5.1.
//   - Function App on S1 Standard with VNet integration + sites PE.
//   - Private DNS zones are created locally by default; optionally reference
//     pre-existing zones in a shared-DNS subscription/RG.
//
// Deploy with:
//   az deployment sub create \
//     --location eastus2 \
//     --template-file v2/infra/main.bicep \
//     --parameters v2/infra/parameters/dev.bicepparam
// =============================================================================

// ─── Resource Group names ─────────────────────────────────────────────────────
@description('Name of the core resource group (VM + Function App)')
param coreRgName string = 'iis-core'

@description('Name of the monitoring resource group (LAW, ADX, Event Hubs, etc.)')
param monitorRgName string = 'iis-core-monitor'

// ─── Shared parameters ────────────────────────────────────────────────────────
@description('Azure region for all resources')
param location string = 'eastus2'

@description('Project prefix for resource naming')
param projectPrefix string = 'iisheal'

@description('VM admin username')
param adminUsername string = 'azureadmin'

@description('VM admin password')
@secure()
param adminPassword string

@description('VM hostname')
param vmHostname string = 'iishealvm'

@description('Azure OpenAI location (must support o4-mini)')
param openaiLocation string = 'eastus2'

@description('ADX cluster SKU name')
@allowed([
  'Dev(No SLA)_Standard_D11_v2'
  'Standard_D11_v2'
  'Standard_D12_v2'
  'Standard_D13_v2'
])
param adxSkuName string = 'Dev(No SLA)_Standard_D11_v2'

@description('ADX cluster SKU tier')
@allowed(['Basic', 'Standard'])
param adxSkuTier string = 'Basic'

@description('ADX cluster node capacity')
param adxCapacity int = 1

// ─── Existing enterprise-network parameters ──────────────────────────────────
@description('Name of the existing VNet owned by the enterprise network team')
param existingVnetName string = 'non-prod_vnet-openshift-for-card-service-eastus2-277f'

@description('Resource group of the existing VNet (ask the network team)')
param existingVnetResourceGroup string

@description('Name of the existing subnet where the VM NIC lands')
param vmSubnetName string

@description('Name of the existing subnet where all private endpoints land (must have privateEndpointNetworkPolicies=Disabled)')
param peSubnetName string

@description('Name of the existing subnet used for Function App VNet integration (must have Microsoft.Web/serverFarms delegation)')
param faIntegrationSubnetName string

@description('Optional: RG containing pre-existing shared private DNS zones. If empty, the module creates zones locally.')
param existingPrivateDnsZonesResourceGroup string = ''

// ─── Resource Groups ──────────────────────────────────────────────────────────
resource coreRg 'Microsoft.Resources/resourceGroups@2024-03-01' = {
  name: coreRgName
  location: location
}

resource monitorRg 'Microsoft.Resources/resourceGroups@2024-03-01' = {
  name: monitorRgName
  location: location
}

// ─── iis-core-monitor modules ─────────────────────────────────────────────────

module loganalytics 'modules/loganalytics.bicep' = {
  name: 'loganalytics'
  scope: monitorRg
  params: {
    location: location
    projectPrefix: projectPrefix
  }
}

module openai 'modules/openai.bicep' = {
  name: 'openai'
  scope: monitorRg
  params: {
    location: openaiLocation
    projectPrefix: projectPrefix
  }
}

module eventhubs 'modules/eventhubs.bicep' = {
  name: 'eventhubs'
  scope: monitorRg
  params: {
    location: location
    projectPrefix: projectPrefix
  }
}

module adx 'modules/adx.bicep' = {
  name: 'adx'
  scope: monitorRg
  params: {
    location: location
    projectPrefix: projectPrefix
    adxSkuName: adxSkuName
    adxSkuTier: adxSkuTier
    adxCapacity: adxCapacity
  }
}

module automation 'modules/automation.bicep' = {
  name: 'automation'
  scope: monitorRg
  params: {
    location: location
    projectPrefix: projectPrefix
  }
}

// ─── iis-core modules ─────────────────────────────────────────────────────────

// Lookup-only: references the existing enterprise VNet + subnets.  No creation.
module networking 'modules/networking.bicep' = {
  name: 'networking'
  scope: coreRg
  params: {
    existingVnetName: existingVnetName
    existingVnetResourceGroup: existingVnetResourceGroup
    vmSubnetName: vmSubnetName
    peSubnetName: peSubnetName
    faIntegrationSubnetName: faIntegrationSubnetName
  }
}

module vm 'modules/vm.bicep' = {
  name: 'vm'
  scope: coreRg
  params: {
    location: location
    projectPrefix: projectPrefix
    vmSubnetId: networking.outputs.vmSubnetId
    adminUsername: adminUsername
    adminPassword: adminPassword
    vmHostname: vmHostname
  }
}

module functionapp 'modules/functionapp.bicep' = {
  name: 'functionapp'
  scope: coreRg
  params: {
    location: location
    projectPrefix: projectPrefix
    lawWorkspaceId: loganalytics.outputs.workspaceId
    lawWorkspaceCustomerId: loganalytics.outputs.workspaceCustomerId
    automationAccountName: automation.outputs.automationAccountName
    automationAccountId: automation.outputs.automationAccountId
    vmName: vm.outputs.vmName
    vmHostname: vmHostname
    openaiEndpoint: openai.outputs.openaiEndpoint
    dceEndpoint: loganalytics.outputs.dceEndpoint
    resourceGroupName: coreRgName
    automationResourceGroupName: monitorRgName
    adxClusterUri: adx.outputs.clusterUri
    adxDatabase: adx.outputs.databaseName
    dcrAgentEventsImmutableId: loganalytics.outputs.dcrAgentEventsImmutableId
    dcrAgentErrorsImmutableId: loganalytics.outputs.dcrAgentErrorsImmutableId
    faIntegrationSubnetId: networking.outputs.faIntegrationSubnetId
    // deploy.sh sets WEBSITE_RUN_FROM_PACKAGE after deploy; leave empty here.
    functionPackageUrl: ''
  }
}

// ─── Private DNS + Private Endpoints ─────────────────────────────────────────

module privateDns 'modules/private_dns.bicep' = {
  name: 'privateDns'
  scope: monitorRg
  params: {
    vnetId: networking.outputs.vnetId
    adxRegion: location
    existingZonesResourceGroup: existingPrivateDnsZonesResourceGroup
    vnetLinkPrefix: projectPrefix
  }
}

module privateEndpoints 'modules/private_endpoints.bicep' = {
  name: 'privateEndpoints'
  scope: monitorRg
  params: {
    location: location
    projectPrefix: projectPrefix
    peSubnetId: networking.outputs.peSubnetId
    automationAccountId: automation.outputs.automationAccountId
    functionAppId: functionapp.outputs.functionAppId
    faStorageAccountId: functionapp.outputs.storageAccountId
    eventHubNamespaceId: eventhubs.outputs.namespaceId
    adxClusterId: adx.outputs.clusterId
    openaiId: openai.outputs.openaiId
    lawId: loganalytics.outputs.workspaceId
    dceId: loganalytics.outputs.dceId
    automationZoneId: privateDns.outputs.automationZoneId
    webhookZoneId: privateDns.outputs.webhookZoneId
    sitesZoneId: privateDns.outputs.sitesZoneId
    blobZoneId: privateDns.outputs.blobZoneId
    fileZoneId: privateDns.outputs.fileZoneId
    queueZoneId: privateDns.outputs.queueZoneId
    tableZoneId: privateDns.outputs.tableZoneId
    monitorZoneId: privateDns.outputs.monitorZoneId
    omsZoneId: privateDns.outputs.omsZoneId
    odsZoneId: privateDns.outputs.odsZoneId
    agentsvcZoneId: privateDns.outputs.agentsvcZoneId
    servicebusZoneId: privateDns.outputs.servicebusZoneId
    kustoZoneId: privateDns.outputs.kustoZoneId
    openaiZoneId: privateDns.outputs.openaiZoneId
  }
}

// ─── RBAC — split by target resource group ───────────────────────────────────

module rbacCore 'modules/rbac_core.bicep' = {
  name: 'rbacCore'
  scope: coreRg
  params: {
    functionAppPrincipalId: functionapp.outputs.functionAppPrincipalId
    automationPrincipalId: automation.outputs.automationPrincipalId
    vmId: vm.outputs.vmId
  }
}

module rbacMonitor 'modules/rbac_monitor.bicep' = {
  name: 'rbacMonitor'
  scope: monitorRg
  params: {
    functionAppPrincipalId: functionapp.outputs.functionAppPrincipalId
    automationPrincipalId: automation.outputs.automationPrincipalId
    vmPrincipalId: vm.outputs.vmPrincipalId
    lawWorkspaceId: loganalytics.outputs.workspaceId
    automationAccountId: automation.outputs.automationAccountId
    openaiId: openai.outputs.openaiId
    adxClusterId: adx.outputs.clusterId
    adxDatabaseName: adx.outputs.databaseName
    adxClusterPrincipalId: adx.outputs.clusterPrincipalId
    iisLogsEventHubId: eventhubs.outputs.iisLogsEventHubId
    vmPerfEventHubId: eventhubs.outputs.vmPerfEventHubId
    iisPerfEventHubId: eventhubs.outputs.iisPerfEventHubId
    baselineEventHubId: eventhubs.outputs.baselineEventHubId
    dcrAgentEventsId: loganalytics.outputs.dcrAgentEventsId
    dcrAgentErrorsId: loganalytics.outputs.dcrAgentErrorsId
  }
}

// NOTE: ADX data connections (adx_connections.bicep) are deployed separately
// from deploy.sh after a 90-second RBAC propagation wait.  Deploying them here
// with dependsOn: [rbacMonitor] is insufficient because Azure RBAC role
// assignments can take 60-90 s to replicate before ADX can validate them.

// ─── Outputs ─────────────────────────────────────────────────────────────────
output coreResourceGroup      string = coreRgName
output monitorResourceGroup   string = monitorRgName
output vmName                 string = vm.outputs.vmName
output vmPrivateIp            string = vm.outputs.vmPrivateIp
output lawWorkspaceId         string = loganalytics.outputs.workspaceId
output lawWorkspaceCustomerId string = loganalytics.outputs.workspaceCustomerId
output dceEndpoint            string = loganalytics.outputs.dceEndpoint
output functionAppName        string = functionapp.outputs.functionAppName
output functionAppHostname    string = functionapp.outputs.functionAppDefaultHostname
output storageAccountName     string = functionapp.outputs.storageAccountName
output automationAccountName  string = automation.outputs.automationAccountName
output openaiEndpoint         string = openai.outputs.openaiEndpoint
output openaiName             string = openai.outputs.openaiName
output adxClusterUri          string = adx.outputs.clusterUri
output adxClusterName         string = adx.outputs.clusterName
output adxDatabaseName        string = adx.outputs.databaseName
output eventHubNamespaceName  string = eventhubs.outputs.namespaceName
output vnetId                 string = networking.outputs.vnetId
output peSubnetId             string = networking.outputs.peSubnetId
