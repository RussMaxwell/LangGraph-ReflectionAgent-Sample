// =============================================================================
// ADX Event Hub Data Connections
//
// Deployed AFTER rbac_monitor.bicep so the ADX cluster MSI already holds the
// Azure Event Hubs Data Receiver role on all three Event Hubs before the
// connections attempt to authenticate.  Creating connections before RBAC is
// applied results in a BadInput / Internal Server Error from the Kusto RP.
// =============================================================================

@description('Azure region for all resources')
param location string

@description('Name of the ADX cluster')
param adxClusterName string

@description('Resource ID of the ADX cluster (used as managedIdentityResourceId)')
param adxClusterId string

@description('Name of the ADX database')
param adxDatabaseName string

// ── IISLogs Event Hub ──────────────────────────────────────────────────────────
@description('Resource ID of the IISLogs Event Hub')
param iisLogsEventHubId string

@description('Consumer group name for IISLogs ADX data connection')
param iisLogsConsumerGroupName string

// ── VMPerf Event Hub ───────────────────────────────────────────────────────────
@description('Resource ID of the VMPerf Event Hub')
param vmPerfEventHubId string

@description('Consumer group name for VMPerf ADX data connection')
param vmPerfConsumerGroupName string

// ── IISPerf Event Hub ──────────────────────────────────────────────────────────
@description('Resource ID of the IISPerf Event Hub')
param iisPerfEventHubId string

@description('Consumer group name for IISPerf ADX data connection')
param iisPerfConsumerGroupName string

// ── Baseline Event Hub ────────────────────────────────────────────────────────
@description('Resource ID of the Baseline Event Hub')
param baselineEventHubId string

@description('Consumer group name for Baseline ADX data connection')
param baselineConsumerGroupName string

// ─── Existing resource references ─────────────────────────────────────────────

resource adxCluster 'Microsoft.Kusto/clusters@2023-08-15' existing = {
  name: adxClusterName
}

resource adxDatabase 'Microsoft.Kusto/clusters/databases@2023-08-15' existing = {
  parent: adxCluster
  name: adxDatabaseName
}

// ─── IISLogs data connection ───────────────────────────────────────────────────

resource iisLogsDataConnection 'Microsoft.Kusto/clusters/databases/dataConnections@2023-08-15' = {
  parent: adxDatabase
  name: 'iislogs-connection'
  location: location
  kind: 'EventHub'
  properties: {
    eventHubResourceId: iisLogsEventHubId
    consumerGroup: iisLogsConsumerGroupName
    tableName: 'IISLogs'
    mappingRuleName: 'IISLogsMapping'
    dataFormat: 'MULTIJSON'
    compression: 'None'
    managedIdentityResourceId: adxClusterId
  }
}

// ─── VMPerf data connection ────────────────────────────────────────────────────

resource vmPerfDataConnection 'Microsoft.Kusto/clusters/databases/dataConnections@2023-08-15' = {
  parent: adxDatabase
  name: 'vmperf-connection'
  location: location
  kind: 'EventHub'
  properties: {
    eventHubResourceId: vmPerfEventHubId
    consumerGroup: vmPerfConsumerGroupName
    tableName: 'VMPerf'
    mappingRuleName: 'VMPerfMapping'
    dataFormat: 'MULTIJSON'
    compression: 'None'
    managedIdentityResourceId: adxClusterId
  }
}

// ─── IISPerf data connection ───────────────────────────────────────────────────

resource iisPerfDataConnection 'Microsoft.Kusto/clusters/databases/dataConnections@2023-08-15' = {
  parent: adxDatabase
  name: 'iisperf-connection'
  location: location
  kind: 'EventHub'
  properties: {
    eventHubResourceId: iisPerfEventHubId
    consumerGroup: iisPerfConsumerGroupName
    tableName: 'IISPerf'
    mappingRuleName: 'IISPerfMapping'
    dataFormat: 'MULTIJSON'
    compression: 'None'
    managedIdentityResourceId: adxClusterId
  }
}

// ─── Baseline data connection ─────────────────────────────────────────────────

resource baselineDataConnection 'Microsoft.Kusto/clusters/databases/dataConnections@2023-08-15' = {
  parent: adxDatabase
  name: 'baseline-connection'
  location: location
  kind: 'EventHub'
  properties: {
    eventHubResourceId: baselineEventHubId
    consumerGroup: baselineConsumerGroupName
    tableName: 'PerformanceBaseline'
    mappingRuleName: 'BaselineMapping'
    dataFormat: 'MULTIJSON'
    compression: 'None'
    managedIdentityResourceId: adxClusterId
  }
}
