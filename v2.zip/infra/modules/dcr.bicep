// =============================================================================
// Data Collection Rules — IIS W3C log files → Event Hub → ADX
//
// Only IISLogs uses this pipeline. Performance counters (VMPerf, IISPerf)
// cannot be routed to Event Hub via DCR (Microsoft-Perf only supports LAW
// destinations). VMPerf and IISPerf are handled by dcr_alerts.bicep → LAW.
//
// NOTE: Event Hub destinations must NOT have dataCollectionEndpointId set.
//       DCE is only required for custom LAW table ingestion.
// =============================================================================

@description('Azure region for all resources')
param location string

@description('Project prefix for resource naming')
param projectPrefix string

@description('VM hostname — added as Computer column via KQL transform')
param vmHostname string

@description('Event Hub resource ID for IISLogs stream')
param iisLogsEventHubId string

// ─── IIS W3C Logs DCR — logFiles → iislogs-eh ────────────────────────────────
// Uses logFiles data source (not iisLogs) so it can route to Event Hub.
// The DCR MSI needs Azure Event Hubs Data Sender on iislogs-eh (rbac_monitor.bicep).

resource dcrIisLogs 'Microsoft.Insights/dataCollectionRules@2023-03-11' = {
  name: '${projectPrefix}-dcr-iislogs'
  location: location
  identity: {
    type: 'SystemAssigned'   // authenticates to Event Hub as Data Sender
  }
  properties: {
    // No dataCollectionEndpointId — Event Hub destinations do not use a DCE.
    streamDeclarations: {
      'Custom-IISAccessLogs': {
        columns: [
          { name: 'TimeGenerated', type: 'datetime' }
          { name: 'Computer',      type: 'string' }
          { name: 'FilePath',      type: 'string' }
          { name: 'RawData',       type: 'string' }
        ]
      }
    }
    dataSources: {
      logFiles: [
        {
          name: 'IISW3CLogs'
          streams: ['Custom-IISAccessLogs']
          filePatterns: ['C:\\inetpub\\logs\\LogFiles\\W3SVC1\\*.log']
          format: 'text'
          settings: {
            text: {
              recordStartTimestampFormat: 'ISO 8601'
            }
          }
        }
      ]
    }
    destinations: {
      eventHubs: [
        {
          eventHubResourceId: iisLogsEventHubId
          name: 'iisLogsEH'
        }
      ]
    }
    dataFlows: [
      {
        streams: ['Custom-IISAccessLogs']
        destinations: ['iisLogsEH']
        transformKql: 'source | extend Computer = \'${vmHostname}\' | project TimeGenerated, Computer, FilePath, RawData'
      }
    ]
  }
}

// ─── Outputs ──────────────────────────────────────────────────────────────────

output dcrIisLogsId          string = dcrIisLogs.id
output dcrIisLogsPrincipalId string = dcrIisLogs.identity.principalId
