// =============================================================================
// Event Hubs — Ingestion pipeline for telemetry → ADX
//
// IISLogs:  DCR (logFiles data source) → iislogs-eh → ADX IISLogs table
// VMPerf:   VM scheduled task (Send-PerfToEventHub.ps1) → vmperf-eh → ADX VMPerf table
// IISPerf:  VM scheduled task (Send-PerfToEventHub.ps1) → iisperf-eh → ADX IISPerf table
// Baseline: Invoke-CaptureBaseline runbook → baseline-eh → ADX PerformanceBaseline table
// =============================================================================

@description('Azure region for all resources')
param location string

@description('Project prefix for resource naming')
param projectPrefix string

var namespaceName = '${projectPrefix}-eh'

// ─── Namespace ────────────────────────────────────────────────────────────────

resource ehNamespace 'Microsoft.EventHub/namespaces@2024-01-01' = {
  name: namespaceName
  location: location
  sku: {
    name: 'Standard'
    tier: 'Standard'
    capacity: 1
  }
  properties: {
    minimumTlsVersion: '1.2'
    publicNetworkAccess: 'Enabled'
    zoneRedundant: false
  }
}

// ─── IISLogs Event Hub ────────────────────────────────────────────────────────

resource iisLogsHub 'Microsoft.EventHub/namespaces/eventhubs@2024-01-01' = {
  parent: ehNamespace
  name: 'iislogs-eh'
  properties: {
    messageRetentionInDays: 1
    partitionCount: 2
  }
}

resource iisLogsCg 'Microsoft.EventHub/namespaces/eventhubs/consumergroups@2024-01-01' = {
  parent: iisLogsHub
  name: 'adx-consumer'
}

// ─── VMPerf Event Hub ─────────────────────────────────────────────────────────

resource vmPerfHub 'Microsoft.EventHub/namespaces/eventhubs@2024-01-01' = {
  parent: ehNamespace
  name: 'vmperf-eh'
  properties: {
    messageRetentionInDays: 1
    partitionCount: 2
  }
}

resource vmPerfCg 'Microsoft.EventHub/namespaces/eventhubs/consumergroups@2024-01-01' = {
  parent: vmPerfHub
  name: 'adx-consumer'
}

// ─── IISPerf Event Hub ────────────────────────────────────────────────────────

resource iisPerfHub 'Microsoft.EventHub/namespaces/eventhubs@2024-01-01' = {
  parent: ehNamespace
  name: 'iisperf-eh'
  properties: {
    messageRetentionInDays: 1
    partitionCount: 2
  }
}

resource iisPerfCg 'Microsoft.EventHub/namespaces/eventhubs/consumergroups@2024-01-01' = {
  parent: iisPerfHub
  name: 'adx-consumer'
}

// ─── Baseline Event Hub ───────────────────────────────────────────────────────

resource baselineHub 'Microsoft.EventHub/namespaces/eventhubs@2024-01-01' = {
  parent: ehNamespace
  name: 'baseline-eh'
  properties: {
    messageRetentionInDays: 1
    partitionCount: 2
  }
}

resource baselineCg 'Microsoft.EventHub/namespaces/eventhubs/consumergroups@2024-01-01' = {
  parent: baselineHub
  name: 'adx-consumer'
}

// ─── Outputs ──────────────────────────────────────────────────────────────────

output namespaceId   string = ehNamespace.id
output namespaceName string = ehNamespace.name

output iisLogsEventHubId          string = iisLogsHub.id
output iisLogsEventHubName        string = iisLogsHub.name
output iisLogsConsumerGroupName   string = iisLogsCg.name

output vmPerfEventHubId           string = vmPerfHub.id
output vmPerfEventHubName         string = vmPerfHub.name
output vmPerfConsumerGroupName    string = vmPerfCg.name

output iisPerfEventHubId          string = iisPerfHub.id
output iisPerfEventHubName        string = iisPerfHub.name
output iisPerfConsumerGroupName   string = iisPerfCg.name

output baselineEventHubId         string = baselineHub.id
output baselineEventHubName       string = baselineHub.name
output baselineConsumerGroupName  string = baselineCg.name
