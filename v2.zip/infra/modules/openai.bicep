@description('Azure region for the OpenAI resource')
param location string = 'eastus'

@description('Project prefix used for naming resources')
param projectPrefix string

var openaiName = '${projectPrefix}-openai'

// ─── Azure OpenAI Service ──────────────────────────────────────────────────────

resource openai 'Microsoft.CognitiveServices/accounts@2024-10-01' = {
  name: openaiName
  location: location
  kind: 'OpenAI'
  sku: {
    name: 'S0'
  }
  properties: {
    publicNetworkAccess: 'Enabled'
    customSubDomainName: openaiName
  }
}

// ─── Model Deployment: o4-mini ─────────────────────────────────────────────────

resource deploymentO4Mini 'Microsoft.CognitiveServices/accounts/deployments@2024-10-01' = {
  parent: openai
  name: 'o4-mini'
  sku: {
    name: 'GlobalStandard'
    capacity: 10
  }
  properties: {
    model: {
      format: 'OpenAI'
      name: 'o4-mini'
      version: '2025-04-16'
    }
  }
}

// ─── Model Deployment: gpt-4o-mini ─────────────────────────────────────────────

resource deploymentGpt4oMini 'Microsoft.CognitiveServices/accounts/deployments@2024-10-01' = {
  parent: openai
  name: 'gpt-4o-mini'
  sku: {
    name: 'GlobalStandard'
    capacity: 30
  }
  properties: {
    model: {
      format: 'OpenAI'
      name: 'gpt-4o-mini'
      version: '2024-07-18'
    }
  }
  dependsOn: [
    deploymentO4Mini
  ]
}

// ─── Outputs ───────────────────────────────────────────────────────────────────

output openaiId string = openai.id
output openaiEndpoint string = openai.properties.endpoint
output openaiName string = openai.name
