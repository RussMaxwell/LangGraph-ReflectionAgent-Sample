// =============================================================================
// DEPRECATED — NOT DEPLOYED
//
// These DCRs previously routed VMPerf + IISPerf counters to LAW custom tables
// (VMPerf_CL / IISPerf_CL) for use by Azure Monitor scheduledQueryRules.
//
// Replaced by IISMonitorPoller (Azure Function timer trigger) which queries the
// same data directly from ADX every 60 seconds, eliminating ~$63/month in alert
// rule evaluation fees and the LAW ingestion cost for these two tables.
//
// This module is no longer referenced in main.bicep and will not be deployed.
// The DCR associations have also been removed from vm.bicep.
// =============================================================================

@description('Azure region for all resources')
param location string

@description('Project prefix used for naming resources')
param projectPrefix string

@description('Hostname of the monitored VM')
param vmHostname string

@description('Data Collection Endpoint resource ID')
param dceId string

@description('Log Analytics Workspace resource ID')
param lawWorkspaceId string

// ─── VMPerf Alert DCR ─────────────────────────────────────────────────────────
// Counters: CPU, Memory, Disk — alert thresholds defined in monitoring.bicep

resource dcrVmPerfAlerts 'Microsoft.Insights/dataCollectionRules@2023-03-11' = {
  name: '${projectPrefix}-dcr-vmperf-alerts'
  location: location
  properties: {
    dataCollectionEndpointId: dceId
    streamDeclarations: {
      'Custom-VMPerf_${vmHostname}_CL': {
        columns: [
          { name: 'TimeGenerated',  type: 'datetime' }
          { name: 'Computer',       type: 'string' }
          { name: 'ObjectName',     type: 'string' }
          { name: 'CounterName',    type: 'string' }
          { name: 'InstanceName',   type: 'string' }
          { name: 'CounterValue',   type: 'real' }
        ]
      }
    }
    dataSources: {
      performanceCounters: [
        {
          name: 'vmPerfAlertCounters'
          streams: ['Custom-VMPerf_${vmHostname}_CL']
          samplingFrequencyInSeconds: 60
          counterSpecifiers: [
            '\\Processor(_Total)\\% Processor Time'
            '\\Memory\\Available MBytes'
            '\\Memory\\% Committed Bytes In Use'
            '\\Memory\\Pages/sec'
            '\\LogicalDisk(C:)\\% Free Space'
            '\\PhysicalDisk(_Total)\\Avg. Disk Queue Length'
            '\\System\\Processor Queue Length'
          ]
        }
      ]
    }
    destinations: {
      logAnalytics: [
        {
          name: 'lawAlertDest'
          workspaceResourceId: lawWorkspaceId
        }
      ]
    }
    dataFlows: [
      {
        streams: ['Custom-VMPerf_${vmHostname}_CL']
        destinations: ['lawAlertDest']
        outputStream: 'Custom-VMPerf_${vmHostname}_CL'
        transformKql: 'source | project TimeGenerated, Computer, ObjectName, CounterName, InstanceName, CounterValue'
      }
    ]
  }
}

// ─── IISPerf Alert DCR ────────────────────────────────────────────────────────
// Counters: IIS connections, ASP.NET, w3wp process — alert thresholds in monitoring.bicep

resource dcrIisPerfAlerts 'Microsoft.Insights/dataCollectionRules@2023-03-11' = {
  name: '${projectPrefix}-dcr-iisperf-alerts'
  location: location
  properties: {
    dataCollectionEndpointId: dceId
    streamDeclarations: {
      'Custom-IISPerf_${vmHostname}_CL': {
        columns: [
          { name: 'TimeGenerated',  type: 'datetime' }
          { name: 'Computer',       type: 'string' }
          { name: 'ObjectName',     type: 'string' }
          { name: 'CounterName',    type: 'string' }
          { name: 'InstanceName',   type: 'string' }
          { name: 'CounterValue',   type: 'real' }
        ]
      }
    }
    dataSources: {
      performanceCounters: [
        {
          name: 'iisPerfAlertCounters'
          streams: ['Custom-IISPerf_${vmHostname}_CL']
          samplingFrequencyInSeconds: 60
          counterSpecifiers: [
            // IIS Web Service
            '\\Web Service(_Total)\\Current Connections'
            '\\Web Service(_Total)\\Connection Attempts Failed'
            '\\Web Service(_Total)\\404 Errors/sec'
            // ASP.NET
            '\\ASP.NET\\Application Restarts'
            '\\ASP.NET\\Requests Queued'
            // w3wp worker process
            '\\Process(w3wp*)\\% Processor Time'
            '\\Process(w3wp*)\\Working Set'
            '\\Process(w3wp*)\\Thread Count'
          ]
        }
      ]
    }
    destinations: {
      logAnalytics: [
        {
          name: 'lawAlertDest'
          workspaceResourceId: lawWorkspaceId
        }
      ]
    }
    dataFlows: [
      {
        streams: ['Custom-IISPerf_${vmHostname}_CL']
        destinations: ['lawAlertDest']
        outputStream: 'Custom-IISPerf_${vmHostname}_CL'
        transformKql: 'source | extend parsed = extract_all("^\\\\\\\\([^(\\\\\\\\]+)(?:\\\\(([^)]+)\\\\))?\\\\\\\\(.+)$", CounterName) | extend ObjectName = tostring(parsed[0][0]), InstanceName = tostring(parsed[0][1]), CounterName = tostring(parsed[0][2]) | project TimeGenerated, Computer, ObjectName, CounterName, InstanceName, CounterValue'
      }
    ]
  }
}

// ─── Outputs ──────────────────────────────────────────────────────────────────

output dcrVmPerfAlertsId  string = dcrVmPerfAlerts.id
output dcrIisPerfAlertsId string = dcrIisPerfAlerts.id
