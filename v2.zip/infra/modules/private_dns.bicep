@description('Resource ID of the existing target VNet (zones get vnetLinks pointing here)')
param vnetId string

@description('Region used only to build the ADX zone name (privatelink.<region>.kusto.windows.net)')
param adxRegion string

@description('If non-empty, reference existing private DNS zones in this RG (shared-DNS pattern) and skip creating new zones')
param existingZonesResourceGroup string = ''

@description('Prefix for vnetLink names')
param vnetLinkPrefix string = 'iisheal'

// ─── Zone names ──────────────────────────────────────────────────────────────
var automationZoneName = 'privatelink.azure-automation.net'
var sitesZoneName      = 'privatelink.azurewebsites.net'
var blobZoneName       = 'privatelink.blob.${environment().suffixes.storage}'
var fileZoneName       = 'privatelink.file.${environment().suffixes.storage}'
var queueZoneName      = 'privatelink.queue.${environment().suffixes.storage}'
var tableZoneName      = 'privatelink.table.${environment().suffixes.storage}'
var monitorZoneName    = 'privatelink.monitor.azure.com'
var omsZoneName        = 'privatelink.oms.opinsights.azure.com'
var odsZoneName        = 'privatelink.ods.opinsights.azure.com'
var agentsvcZoneName   = 'privatelink.agentsvc.azure-automation.net'
var servicebusZoneName = 'privatelink.servicebus.windows.net'
var kustoZoneName      = 'privatelink.${adxRegion}.kusto.windows.net'
var openaiZoneName     = 'privatelink.openai.azure.com'

var createZones = empty(existingZonesResourceGroup)

var zoneNames = [
  automationZoneName
  sitesZoneName
  blobZoneName
  fileZoneName
  queueZoneName
  tableZoneName
  monitorZoneName
  omsZoneName
  odsZoneName
  agentsvcZoneName
  servicebusZoneName
  kustoZoneName
  openaiZoneName
]

// ─── Create zones (only when existingZonesResourceGroup is empty) ────────────
resource zones 'Microsoft.Network/privateDnsZones@2020-06-01' = [for zoneName in zoneNames: if (createZones) {
  name: zoneName
  location: 'global'
}]

// ─── VNet links — always target the caller-provided VNet by resource ID ──────
// Cross-RG is fine: the link lives under the zone's RG but references VNet id.
resource vnetLinks 'Microsoft.Network/privateDnsZones/virtualNetworkLinks@2020-06-01' = [for (zoneName, i) in zoneNames: if (createZones) {
  name: '${vnetLinkPrefix}-link'
  parent: zones[i]
  location: 'global'
  properties: {
    registrationEnabled: false
    virtualNetwork: {
      id: vnetId
    }
  }
}]

// ─── Outputs: resource IDs of each zone (create or reference) ────────────────
// When createZones is false we synthesize the resourceId in existingZonesResourceGroup.

output automationZoneId string = createZones
  ? resourceId('Microsoft.Network/privateDnsZones', automationZoneName)
  : resourceId(existingZonesResourceGroup, 'Microsoft.Network/privateDnsZones', automationZoneName)

output sitesZoneId string = createZones
  ? resourceId('Microsoft.Network/privateDnsZones', sitesZoneName)
  : resourceId(existingZonesResourceGroup, 'Microsoft.Network/privateDnsZones', sitesZoneName)

output blobZoneId string = createZones
  ? resourceId('Microsoft.Network/privateDnsZones', blobZoneName)
  : resourceId(existingZonesResourceGroup, 'Microsoft.Network/privateDnsZones', blobZoneName)

output fileZoneId string = createZones
  ? resourceId('Microsoft.Network/privateDnsZones', fileZoneName)
  : resourceId(existingZonesResourceGroup, 'Microsoft.Network/privateDnsZones', fileZoneName)

output queueZoneId string = createZones
  ? resourceId('Microsoft.Network/privateDnsZones', queueZoneName)
  : resourceId(existingZonesResourceGroup, 'Microsoft.Network/privateDnsZones', queueZoneName)

output tableZoneId string = createZones
  ? resourceId('Microsoft.Network/privateDnsZones', tableZoneName)
  : resourceId(existingZonesResourceGroup, 'Microsoft.Network/privateDnsZones', tableZoneName)

output monitorZoneId string = createZones
  ? resourceId('Microsoft.Network/privateDnsZones', monitorZoneName)
  : resourceId(existingZonesResourceGroup, 'Microsoft.Network/privateDnsZones', monitorZoneName)

output omsZoneId string = createZones
  ? resourceId('Microsoft.Network/privateDnsZones', omsZoneName)
  : resourceId(existingZonesResourceGroup, 'Microsoft.Network/privateDnsZones', omsZoneName)

output odsZoneId string = createZones
  ? resourceId('Microsoft.Network/privateDnsZones', odsZoneName)
  : resourceId(existingZonesResourceGroup, 'Microsoft.Network/privateDnsZones', odsZoneName)

output agentsvcZoneId string = createZones
  ? resourceId('Microsoft.Network/privateDnsZones', agentsvcZoneName)
  : resourceId(existingZonesResourceGroup, 'Microsoft.Network/privateDnsZones', agentsvcZoneName)

output servicebusZoneId string = createZones
  ? resourceId('Microsoft.Network/privateDnsZones', servicebusZoneName)
  : resourceId(existingZonesResourceGroup, 'Microsoft.Network/privateDnsZones', servicebusZoneName)

output kustoZoneId string = createZones
  ? resourceId('Microsoft.Network/privateDnsZones', kustoZoneName)
  : resourceId(existingZonesResourceGroup, 'Microsoft.Network/privateDnsZones', kustoZoneName)

output openaiZoneId string = createZones
  ? resourceId('Microsoft.Network/privateDnsZones', openaiZoneName)
  : resourceId(existingZonesResourceGroup, 'Microsoft.Network/privateDnsZones', openaiZoneName)

// Webhook and DSCAndHybridWorker both resolve through the azure-automation.net zone.
output webhookZoneId string = createZones
  ? resourceId('Microsoft.Network/privateDnsZones', automationZoneName)
  : resourceId(existingZonesResourceGroup, 'Microsoft.Network/privateDnsZones', automationZoneName)
