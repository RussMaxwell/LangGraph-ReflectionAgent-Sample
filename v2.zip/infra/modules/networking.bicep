@description('Name of the existing VNet owned by the enterprise network team')
param existingVnetName string

@description('Resource group that contains the existing VNet')
param existingVnetResourceGroup string

@description('Name of the existing subnet where the VM NIC lands')
param vmSubnetName string

@description('Name of the existing subnet where private endpoints land (must have privateEndpointNetworkPolicies=Disabled)')
param peSubnetName string

@description('Name of the existing subnet used for Function App VNet integration (must have Microsoft.Web/serverFarms delegation)')
param faIntegrationSubnetName string

// ─── Existing network references (lookup only — no creation) ─────────────────
// The enterprise network team owns VNet, NSGs, and subnet creation/config.
// This module only references the existing resources and exposes their IDs.

resource vnet 'Microsoft.Network/virtualNetworks@2023-11-01' existing = {
  name: existingVnetName
  scope: resourceGroup(existingVnetResourceGroup)
}

resource vmSubnet 'Microsoft.Network/virtualNetworks/subnets@2023-11-01' existing = {
  name: vmSubnetName
  parent: vnet
}

resource peSubnet 'Microsoft.Network/virtualNetworks/subnets@2023-11-01' existing = {
  name: peSubnetName
  parent: vnet
}

resource faIntegrationSubnet 'Microsoft.Network/virtualNetworks/subnets@2023-11-01' existing = {
  name: faIntegrationSubnetName
  parent: vnet
}

// ─── Outputs ─────────────────────────────────────────────────────────────────
output vnetId                 string = vnet.id
output vnetName               string = vnet.name
output vmSubnetId             string = vmSubnet.id
output peSubnetId             string = peSubnet.id
output faIntegrationSubnetId  string = faIntegrationSubnet.id
