@description('Azure region for all resources')
param location string

@description('Project prefix used for PE naming')
param projectPrefix string

@description('Subnet resource ID where every private endpoint lands (must have privateEndpointNetworkPolicies=Disabled)')
param peSubnetId string

// ─── Target resource IDs ─────────────────────────────────────────────────────
param automationAccountId string
param functionAppId string
param faStorageAccountId string
param eventHubNamespaceId string
param adxClusterId string
param openaiId string
param lawId string
param dceId string

// ─── Private DNS zone IDs (all produced by private_dns.bicep) ────────────────
param automationZoneId string
param webhookZoneId string
param sitesZoneId string
param blobZoneId string
param fileZoneId string
param queueZoneId string
param tableZoneId string
param monitorZoneId string
param omsZoneId string
param odsZoneId string
param agentsvcZoneId string
param servicebusZoneId string
param kustoZoneId string
param openaiZoneId string

// ─── AMPLS (Azure Monitor Private Link Scope) ────────────────────────────────
// Binds LAW + DCE under one scope object so a single "azuremonitor" PE covers
// Log Analytics ingestion and query plus DCR ingestion via the DCE.
resource ampls 'Microsoft.Insights/privateLinkScopes@2021-07-01-preview' = {
  name: '${projectPrefix}-ampls'
  location: 'global'
  properties: {
    accessModeSettings: {
      ingestionAccessMode: 'PrivateOnly'
      queryAccessMode: 'PrivateOnly'
    }
  }
}

resource amplsLaw 'Microsoft.Insights/privateLinkScopes/scopedResources@2021-07-01-preview' = {
  parent: ampls
  name: '${projectPrefix}-ampls-law'
  properties: {
    linkedResourceId: lawId
  }
}

resource amplsDce 'Microsoft.Insights/privateLinkScopes/scopedResources@2021-07-01-preview' = {
  parent: ampls
  name: '${projectPrefix}-ampls-dce'
  properties: {
    linkedResourceId: dceId
  }
}

// ─── Helper local: PE for AMPLS (azuremonitor groupId) ───────────────────────
resource peAmpls 'Microsoft.Network/privateEndpoints@2023-11-01' = {
  name: '${projectPrefix}-pe-ampls'
  location: location
  properties: {
    subnet: {
      id: peSubnetId
    }
    privateLinkServiceConnections: [
      {
        name: 'ampls'
        properties: {
          privateLinkServiceId: ampls.id
          groupIds: [
            'azuremonitor'
          ]
        }
      }
    ]
  }
  dependsOn: [
    amplsLaw
    amplsDce
  ]
}

resource peAmplsDns 'Microsoft.Network/privateEndpoints/privateDnsZoneGroups@2023-11-01' = {
  parent: peAmpls
  name: 'default'
  properties: {
    privateDnsZoneConfigs: [
      {
        name: 'monitor'
        properties: {
          privateDnsZoneId: monitorZoneId
        }
      }
      {
        name: 'oms'
        properties: {
          privateDnsZoneId: omsZoneId
        }
      }
      {
        name: 'ods'
        properties: {
          privateDnsZoneId: odsZoneId
        }
      }
      {
        name: 'agentsvc'
        properties: {
          privateDnsZoneId: agentsvcZoneId
        }
      }
      {
        name: 'blob'
        properties: {
          privateDnsZoneId: blobZoneId
        }
      }
    ]
  }
}

// ─── Automation — DSCAndHybridWorker ─────────────────────────────────────────
resource peAutoDsc 'Microsoft.Network/privateEndpoints@2023-11-01' = {
  name: '${projectPrefix}-pe-automation-dsc'
  location: location
  properties: {
    subnet: {
      id: peSubnetId
    }
    privateLinkServiceConnections: [
      {
        name: 'automation-dsc'
        properties: {
          privateLinkServiceId: automationAccountId
          groupIds: [
            'DSCAndHybridWorker'
          ]
        }
      }
    ]
  }
}

resource peAutoDscDns 'Microsoft.Network/privateEndpoints/privateDnsZoneGroups@2023-11-01' = {
  parent: peAutoDsc
  name: 'default'
  properties: {
    privateDnsZoneConfigs: [
      {
        name: 'automation'
        properties: {
          privateDnsZoneId: automationZoneId
        }
      }
      {
        name: 'agentsvc'
        properties: {
          privateDnsZoneId: agentsvcZoneId
        }
      }
    ]
  }
}

// ─── Automation — Webhook ────────────────────────────────────────────────────
resource peAutoWebhook 'Microsoft.Network/privateEndpoints@2023-11-01' = {
  name: '${projectPrefix}-pe-automation-webhook'
  location: location
  properties: {
    subnet: {
      id: peSubnetId
    }
    privateLinkServiceConnections: [
      {
        name: 'automation-webhook'
        properties: {
          privateLinkServiceId: automationAccountId
          groupIds: [
            'Webhook'
          ]
        }
      }
    ]
  }
}

resource peAutoWebhookDns 'Microsoft.Network/privateEndpoints/privateDnsZoneGroups@2023-11-01' = {
  parent: peAutoWebhook
  name: 'default'
  properties: {
    privateDnsZoneConfigs: [
      {
        name: 'webhook'
        properties: {
          privateDnsZoneId: webhookZoneId
        }
      }
    ]
  }
}

// ─── Function App (sites groupId) ────────────────────────────────────────────
resource peFunc 'Microsoft.Network/privateEndpoints@2023-11-01' = {
  name: '${projectPrefix}-pe-functionapp'
  location: location
  properties: {
    subnet: {
      id: peSubnetId
    }
    privateLinkServiceConnections: [
      {
        name: 'functionapp'
        properties: {
          privateLinkServiceId: functionAppId
          groupIds: [
            'sites'
          ]
        }
      }
    ]
  }
}

resource peFuncDns 'Microsoft.Network/privateEndpoints/privateDnsZoneGroups@2023-11-01' = {
  parent: peFunc
  name: 'default'
  properties: {
    privateDnsZoneConfigs: [
      {
        name: 'sites'
        properties: {
          privateDnsZoneId: sitesZoneId
        }
      }
    ]
  }
}

// ─── FA Storage — blob ───────────────────────────────────────────────────────
resource peFaSaBlob 'Microsoft.Network/privateEndpoints@2023-11-01' = {
  name: '${projectPrefix}-pe-fa-storage-blob'
  location: location
  properties: {
    subnet: {
      id: peSubnetId
    }
    privateLinkServiceConnections: [
      {
        name: 'fa-storage-blob'
        properties: {
          privateLinkServiceId: faStorageAccountId
          groupIds: [
            'blob'
          ]
        }
      }
    ]
  }
}

resource peFaSaBlobDns 'Microsoft.Network/privateEndpoints/privateDnsZoneGroups@2023-11-01' = {
  parent: peFaSaBlob
  name: 'default'
  properties: {
    privateDnsZoneConfigs: [
      {
        name: 'blob'
        properties: {
          privateDnsZoneId: blobZoneId
        }
      }
    ]
  }
}

// ─── FA Storage — file ───────────────────────────────────────────────────────
resource peFaSaFile 'Microsoft.Network/privateEndpoints@2023-11-01' = {
  name: '${projectPrefix}-pe-fa-storage-file'
  location: location
  properties: {
    subnet: {
      id: peSubnetId
    }
    privateLinkServiceConnections: [
      {
        name: 'fa-storage-file'
        properties: {
          privateLinkServiceId: faStorageAccountId
          groupIds: [
            'file'
          ]
        }
      }
    ]
  }
}

resource peFaSaFileDns 'Microsoft.Network/privateEndpoints/privateDnsZoneGroups@2023-11-01' = {
  parent: peFaSaFile
  name: 'default'
  properties: {
    privateDnsZoneConfigs: [
      {
        name: 'file'
        properties: {
          privateDnsZoneId: fileZoneId
        }
      }
    ]
  }
}

// ─── FA Storage — queue ──────────────────────────────────────────────────────
resource peFaSaQueue 'Microsoft.Network/privateEndpoints@2023-11-01' = {
  name: '${projectPrefix}-pe-fa-storage-queue'
  location: location
  properties: {
    subnet: {
      id: peSubnetId
    }
    privateLinkServiceConnections: [
      {
        name: 'fa-storage-queue'
        properties: {
          privateLinkServiceId: faStorageAccountId
          groupIds: [
            'queue'
          ]
        }
      }
    ]
  }
}

resource peFaSaQueueDns 'Microsoft.Network/privateEndpoints/privateDnsZoneGroups@2023-11-01' = {
  parent: peFaSaQueue
  name: 'default'
  properties: {
    privateDnsZoneConfigs: [
      {
        name: 'queue'
        properties: {
          privateDnsZoneId: queueZoneId
        }
      }
    ]
  }
}

// ─── FA Storage — table ──────────────────────────────────────────────────────
resource peFaSaTable 'Microsoft.Network/privateEndpoints@2023-11-01' = {
  name: '${projectPrefix}-pe-fa-storage-table'
  location: location
  properties: {
    subnet: {
      id: peSubnetId
    }
    privateLinkServiceConnections: [
      {
        name: 'fa-storage-table'
        properties: {
          privateLinkServiceId: faStorageAccountId
          groupIds: [
            'table'
          ]
        }
      }
    ]
  }
}

resource peFaSaTableDns 'Microsoft.Network/privateEndpoints/privateDnsZoneGroups@2023-11-01' = {
  parent: peFaSaTable
  name: 'default'
  properties: {
    privateDnsZoneConfigs: [
      {
        name: 'table'
        properties: {
          privateDnsZoneId: tableZoneId
        }
      }
    ]
  }
}

// ─── Event Hub Namespace ─────────────────────────────────────────────────────
resource peEh 'Microsoft.Network/privateEndpoints@2023-11-01' = {
  name: '${projectPrefix}-pe-eventhubs'
  location: location
  properties: {
    subnet: {
      id: peSubnetId
    }
    privateLinkServiceConnections: [
      {
        name: 'eventhubs'
        properties: {
          privateLinkServiceId: eventHubNamespaceId
          groupIds: [
            'namespace'
          ]
        }
      }
    ]
  }
}

resource peEhDns 'Microsoft.Network/privateEndpoints/privateDnsZoneGroups@2023-11-01' = {
  parent: peEh
  name: 'default'
  properties: {
    privateDnsZoneConfigs: [
      {
        name: 'servicebus'
        properties: {
          privateDnsZoneId: servicebusZoneId
        }
      }
    ]
  }
}

// ─── ADX (Kusto) ─────────────────────────────────────────────────────────────
resource peAdx 'Microsoft.Network/privateEndpoints@2023-11-01' = {
  name: '${projectPrefix}-pe-adx'
  location: location
  properties: {
    subnet: {
      id: peSubnetId
    }
    privateLinkServiceConnections: [
      {
        name: 'adx'
        properties: {
          privateLinkServiceId: adxClusterId
          groupIds: [
            'cluster'
          ]
        }
      }
    ]
  }
}

resource peAdxDns 'Microsoft.Network/privateEndpoints/privateDnsZoneGroups@2023-11-01' = {
  parent: peAdx
  name: 'default'
  properties: {
    privateDnsZoneConfigs: [
      {
        name: 'kusto'
        properties: {
          privateDnsZoneId: kustoZoneId
        }
      }
    ]
  }
}

// ─── OpenAI ──────────────────────────────────────────────────────────────────
resource peOpenAi 'Microsoft.Network/privateEndpoints@2023-11-01' = {
  name: '${projectPrefix}-pe-openai'
  location: location
  properties: {
    subnet: {
      id: peSubnetId
    }
    privateLinkServiceConnections: [
      {
        name: 'openai'
        properties: {
          privateLinkServiceId: openaiId
          groupIds: [
            'account'
          ]
        }
      }
    ]
  }
}

resource peOpenAiDns 'Microsoft.Network/privateEndpoints/privateDnsZoneGroups@2023-11-01' = {
  parent: peOpenAi
  name: 'default'
  properties: {
    privateDnsZoneConfigs: [
      {
        name: 'openai'
        properties: {
          privateDnsZoneId: openaiZoneId
        }
      }
    ]
  }
}

output amplsId string = ampls.id
