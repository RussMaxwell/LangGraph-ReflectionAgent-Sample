// =============================================================================
// DEPRECATED — replaced by rbac_core.bicep + rbac_monitor.bicep
//
// The two-RG split (iis-core / iis-core-monitor) requires role assignments to
// be deployed in the same resource group as the target resource.
//
//   rbac_core.bicep    — role assignments for resources in iis-core (VM)
//   rbac_monitor.bicep — role assignments for resources in iis-core-monitor
//                        (LAW, Automation, OpenAI, ADX, Event Hubs, DCRs)
//
// This file is intentionally empty and is no longer referenced by main.bicep.
// =============================================================================
