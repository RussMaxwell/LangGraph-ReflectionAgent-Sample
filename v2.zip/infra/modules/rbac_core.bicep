// =============================================================================
// RBAC Role Assignments — iis-core resource group
//
// Scope: iis-core (VM, NIC, networking)
// Contains only role assignments whose TARGET resource lives in iis-core.
// =============================================================================

@description('Principal ID of the Function App managed identity')
param functionAppPrincipalId string

@description('Principal ID of the Automation Account managed identity')
param automationPrincipalId string

@description('Resource ID of the Virtual Machine')
param vmId string

// ---------------------------------------------------------------------------
// Built-in Role Definition IDs
// ---------------------------------------------------------------------------
var virtualMachineContributorRoleId = '9980e02c-c2be-4d73-94e8-173b1dc7cf3c'

// ---------------------------------------------------------------------------
// Existing resource reference
// ---------------------------------------------------------------------------
resource vm 'Microsoft.Compute/virtualMachines@2024-03-01' existing = {
  name: last(split(vmId, '/'))!
}

// ---------------------------------------------------------------------------
// Role Assignments
// ---------------------------------------------------------------------------

// 1. Function App MI → Virtual Machine Contributor on VM
resource funcAppVmContributor 'Microsoft.Authorization/roleAssignments@2022-04-01' = {
  name: guid(vm.id, functionAppPrincipalId, virtualMachineContributorRoleId)
  scope: vm
  properties: {
    roleDefinitionId: subscriptionResourceId('Microsoft.Authorization/roleDefinitions', virtualMachineContributorRoleId)
    principalId: functionAppPrincipalId
    principalType: 'ServicePrincipal'
  }
}

// 2. Automation Account MI → Virtual Machine Contributor on VM
resource autoAcctVmContributor 'Microsoft.Authorization/roleAssignments@2022-04-01' = {
  name: guid(vm.id, automationPrincipalId, virtualMachineContributorRoleId)
  scope: vm
  properties: {
    roleDefinitionId: subscriptionResourceId('Microsoft.Authorization/roleDefinitions', virtualMachineContributorRoleId)
    principalId: automationPrincipalId
    principalType: 'ServicePrincipal'
  }
}
