// =============================================================================
// Log Analytics Workspace — agent event tables, DCE, and ingestion DCRs.
//
// This workspace holds only healing pipeline log tables:
//   AgentEvents_CL  — healing event records (written by reporting agents)
//   AgentErrors_CL  — agent error logs
//
// The VMPerf_CL / IISPerf_CL alert-tier tables have been removed.
// Perf telemetry now lives exclusively in ADX, polled by IISMonitorPoller.
// =============================================================================

@description('Azure region for all resources')
param location string

@description('Project prefix used for naming resources')
param projectPrefix string

var workspaceName = '${projectPrefix}-law'
var dceName        = '${projectPrefix}-dce'

// ─── Log Analytics Workspace ──────────────────────────────────────────────────

resource workspace 'Microsoft.OperationalInsights/workspaces@2023-09-01' = {
  name: workspaceName
  location: location
  properties: {
    sku: {
      name: 'PerGB2018'
    }
    retentionInDays: 30
  }
}

// ─── Agent event tables ───────────────────────────────────────────────────────

resource tableAgentEvents 'Microsoft.OperationalInsights/workspaces/tables@2022-10-01' = {
  parent: workspace
  name: 'AgentEvents_CL'
  properties: {
    schema: {
      name: 'AgentEvents_CL'
      columns: [
        { name: 'TimeGenerated',        type: 'datetime' }
        { name: 'VMHostname',           type: 'string'   }
        { name: 'AlertId',              type: 'string'   }
        { name: 'AlertName',            type: 'string'   }
        { name: 'Severity',             type: 'string'   }
        { name: 'IssueType',            type: 'string'   }
        { name: 'IssueSummary',         type: 'string'   }
        { name: 'DetectionTime',        type: 'datetime' }
        { name: 'AnalysisResult',       type: 'string'   }
        { name: 'MitigationSteps',      type: 'string'   }
        { name: 'RunbookExecuted',      type: 'string'   }
        { name: 'RemediationOutcome',   type: 'string'   }
        { name: 'RemediationDetail',    type: 'string'   }
        { name: 'IsHealthy',            type: 'boolean'  }
        { name: 'RetryCount',           type: 'int'      }
        { name: 'RootCause',            type: 'string'   }
        { name: 'NextSteps',            type: 'string'   }
        { name: 'ReasoningModel',       type: 'string'   }
        { name: 'FastModel',            type: 'string'   }
        { name: 'AgentVersion',         type: 'string'   }
        { name: 'TotalDurationSeconds', type: 'real'     }
        // ─── v3 single-path fields ──────────────────────────────────────
        { name: 'DecisionAction',       type: 'string'   }
        { name: 'DecisionConfidence',   type: 'string'   }
        { name: 'Strategy',             type: 'string'   }
        { name: 'EscalationTarget',     type: 'string'   }
      ]
    }
    retentionInDays: 30
  }
}

resource tableAgentErrors 'Microsoft.OperationalInsights/workspaces/tables@2022-10-01' = {
  parent: workspace
  name: 'AgentErrors_CL'
  properties: {
    schema: {
      name: 'AgentErrors_CL'
      columns: [
        { name: 'TimeGenerated', type: 'datetime' }
        { name: 'VMHostname',    type: 'string'   }
        { name: 'Agent',         type: 'string'   }
        { name: 'Error',         type: 'string'   }
      ]
    }
    retentionInDays: 30
  }
}

// ─── Data Collection Endpoint (used by LogsIngestionClient in the Function App) ─

resource dce 'Microsoft.Insights/dataCollectionEndpoints@2023-03-11' = {
  name: dceName
  location: location
  properties: {
    networkAcls: {
      publicNetworkAccess: 'Enabled'
    }
  }
}

// ─── DCR — AgentEvents_CL ingestion ──────────────────────────────────────────
// The Function App's LogsIngestionClient uses this DCR's immutableId as the
// rule_id when calling write_agent_event().  The Monitoring Metrics Publisher
// role on this DCR is granted to the Function App MI in rbac_monitor.bicep.

resource dcrAgentEvents 'Microsoft.Insights/dataCollectionRules@2023-03-11' = {
  name: '${projectPrefix}-dcr-agent-events'
  location: location
  properties: {
    dataCollectionEndpointId: dce.id
    streamDeclarations: {
      'Custom-AgentEvents_CL': {
        columns: [
          { name: 'TimeGenerated',        type: 'datetime' }
          { name: 'VMHostname',           type: 'string'   }
          { name: 'AlertId',              type: 'string'   }
          { name: 'AlertName',            type: 'string'   }
          { name: 'Severity',             type: 'string'   }
          { name: 'IssueType',            type: 'string'   }
          { name: 'IssueSummary',         type: 'string'   }
          { name: 'DetectionTime',        type: 'datetime' }
          { name: 'AnalysisResult',       type: 'string'   }
          { name: 'MitigationSteps',      type: 'string'   }
          { name: 'RunbookExecuted',      type: 'string'   }
          { name: 'RemediationOutcome',   type: 'string'   }
          { name: 'RemediationDetail',    type: 'string'   }
          { name: 'IsHealthy',            type: 'boolean'  }
          { name: 'RetryCount',           type: 'int'      }
          { name: 'RootCause',            type: 'string'   }
          { name: 'NextSteps',            type: 'string'   }
          { name: 'ReasoningModel',       type: 'string'   }
          { name: 'FastModel',            type: 'string'   }
          { name: 'AgentVersion',         type: 'string'   }
          { name: 'TotalDurationSeconds', type: 'real'     }
          // ─── v3 single-path fields ────────────────────────────────────
          { name: 'DecisionAction',       type: 'string'   }
          { name: 'DecisionConfidence',   type: 'string'   }
          { name: 'Strategy',             type: 'string'   }
          { name: 'EscalationTarget',     type: 'string'   }
        ]
      }
    }
    dataSources: {}
    destinations: {
      logAnalytics: [
        {
          name:                'lawDest'
          workspaceResourceId: workspace.id
        }
      ]
    }
    dataFlows: [
      {
        streams:      ['Custom-AgentEvents_CL']
        destinations: ['lawDest']
        outputStream: 'Custom-AgentEvents_CL'
      }
    ]
  }
  dependsOn: [tableAgentEvents]
}

// ─── DCR — AgentErrors_CL ingestion ──────────────────────────────────────────

resource dcrAgentErrors 'Microsoft.Insights/dataCollectionRules@2023-03-11' = {
  name: '${projectPrefix}-dcr-agent-errors'
  location: location
  properties: {
    dataCollectionEndpointId: dce.id
    streamDeclarations: {
      'Custom-AgentErrors_CL': {
        columns: [
          { name: 'TimeGenerated', type: 'datetime' }
          { name: 'VMHostname',    type: 'string'   }
          { name: 'Agent',         type: 'string'   }
          { name: 'Error',         type: 'string'   }
        ]
      }
    }
    dataSources: {}
    destinations: {
      logAnalytics: [
        {
          name:                'lawDest'
          workspaceResourceId: workspace.id
        }
      ]
    }
    dataFlows: [
      {
        streams:      ['Custom-AgentErrors_CL']
        destinations: ['lawDest']
        outputStream: 'Custom-AgentErrors_CL'
      }
    ]
  }
  dependsOn: [tableAgentErrors]
}

// ─── Outputs ──────────────────────────────────────────────────────────────────

output workspaceId         string = workspace.id
output workspaceCustomerId string = workspace.properties.customerId
output dceId               string = dce.id
output dceEndpoint         string = dce.properties.logsIngestion.endpoint

// Immutable IDs are the rule_id values passed to LogsIngestionClient.upload()
output dcrAgentEventsImmutableId string = dcrAgentEvents.properties.immutableId
output dcrAgentErrorsImmutableId string = dcrAgentErrors.properties.immutableId

// Resource IDs are used by rbac_monitor.bicep to assign Monitoring Metrics Publisher
output dcrAgentEventsId string = dcrAgentEvents.id
output dcrAgentErrorsId string = dcrAgentErrors.id
