// =============================================================================
// DEPRECATED — NOT DEPLOYED
//
// Previously contained 15 Azure Monitor scheduledQueryRules that queried
// VMPerf_CL / IISPerf_CL in LAW and fired an Action Group webhook to the
// IISHealingOrchestrator Function App endpoint.
//
// Replaced by IISMonitorPoller (Azure Function timer trigger) which queries
// ADX directly every 60 seconds and calls IISHealingOrchestratorInternal,
// eliminating ~$63/month in scheduledQueryRule evaluation fees.
//
// This module is no longer referenced in main.bicep and will not be deployed.
// =============================================================================

@description('Azure region for all resources')
param location string

@description('Project prefix for naming resources')
param projectPrefix string

@description('Resource ID of the Log Analytics Workspace')
param lawWorkspaceId string

@description('Hostname of the monitored VM (used in custom log table names)')
param vmHostname string

@description('Default hostname of the Function App')
param functionAppDefaultHostname string

// ---------------------------------------------------------------------------
// Custom log table names derived from VM hostname
// ---------------------------------------------------------------------------
var vmPerfTable = 'VMPerf_${vmHostname}_CL'
var iisPerfTable = 'IISPerf_${vmHostname}_CL'

// ---------------------------------------------------------------------------
// Action Group — sends HTTP POST to the Function App orchestrator endpoint
// ---------------------------------------------------------------------------
resource actionGroup 'Microsoft.Insights/actionGroups@2023-01-01' = {
  name: '${projectPrefix}-ag-iis-healing'
  location: 'global'
  properties: {
    groupShortName: 'IISHeal'
    enabled: true
    webhookReceivers: [
      {
        name: 'FunctionAppOrchestrator'
        serviceUri: 'https://${functionAppDefaultHostname}/api/IISHealingOrchestrator'
        useCommonAlertSchema: true
      }
    ]
  }
}

// ---------------------------------------------------------------------------
// Helper variable for action group reference
// ---------------------------------------------------------------------------
var actionGroupRef = [
  actionGroup.id
]

// ============================================================================
// VM BASELINE ALERTS — query VMPerf_{vmHostname}_CL
//
// NOTE: AMA perfmon collection stores the FULL counter path in CounterName
// (e.g. "\\Processor(_Total)\\% Processor Time") with ObjectName and
// InstanceName left empty. All queries therefore use `endswith` for the
// counter name and `contains` for instance filtering.
// ============================================================================

// ---------------------------------------------------------------------------
// 1. CPU > 85% sustained 5 min — Severity 2 (High)
// ---------------------------------------------------------------------------
resource alertCpuHigh 'Microsoft.Insights/scheduledQueryRules@2023-03-15-preview' = {
  name: '${projectPrefix}-alert-cpu-high'
  location: location
  properties: {
    displayName: 'VM CPU > 85% sustained 5 min'
    description: 'Triggers when the VM processor utilization exceeds 85 percent for a sustained 5-minute window.'
    severity: 2
    enabled: true
    evaluationFrequency: 'PT1M'
    windowSize: 'PT5M'
    scopes: [
      lawWorkspaceId
    ]
    criteria: {
      allOf: [
        {
          query: '${vmPerfTable} | where CounterName endswith "% Processor Time" and CounterName contains "_Total" | summarize AvgCpu = avg(CounterValue) by bin(TimeGenerated, 1m) | where AvgCpu > 85'
          timeAggregation: 'Count'
          operator: 'GreaterThanOrEqual'
          threshold: 5
          failingPeriods: {
            numberOfEvaluationPeriods: 1
            minFailingPeriodsToAlert: 1
          }
        }
      ]
    }
    actions: {
      actionGroups: actionGroupRef
    }
  }
}

// ---------------------------------------------------------------------------
// 2. Available memory < 512 MB for 5 min — Severity 2 (High)
// ---------------------------------------------------------------------------
resource alertMemoryLow 'Microsoft.Insights/scheduledQueryRules@2023-03-15-preview' = {
  name: '${projectPrefix}-alert-memory-low'
  location: location
  properties: {
    displayName: 'VM Available Memory < 512 MB for 5 min'
    description: 'Triggers when available memory drops below 512 MB for a sustained 5-minute window.'
    severity: 2
    enabled: true
    evaluationFrequency: 'PT1M'
    windowSize: 'PT5M'
    scopes: [
      lawWorkspaceId
    ]
    criteria: {
      allOf: [
        {
          query: '${vmPerfTable} | where CounterName endswith "Available MBytes" | summarize AvgMem = avg(CounterValue) by bin(TimeGenerated, 1m) | where AvgMem < 512'
          timeAggregation: 'Count'
          operator: 'GreaterThanOrEqual'
          threshold: 5
          failingPeriods: {
            numberOfEvaluationPeriods: 1
            minFailingPeriodsToAlert: 1
          }
        }
      ]
    }
    actions: {
      actionGroups: actionGroupRef
    }
  }
}

// ---------------------------------------------------------------------------
// 3. Memory committed > 90% for 5 min — Severity 2 (High)
// ---------------------------------------------------------------------------
resource alertMemoryCommitted 'Microsoft.Insights/scheduledQueryRules@2023-03-15-preview' = {
  name: '${projectPrefix}-alert-memory-committed'
  location: location
  properties: {
    displayName: 'VM Memory Committed > 90% for 5 min'
    description: 'Triggers when committed memory exceeds 90 percent for a sustained 5-minute window.'
    severity: 2
    enabled: true
    evaluationFrequency: 'PT1M'
    windowSize: 'PT5M'
    scopes: [
      lawWorkspaceId
    ]
    criteria: {
      allOf: [
        {
          query: '${vmPerfTable} | where CounterName endswith "% Committed Bytes In Use" | summarize AvgCommitted = avg(CounterValue) by bin(TimeGenerated, 1m) | where AvgCommitted > 90'
          timeAggregation: 'Count'
          operator: 'GreaterThanOrEqual'
          threshold: 5
          failingPeriods: {
            numberOfEvaluationPeriods: 1
            minFailingPeriodsToAlert: 1
          }
        }
      ]
    }
    actions: {
      actionGroups: actionGroupRef
    }
  }
}

// ---------------------------------------------------------------------------
// 4. C drive free space < 5% — Severity 1 (Critical)
// ---------------------------------------------------------------------------
resource alertDiskSpace 'Microsoft.Insights/scheduledQueryRules@2023-03-15-preview' = {
  name: '${projectPrefix}-alert-disk-space-low'
  location: location
  properties: {
    displayName: 'VM C: Drive Free Space < 5%'
    description: 'Triggers when the C drive free space drops below 5 percent.'
    severity: 1
    enabled: true
    evaluationFrequency: 'PT1M'
    windowSize: 'PT5M'
    scopes: [
      lawWorkspaceId
    ]
    criteria: {
      allOf: [
        {
          query: '${vmPerfTable} | where CounterName endswith "% Free Space" and CounterName contains "C:" | summarize AvgFree = avg(CounterValue) by bin(TimeGenerated, 1m) | where AvgFree < 5'
          timeAggregation: 'Count'
          operator: 'GreaterThanOrEqual'
          threshold: 1
          failingPeriods: {
            numberOfEvaluationPeriods: 1
            minFailingPeriodsToAlert: 1
          }
        }
      ]
    }
    actions: {
      actionGroups: actionGroupRef
    }
  }
}

// ---------------------------------------------------------------------------
// 5. Disk queue length > 5 for 5 min — Severity 2 (High)
// ---------------------------------------------------------------------------
resource alertDiskQueue 'Microsoft.Insights/scheduledQueryRules@2023-03-15-preview' = {
  name: '${projectPrefix}-alert-disk-queue'
  location: location
  properties: {
    displayName: 'VM Disk Queue Length > 5 for 5 min'
    description: 'Triggers when the average disk queue length exceeds 5 for a sustained 5-minute window.'
    severity: 2
    enabled: true
    evaluationFrequency: 'PT1M'
    windowSize: 'PT5M'
    scopes: [
      lawWorkspaceId
    ]
    criteria: {
      allOf: [
        {
          query: '${vmPerfTable} | where CounterName endswith "Avg. Disk Queue Length" | summarize AvgQueue = avg(CounterValue) by bin(TimeGenerated, 1m) | where AvgQueue > 5'
          timeAggregation: 'Count'
          operator: 'GreaterThanOrEqual'
          threshold: 5
          failingPeriods: {
            numberOfEvaluationPeriods: 1
            minFailingPeriodsToAlert: 1
          }
        }
      ]
    }
    actions: {
      actionGroups: actionGroupRef
    }
  }
}

// ---------------------------------------------------------------------------
// 6. Paging > 1000 pages/sec for 5 min — Severity 3 (Medium)
// ---------------------------------------------------------------------------
resource alertPaging 'Microsoft.Insights/scheduledQueryRules@2023-03-15-preview' = {
  name: '${projectPrefix}-alert-paging-high'
  location: location
  properties: {
    displayName: 'VM Paging > 1000 pages/sec for 5 min'
    description: 'Triggers when page reads per second exceed 1000 for a sustained 5-minute window.'
    severity: 3
    enabled: true
    evaluationFrequency: 'PT1M'
    windowSize: 'PT5M'
    scopes: [
      lawWorkspaceId
    ]
    criteria: {
      allOf: [
        {
          query: '${vmPerfTable} | where CounterName endswith "Pages/sec" | summarize AvgPages = avg(CounterValue) by bin(TimeGenerated, 1m) | where AvgPages > 1000'
          timeAggregation: 'Count'
          operator: 'GreaterThanOrEqual'
          threshold: 5
          failingPeriods: {
            numberOfEvaluationPeriods: 1
            minFailingPeriodsToAlert: 1
          }
        }
      ]
    }
    actions: {
      actionGroups: actionGroupRef
    }
  }
}

// ---------------------------------------------------------------------------
// 7. CPU processor queue > 10 for 5 min — Severity 3 (Medium)
// ---------------------------------------------------------------------------
resource alertProcessorQueue 'Microsoft.Insights/scheduledQueryRules@2023-03-15-preview' = {
  name: '${projectPrefix}-alert-processor-queue'
  location: location
  properties: {
    displayName: 'VM Processor Queue Length > 10 for 5 min'
    description: 'Triggers when the processor queue length exceeds 10 for a sustained 5-minute window.'
    severity: 3
    enabled: true
    evaluationFrequency: 'PT1M'
    windowSize: 'PT5M'
    scopes: [
      lawWorkspaceId
    ]
    criteria: {
      allOf: [
        {
          query: '${vmPerfTable} | where CounterName endswith "Processor Queue Length" | summarize AvgQueue = avg(CounterValue) by bin(TimeGenerated, 1m) | where AvgQueue > 10'
          timeAggregation: 'Count'
          operator: 'GreaterThanOrEqual'
          threshold: 5
          failingPeriods: {
            numberOfEvaluationPeriods: 1
            minFailingPeriodsToAlert: 1
          }
        }
      ]
    }
    actions: {
      actionGroups: actionGroupRef
    }
  }
}

// ============================================================================
// IIS / APPLICATION ALERTS — query IISPerf_{vmHostname}_CL
//
// Same `endswith` / `contains` pattern — AMA stores full perfmon paths.
// ============================================================================

// ---------------------------------------------------------------------------
// 8. IIS Current Connections = 0 for 3 min (IIS down) — Severity 1 (Critical)
// ---------------------------------------------------------------------------
resource alertIISDown 'Microsoft.Insights/scheduledQueryRules@2023-03-15-preview' = {
  name: '${projectPrefix}-alert-iis-down'
  location: location
  properties: {
    displayName: 'IIS Current Connections = 0 for 5 min (IIS Down)'
    description: 'Triggers when IIS current connections drop to zero for 5 minutes, indicating the service may be down.'
    severity: 1
    enabled: true
    evaluationFrequency: 'PT1M'
    windowSize: 'PT5M'
    scopes: [
      lawWorkspaceId
    ]
    criteria: {
      allOf: [
        {
          query: '${iisPerfTable} | where CounterName endswith "Current Connections" | summarize MaxConn = max(CounterValue) by bin(TimeGenerated, 1m) | where MaxConn == 0'
          timeAggregation: 'Count'
          operator: 'GreaterThanOrEqual'
          threshold: 5
          failingPeriods: {
            numberOfEvaluationPeriods: 1
            minFailingPeriodsToAlert: 1
          }
        }
      ]
    }
    actions: {
      actionGroups: actionGroupRef
    }
  }
}

// ---------------------------------------------------------------------------
// 9. Failed connection attempts > 50 in 5 min — Severity 2 (High)
// ---------------------------------------------------------------------------
resource alertFailedConnections 'Microsoft.Insights/scheduledQueryRules@2023-03-15-preview' = {
  name: '${projectPrefix}-alert-failed-connections'
  location: location
  properties: {
    displayName: 'IIS Failed Connection Attempts > 50 in 5 min'
    description: 'Triggers when the total failed connection attempts exceed 50 within a 5-minute window.'
    severity: 2
    enabled: true
    evaluationFrequency: 'PT1M'
    windowSize: 'PT5M'
    scopes: [
      lawWorkspaceId
    ]
    criteria: {
      allOf: [
        {
          query: '${iisPerfTable} | where CounterName endswith "Connection Attempts Failed" | summarize TotalFailed = sum(CounterValue) by bin(TimeGenerated, 5m) | where TotalFailed > 50'
          timeAggregation: 'Count'
          operator: 'GreaterThanOrEqual'
          threshold: 1
          failingPeriods: {
            numberOfEvaluationPeriods: 1
            minFailingPeriodsToAlert: 1
          }
        }
      ]
    }
    actions: {
      actionGroups: actionGroupRef
    }
  }
}

// ---------------------------------------------------------------------------
// 10. ASP.NET requests queued > 100 — Severity 2 (High)
// ---------------------------------------------------------------------------
resource alertAspNetRequestsQueued 'Microsoft.Insights/scheduledQueryRules@2023-03-15-preview' = {
  name: '${projectPrefix}-alert-aspnet-requests-queued'
  location: location
  properties: {
    displayName: 'ASP.NET Requests Queued > 100'
    description: 'Triggers when ASP.NET queued requests exceed 100.'
    severity: 2
    enabled: true
    evaluationFrequency: 'PT1M'
    windowSize: 'PT5M'
    scopes: [
      lawWorkspaceId
    ]
    criteria: {
      allOf: [
        {
          query: '${iisPerfTable} | where CounterName endswith "Requests Queued" | summarize AvgQueued = avg(CounterValue) by bin(TimeGenerated, 1m) | where AvgQueued > 100'
          timeAggregation: 'Count'
          operator: 'GreaterThanOrEqual'
          threshold: 1
          failingPeriods: {
            numberOfEvaluationPeriods: 1
            minFailingPeriodsToAlert: 1
          }
        }
      ]
    }
    actions: {
      actionGroups: actionGroupRef
    }
  }
}

// ---------------------------------------------------------------------------
// 11. ASP.NET application restarts > 2 in 10 min — Severity 1 (Critical)
// ---------------------------------------------------------------------------
resource alertAspNetRestarts 'Microsoft.Insights/scheduledQueryRules@2023-03-15-preview' = {
  name: '${projectPrefix}-alert-aspnet-restarts'
  location: location
  properties: {
    displayName: 'ASP.NET Application Restarts > 2 in 10 min'
    description: 'Triggers when ASP.NET application restarts exceed 2 within a 10-minute window, indicating instability.'
    severity: 1
    enabled: true
    evaluationFrequency: 'PT1M'
    windowSize: 'PT10M'
    scopes: [
      lawWorkspaceId
    ]
    criteria: {
      allOf: [
        {
          query: '${iisPerfTable} | where CounterName endswith "Application Restarts" | summarize TotalRestarts = sum(CounterValue) by bin(TimeGenerated, 10m) | where TotalRestarts > 2'
          timeAggregation: 'Count'
          operator: 'GreaterThanOrEqual'
          threshold: 1
          failingPeriods: {
            numberOfEvaluationPeriods: 1
            minFailingPeriodsToAlert: 1
          }
        }
      ]
    }
    actions: {
      actionGroups: actionGroupRef
    }
  }
}

// ---------------------------------------------------------------------------
// 12. w3wp CPU > 80% for 5 min — Severity 2 (High)
// ---------------------------------------------------------------------------
resource alertW3wpCpu 'Microsoft.Insights/scheduledQueryRules@2023-03-15-preview' = {
  name: '${projectPrefix}-alert-w3wp-cpu'
  location: location
  properties: {
    displayName: 'w3wp Process CPU > 80% for 5 min'
    description: 'Triggers when the IIS worker process (w3wp) CPU utilization exceeds 80 percent for a sustained 5-minute window.'
    severity: 2
    enabled: true
    evaluationFrequency: 'PT1M'
    windowSize: 'PT5M'
    scopes: [
      lawWorkspaceId
    ]
    criteria: {
      allOf: [
        {
          query: '${iisPerfTable} | where CounterName endswith "% Processor Time" and CounterName contains "w3wp" | summarize AvgCpu = avg(CounterValue) by bin(TimeGenerated, 1m) | where AvgCpu > 80'
          timeAggregation: 'Count'
          operator: 'GreaterThanOrEqual'
          threshold: 5
          failingPeriods: {
            numberOfEvaluationPeriods: 1
            minFailingPeriodsToAlert: 1
          }
        }
      ]
    }
    actions: {
      actionGroups: actionGroupRef
    }
  }
}

// ---------------------------------------------------------------------------
// 13. w3wp Working Set > 1.5 GB — Severity 2 (High)
// ---------------------------------------------------------------------------
resource alertW3wpMemory 'Microsoft.Insights/scheduledQueryRules@2023-03-15-preview' = {
  name: '${projectPrefix}-alert-w3wp-memory'
  location: location
  properties: {
    displayName: 'w3wp Working Set > 1.5 GB'
    description: 'Triggers when the IIS worker process (w3wp) working set memory exceeds 1.5 GB.'
    severity: 2
    enabled: true
    evaluationFrequency: 'PT1M'
    windowSize: 'PT5M'
    scopes: [
      lawWorkspaceId
    ]
    criteria: {
      allOf: [
        {
          query: '${iisPerfTable} | where CounterName endswith "Working Set" and CounterName contains "w3wp" | summarize AvgWS = avg(CounterValue) by bin(TimeGenerated, 1m) | where AvgWS > 1610612736'
          timeAggregation: 'Count'
          operator: 'GreaterThanOrEqual'
          threshold: 1
          failingPeriods: {
            numberOfEvaluationPeriods: 1
            minFailingPeriodsToAlert: 1
          }
        }
      ]
    }
    actions: {
      actionGroups: actionGroupRef
    }
  }
}

// ---------------------------------------------------------------------------
// 14. w3wp thread count > 200 — Severity 3 (Medium)
// ---------------------------------------------------------------------------
resource alertW3wpThreads 'Microsoft.Insights/scheduledQueryRules@2023-03-15-preview' = {
  name: '${projectPrefix}-alert-w3wp-threads'
  location: location
  properties: {
    displayName: 'w3wp Thread Count > 200'
    description: 'Triggers when the IIS worker process (w3wp) thread count exceeds 200.'
    severity: 3
    enabled: true
    evaluationFrequency: 'PT1M'
    windowSize: 'PT5M'
    scopes: [
      lawWorkspaceId
    ]
    criteria: {
      allOf: [
        {
          query: '${iisPerfTable} | where CounterName endswith "Thread Count" and CounterName contains "w3wp" | summarize AvgThreads = avg(CounterValue) by bin(TimeGenerated, 1m) | where AvgThreads > 200'
          timeAggregation: 'Count'
          operator: 'GreaterThanOrEqual'
          threshold: 1
          failingPeriods: {
            numberOfEvaluationPeriods: 1
            minFailingPeriodsToAlert: 1
          }
        }
      ]
    }
    actions: {
      actionGroups: actionGroupRef
    }
  }
}

// ---------------------------------------------------------------------------
// 15. HTTP 404 errors/sec > 20 — Severity 3 (Medium)
// ---------------------------------------------------------------------------
resource alertHttp404 'Microsoft.Insights/scheduledQueryRules@2023-03-15-preview' = {
  name: '${projectPrefix}-alert-http-404'
  location: location
  properties: {
    displayName: 'HTTP 404 Errors/sec > 20'
    description: 'Triggers when the rate of HTTP 404 errors exceeds 20 per second.'
    severity: 3
    enabled: true
    evaluationFrequency: 'PT1M'
    windowSize: 'PT5M'
    scopes: [
      lawWorkspaceId
    ]
    criteria: {
      allOf: [
        {
          query: '${iisPerfTable} | where CounterName endswith "404 Errors/sec" | summarize Avg404 = avg(CounterValue) by bin(TimeGenerated, 1m) | where Avg404 > 20'
          timeAggregation: 'Count'
          operator: 'GreaterThanOrEqual'
          threshold: 1
          failingPeriods: {
            numberOfEvaluationPeriods: 1
            minFailingPeriodsToAlert: 1
          }
        }
      ]
    }
    actions: {
      actionGroups: actionGroupRef
    }
  }
}
