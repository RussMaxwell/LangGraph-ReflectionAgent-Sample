// =============================================================================
// RBAC Role Assignments — iis-core-monitor resource group
//
// Scope: iis-core-monitor (LAW, Automation, OpenAI, ADX, Event Hubs, DCRs)
// =============================================================================

// ── Identity parameters ──────────────────────────────────────────────────────
@description('Principal ID of the Function App managed identity')
param functionAppPrincipalId string

@description('Principal ID of the Automation Account managed identity')
param automationPrincipalId string

@description('System-assigned principal ID of the VM (for Event Hub sender roles)')
param vmPrincipalId string

// ── Resource ID parameters ───────────────────────────────────────────────────
@description('Resource ID of the Log Analytics Workspace')
param lawWorkspaceId string

@description('Resource ID of the Automation Account')
param automationAccountId string

@description('Resource ID of the Azure OpenAI resource')
param openaiId string

@description('Resource ID of the ADX cluster')
param adxClusterId string

@description('Name of the ADX database')
param adxDatabaseName string

@description('System-assigned principal ID of the ADX cluster (for Event Hub receiver)')
param adxClusterPrincipalId string

@description('Resource ID of the IISLogs Event Hub')
param iisLogsEventHubId string

@description('Resource ID of the VMPerf Event Hub')
param vmPerfEventHubId string

@description('Resource ID of the IISPerf Event Hub')
param iisPerfEventHubId string

@description('Resource ID of the Baseline Event Hub')
param baselineEventHubId string

@description('Resource ID of the AgentEvents_CL DCR')
param dcrAgentEventsId string

@description('Resource ID of the AgentErrors_CL DCR')
param dcrAgentErrorsId string

// ---------------------------------------------------------------------------
// Built-in Role Definition IDs
// ---------------------------------------------------------------------------
var logAnalyticsContributorRoleId     = '92aaf0da-9dab-42b6-94a3-d43ce8d16293'
var monitoringMetricsPublisherRoleId  = '3913510d-42f4-4e42-8a64-420c390055eb'
var automationContributorRoleId       = 'f353d9bd-d4a6-484e-a77a-8050b599b867'
var cognitiveServicesOpenAIUserRoleId = '5e0bd9bd-7b93-4f28-af87-19fc36ad61bd'
var eventHubsDataSenderRoleId         = '2b629674-e913-4c01-ae53-ef4638d8f975'
var eventHubsDataReceiverRoleId       = 'a638d3c7-ab3a-418d-83e6-5f17a39d4fde'

// ---------------------------------------------------------------------------
// Existing resource references
// ---------------------------------------------------------------------------
resource lawWorkspace 'Microsoft.OperationalInsights/workspaces@2023-09-01' existing = {
  name: last(split(lawWorkspaceId, '/'))!
}

resource automationAccount 'Microsoft.Automation/automationAccounts@2023-11-01' existing = {
  name: last(split(automationAccountId, '/'))!
}

resource openai 'Microsoft.CognitiveServices/accounts@2024-04-01-preview' existing = {
  name: last(split(openaiId, '/'))!
}

resource adxCluster 'Microsoft.Kusto/clusters@2023-08-15' existing = {
  name: last(split(adxClusterId, '/'))!
}

resource adxDatabase 'Microsoft.Kusto/clusters/databases@2023-08-15' existing = {
  parent: adxCluster
  name: adxDatabaseName
}

resource iisLogsEventHub 'Microsoft.EventHub/namespaces/eventhubs@2024-01-01' existing = {
  name: '${split(iisLogsEventHubId, '/')[8]}/${last(split(iisLogsEventHubId, '/'))}'
}

resource vmPerfEventHub 'Microsoft.EventHub/namespaces/eventhubs@2024-01-01' existing = {
  name: '${split(vmPerfEventHubId, '/')[8]}/${last(split(vmPerfEventHubId, '/'))}'
}

resource iisPerfEventHub 'Microsoft.EventHub/namespaces/eventhubs@2024-01-01' existing = {
  name: '${split(iisPerfEventHubId, '/')[8]}/${last(split(iisPerfEventHubId, '/'))}'
}

resource baselineEventHub 'Microsoft.EventHub/namespaces/eventhubs@2024-01-01' existing = {
  name: '${split(baselineEventHubId, '/')[8]}/${last(split(baselineEventHubId, '/'))}'
}

resource dcrAgentEvents 'Microsoft.Insights/dataCollectionRules@2023-03-11' existing = {
  name: last(split(dcrAgentEventsId, '/'))!
}

resource dcrAgentErrors 'Microsoft.Insights/dataCollectionRules@2023-03-11' existing = {
  name: last(split(dcrAgentErrorsId, '/'))!
}

// ===========================================================================
// SECTION A — Function App + Automation Account → monitoring resources
// ===========================================================================

resource funcAppLawContributor 'Microsoft.Authorization/roleAssignments@2022-04-01' = {
  name: guid(lawWorkspace.id, functionAppPrincipalId, logAnalyticsContributorRoleId)
  scope: lawWorkspace
  properties: {
    roleDefinitionId: subscriptionResourceId('Microsoft.Authorization/roleDefinitions', logAnalyticsContributorRoleId)
    principalId: functionAppPrincipalId
    principalType: 'ServicePrincipal'
  }
}

resource funcAppMetricsPublisher 'Microsoft.Authorization/roleAssignments@2022-04-01' = {
  name: guid(lawWorkspace.id, functionAppPrincipalId, monitoringMetricsPublisherRoleId)
  scope: lawWorkspace
  properties: {
    roleDefinitionId: subscriptionResourceId('Microsoft.Authorization/roleDefinitions', monitoringMetricsPublisherRoleId)
    principalId: functionAppPrincipalId
    principalType: 'ServicePrincipal'
  }
}

resource funcAppAutomationContributor 'Microsoft.Authorization/roleAssignments@2022-04-01' = {
  name: guid(automationAccount.id, functionAppPrincipalId, automationContributorRoleId)
  scope: automationAccount
  properties: {
    roleDefinitionId: subscriptionResourceId('Microsoft.Authorization/roleDefinitions', automationContributorRoleId)
    principalId: functionAppPrincipalId
    principalType: 'ServicePrincipal'
  }
}

resource funcAppOpenAIUser 'Microsoft.Authorization/roleAssignments@2022-04-01' = {
  name: guid(openai.id, functionAppPrincipalId, cognitiveServicesOpenAIUserRoleId)
  scope: openai
  properties: {
    roleDefinitionId: subscriptionResourceId('Microsoft.Authorization/roleDefinitions', cognitiveServicesOpenAIUserRoleId)
    principalId: functionAppPrincipalId
    principalType: 'ServicePrincipal'
  }
}

// Function App MI → Monitoring Metrics Publisher on AgentEvents DCR
// Required for LogsIngestionClient.upload() to write to AgentEvents_CL.
resource funcAppDcrAgentEventsPublisher 'Microsoft.Authorization/roleAssignments@2022-04-01' = {
  name: guid(dcrAgentEvents.id, functionAppPrincipalId, monitoringMetricsPublisherRoleId)
  scope: dcrAgentEvents
  properties: {
    roleDefinitionId: subscriptionResourceId('Microsoft.Authorization/roleDefinitions', monitoringMetricsPublisherRoleId)
    principalId: functionAppPrincipalId
    principalType: 'ServicePrincipal'
  }
}

// Function App MI → Monitoring Metrics Publisher on AgentErrors DCR
resource funcAppDcrAgentErrorsPublisher 'Microsoft.Authorization/roleAssignments@2022-04-01' = {
  name: guid(dcrAgentErrors.id, functionAppPrincipalId, monitoringMetricsPublisherRoleId)
  scope: dcrAgentErrors
  properties: {
    roleDefinitionId: subscriptionResourceId('Microsoft.Authorization/roleDefinitions', monitoringMetricsPublisherRoleId)
    principalId: functionAppPrincipalId
    principalType: 'ServicePrincipal'
  }
}

resource autoAcctLawContributor 'Microsoft.Authorization/roleAssignments@2022-04-01' = {
  name: guid(lawWorkspace.id, automationPrincipalId, logAnalyticsContributorRoleId)
  scope: lawWorkspace
  properties: {
    roleDefinitionId: subscriptionResourceId('Microsoft.Authorization/roleDefinitions', logAnalyticsContributorRoleId)
    principalId: automationPrincipalId
    principalType: 'ServicePrincipal'
  }
}

// ===========================================================================
// SECTION B — Function App MI → ADX Database Viewer (Kusto native RBAC)
// ===========================================================================

resource funcAppAdxViewer 'Microsoft.Kusto/clusters/databases/principalAssignments@2023-08-15' = {
  parent: adxDatabase
  name: guid(adxDatabase.id, functionAppPrincipalId, 'Viewer')
  properties: {
    principalId: functionAppPrincipalId
    principalType: 'App'
    role: 'Viewer'
    tenantId: subscription().tenantId
  }
}

// ===========================================================================
// SECTION C — ADX cluster MSI → Event Hub Data Receiver (all three hubs)
// ===========================================================================

resource adxIisLogsReceiver 'Microsoft.Authorization/roleAssignments@2022-04-01' = {
  name: guid(iisLogsEventHubId, adxClusterPrincipalId, eventHubsDataReceiverRoleId)
  scope: iisLogsEventHub
  properties: {
    roleDefinitionId: subscriptionResourceId('Microsoft.Authorization/roleDefinitions', eventHubsDataReceiverRoleId)
    principalId: adxClusterPrincipalId
    principalType: 'ServicePrincipal'
  }
}

resource adxVmPerfReceiver 'Microsoft.Authorization/roleAssignments@2022-04-01' = {
  name: guid(vmPerfEventHubId, adxClusterPrincipalId, eventHubsDataReceiverRoleId)
  scope: vmPerfEventHub
  properties: {
    roleDefinitionId: subscriptionResourceId('Microsoft.Authorization/roleDefinitions', eventHubsDataReceiverRoleId)
    principalId: adxClusterPrincipalId
    principalType: 'ServicePrincipal'
  }
}

resource adxIisPerfReceiver 'Microsoft.Authorization/roleAssignments@2022-04-01' = {
  name: guid(iisPerfEventHubId, adxClusterPrincipalId, eventHubsDataReceiverRoleId)
  scope: iisPerfEventHub
  properties: {
    roleDefinitionId: subscriptionResourceId('Microsoft.Authorization/roleDefinitions', eventHubsDataReceiverRoleId)
    principalId: adxClusterPrincipalId
    principalType: 'ServicePrincipal'
  }
}

resource adxBaselineReceiver 'Microsoft.Authorization/roleAssignments@2022-04-01' = {
  name: guid(baselineEventHubId, adxClusterPrincipalId, eventHubsDataReceiverRoleId)
  scope: baselineEventHub
  properties: {
    roleDefinitionId: subscriptionResourceId('Microsoft.Authorization/roleDefinitions', eventHubsDataReceiverRoleId)
    principalId: adxClusterPrincipalId
    principalType: 'ServicePrincipal'
  }
}

// ===========================================================================
// SECTION D — VM MSI → IISLogs + VMPerf + IISPerf Event Hub Data Sender
// ===========================================================================

resource vmIisLogsSender 'Microsoft.Authorization/roleAssignments@2022-04-01' = {
  name: guid(iisLogsEventHubId, vmPrincipalId, eventHubsDataSenderRoleId)
  scope: iisLogsEventHub
  properties: {
    roleDefinitionId: subscriptionResourceId('Microsoft.Authorization/roleDefinitions', eventHubsDataSenderRoleId)
    principalId: vmPrincipalId
    principalType: 'ServicePrincipal'
  }
}

resource vmVmPerfSender 'Microsoft.Authorization/roleAssignments@2022-04-01' = {
  name: guid(vmPerfEventHubId, vmPrincipalId, eventHubsDataSenderRoleId)
  scope: vmPerfEventHub
  properties: {
    roleDefinitionId: subscriptionResourceId('Microsoft.Authorization/roleDefinitions', eventHubsDataSenderRoleId)
    principalId: vmPrincipalId
    principalType: 'ServicePrincipal'
  }
}

resource vmIisPerfSender 'Microsoft.Authorization/roleAssignments@2022-04-01' = {
  name: guid(iisPerfEventHubId, vmPrincipalId, eventHubsDataSenderRoleId)
  scope: iisPerfEventHub
  properties: {
    roleDefinitionId: subscriptionResourceId('Microsoft.Authorization/roleDefinitions', eventHubsDataSenderRoleId)
    principalId: vmPrincipalId
    principalType: 'ServicePrincipal'
  }
}

resource vmBaselineSender 'Microsoft.Authorization/roleAssignments@2022-04-01' = {
  name: guid(baselineEventHubId, vmPrincipalId, eventHubsDataSenderRoleId)
  scope: baselineEventHub
  properties: {
    roleDefinitionId: subscriptionResourceId('Microsoft.Authorization/roleDefinitions', eventHubsDataSenderRoleId)
    principalId: vmPrincipalId
    principalType: 'ServicePrincipal'
  }
}
