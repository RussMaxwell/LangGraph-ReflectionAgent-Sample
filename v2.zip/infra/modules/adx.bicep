// =============================================================================
// Azure Data Explorer — cluster, database, tables + ingestion mappings
//
// Tables:
//   IISLogs              — Raw log lines (W3C access log + HTTPERR), ingested via iislogs-eh
//                          LogType column distinguishes 'HTTPERR' from W3C (null/empty).
//   IISLogsParsed        — Parsed W3C fields, auto-populated from IISLogs via update policy
//   IISHttpErrors        — Parsed HTTPERR fields (503s from app pool crash/stop/queue flood),
//                          auto-populated from IISLogs where LogType='HTTPERR' via update policy
//   VMPerf               — VM performance counters, ingested via Send-PerfToEventHub.ps1 → vmperf-eh
//   IISPerf              — IIS/ASP.NET counters,  ingested via Send-PerfToEventHub.ps1 → iisperf-eh
//   PerformanceBaseline  — Baseline snapshots + summary, ingested via Invoke-CaptureBaseline → baseline-eh
//
// Event Hub data connections are deployed separately in adx_connections.bicep
// AFTER rbac_monitor.bicep assigns the ADX MSI the Data Receiver role.
//
// Dev SKU   : Dev(No SLA)_Standard_D11_v2, capacity 1  (~$60/month)
// Prod SKU  : Standard_D11_v2, capacity 2              (~$450/month)
// =============================================================================

@description('Azure region for all resources')
param location string

@description('Project prefix for resource naming')
param projectPrefix string

@description('ADX cluster SKU name')
@allowed([
  'Dev(No SLA)_Standard_D11_v2'
  'Standard_D11_v2'
  'Standard_D12_v2'
  'Standard_D13_v2'
])
param adxSkuName string = 'Dev(No SLA)_Standard_D11_v2'

@description('ADX cluster SKU tier')
@allowed(['Basic', 'Standard'])
param adxSkuTier string = 'Basic'

@description('ADX cluster node capacity (1 for dev, 2+ for prod)')
param adxCapacity int = 1

var clusterName  = '${replace(projectPrefix, '-', '')}adx'
var databaseName = '${projectPrefix}-db'

// ─── ADX Cluster ──────────────────────────────────────────────────────────────

resource adxCluster 'Microsoft.Kusto/clusters@2023-08-15' = {
  name: clusterName
  location: location
  sku: {
    name: adxSkuName
    tier: adxSkuTier
    capacity: adxCapacity
  }
  identity: {
    type: 'SystemAssigned'   // Used by Event Hub data connections in adx_connections.bicep
  }
  properties: {
    enableStreamingIngest: false
    enablePurge: false
    trustedExternalTenants: []
    optimizedAutoscale: {
      isEnabled: false
      minimum: adxCapacity
      maximum: adxCapacity
      version: 1
    }
  }
}

// ─── ADX Database ─────────────────────────────────────────────────────────────

resource adxDatabase 'Microsoft.Kusto/clusters/databases@2023-08-15' = {
  parent: adxCluster
  name: databaseName
  location: location
  kind: 'ReadWrite'
  properties: {
    hotCachePeriod: 'P7D'
    softDeletePeriod: 'P90D'
  }
}

// ─── Tables and ingestion mappings ────────────────────────────────────────────
// .create-merge is idempotent — safe to redeploy without data loss.

resource adxScript 'Microsoft.Kusto/clusters/databases/scripts@2023-08-15' = {
  parent: adxDatabase
  name: 'create-iis-tables'
  properties: {
    continueOnErrors: false
    scriptContent: '''
// ── IISLogs ──────────────────────────────────────────────────────────────────
// LogType is null/empty for W3C access log entries; 'HTTPERR' for HTTP.sys
// kernel-level errors (503 from app pool crash, stop, queue flood, etc.)
// that never appear in the IIS W3C access log.
.create-merge table IISLogs (TimeGenerated:datetime, Computer:string, FilePath:string, LogType:string, RawData:string)

.create-or-alter table IISLogs ingestion json mapping 'IISLogsMapping'
'[{"column":"TimeGenerated","path":"$.TimeGenerated","datatype":"datetime"},{"column":"Computer","path":"$.Computer","datatype":"string"},{"column":"FilePath","path":"$.FilePath","datatype":"string"},{"column":"LogType","path":"$.LogType","datatype":"string"},{"column":"RawData","path":"$.RawData","datatype":"string"}]'

// ── VMPerf ───────────────────────────────────────────────────────────────────
.create-merge table VMPerf (TimeGenerated:datetime, Computer:string, ObjectName:string, CounterName:string, InstanceName:string, CounterValue:real)

.create-or-alter table VMPerf ingestion json mapping 'VMPerfMapping'
'[{"column":"TimeGenerated","path":"$.TimeGenerated","datatype":"datetime"},{"column":"Computer","path":"$.Computer","datatype":"string"},{"column":"ObjectName","path":"$.ObjectName","datatype":"string"},{"column":"CounterName","path":"$.CounterName","datatype":"string"},{"column":"InstanceName","path":"$.InstanceName","datatype":"string"},{"column":"CounterValue","path":"$.CounterValue","datatype":"real"}]'

// ── IISPerf ──────────────────────────────────────────────────────────────────
.create-merge table IISPerf (TimeGenerated:datetime, Computer:string, ObjectName:string, CounterName:string, InstanceName:string, CounterValue:real)

.create-or-alter table IISPerf ingestion json mapping 'IISPerfMapping'
'[{"column":"TimeGenerated","path":"$.TimeGenerated","datatype":"datetime"},{"column":"Computer","path":"$.Computer","datatype":"string"},{"column":"ObjectName","path":"$.ObjectName","datatype":"string"},{"column":"CounterName","path":"$.CounterName","datatype":"string"},{"column":"InstanceName","path":"$.InstanceName","datatype":"string"},{"column":"CounterValue","path":"$.CounterValue","datatype":"real"}]'

// ── PerformanceBaseline ─────────────────────────────────────────────────────
.create-merge table PerformanceBaseline (TimeGenerated:datetime, Computer:string, RecordType:string, MetricName:string, MetricValue:real, CaptureId:string, WindowIndex:int)

.create-or-alter table PerformanceBaseline ingestion json mapping 'BaselineMapping'
'[{"column":"TimeGenerated","path":"$.TimeGenerated","datatype":"datetime"},{"column":"Computer","path":"$.Computer","datatype":"string"},{"column":"RecordType","path":"$.RecordType","datatype":"string"},{"column":"MetricName","path":"$.MetricName","datatype":"string"},{"column":"MetricValue","path":"$.MetricValue","datatype":"real"},{"column":"CaptureId","path":"$.CaptureId","datatype":"string"},{"column":"WindowIndex","path":"$.WindowIndex","datatype":"int"}]'

// ── IISLogsParsed (auto-populated via update policy from IISLogs) ───────────
// Only processes W3C access log entries (LogType is null/empty).
// HTTPERR entries (LogType='HTTPERR') are routed to IISHttpErrors instead.
.create-merge table IISLogsParsed (TimeGenerated:datetime, Computer:string, SiteName:string, ServerIP:string, Method:string, UriStem:string, UriQuery:string, Port:int, Username:string, ClientIP:string, HttpVersion:string, UserAgent:string, Cookie:string, Referer:string, Host:string, StatusCode:int, SubStatus:int, Win32Status:int, TimeTakenMs:int, BytesSent:int, BytesReceived:int)

.create-or-alter function ParseIISLogs() { IISLogs | where (isempty(LogType) or LogType != 'HTTPERR') and RawData !startswith "#" and isnotempty(RawData) | parse RawData with LogDate:string " " LogTime:string " " SiteName:string " " Computer2:string " " ServerIP:string " " Method:string " " UriStem:string " " UriQuery:string " " Port:int " " Username:string " " ClientIP:string " " HttpVersion:string " " UserAgent:string " " Cookie:string " " Referer:string " " Host:string " " StatusCode:int " " SubStatus:int " " Win32Status:int " " TimeTakenMs:int " " BytesSent:int " " BytesReceived:int | project TimeGenerated, Computer, SiteName, ServerIP, Method, UriStem, UriQuery, Port, Username, ClientIP, HttpVersion, UserAgent=replace_string(UserAgent, "+", " "), Cookie, Referer, Host, StatusCode, SubStatus, Win32Status, TimeTakenMs, BytesSent, BytesReceived }

// ── IISHttpErrors (auto-populated via update policy from IISLogs) ────────────
// Captures HTTP.sys kernel-level 503s that never reach the IIS W3C access log:
//   AppOffline   — app pool stopped or crashed (Environment.FailFast, net stop w3svc)
//   ConnLimit    — HTTP.sys connection/queue limit hit (request queue flood)
//   MaxConnLimit — global connection limit reached
//   Timeout      — worker process did not respond in time (worker hang)
// HTTPERR field order: date time c-ip c-port s-ip s-port cs-version cs-verb
//                      cs-uri sc-status s-siteid s-reason s-queuename
.create-merge table IISHttpErrors (TimeGenerated:datetime, Computer:string, ClientIP:string, ClientPort:int, ServerIP:string, Port:int, HttpVersion:string, Method:string, UriStem:string, StatusCode:int, SiteId:int, Reason:string, QueueName:string)

// HTTPERR field order (16 fields — includes streamid + streamid_ex between cs-uri and sc-status):
// date time c-ip c-port s-ip s-port cs-version cs-method cs-uri streamid streamid_ex sc-status s-siteid s-reason s-queuename transport
.create-or-alter function ParseHttpErrors() { IISLogs | where LogType == 'HTTPERR' and isnotempty(RawData) | parse RawData with LogDate:string " " LogTime:string " " ClientIP:string " " ClientPort_s:string " " ServerIP:string " " Port_s:string " " HttpVersion:string " " Method:string " " UriStem:string " " StreamId:string " " StreamIdEx:string " " StatusCode:int " " SiteId_s:string " " Reason:string " " QueueName:string " " Transport:string | project TimeGenerated, Computer, ClientIP, ClientPort=toint(ClientPort_s), ServerIP, Port=toint(Port_s), HttpVersion, Method, UriStem, StatusCode, SiteId=toint(SiteId_s), Reason, QueueName }

// ── Ingestion batching policies ───────────────────────────────────────────────
// Default ADX batching is 5 minutes. The IISMonitorPoller and Send-PerfToEventHub.ps1
// both run every 60 seconds, so we cap batching at 30 s (ADX minimum for Event Hub
// connections) to ensure each poller cycle sees the latest data.
// IISLogs controls latency for IISLogsParsed and IISHttpErrors too (update policy).
.alter table IISLogs policy ingestionbatching '{"MaximumBatchingTimeSpan":"00:00:30","MaximumNumberOfItems":500,"MaximumRawDataSizeMB":1024}'
.alter table VMPerf policy ingestionbatching '{"MaximumBatchingTimeSpan":"00:00:30","MaximumNumberOfItems":500,"MaximumRawDataSizeMB":1024}'
.alter table IISPerf policy ingestionbatching '{"MaximumBatchingTimeSpan":"00:00:30","MaximumNumberOfItems":500,"MaximumRawDataSizeMB":1024}'
'''
  }
}

// ─── Outputs ──────────────────────────────────────────────────────────────────

output clusterId          string = adxCluster.id
output clusterName        string = adxCluster.name
output clusterUri         string = adxCluster.properties.uri
output clusterPrincipalId string = adxCluster.identity.principalId
output databaseName       string = adxDatabase.name
output databaseId         string = adxDatabase.id
