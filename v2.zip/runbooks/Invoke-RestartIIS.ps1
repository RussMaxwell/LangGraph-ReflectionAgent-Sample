<#
.SYNOPSIS
    Performs a full IIS reset and verifies the W3SVC service is running afterwards.
.DESCRIPTION
    Executes iisreset /restart, then checks that the World Wide Web Publishing Service
    (W3SVC) is in a Running state.
.PARAMETER VMName
    Name of the virtual machine.
.PARAMETER ResourceGroup
    Azure Resource Group the VM belongs to.
.PARAMETER AppPoolName
    Included for interface consistency; not used by this runbook.
#>
param(
    [Parameter(Mandatory = $true)]
    [string]$VMName,

    [Parameter(Mandatory = $true)]
    [string]$ResourceGroup,

    [Parameter(Mandatory = $false)]
    [string]$AppPoolName = "DefaultAppPool"
)

$result = @{
    Success      = $false
    Action       = "RestartIIS"
    Detail       = ""
    ErrorMessage = ""
}

try {
    Write-Output "[$VMName/$ResourceGroup] Initiating full IIS restart."

    # Run iisreset and capture output
    $iisResetOutput = & iisreset /restart 2>&1
    $exitCode = $LASTEXITCODE
    $outputText = ($iisResetOutput | Out-String).Trim()

    Write-Output "iisreset output:`n$outputText"
    Write-Output "iisreset exit code: $exitCode"

    if ($exitCode -ne 0) {
        $result.Detail       = "iisreset exited with code $exitCode. Output: $outputText"
        $result.ErrorMessage = $result.Detail
        Write-Output "FAILURE: $($result.Detail)"
    }
    else {
        Write-Output "iisreset completed successfully. Verifying W3SVC service state."

        # Allow a moment for the service to stabilise
        Start-Sleep -Seconds 3

        $svc = Get-Service -Name W3SVC -ErrorAction Stop
        Write-Output "W3SVC service status: $($svc.Status)"

        if ($svc.Status -eq 'Running') {
            $result.Success = $true
            $result.Detail  = "IIS restarted via iisreset. W3SVC confirmed Running."
            Write-Output $result.Detail
        }
        else {
            $result.Detail       = "iisreset succeeded but W3SVC is not Running (status: $($svc.Status))."
            $result.ErrorMessage = $result.Detail
            Write-Output "FAILURE: $($result.Detail)"
        }
    }
}
catch {
    $result.ErrorMessage = $_.Exception.Message
    $result.Detail       = "Exception during IIS restart: $($_.Exception.Message)"
    Write-Output "ERROR: $($result.Detail)"
}

Write-Output "Runbook complete. Success=$($result.Success)"
$result
