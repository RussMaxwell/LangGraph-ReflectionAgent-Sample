<#
.SYNOPSIS
    Resets ACL on C:\inetpub\wwwroot to grant IIS_IUSRS and IUSR read and execute access.
.DESCRIPTION
    Uses Get-Acl / Set-Acl with FileSystemAccessRule objects to ensure
    IIS_IUSRS and IUSR have ReadAndExecute, ListDirectory, and Read
    permissions on the wwwroot directory and all child objects.
    Runs as an Azure Automation runbook on a Hybrid Runbook Worker.
#>

param(
    [Parameter(Mandatory = $true)]
    [string]$VMName,

    [Parameter(Mandatory = $true)]
    [string]$ResourceGroup,

    [Parameter(Mandatory = $false)]
    [string]$AppPoolName = "DefaultAppPool"
)

$result = @{
    Success      = $false
    Action       = "FixPermissions"
    Detail       = ""
    ErrorMessage = ""
}

try {
    Write-Output "[$VMName] Starting FixPermissions runbook."
    Write-Output "[$VMName] Resource Group: $ResourceGroup | AppPool context: $AppPoolName"

    $targetPath = "C:\inetpub\wwwroot"

    if (-not (Test-Path -Path $targetPath)) {
        throw "Target path '$targetPath' does not exist."
    }

    Write-Output "[$VMName] Target path: $targetPath"

    # --- Get current ACL ---
    Write-Output "[$VMName] Retrieving current ACL..."
    $acl = Get-Acl -Path $targetPath -ErrorAction Stop

    Write-Output "[$VMName] Current ACL owner: $($acl.Owner)"
    Write-Output "[$VMName] Current access rules:"
    foreach ($rule in $acl.Access) {
        Write-Output "[$VMName]   Identity=$($rule.IdentityReference) Rights=$($rule.FileSystemRights) Type=$($rule.AccessControlType)"
    }

    # --- Define the accounts and permissions to grant ---
    $accounts = @(
        @{
            Identity = "BUILTIN\IIS_IUSRS"
            Rights   = @(
                [System.Security.AccessControl.FileSystemRights]::ReadAndExecute,
                [System.Security.AccessControl.FileSystemRights]::ListDirectory,
                [System.Security.AccessControl.FileSystemRights]::Read
            )
        },
        @{
            Identity = "IUSR"
            Rights   = @(
                [System.Security.AccessControl.FileSystemRights]::ReadAndExecute,
                [System.Security.AccessControl.FileSystemRights]::ListDirectory,
                [System.Security.AccessControl.FileSystemRights]::Read
            )
        }
    )

    $changesApplied = @()

    foreach ($account in $accounts) {
        $identity = $account.Identity
        Write-Output "[$VMName] Processing permissions for: $identity"

        # Combine the rights flags
        $combinedRights = [System.Security.AccessControl.FileSystemRights]::ReadAndExecute -bor `
                          [System.Security.AccessControl.FileSystemRights]::ListDirectory -bor `
                          [System.Security.AccessControl.FileSystemRights]::Read

        $inheritanceFlags = [System.Security.AccessControl.InheritanceFlags]::ContainerInherit -bor `
                            [System.Security.AccessControl.InheritanceFlags]::ObjectInherit
        $propagationFlags = [System.Security.AccessControl.PropagationFlags]::None
        $accessType       = [System.Security.AccessControl.AccessControlType]::Allow

        # Check if the rule already exists with the required rights
        $existingRule = $acl.Access | Where-Object {
            $_.IdentityReference.Value -eq $identity -and
            $_.AccessControlType -eq 'Allow' -and
            (($_.FileSystemRights -band $combinedRights) -eq $combinedRights)
        }

        if ($existingRule) {
            Write-Output "[$VMName]   $identity already has the required permissions. Skipping."
            $changesApplied += "$identity (already present)"
            continue
        }

        # Create and add the access rule
        $accessRule = New-Object System.Security.AccessControl.FileSystemAccessRule(
            $identity,
            $combinedRights,
            $inheritanceFlags,
            $propagationFlags,
            $accessType
        )

        $acl.AddAccessRule($accessRule)
        Write-Output "[$VMName]   Added access rule for $identity: ReadAndExecute, ListDirectory, Read (Allow, inherited by children)."
        $changesApplied += "$identity (added)"
    }

    # --- Apply the modified ACL ---
    Write-Output "[$VMName] Applying updated ACL to '$targetPath'..."
    Set-Acl -Path $targetPath -AclObject $acl -ErrorAction Stop
    Write-Output "[$VMName] ACL applied successfully."

    # --- Verify the ACL ---
    Write-Output "[$VMName] Verifying applied permissions..."
    $verifyAcl = Get-Acl -Path $targetPath -ErrorAction Stop

    $verificationPassed = $true
    $verificationDetails = @()

    foreach ($account in $accounts) {
        $identity = $account.Identity
        $combinedRights = [System.Security.AccessControl.FileSystemRights]::ReadAndExecute -bor `
                          [System.Security.AccessControl.FileSystemRights]::ListDirectory -bor `
                          [System.Security.AccessControl.FileSystemRights]::Read

        $verified = $verifyAcl.Access | Where-Object {
            $_.IdentityReference.Value -eq $identity -and
            $_.AccessControlType -eq 'Allow' -and
            (($_.FileSystemRights -band $combinedRights) -eq $combinedRights)
        }

        if ($verified) {
            Write-Output "[$VMName]   VERIFIED: $identity has required permissions."
            $verificationDetails += "$identity = OK"
        } else {
            Write-Output "[$VMName]   FAILED: $identity does NOT have required permissions after applying ACL."
            $verificationPassed = $false
            $verificationDetails += "$identity = MISSING"
        }
    }

    if (-not $verificationPassed) {
        throw "Post-apply verification failed. Details: $($verificationDetails -join ', ')"
    }

    $changeSummary = $changesApplied -join "; "
    $verifySummary = $verificationDetails -join "; "

    $result.Success = $true
    $result.Detail  = "Permissions fixed on '$targetPath'. Changes: $changeSummary. Verification: $verifySummary."

    Write-Output "[$VMName] FixPermissions completed successfully."

} catch {
    $result.Success      = $false
    $result.ErrorMessage = $_.Exception.Message
    Write-Output "[$VMName] ERROR during FixPermissions: $($_.Exception.Message)"
}

Write-Output "[$VMName] Runbook result: Success=$($result.Success) | Action=$($result.Action)"
Write-Output ($result | ConvertTo-Json -Depth 3)

return $result
