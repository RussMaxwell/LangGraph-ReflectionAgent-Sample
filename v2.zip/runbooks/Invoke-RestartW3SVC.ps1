<#
.SYNOPSIS
    Restarts the W3SVC (World Wide Web Publishing Service) on the target VM.
.DESCRIPTION
    Stops and restarts W3SVC with force, then verifies the service reaches
    a Running state. Designed to run as an Azure Automation runbook on a
    Hybrid Runbook Worker.
#>

param(
    [Parameter(Mandatory = $true)]
    [string]$VMName,

    [Parameter(Mandatory = $true)]
    [string]$ResourceGroup,

    [Parameter(Mandatory = $false)]
    [string]$AppPoolName = "DefaultAppPool"
)

$result = @{
    Success      = $false
    Action       = "RestartW3SVC"
    Detail       = ""
    ErrorMessage = ""
}

try {
    Write-Output "[$VMName] Starting W3SVC restart runbook."
    Write-Output "[$VMName] Resource Group: $ResourceGroup | AppPool context: $AppPoolName"

    # --- Check current service state ---
    $svcBefore = Get-Service -Name W3SVC -ErrorAction Stop
    Write-Output "[$VMName] W3SVC current status: $($svcBefore.Status)"

    # --- Stop W3SVC ---
    Write-Output "[$VMName] Stopping W3SVC with -Force..."
    Stop-Service -Name W3SVC -Force -ErrorAction Stop
    Write-Output "[$VMName] Stop-Service command completed."

    # Wait briefly for the service to fully stop
    $stopTimeout = 30
    $stopwatch = [System.Diagnostics.Stopwatch]::StartNew()
    while ((Get-Service -Name W3SVC).Status -ne 'Stopped' -and $stopwatch.Elapsed.TotalSeconds -lt $stopTimeout) {
        Start-Sleep -Seconds 1
    }
    $stopwatch.Stop()

    $svcAfterStop = Get-Service -Name W3SVC -ErrorAction Stop
    if ($svcAfterStop.Status -ne 'Stopped') {
        throw "W3SVC did not reach Stopped state within $stopTimeout seconds. Current state: $($svcAfterStop.Status)"
    }
    Write-Output "[$VMName] W3SVC stopped successfully in $([math]::Round($stopwatch.Elapsed.TotalSeconds, 1))s."

    # --- Start W3SVC ---
    Write-Output "[$VMName] Starting W3SVC..."
    Start-Service -Name W3SVC -ErrorAction Stop
    Write-Output "[$VMName] Start-Service command completed."

    # Wait for the service to reach Running state
    $startTimeout = 30
    $stopwatch = [System.Diagnostics.Stopwatch]::StartNew()
    while ((Get-Service -Name W3SVC).Status -ne 'Running' -and $stopwatch.Elapsed.TotalSeconds -lt $startTimeout) {
        Start-Sleep -Seconds 1
    }
    $stopwatch.Stop()

    # --- Verify Running state ---
    $svcAfterStart = Get-Service -Name W3SVC -ErrorAction Stop
    if ($svcAfterStart.Status -ne 'Running') {
        throw "W3SVC did not reach Running state within $startTimeout seconds. Current state: $($svcAfterStart.Status)"
    }

    $totalTime = [math]::Round($stopwatch.Elapsed.TotalSeconds, 1)
    Write-Output "[$VMName] W3SVC is now Running. Restart completed in ${totalTime}s."

    $result.Success = $true
    $result.Detail  = "W3SVC restarted successfully. Service confirmed Running after ${totalTime}s."

} catch {
    $result.Success      = $false
    $result.ErrorMessage = $_.Exception.Message
    Write-Output "[$VMName] ERROR during W3SVC restart: $($_.Exception.Message)"
}

Write-Output "[$VMName] Runbook result: Success=$($result.Success) | Action=$($result.Action)"
Write-Output ($result | ConvertTo-Json -Depth 3)

return $result
