<#
.SYNOPSIS
    Resets an IIS application pool to use the built-in ApplicationPoolIdentity and verifies it starts.
.DESCRIPTION
    Sets the processModel identityType to ApplicationPoolIdentity (numeric value 4),
    clears any stored userName and password, recycles the pool, and confirms it
    reaches the Started state.
.PARAMETER VMName
    Name of the virtual machine.
.PARAMETER ResourceGroup
    Azure Resource Group the VM belongs to.
.PARAMETER AppPoolName
    IIS application pool to fix. Defaults to DefaultAppPool.
#>
param(
    [Parameter(Mandatory = $true)]
    [string]$VMName,

    [Parameter(Mandatory = $true)]
    [string]$ResourceGroup,

    [Parameter(Mandatory = $false)]
    [string]$AppPoolName = "DefaultAppPool"
)

$result = @{
    Success      = $false
    Action       = "FixAppPoolIdentity"
    Detail       = ""
    ErrorMessage = ""
}

try {
    Write-Output "[$VMName/$ResourceGroup] Fixing identity for app pool '$AppPoolName'."

    Import-Module WebAdministration -ErrorAction Stop
    Write-Output "WebAdministration module loaded."

    # Verify the pool exists
    $poolPath = "IIS:\AppPools\$AppPoolName"
    $pool = Get-Item $poolPath -ErrorAction Stop
    $currentIdentity = (Get-ItemProperty $poolPath -Name processModel.identityType -ErrorAction Stop).Value
    Write-Output "Current identityType for '$AppPoolName': $currentIdentity"

    # Set identityType to ApplicationPoolIdentity (4)
    Set-ItemProperty $poolPath -Name processModel.identityType -Value 4 -ErrorAction Stop
    Write-Output "identityType set to ApplicationPoolIdentity (4)."

    # Clear userName and password
    Set-ItemProperty $poolPath -Name processModel.userName -Value "" -ErrorAction Stop
    Set-ItemProperty $poolPath -Name processModel.password -Value "" -ErrorAction Stop
    Write-Output "userName and password fields cleared."

    # Recycle the pool to apply changes
    Restart-WebAppPool -Name $AppPoolName -ErrorAction Stop
    Write-Output "App pool '$AppPoolName' recycled."

    # Wait for the pool to start (up to 30 seconds, poll every 2 seconds)
    $maxWaitSeconds = 30
    $pollIntervalSeconds = 2
    $elapsed = 0
    $started = $false

    while ($elapsed -lt $maxWaitSeconds) {
        Start-Sleep -Seconds $pollIntervalSeconds
        $elapsed += $pollIntervalSeconds

        $state = (Get-WebAppPoolState -Name $AppPoolName -ErrorAction Stop).Value
        Write-Output "Poll at ${elapsed}s — pool state: $state."

        if ($state -eq "Started") {
            $started = $true
            break
        }
    }

    if ($started) {
        $result.Success = $true
        $result.Detail  = "App pool '$AppPoolName' identity reset to ApplicationPoolIdentity. Pool confirmed Started after ${elapsed}s."
        Write-Output $result.Detail
    }
    else {
        $finalState = (Get-WebAppPoolState -Name $AppPoolName -ErrorAction SilentlyContinue).Value
        $result.Detail       = "Identity was updated but pool did not reach Started state within ${maxWaitSeconds}s. Last state: $finalState."
        $result.ErrorMessage = $result.Detail
        Write-Output "FAILURE: $($result.Detail)"
    }
}
catch {
    $result.ErrorMessage = $_.Exception.Message
    $result.Detail       = "Exception during identity fix: $($_.Exception.Message)"
    Write-Output "ERROR: $($result.Detail)"
}

Write-Output "Runbook complete. Success=$($result.Success)"
$result
