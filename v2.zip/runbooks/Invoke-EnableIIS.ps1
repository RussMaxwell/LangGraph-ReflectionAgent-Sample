<#
.SYNOPSIS
    Ensures IIS is installed and the W3SVC service is running.
.DESCRIPTION
    Installs the Web-Server Windows feature (with management tools) if not already present,
    then starts the W3SVC service and confirms it is Running.
.PARAMETER VMName
    Name of the virtual machine.
.PARAMETER ResourceGroup
    Azure Resource Group the VM belongs to.
.PARAMETER AppPoolName
    Included for interface consistency; not used by this runbook.
#>
param(
    [Parameter(Mandatory = $true)]
    [string]$VMName,

    [Parameter(Mandatory = $true)]
    [string]$ResourceGroup,

    [Parameter(Mandatory = $false)]
    [string]$AppPoolName = "DefaultAppPool"
)

$result = @{
    Success      = $false
    Action       = "EnableIIS"
    Detail       = ""
    ErrorMessage = ""
}

try {
    Write-Output "[$VMName/$ResourceGroup] Ensuring IIS (Web-Server) feature is installed."

    # Install the feature — this is idempotent; if already installed it returns quickly
    $featureResult = Install-WindowsFeature -Name Web-Server -IncludeManagementTools -ErrorAction Stop
    if ($featureResult.RestartNeeded -eq 'Yes') {
        Write-Output "WARNING: A server restart is required to complete IIS installation."
    }

    if ($featureResult.Success) {
        Write-Output "Install-WindowsFeature succeeded. ExitCode: $($featureResult.ExitCode). RestartNeeded: $($featureResult.RestartNeeded)."
    }
    else {
        $result.Detail       = "Install-WindowsFeature reported failure. ExitCode: $($featureResult.ExitCode)."
        $result.ErrorMessage = $result.Detail
        Write-Output "FAILURE: $($result.Detail)"
        Write-Output "Runbook complete. Success=$($result.Success)"
        return $result
    }

    # Ensure W3SVC is running
    $svc = Get-Service -Name W3SVC -ErrorAction Stop
    Write-Output "W3SVC current status: $($svc.Status)."

    if ($svc.Status -ne 'Running') {
        Write-Output "Starting W3SVC service."
        Start-Service -Name W3SVC -ErrorAction Stop

        # Wait briefly for the service to reach Running state
        $svc.WaitForStatus('Running', [TimeSpan]::FromSeconds(30))
        $svc.Refresh()
        Write-Output "W3SVC status after start attempt: $($svc.Status)."
    }

    if ($svc.Status -eq 'Running') {
        $result.Success = $true
        $result.Detail  = "IIS feature installed/confirmed. W3SVC is Running."
        Write-Output $result.Detail
    }
    else {
        $result.Detail       = "W3SVC is not Running after start attempt (status: $($svc.Status))."
        $result.ErrorMessage = $result.Detail
        Write-Output "FAILURE: $($result.Detail)"
    }
}
catch {
    $result.ErrorMessage = $_.Exception.Message
    $result.Detail       = "Exception during IIS enablement: $($_.Exception.Message)"
    Write-Output "ERROR: $($result.Detail)"
}

Write-Output "Runbook complete. Success=$($result.Success)"
$result
