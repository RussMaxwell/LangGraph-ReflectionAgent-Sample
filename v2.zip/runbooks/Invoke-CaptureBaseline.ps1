<#
.SYNOPSIS
    Wrapper runbook that executes the baseline capture script on a Hybrid Runbook Worker.
.DESCRIPTION
    Invokes the baseline capture script at C:\iis-autohealing\baseline\run_baseline.ps1
    on the local VM. Streams progress to the Automation job output every 5 minutes.
    Returns a structured result with baseline summary upon completion.
    Runs as an Azure Automation runbook on a Hybrid Runbook Worker.
#>

param(
    [Parameter(Mandatory = $true)]
    [string]$VMName,

    [Parameter(Mandatory = $true)]
    [string]$ResourceGroup,

    [Parameter(Mandatory = $false)]
    [string]$AppPoolName = "DefaultAppPool",

    [Parameter(Mandatory = $false)]
    [int]$DurationMinutes = 60,

    [Parameter(Mandatory = $false)]
    [int]$VirtualUsers = 0,

    [Parameter(Mandatory = $false)]
    [string]$EventHubNamespace = ""
)

$result = @{
    Success      = $false
    Action       = "CaptureBaseline"
    Detail       = ""
    ErrorMessage = ""
}

try {
    Write-Output "[$VMName] Starting CaptureBaseline runbook."
    Write-Output "[$VMName] Resource Group: $ResourceGroup | AppPool: $AppPoolName"
    Write-Output "[$VMName] Duration: $DurationMinutes minutes | Virtual Users: $VirtualUsers"

    $baselineScript = "C:\iis-autohealing\baseline\run_baseline.ps1"

    # --- Locate the baseline script ---
    if (-not (Test-Path -Path $baselineScript)) {
        Write-Output "[$VMName] Baseline script not found at: $baselineScript"
        Write-Output "[$VMName] Searching for run_baseline.ps1 on the system..."

        $searchPaths = @(
            "C:\iis-autohealing",
            "C:\Projects\workIIS\iis-autohealing",
            "C:\Program Files\iis-autohealing",
            "C:\Scripts",
            "D:\iis-autohealing"
        )

        $foundScript = $null
        foreach ($searchPath in $searchPaths) {
            if (Test-Path -Path $searchPath) {
                $candidates = Get-ChildItem -Path $searchPath -Recurse -Filter "run_baseline.ps1" -ErrorAction SilentlyContinue
                if ($candidates) {
                    $foundScript = $candidates[0].FullName
                    Write-Output "[$VMName] Found baseline script at: $foundScript"
                    break
                }
            }
        }

        if (-not $foundScript) {
            throw "Baseline script 'run_baseline.ps1' not found at expected path '$baselineScript' or any searched location. Searched: $($searchPaths -join ', '). Ensure the baseline module is deployed to the VM."
        }

        $baselineScript = $foundScript
    }

    Write-Output "[$VMName] Using baseline script: $baselineScript"

    # --- Launch the baseline script as a background job ---
    Write-Output "[$VMName] Launching baseline capture job (Duration=${DurationMinutes}m, Users=${VirtualUsers})..."

    $scriptBlock = [scriptblock]::Create(
        "& '$baselineScript' -DurationMinutes $DurationMinutes -VirtualUsers $VirtualUsers -EventHubNamespace '$EventHubNamespace'"
    )

    $job = Start-Job -ScriptBlock $scriptBlock -ErrorAction Stop
    Write-Output "[$VMName] Baseline job started: JobId=$($job.Id), JobState=$($job.State)"

    # --- Stream progress every 5 minutes ---
    $progressIntervalSec = 300
    $totalTimeoutSec = ($DurationMinutes + 15) * 60  # Allow 15 extra minutes for overhead
    $elapsed = [System.Diagnostics.Stopwatch]::StartNew()
    $lastProgressCheck = [System.Diagnostics.Stopwatch]::StartNew()

    while ($job.State -eq 'Running' -and $elapsed.Elapsed.TotalSeconds -lt $totalTimeoutSec) {

        # Emit progress every 5 minutes
        if ($lastProgressCheck.Elapsed.TotalSeconds -ge $progressIntervalSec) {
            $elapsedMin = [math]::Round($elapsed.Elapsed.TotalMinutes, 1)
            $pctEstimate = [math]::Min(100, [math]::Round(($elapsed.Elapsed.TotalMinutes / $DurationMinutes) * 100, 0))
            Write-Output "[$VMName] Baseline progress: ${elapsedMin}m elapsed (~${pctEstimate}% of ${DurationMinutes}m). Job state: $($job.State)"

            # Collect any partial output from the job
            $partialOutput = Receive-Job -Job $job -Keep -ErrorAction SilentlyContinue
            if ($partialOutput) {
                $recentLines = $partialOutput | Select-Object -Last 3
                foreach ($line in $recentLines) {
                    Write-Output "[$VMName]   [baseline] $line"
                }
            }

            $lastProgressCheck.Restart()
        }

        Start-Sleep -Seconds 10
    }

    $elapsed.Stop()
    $totalElapsedMin = [math]::Round($elapsed.Elapsed.TotalMinutes, 1)

    # --- Check if the job timed out ---
    if ($job.State -eq 'Running') {
        Write-Output "[$VMName] WARNING: Baseline job exceeded timeout of $totalTimeoutSec seconds. Stopping job..."
        Stop-Job -Job $job -ErrorAction SilentlyContinue
        $jobTimedOut = $true
    } else {
        $jobTimedOut = $false
    }

    # --- Collect final output ---
    Write-Output "[$VMName] Collecting baseline job output..."
    $jobOutput = Receive-Job -Job $job -ErrorAction SilentlyContinue

    if ($jobOutput) {
        Write-Output "[$VMName] Baseline job output ($($jobOutput.Count) line(s)):"
        foreach ($line in $jobOutput) {
            Write-Output "[$VMName]   [baseline] $line"
        }
    } else {
        Write-Output "[$VMName] No output received from baseline job."
    }

    # --- Check job completion status ---
    $finalState = $job.State
    Write-Output "[$VMName] Baseline job final state: $finalState (ran for ${totalElapsedMin}m)"

    if ($job.State -eq 'Failed') {
        $jobError = $job.ChildJobs[0].JobStateInfo.Reason.Message
        if (-not $jobError) { $jobError = "Unknown job failure" }
        Remove-Job -Job $job -Force -ErrorAction SilentlyContinue
        throw "Baseline capture job failed: $jobError"
    }

    if ($jobTimedOut) {
        Remove-Job -Job $job -Force -ErrorAction SilentlyContinue
        throw "Baseline capture job timed out after ${totalElapsedMin} minutes (limit was $([math]::Round($totalTimeoutSec / 60, 0))m)."
    }

    Remove-Job -Job $job -Force -ErrorAction SilentlyContinue

    # --- Build baseline summary ---
    $baselineSummary = @{
        VMName          = $VMName
        AppPoolName     = $AppPoolName
        DurationMinutes = $DurationMinutes
        VirtualUsers    = $VirtualUsers
        ElapsedMinutes  = $totalElapsedMin
        JobState        = $finalState
        OutputLines     = if ($jobOutput) { $jobOutput.Count } else { 0 }
        CompletedAt     = (Get-Date -Format "yyyy-MM-dd HH:mm:ss UTC" )
    }

    # Try to parse structured data from the last lines of output (if the baseline script returns JSON)
    if ($jobOutput) {
        $lastLine = ($jobOutput | Select-Object -Last 1) -as [string]
        try {
            $parsedResult = $lastLine | ConvertFrom-Json -ErrorAction Stop
            if ($parsedResult) {
                $baselineSummary['ParsedResult'] = $parsedResult
                Write-Output "[$VMName] Successfully parsed structured baseline result from job output."
            }
        } catch {
            Write-Output "[$VMName] Job output is not JSON-structured. Raw output preserved."
            $baselineSummary['RawOutputTail'] = ($jobOutput | Select-Object -Last 5) -join "`n"
        }
    }

    Write-Output "[$VMName] Baseline summary:"
    Write-Output ($baselineSummary | ConvertTo-Json -Depth 5)

    $result.Success = $true
    $result.Detail  = "Baseline capture completed in ${totalElapsedMin}m. Duration=${DurationMinutes}m, VirtualUsers=${VirtualUsers}, JobState=$finalState, OutputLines=$($baselineSummary.OutputLines)."

    Write-Output "[$VMName] CaptureBaseline runbook completed successfully."

} catch {
    $result.Success      = $false
    $result.ErrorMessage = $_.Exception.Message
    Write-Output "[$VMName] ERROR during CaptureBaseline: $($_.Exception.Message)"
}

Write-Output "[$VMName] Runbook result: Success=$($result.Success) | Action=$($result.Action)"
Write-Output ($result | ConvertTo-Json -Depth 3)

return $result
