<#
.SYNOPSIS
    Clears the ASP.NET Temporary Files cache for both Framework64 and Framework paths.
.DESCRIPTION
    Recursively removes all files from the Temporary ASP.NET Files directories
    for .NET Framework 4.0 (both 64-bit and 32-bit). Recycles the specified
    application pool after clearing the cache. Returns the total bytes freed.
    Runs as an Azure Automation runbook on a Hybrid Runbook Worker.
#>

param(
    [Parameter(Mandatory = $true)]
    [string]$VMName,

    [Parameter(Mandatory = $true)]
    [string]$ResourceGroup,

    [Parameter(Mandatory = $false)]
    [string]$AppPoolName = "DefaultAppPool"
)

$result = @{
    Success      = $false
    Action       = "ClearASPNETCache"
    Detail       = ""
    ErrorMessage = ""
}

try {
    Write-Output "[$VMName] Starting ClearASPNETCache runbook."
    Write-Output "[$VMName] Resource Group: $ResourceGroup | AppPool: $AppPoolName"

    $totalBytesFreed = 0
    $pathsCleared = @()

    $cachePaths = @(
        "C:\Windows\Microsoft.NET\Framework64\v4.0.30319\Temporary ASP.NET Files",
        "C:\Windows\Microsoft.NET\Framework\v4.0.30319\Temporary ASP.NET Files"
    )

    foreach ($cachePath in $cachePaths) {
        Write-Output "[$VMName] Processing cache path: $cachePath"

        if (-not (Test-Path -Path $cachePath)) {
            Write-Output "[$VMName]   Path does not exist. Skipping."
            continue
        }

        # Calculate size before deletion
        $items = Get-ChildItem -Path $cachePath -Recurse -Force -ErrorAction SilentlyContinue
        $fileItems = $items | Where-Object { -not $_.PSIsContainer }
        $pathBytes = ($fileItems | Measure-Object -Property Length -Sum).Sum
        if ($null -eq $pathBytes) { $pathBytes = 0 }
        $fileCount = ($fileItems | Measure-Object).Count

        Write-Output "[$VMName]   Found $fileCount file(s) totaling $([math]::Round($pathBytes / 1MB, 2)) MB."

        if ($fileCount -eq 0) {
            Write-Output "[$VMName]   Cache is already empty. Skipping."
            $pathsCleared += "$cachePath (already empty)"
            continue
        }

        # Remove all contents recursively
        Write-Output "[$VMName]   Removing all files and subdirectories..."
        $errors = @()
        Get-ChildItem -Path $cachePath -Force -ErrorAction SilentlyContinue | ForEach-Object {
            try {
                Remove-Item -Path $_.FullName -Recurse -Force -ErrorAction Stop
            } catch {
                $errors += $_.Exception.Message
            }
        }

        if ($errors.Count -gt 0) {
            Write-Output "[$VMName]   WARNING: $($errors.Count) item(s) could not be removed (may be locked)."
            foreach ($err in $errors) {
                Write-Output "[$VMName]     - $err"
            }
        }

        # Verify what remains
        $remaining = Get-ChildItem -Path $cachePath -Recurse -Force -ErrorAction SilentlyContinue
        $remainingFiles = ($remaining | Where-Object { -not $_.PSIsContainer } | Measure-Object).Count
        $removedBytes = $pathBytes - (($remaining | Where-Object { -not $_.PSIsContainer } | Measure-Object -Property Length -Sum).Sum)
        if ($null -eq $removedBytes -or $removedBytes -lt 0) { $removedBytes = $pathBytes }

        $totalBytesFreed += $removedBytes
        $pathsCleared += "$cachePath ($([math]::Round($removedBytes / 1MB, 2)) MB freed, $remainingFiles file(s) remaining)"

        Write-Output "[$VMName]   Freed $([math]::Round($removedBytes / 1MB, 2)) MB from $cachePath. $remainingFiles file(s) could not be removed."
    }

    # --- Recycle the application pool ---
    Write-Output "[$VMName] Importing WebAdministration module for app pool recycle..."
    Import-Module WebAdministration -ErrorAction Stop

    Write-Output "[$VMName] Recycling application pool '$AppPoolName'..."
    $poolState = Get-WebAppPoolState -Name $AppPoolName -ErrorAction Stop
    Write-Output "[$VMName] App pool '$AppPoolName' current state: $($poolState.Value)"

    if ($poolState.Value -eq 'Started') {
        Restart-WebAppPool -Name $AppPoolName -ErrorAction Stop
        Write-Output "[$VMName] App pool '$AppPoolName' recycled successfully."
    } elseif ($poolState.Value -eq 'Stopped') {
        Start-WebAppPool -Name $AppPoolName -ErrorAction Stop
        Write-Output "[$VMName] App pool '$AppPoolName' was stopped; started it."
    } else {
        Write-Output "[$VMName] App pool '$AppPoolName' is in state '$($poolState.Value)'. Attempting restart..."
        Stop-WebAppPool -Name $AppPoolName -ErrorAction SilentlyContinue
        Start-Sleep -Seconds 2
        Start-WebAppPool -Name $AppPoolName -ErrorAction Stop
        Write-Output "[$VMName] App pool '$AppPoolName' restarted from intermediate state."
    }

    $totalMBFreed = [math]::Round($totalBytesFreed / 1MB, 2)
    $pathSummary = $pathsCleared -join "; "

    $result.Success = $true
    $result.Detail  = "Cleared ASP.NET cache. Total freed: ${totalMBFreed} MB. Paths: $pathSummary. App pool '$AppPoolName' recycled."

    Write-Output "[$VMName] Cache clear complete. Total bytes freed: $totalBytesFreed ($totalMBFreed MB)."

} catch {
    $result.Success      = $false
    $result.ErrorMessage = $_.Exception.Message
    Write-Output "[$VMName] ERROR during ClearASPNETCache: $($_.Exception.Message)"
}

Write-Output "[$VMName] Runbook result: Success=$($result.Success) | Action=$($result.Action)"
Write-Output ($result | ConvertTo-Json -Depth 3)

return $result
