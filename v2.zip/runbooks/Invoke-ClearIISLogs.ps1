<#
.SYNOPSIS
    Removes IIS log files older than 7 days and any chaos_fill.dat file to free disk space.
.DESCRIPTION
    Scans C:\inetpub\logs\LogFiles\ recursively for files older than 7 days and deletes
    them.  Also removes chaos_fill.dat if present anywhere under the logs directory.
    Reports total gigabytes freed in the Detail field.
.PARAMETER VMName
    Name of the virtual machine.
.PARAMETER ResourceGroup
    Azure Resource Group the VM belongs to.
.PARAMETER AppPoolName
    Included for interface consistency; not used by this runbook.
#>
param(
    [Parameter(Mandatory = $true)]
    [string]$VMName,

    [Parameter(Mandatory = $true)]
    [string]$ResourceGroup,

    [Parameter(Mandatory = $false)]
    [string]$AppPoolName = "DefaultAppPool"
)

$result = @{
    Success      = $false
    Action       = "ClearIISLogs"
    Detail       = ""
    ErrorMessage = ""
}

try {
    $logRoot = "C:\inetpub\logs\LogFiles"
    Write-Output "[$VMName/$ResourceGroup] Clearing IIS logs older than 7 days from $logRoot."

    if (-not (Test-Path $logRoot)) {
        $result.Detail       = "Log directory '$logRoot' does not exist. Nothing to clean."
        $result.ErrorMessage = $result.Detail
        Write-Output "WARNING: $($result.Detail)"
        # Treat missing dir as non-fatal success — there is nothing to clean
        $result.Success = $true
        Write-Output "Runbook complete. Success=$($result.Success)"
        return $result
    }

    $totalBytesFreed = [long]0
    $filesDeleted    = 0
    $cutoffDate      = (Get-Date).AddDays(-7)

    # --- Delete log files older than 7 days ---
    $oldFiles = Get-ChildItem -Path $logRoot -Recurse -File -ErrorAction Stop |
                Where-Object { $_.LastWriteTime -lt $cutoffDate }

    foreach ($file in $oldFiles) {
        try {
            $size = $file.Length
            Remove-Item -Path $file.FullName -Force -ErrorAction Stop
            $totalBytesFreed += $size
            $filesDeleted++
        }
        catch {
            Write-Output "Could not delete '$($file.FullName)': $($_.Exception.Message)"
        }
    }

    Write-Output "Deleted $filesDeleted log file(s) older than 7 days."

    # --- Delete chaos_fill.dat if it exists anywhere under the log root ---
    $chaosFiles = Get-ChildItem -Path $logRoot -Recurse -File -Filter "chaos_fill.dat" -ErrorAction SilentlyContinue
    foreach ($chaos in $chaosFiles) {
        try {
            $size = $chaos.Length
            Remove-Item -Path $chaos.FullName -Force -ErrorAction Stop
            $totalBytesFreed += $size
            $filesDeleted++
            Write-Output "Removed chaos_fill.dat at '$($chaos.FullName)' ($([math]::Round($size / 1MB, 2)) MB)."
        }
        catch {
            Write-Output "Could not delete chaos_fill.dat '$($chaos.FullName)': $($_.Exception.Message)"
        }
    }

    # Also check common root locations for chaos_fill.dat
    $commonChaosPaths = @(
        "C:\inetpub\logs\chaos_fill.dat",
        "C:\chaos_fill.dat"
    )
    foreach ($path in $commonChaosPaths) {
        if (Test-Path $path) {
            try {
                $size = (Get-Item $path -ErrorAction Stop).Length
                Remove-Item -Path $path -Force -ErrorAction Stop
                $totalBytesFreed += $size
                $filesDeleted++
                Write-Output "Removed chaos_fill.dat at '$path' ($([math]::Round($size / 1MB, 2)) MB)."
            }
            catch {
                Write-Output "Could not delete '$path': $($_.Exception.Message)"
            }
        }
    }

    $gbFreed = [math]::Round($totalBytesFreed / 1GB, 3)
    $result.Success = $true
    $result.Detail  = "Freed ${gbFreed} GB by deleting $filesDeleted file(s)."
    Write-Output $result.Detail
}
catch {
    $result.ErrorMessage = $_.Exception.Message
    $result.Detail       = "Exception during log cleanup: $($_.Exception.Message)"
    Write-Output "ERROR: $($result.Detail)"
}

Write-Output "Runbook complete. Success=$($result.Success)"
$result
