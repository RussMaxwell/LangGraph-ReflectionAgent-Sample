<#
.SYNOPSIS
    Ensures the Default Web Site has an HTTP binding on port 80.
.DESCRIPTION
    Imports WebAdministration, checks whether the Default Web Site already
    has an HTTP :80 binding. If missing, creates one. Verifies the binding
    exists after the fix. Runs as an Azure Automation runbook on a Hybrid
    Runbook Worker.
#>

param(
    [Parameter(Mandatory = $true)]
    [string]$VMName,

    [Parameter(Mandatory = $true)]
    [string]$ResourceGroup,

    [Parameter(Mandatory = $false)]
    [string]$AppPoolName = "DefaultAppPool"
)

$result = @{
    Success      = $false
    Action       = "FixBindings"
    Detail       = ""
    ErrorMessage = ""
}

try {
    Write-Output "[$VMName] Starting FixBindings runbook."
    Write-Output "[$VMName] Resource Group: $ResourceGroup | AppPool context: $AppPoolName"

    # --- Import WebAdministration module ---
    Write-Output "[$VMName] Importing WebAdministration module..."
    Import-Module WebAdministration -ErrorAction Stop
    Write-Output "[$VMName] WebAdministration module loaded."

    $siteName = "Default Web Site"

    # --- Check existing bindings ---
    Write-Output "[$VMName] Retrieving bindings for '$siteName'..."
    $bindings = Get-WebBinding -Name $siteName -ErrorAction Stop
    Write-Output "[$VMName] Found $($bindings.Count) binding(s) on '$siteName'."

    foreach ($b in $bindings) {
        Write-Output "[$VMName]   Binding: Protocol=$($b.protocol) BindingInfo=$($b.bindingInformation)"
    }

    # Look for an HTTP binding on port 80 (any IP)
    $httpBinding = $bindings | Where-Object {
        $_.protocol -eq 'http' -and $_.bindingInformation -match ':80:'
    }

    if ($httpBinding) {
        Write-Output "[$VMName] HTTP :80 binding already exists. No action needed."
        $result.Success = $true
        $result.Detail  = "HTTP port 80 binding already present on '$siteName'. No changes made."
    } else {
        Write-Output "[$VMName] HTTP :80 binding is MISSING. Adding binding..."

        New-WebBinding -Name $siteName -Protocol http -Port 80 -IPAddress "*" -ErrorAction Stop
        Write-Output "[$VMName] New-WebBinding command completed."

        # --- Verify the binding was created ---
        Write-Output "[$VMName] Verifying binding was created..."
        $verifyBindings = Get-WebBinding -Name $siteName -ErrorAction Stop
        $verifyHttp = $verifyBindings | Where-Object {
            $_.protocol -eq 'http' -and $_.bindingInformation -match ':80:'
        }

        if ($verifyHttp) {
            Write-Output "[$VMName] Verification passed: HTTP :80 binding now exists."
            $result.Success = $true
            $result.Detail  = "HTTP port 80 binding was missing and has been added to '$siteName'. Verified successfully."
        } else {
            throw "Binding was added but verification failed. HTTP :80 binding not found after creation."
        }
    }

} catch {
    $result.Success      = $false
    $result.ErrorMessage = $_.Exception.Message
    Write-Output "[$VMName] ERROR during FixBindings: $($_.Exception.Message)"
}

Write-Output "[$VMName] Runbook result: Success=$($result.Success) | Action=$($result.Action)"
Write-Output ($result | ConvertTo-Json -Depth 3)

return $result
