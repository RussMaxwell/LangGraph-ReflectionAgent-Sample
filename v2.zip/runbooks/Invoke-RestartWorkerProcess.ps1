<#
.SYNOPSIS
    Kills all w3wp.exe worker processes and waits for the app pool to spawn a new one.
.DESCRIPTION
    Finds all running w3wp.exe processes, terminates them, then waits up to
    30 seconds for IIS to automatically restart a new worker process for the
    specified application pool. Verifies a new w3wp.exe process exists.
    Runs as an Azure Automation runbook on a Hybrid Runbook Worker.
#>

param(
    [Parameter(Mandatory = $true)]
    [string]$VMName,

    [Parameter(Mandatory = $true)]
    [string]$ResourceGroup,

    [Parameter(Mandatory = $false)]
    [string]$AppPoolName = "DefaultAppPool"
)

$result = @{
    Success      = $false
    Action       = "RestartWorkerProcess"
    Detail       = ""
    ErrorMessage = ""
}

try {
    Write-Output "[$VMName] Starting RestartWorkerProcess runbook."
    Write-Output "[$VMName] Resource Group: $ResourceGroup | AppPool: $AppPoolName"

    # --- Find existing w3wp.exe processes ---
    $existingProcesses = Get-Process -Name w3wp -ErrorAction SilentlyContinue
    $existingPIDs = @()

    if ($existingProcesses) {
        $existingPIDs = $existingProcesses | ForEach-Object { $_.Id }
        Write-Output "[$VMName] Found $($existingProcesses.Count) existing w3wp.exe process(es): PIDs $($existingPIDs -join ', ')"
    } else {
        Write-Output "[$VMName] No existing w3wp.exe processes found."
    }

    # --- Kill all w3wp.exe processes ---
    if ($existingProcesses) {
        Write-Output "[$VMName] Terminating all w3wp.exe processes..."
        foreach ($proc in $existingProcesses) {
            try {
                Write-Output "[$VMName]   Killing PID $($proc.Id) (WorkingSet: $([math]::Round($proc.WorkingSet64 / 1MB, 1)) MB)..."
                Stop-Process -Id $proc.Id -Force -ErrorAction Stop
                Write-Output "[$VMName]   PID $($proc.Id) terminated."
            } catch {
                Write-Output "[$VMName]   WARNING: Could not kill PID $($proc.Id): $($_.Exception.Message)"
            }
        }

        # Brief pause to let processes fully exit
        Start-Sleep -Seconds 2

        # Confirm old processes are gone
        $stillRunning = Get-Process -Name w3wp -ErrorAction SilentlyContinue | Where-Object { $existingPIDs -contains $_.Id }
        if ($stillRunning) {
            Write-Output "[$VMName] WARNING: $($stillRunning.Count) old w3wp.exe process(es) still running after kill attempt."
        } else {
            Write-Output "[$VMName] All old w3wp.exe processes terminated."
        }
    }

    # --- Ensure the app pool is started so IIS will spawn a new worker ---
    Write-Output "[$VMName] Importing WebAdministration module..."
    Import-Module WebAdministration -ErrorAction Stop

    $poolState = Get-WebAppPoolState -Name $AppPoolName -ErrorAction Stop
    Write-Output "[$VMName] App pool '$AppPoolName' state: $($poolState.Value)"

    if ($poolState.Value -ne 'Started') {
        Write-Output "[$VMName] Starting app pool '$AppPoolName'..."
        Start-WebAppPool -Name $AppPoolName -ErrorAction Stop
        Write-Output "[$VMName] App pool '$AppPoolName' started."
    }

    # --- Send a warm-up request to trigger worker process creation ---
    Write-Output "[$VMName] Sending warm-up request to localhost to trigger worker process spawn..."
    try {
        $null = Invoke-WebRequest -Uri "http://localhost/" -UseBasicParsing -TimeoutSec 10 -ErrorAction SilentlyContinue
    } catch {
        Write-Output "[$VMName] Warm-up request completed (response code or error is expected if site is restarting)."
    }

    # --- Wait up to 30 seconds for a new w3wp.exe process ---
    Write-Output "[$VMName] Waiting up to 30 seconds for a new w3wp.exe process..."
    $timeout = 30
    $stopwatch = [System.Diagnostics.Stopwatch]::StartNew()
    $newProcess = $null

    while ($stopwatch.Elapsed.TotalSeconds -lt $timeout) {
        $currentProcesses = Get-Process -Name w3wp -ErrorAction SilentlyContinue
        if ($currentProcesses) {
            # Look for a process with a PID not in the old list
            $newProcess = $currentProcesses | Where-Object { $existingPIDs -notcontains $_.Id } | Select-Object -First 1
            if ($newProcess) {
                break
            }
            # If all old PIDs are gone, any w3wp is a new one
            if (-not ($currentProcesses | Where-Object { $existingPIDs -contains $_.Id })) {
                $newProcess = $currentProcesses | Select-Object -First 1
                break
            }
        }
        Start-Sleep -Seconds 1
    }
    $stopwatch.Stop()
    $elapsedSec = [math]::Round($stopwatch.Elapsed.TotalSeconds, 1)

    # --- Verify ---
    if ($newProcess) {
        Write-Output "[$VMName] New w3wp.exe process detected: PID $($newProcess.Id) after ${elapsedSec}s."
        $result.Success = $true
        $result.Detail  = "Killed $($existingPIDs.Count) old w3wp.exe process(es). New worker PID $($newProcess.Id) started after ${elapsedSec}s for app pool '$AppPoolName'."
    } else {
        # Final check
        $finalCheck = Get-Process -Name w3wp -ErrorAction SilentlyContinue
        if ($finalCheck) {
            Write-Output "[$VMName] w3wp.exe process found on final check: PID $($finalCheck[0].Id)."
            $result.Success = $true
            $result.Detail  = "Killed $($existingPIDs.Count) old w3wp.exe process(es). Worker PID $($finalCheck[0].Id) found after ${elapsedSec}s."
        } else {
            throw "No new w3wp.exe process appeared within $timeout seconds after killing old workers."
        }
    }

    Write-Output "[$VMName] RestartWorkerProcess completed successfully."

} catch {
    $result.Success      = $false
    $result.ErrorMessage = $_.Exception.Message
    Write-Output "[$VMName] ERROR during RestartWorkerProcess: $($_.Exception.Message)"
}

Write-Output "[$VMName] Runbook result: Success=$($result.Success) | Action=$($result.Action)"
Write-Output ($result | ConvertTo-Json -Depth 3)

return $result
