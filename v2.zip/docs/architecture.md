# Architecture

This document describes the v2 deployment's end-to-end architecture: the Azure
components, how telemetry flows, the LangGraph healing pipeline, and two
worked-through scenarios showing the pipeline in action.

---

## 1. System components

```
                              ┌────────────────────────────────────────────────┐
                              │         Existing enterprise VNet              │
                              │  non-prod_vnet-openshift-for-card-service-...  │
                              │                                                │
          ┌────────────┐      │   ┌──────────────┐      ┌──────────────────┐  │
          │  Operator  │──────┼──▶│ vm-subnet    │      │ pe-subnet        │  │
          │ (portal /  │      │   │  ┌─────────┐ │      │  ┌─────────────┐ │  │
          │   az CLI)  │      │   │  │ IIS VM  │◀┼──────┼──│ Private     │ │  │
          └────────────┘      │   │  │  + HRW  │ │      │  │ endpoints:  │ │  │
                              │   │  └─────────┘ │      │  │  Automation │ │  │
                              │   └──────┬───────┘      │  │  FuncApp    │ │  │
                              │          │              │  │  Storage    │ │  │
                              │          ▼              │  │  AMPLS      │ │  │
          ┌────────────┐      │   ┌──────────────┐      │  │  EventHubs  │ │  │
          │ Azure Mon. │      │   │ fa-integ     │      │  │  ADX        │ │  │
          │   alerts   │──────┼──▶│ subnet       │─────▶│  │  OpenAI     │ │  │
          │ (+ webhook)│      │   │  (FA VNet    │      │  └─────────────┘ │  │
          └────────────┘      │   │   integ.)    │      │                  │  │
                              │   └──────────────┘      └──────────────────┘  │
                              └────────────────────────────────────────────────┘
                                             │
                                             ▼
                     ┌────────────────────────────────────────────────┐
                     │     iis-core-monitor RG (private, PE-only)     │
                     │                                                │
                     │   LAW+DCE ─► AMPLS ◀──── Event Hubs ─► ADX     │
                     │                  │                             │
                     │        Automation Account (Hybrid Worker)      │
                     │                  │                             │
                     │        Azure OpenAI (o4-mini + gpt-4o-mini)    │
                     └────────────────────────────────────────────────┘

                     ┌────────────────────────────────────────────────┐
                     │      iis-core RG (workload + control plane)    │
                     │                                                │
                     │     Windows Server 2022 VM  (IIS + .NET)       │
                     │        Azure Function App (S1, private)        │
                     │        Function Storage (private, blob-only)   │
                     └────────────────────────────────────────────────┘
```

### Component reference

| Component                | Role                                                                                                       | Notes                                                         |
|--------------------------|------------------------------------------------------------------------------------------------------------|---------------------------------------------------------------|
| Windows Server 2022 VM   | Runs IIS + .NET workload. Also hosts the Azure Automation Hybrid Runbook Worker (HRW).                      | Private IP only; no Bastion; managed identity for IMDS auth.  |
| IIS W3SVC                | Web server + app pools that serve customer traffic.                                                         | Chaos app endpoints simulate faults for validation.            |
| `Send-PerfToEventHub.ps1`| Scheduled task (SYSTEM, 60 s) — ships VM perf counters, IIS perf counters, and tailed W3C logs to Event Hubs.| Windows PowerShell 5.1; IMDS token auth.                     |
| Event Hubs namespace     | Buffers telemetry streams: `vmperf-eh`, `iisperf-eh`, `iislogs-eh`, `baseline-eh`.                           | Consumed directly by ADX data connections.                   |
| Azure Data Explorer      | Long-term analytics store: `VMPerf`, `IISPerf`, `IISLogs`, `PerformanceBaseline`.                            | Query engine for both detection queries and LangGraph gatherers.|
| Log Analytics + DCE      | Hosts `AgentEvents_CL` and `AgentErrors_CL` custom tables — the durable audit trail for every pipeline run.  | DCE required because LAW ingestion now goes through AMPLS.    |
| Azure Monitor Private Link Scope (AMPLS) | Private-link entry point for LAW + DCE ingestion.                                                | Single PE for all Azure Monitor traffic.                      |
| Azure Automation Account | Stores the 11 PowerShell runbooks and dispatches jobs to the Hybrid Worker on the VM.                        | `publicNetworkAccess=Disabled`; PS 5.1 runtime only.          |
| Azure Function App (S1)  | Hosts two triggers: `IISMonitorPoller` (timer) and `IISHealingOrchestratorInternal` (HTTP). Runs the LangGraph pipeline. | `publicNetworkAccess=Disabled`; VNet integrated; run-from-package. |
| Azure OpenAI             | Serves `gpt-4o-mini` (judge) and `o4-mini` (analyze/RCA).                                                    | Managed-identity auth; private endpoint.                      |
| Private DNS zones        | Resolve `privatelink.*` host names to the PE IP addresses inside the VNet.                                   | Either created by v2 or referenced from a shared-DNS RG.      |

### Data flow at a glance

1. **Telemetry ingestion (continuous)**
   - `Send-PerfToEventHub.ps1` → Event Hubs (`vmperf`, `iisperf`, `iislogs`) → ADX tables.
   - `Invoke-CaptureBaseline.ps1` → Event Hub (`baseline`) → ADX `PerformanceBaseline`.

2. **Detection (every 60 s)**
   - `IISMonitorPoller` runs KQL against ADX to detect W3SVC-down, high CPU, memory-leak patterns, HTTPERR spikes, etc.
   - When a condition fires, it synthesises an Azure Monitor-style alert payload and invokes `IISHealingOrchestratorInternal` over the Function App's internal HTTP endpoint.

3. **Alternative detection path**
   - Azure Monitor metric alerts can also POST the common alert schema to `IISHealingOrchestratorInternal` directly (e.g., external SRE alerting).

4. **Healing (per invocation)**
   - The HTTP trigger parses the alert, builds initial state, and runs the LangGraph pipeline (section 2).

5. **Audit**
   - Every run emits a single `AgentEvents_CL` row via the DCE. Failures emit an additional `AgentErrors_CL` row.

---

## 2. LangGraph healing pipeline

### 2.1 Design principle

**Single path, profile-driven, data-variant.** Every alert walks the same seven
nodes. Behavioural variance per issue type lives entirely in the
`IssueProfile` that `classify` loads from `agents/profiles.py`. Adding a new
issue type is a one-row change in the registry — no new agents, no new graph
edges.

### 2.2 Graph

```
         START
           │
           ▼
      ┌──────────┐  resolve alert text → issue_type → IssueProfile
      │ classify │  no LLM
      └────┬─────┘
           ▼
      ┌──────────┐  execute profile.gatherers in parallel
      │  gather  │  no LLM
      └────┬─────┘
           ▼
      ┌──────────┐  dispatch on profile.strategy:
      │  judge   │    MECHANICAL         → no LLM; pick profile.default_runbook
      │          │    REASONED           → gpt-4o-mini; action ∈ {remediate, no_action}
      │          │    REASONED_WITH_VETO → gpt-4o-mini; adds escalate_only + remediate_and_escalate
      └────┬─────┘
           ▼
      ┌──────────┐  execute runbook via Automation (Hybrid Worker)
      │   act    │  skipped body for no_action / escalate_only
      └────┬─────┘
           ▼
      ┌──────────┐  run profile.confirmation checks
      │ confirm  │  no LLM
      └────┬─────┘
           │
           ├── !is_healthy AND retry_count < 2 ──► retry → judge
           │
           ▼
      ┌──────────┐  if profile.analyze: o4-mini RCA on preserved evidence
      │ analyze  │
      └────┬─────┘
           ▼
      ┌──────────┐  write AgentEvents_CL record
      │summarize │
      └────┬─────┘
           ▼
          END
```

### 2.3 Agents in detail

| Agent        | Purpose                                                                                                                                 | LLM used          |
|--------------|-----------------------------------------------------------------------------------------------------------------------------------------|-------------------|
| `classify`   | Parses the alert payload, maps alert text / metric name to an `issue_type` key, loads the matching `IssueProfile`.                      | **None** — pure string match + registry lookup. |
| `gather`     | Runs the profile's declared `Gatherer`s concurrently. Each gatherer is a pure evidence collector (KQL against ADX, VM state probe, baseline lookup, HTTPERR tail). Results are dropped into `state.evidence`. | **None** |
| `judge`      | Decides the action. Behaviour dispatches on `profile.strategy` (see 2.4). Outputs `decision_action`, `decision_runbook`, `decision_reasoning`, `decision_confidence`. | **gpt-4o-mini** for REASONED and REASONED_WITH_VETO; none for MECHANICAL. |
| `act`        | For `remediate` / `remediate_and_escalate`: starts the chosen runbook in Azure Automation (management plane → Hybrid Worker executes on VM). For `no_action` / `escalate_only`: records the decision without running anything and signals the graph to skip `confirm`. | None |
| `confirm`    | Runs the profile's `confirmation` checks (e.g., `HTTP_OK`, `DISK_FREE_ABOVE_THRESHOLD`, `FIVE_XX_RATE_BELOW`). Sets `is_healthy`. If unhealthy and retries remain, loops back to `judge` (not `act`) so `judge` can re-pick — possibly escalating to `profile.escalation_runbook`. | None |
| `analyze`    | Deep root-cause analysis on preserved evidence. Runs only if `profile.analyze=True`. Produces `root_cause` + structured `next_steps`.    | **o4-mini** (reasoning model, higher cost, richer output). |
| `summarize`  | Assembles the final `AgentEvents_CL` record from state and writes it to LAW via the DCE.                                                | None |

### 2.4 Strategies

The `Strategy` enum governs `judge`:

| Strategy               | When used                                                                  | Judge behaviour                                                                                                    |
|------------------------|----------------------------------------------------------------------------|--------------------------------------------------------------------------------------------------------------------|
| **MECHANICAL**         | Signal is unambiguous, a safe known fix exists.                            | No LLM. Returns `profile.default_runbook` on first pass; `profile.escalation_runbook` on retry.                     |
| **REASONED**           | Symptom class — LLM validates and picks the runbook from a short menu.     | gpt-4o-mini with structured output. Action ∈ `{remediate, no_action}`. Reasoning stored in state.                  |
| **REASONED_WITH_VETO** | Fix can make things worse if root cause is upstream (classic example: 5xx flood driven by a slow Oracle DB — recycling the pool causes cold connection pool, re-auth, cache misses). | gpt-4o-mini. Action ∈ `{remediate, no_action, escalate_only, remediate_and_escalate}`. Judge is explicitly told it may veto. |

### 2.5 Retry semantics

When `confirm` fails, the graph loops back to `judge` — **not** `act`. On
retry, `judge` sees `retry_count=1` and:

- **MECHANICAL:** switches to `profile.escalation_runbook` deterministically (cheap; no LLM call).
- **REASONED / REASONED_WITH_VETO:** re-prompts the LLM with the new evidence and retry flag; the LLM may pick the escalation runbook, escalate externally, or give up.

Max 2 retries (`_MAX_RETRIES = 2` in `orchestrator.py`). After that, the graph
proceeds to `analyze` regardless of health.

### 2.6 The IssueProfile registry

`agents/profiles.py` defines 17 profiles. Each profile is a 7-field row:

```python
IssueProfile(
    label              = "...",         # human-readable
    gatherers          = (...,),        # which evidence to collect
    strategy           = Strategy.X,    # MECHANICAL / REASONED / REASONED_WITH_VETO
    default_runbook    = "...",         # first attempt
    escalation_runbook = "...",         # retry
    confirmation       = (...,),        # how to verify recovery
    analyze            = True/False,    # run deep RCA after summarising?
    escalation_target  = "...",         # optional: external webhook for REASONED_WITH_VETO
)
```

Current taxonomy:

- **Mechanical:** `w3svc_stopped`, `app_pool_stopped`, `app_pool_crash`, `log_disk_full`, `binding_missing`, `app_pool_identity`, `bad_permissions`, `high_cpu`, `high_cpu_w3wp`
- **Reasoned:** `memory_leak`, `worker_process_hang`, `request_queue_flood`, `bad_http_errors`, `high_memory`, `high_disk_io`
- **Reasoned with veto:** `http_5xx_flood`
- **Fallback:** `unknown` (reasoned, broadest gatherers, conservative escalation runbook)

---

## 3. Scenario walkthroughs

### 3.1 Scenario A — W3SVC is stopped

**Trigger.** The VM's World Wide Web Publishing Service (`W3SVC`) has stopped.
All traffic to `iishealvm` returns connection refused. A detection query
inside `IISMonitorPoller` looks for `VMPerf` rows where IIS-specific counters
have gone to zero for > 60 s, or for an Event Log query that has picked up
`Service Control Manager 7036 Stopped`.

**Pipeline trace.**

1. **classify** — alert payload text contains "w3svc" / "World Wide Web Publishing Service". String match in `classify_agent._ALERT_TO_ISSUE` → `issue_type = "w3svc_stopped"`. Profile loaded:
   ```
   gatherers = (SERVICE_STATE,)
   strategy  = MECHANICAL
   default   = Invoke-RestartW3SVC
   escalate  = Invoke-RestartIIS
   confirm   = (HTTP_OK,)
   analyze   = False
   ```

2. **gather** — runs `Gatherer.SERVICE_STATE` against the VM via `az vm run-command` (management plane; works even though VM has no public IP). Evidence recorded:
   ```
   evidence.service_state = {
     W3SVC:   Stopped,
     WAS:     Running,
     IISADMIN: Running
   }
   ```

3. **judge** — `Strategy.MECHANICAL`, no LLM. Returns:
   ```
   decision_action   = "remediate"
   decision_runbook  = "Invoke-RestartW3SVC"
   decision_reasoning = "Mechanical profile w3svc_stopped; default runbook."
   ```
   Latency: ~5 ms.

4. **act** — starts the `Invoke-RestartW3SVC` runbook via Azure Automation. Management-plane API call; HRW picks up the job and executes locally on the VM:
   ```
   Set-Service W3SVC -StartupType Automatic
   Start-Service W3SVC
   ```
   Job returns `Completed` after ~8 s.

5. **confirm** — `Check.HTTP_OK` issues an HTTP GET to `http://localhost/` on the VM (via `az vm run-command`). Returns 200. `is_healthy = True`.

6. **analyze** — `profile.analyze = False`, so `_maybe_analyze` returns `{}` without calling the LLM.

7. **summarize** — writes an `AgentEvents_CL` row:
   ```
   issue_type         = "w3svc_stopped"
   decision_action    = "remediate"
   remediation_runbook = "Invoke-RestartW3SVC"
   remediation_outcome = "Completed"
   is_healthy         = True
   analysis_result    = ""
   retry_count        = 0
   llm_calls          = 0
   duration_ms        = ~14000
   ```

**Outcome.** Service restored end-to-end in ~14 s with zero LLM cost.

---

### 3.2 Scenario B — Excessive HTTP 500s caused by a downstream Oracle DB

**Trigger.** The IIS site starts returning 500s at a high rate. The VM itself
is healthy: CPU moderate, memory moderate, request queue building. The
underlying cause is that an Oracle database one hop downstream is timing out
on a critical query path, so application code is throwing `OracleException`
and bubbling up as 500s.

This is the canonical case for `REASONED_WITH_VETO`: **recycling the app pool
does not fix downstream DB latency and will likely make it worse** (cold
connection pool, re-authentication, lost query plan cache). The judge must
have the option to veto the mechanical fix.

**Pipeline trace.**

1. **classify** — alert text contains "5xx" / "HTTP 5xx" / "server error rate". Matches `http_5xx_flood`. Profile loaded:
   ```
   gatherers = (
     ADX_IIS_LOGS_30M,
     ADX_IIS_PERF_30M,
     ADX_HTTP_ERRORS_7M,
     BASELINE,
   )
   strategy   = REASONED_WITH_VETO
   default    = Invoke-RecycleAppPool
   escalate   = Invoke-RestartIIS
   confirm    = (HTTP_OK, FIVE_XX_RATE_BELOW)
   analyze    = True
   escalation_target = "oncall_webhook"
   ```

2. **gather** — runs four gatherers in parallel (`asyncio.gather`):
   - `ADX_IIS_LOGS_30M` — pulls last 30 min of `IISLogs` rows where `scStatus >= 500`. Returns ~1,200 rows. Pattern: concentrated on `/api/payments/*` and `/api/accounts/*` URIs; response times mostly 28–30 s (close to the IIS request timeout); user agents varied (not a single bad actor); correlation IDs unique per request (not a retry storm).
   - `ADX_IIS_PERF_30M` — w3wp CPU ~35% (not elevated), Private Bytes flat, Requests Current climbing (queue build-up), Requests/sec **dropped** from 800 baseline → 180.
   - `ADX_HTTP_ERRORS_7M` — HTTPERR rows: `Timer_ConnectionIdle`, a few `Client_Reset`; no `AppOffline`.
   - `BASELINE` — normal Requests/sec 750–900; normal 5xx ≤ 0.5% of traffic. Current 5xx is 18%.

3. **judge** — `Strategy.REASONED_WITH_VETO`. Calls `gpt-4o-mini` with the evidence and the profile's prompt template. The prompt explicitly enumerates the 4 action choices and tells the model it *may* veto remediation. Model output (structured):
   ```json
   {
     "action": "escalate_only",
     "runbook": "",
     "confidence": "high",
     "reasoning": "Evidence points to a downstream dependency, not a local IIS
      defect.  w3wp CPU and memory are both in baseline range.  Incoming
      request rate has dropped while the request queue is building -- classic
      back-pressure signature from a slow upstream callee.  30-s response
      times align with the Oracle connection-string default timeout.  Recycling
      the app pool would evict the OCI connection pool and warm cache, which
      typically worsens this symptom.  Paging the on-call DB engineer is the
      correct response."
   }
   ```
   Latency: ~1.2 s. Cost: fractions of a cent.

4. **act** — `decision_action = "escalate_only"`. The `act` node skips runbook execution, records `remediation_outcome = "Skipped (escalate_only)"`, and signals the router to bypass `confirm` (there's nothing to re-check — the fault is upstream and intact). If `escalation_target` is configured, `act` also POSTs a payload to the on-call webhook with the evidence summary and the judge's reasoning.

5. **confirm** — **skipped** by `_route_after_act`. Bypassing confirm for `escalate_only` avoids an always-false health check and prevents the retry loop from kicking in on a problem the graph can't fix.

6. **analyze** — `profile.analyze = True`, so `o4-mini` runs an RCA on the preserved evidence. Output stored in `state.root_cause` and `state.next_steps`, e.g.:
   ```
   root_cause = "Downstream Oracle DB latency causing 28-30 s request
     timeouts in payment/account APIs.  No local IIS defect."
   next_steps = [
     "Verify Oracle listener health and session wait events",
     "Check connection-pool exhaustion metrics on the application side",
     "Confirm whether a long-running transaction or lock is holding
      connections",
     "Consider temporary traffic shedding at the load balancer while
      DB is investigated"
   ]
   ```

7. **summarize** — writes `AgentEvents_CL`:
   ```
   issue_type          = "http_5xx_flood"
   decision_action     = "escalate_only"
   remediation_runbook = ""
   remediation_outcome = "Skipped (escalate_only)"
   is_healthy          = false
   analysis_result     = "<RCA narrative>"
   root_cause          = "Downstream Oracle DB latency..."
   next_steps          = [ ... ]
   retry_count         = 0
   llm_calls           = 2     # gpt-4o-mini in judge + o4-mini in analyze
   duration_ms         = ~4800
   escalated           = true
   ```

**Outcome.** The pipeline **refused to recycle the app pool**, escalated to
the on-call engineer with a data-backed rationale and a ranked list of next
steps, and wrote a durable audit record. Total wall time: under 5 s. Had the
profile been `REASONED` instead of `REASONED_WITH_VETO`, the LLM would have
had only `remediate` / `no_action` in its action menu — meaning it could only
have blessed a pool recycle or punted silently. The veto strategy is the
feature that turns this class of incident from "automation made it worse"
into "automation correctly identified it was upstream and got the right human
involved".

---

## 4. Why this shape

- **Single path** eliminates the N-variant-graph-per-issue explosion that the
  v2 predecessor suffered from. Every pipeline run is predictable and
  observable: seven nodes, same order, always.
- **Profile-driven** means adding or tuning issue behaviour is a data change
  (one row in `profiles.py`), not a code change. The graph doesn't move.
- **Strategy dispatch** keeps LLM cost proportional to issue complexity:
  mechanical issues spend $0 on LLM calls; symptom-class issues spend ~$0.0005
  per decision; RCA spends ~$0.02 per root-cause.
- **Retry-to-judge (not act)** ensures the second attempt can be fundamentally
  different from the first — a different runbook, a veto, or a handoff —
  rather than hammering the same failed action twice.
- **DCE + `AgentEvents_CL`** gives a single-row-per-incident audit trail that's
  trivially queryable in KQL for operational reviews, cost attribution, and
  model evaluation.
