# v2 Setup & Deployment Guide

This guide walks through deploying the **v2** (enterprise-network) variant of the
IIS Auto-Healing system. It plugs into an existing VNet, uses private endpoints
for every Azure resource, does not use Bastion, and runs all VM-side PowerShell
on Windows PowerShell 5.1.

If you are reading this for the first time, follow the sections in order — each
one ends in a checkpoint you can verify before moving on.

---

## 1. Prerequisites

### 1.1 Tooling on the deploy machine

| Tool        | Version   | Install                                                 |
|-------------|-----------|---------------------------------------------------------|
| Azure CLI   | 2.55+     | https://learn.microsoft.com/cli/azure/install-azure-cli |
| Bicep       | 0.24+     | `az bicep install` (bundled with az)                    |
| jq          | 1.6+      | `apt-get install jq` / `winget install jqlang.jq`       |
| zip         | any       | `apt-get install zip` / `winget install GnuWin32.Zip`   |
| bash        | 4+        | WSL2, Git Bash, or native Linux/macOS                   |

You do **not** need PowerShell 7 anywhere — not on the deploy machine, not on
the target VM, not in Azure Automation. Windows PowerShell 5.1 is sufficient.

### 1.2 Azure subscription access

The account running `deploy.sh` must hold the following roles:

| Scope                                                     | Role                              | Why                                                                   |
|-----------------------------------------------------------|-----------------------------------|-----------------------------------------------------------------------|
| Subscription                                              | Contributor                       | Creates the two resource groups and all resources                     |
| Existing VNet (`non-prod_vnet-openshift-...`)             | Network Contributor               | Creates private endpoints + vnet links                                |
| Resource group `iis-core` (after it is created)           | Storage Blob Data Contributor     | Uploads the function package zip with `--auth-mode login`             |
| Subscription                                              | User Access Administrator         | Creates role assignments in `rbac_core.bicep` / `rbac_monitor.bicep`  |

If your identity already has **Owner** on the subscription, the first three are
covered and only `Storage Blob Data Contributor` on the function storage
account needs to be added after the first deploy pass (see 4.3).

### 1.3 Azure quotas

Before deploying, confirm the target region has headroom for:

- `Standard DSv3 Family vCPUs` — 2 vCPU (for the Windows VM)
- `App Service Standard Plan` — 1 S1 instance (for the Function App)
- `Cognitive Services Accounts` — 1 Azure OpenAI account
- `Azure OpenAI o4-mini GlobalStandard TPM` — at least 30k
- `Azure OpenAI gpt-4o-mini GlobalStandard TPM` — at least 30k
- `ADX clusters` — 1 (Dev SKU is fine for test, Standard_D11_v2 for prod)

Check with: `az vm list-usage --location eastus2 -o table`

---

## 2. Information to gather from the network team

The v2 variant does **not** create a VNet or subnets. Your network team must
pre-provision the following and hand you their names:

| Item                            | Requirement                                                                       |
|---------------------------------|-----------------------------------------------------------------------------------|
| VNet                            | `non-prod_vnet-openshift-for-card-service-eastus2-277f` (already exists)          |
| VNet's resource group           | Ask the network team                                                              |
| VM subnet                       | Any subnet with routing to the internet *or* to the rest of the Azure backbone    |
| Private-endpoint subnet         | Must have `privateEndpointNetworkPolicies: Disabled`. Minimum /27 recommended     |
| Function App integration subnet | `/28` or larger, delegated to `Microsoft.Web/serverFarms`, empty of other traffic |

If your enterprise runs **shared private DNS** (a central RG with the
`privatelink.*` zones already linked to this VNet), also ask for:

| Item                              | Notes                                                                  |
|-----------------------------------|------------------------------------------------------------------------|
| Shared DNS zones resource group   | Contains all `privatelink.*` zones. v2 will not create or link zones.  |

If shared DNS is **not** in use, leave the param empty and v2 will create all
zones locally in `iis-core-monitor` and link them to the enterprise VNet.

### 2.1 Checklist before proceeding

- [ ] VNet name confirmed
- [ ] VNet resource group confirmed
- [ ] VM subnet name confirmed
- [ ] PE subnet name confirmed AND `privateEndpointNetworkPolicies=Disabled` verified
- [ ] Function-App integration subnet name confirmed AND delegation verified
- [ ] DNS strategy decided (local vs shared)

Verify the two subnet policies with:

```bash
az network vnet subnet show \
  --vnet-name non-prod_vnet-openshift-for-card-service-eastus2-277f \
  --resource-group <their-rg> \
  --name <pe-subnet-name> \
  --query "privateEndpointNetworkPolicies"
# Expect: "Disabled"

az network vnet subnet show \
  --vnet-name non-prod_vnet-openshift-for-card-service-eastus2-277f \
  --resource-group <their-rg> \
  --name <fa-integration-subnet-name> \
  --query "delegations[0].serviceName"
# Expect: "Microsoft.Web/serverFarms"
```

---

## 3. Bicep / parameter edits before deploy

### 3.1 Required edits — `v2/infra/parameters/dev.bicepparam`

Open this file and fill in the five `TODO` placeholders at the bottom:

```bicep
param existingVnetName                     = 'non-prod_vnet-openshift-for-card-service-eastus2-277f'
param existingVnetResourceGroup            = '<NETWORK-TEAM-RG>'              // REQUIRED
param vmSubnetName                         = '<vm-subnet-name>'               // REQUIRED
param peSubnetName                         = '<pe-subnet-name>'               // REQUIRED
param faIntegrationSubnetName              = '<fa-integration-subnet-name>'   // REQUIRED
param existingPrivateDnsZonesResourceGroup = ''                               // '' = create locally; fill in only if shared DNS is in use
```

The file will not compile (bicep lint will warn, deploy will fail with a
"subnet not found" error at runtime) unless the four REQUIRED fields are set.

### 3.2 Optional edits — same file

| Param            | Default                          | Change when                                                                     |
|------------------|----------------------------------|---------------------------------------------------------------------------------|
| `coreRgName`     | `iis-core`                       | You want a different RG name (e.g. env prefix: `iis-core-dev`)                  |
| `monitorRgName`  | `iis-core-monitor`               | Same                                                                            |
| `location`       | `eastus2`                        | Different Azure region. Also update `openaiLocation` unless routing OpenAI east |
| `projectPrefix`  | `iisheals`                       | Must be unique (used in globally-unique names: storage, OpenAI, EH, ADX)        |
| `vmHostname`     | `iishealvm`                      | VM computer name; 15-char Windows limit                                         |
| `openaiLocation` | `eastus2`                        | Must be a region supporting `o4-mini` model                                     |
| `adxSkuName`     | `Dev(No SLA)_Standard_D11_v2`    | Production: `Standard_D11_v2`                                                   |
| `adxSkuTier`     | `Basic`                          | Production: `Standard`                                                          |
| `adxCapacity`    | `1`                              | Production: `2` (for SLA)                                                       |

### 3.3 Bicep module edits you may want

Most module defaults are fine. Three places worth reviewing:

**`v2/infra/modules/functionapp.bicep`** — Function App tier
- Default is `S1 Standard` (~$70/mo). Private endpoints and `publicNetworkAccess=Disabled` require Standard or higher; do **not** drop back to B1.
- For higher scale, change `sku.name` to `P1v3` (~$130/mo) and `sku.tier` to `PremiumV3`. No other changes required.

**`v2/infra/modules/vm.bicep`** — VM size
- Default is `Standard_D2s_v3`. Bump to `Standard_D4s_v3` for heavier chaos/load testing. Line is `hardwareProfile.vmSize`.

**`v2/infra/modules/private_dns.bicep`** — DNS zone list
- If your enterprise uses non-default zone names (e.g., `privatelink.eastus2.azurewebsites.net` instead of the public `privatelink.azurewebsites.net`), edit the zone name literals in this module. Default names match Microsoft's public documentation and work in 99% of environments.

### 3.4 Do **not** edit

- `v2/infra/modules/automation.bicep` `publicNetworkAccess` — keep `Disabled`
- `v2/infra/modules/functionapp.bicep` `publicNetworkAccess` — keep `Disabled`
- `v2/infra/modules/functionapp.bicep` storage `networkAcls.defaultAction` — keep `Deny`
- Runbook runtime — keep `runtime: 'PowerShell'` (5.1); switching to `PowerShell72` re-introduces the PS 7 dependency

---

## 4. Deploy

### 4.1 Set the VM admin password

```bash
export VM_ADMIN_PASSWORD='StrongP@ssw0rd!2024'
```

Requirements: 12+ chars, upper + lower + digit + symbol, not in Azure's reserved list.

### 4.2 (Optional) Pin the subscription

```bash
az login
az account set --subscription "<subscription-name-or-id>"
```

### 4.3 Run the deploy script

```bash
cd C:/Projects/workIIS/iis-autohealing
bash v2/scripts/deploy.sh
```

What it does, in order:

1. Validates prerequisites (tooling, login, env vars).
2. Compiles `v2/infra/main.bicep` → `v2/infra/main.json`.
3. `az deployment sub create` — creates both resource groups and all resources (takes 12-20 minutes; ADX is the slowest).
4. Waits **90 seconds** for RBAC propagation (Azure role assignments need time to replicate before ADX can validate them).
5. Deploys ADX data connections (`adx_connections.bicep`).
6. Bootstraps VM: runs `setup-iis.ps1` via `az vm run-command`, configures IIS, registers the Hybrid Worker, drops in `Send-PerfToEventHub.ps1` as a scheduled task.
7. Uploads runbooks to the Automation account (management-plane, unaffected by private endpoint).
8. Packages the Function App:
   - Zips `v2/function-app/` to `/tmp/functionapp.zip`
   - **Temporarily** adds the deploy machine's public IP to the function's storage account network rules (storage stays `publicNetworkAccess=Disabled` but an IP allowlist exists for the PE bypass path — actually flips to `Enabled` briefly; see note below).
   - Uploads the zip to the `function-packages` container using `--auth-mode login` (AAD).
   - Generates a 10-year user-delegation SAS.
   - Sets `WEBSITE_RUN_FROM_PACKAGE` on the Function App.
   - Removes the IP allowance.
   - Restarts the Function App.
9. Prints a summary: resource group names, VM private IP, Function App URL, ADX cluster URI.

**Expected total runtime:** 25–35 minutes.

### 4.4 First-run RBAC bootstrapping

On the very first run, step 8 will fail with `AuthorizationPermissionMismatch`
because the deployer was just granted **Storage Blob Data Contributor** on the
new storage account and AAD hasn't propagated the role yet.

If this happens:

1. Wait 5 minutes.
2. Re-run `bash v2/scripts/deploy.sh` — it's idempotent; everything except the
   function package step is a no-op on the second run.

Alternatively, grant yourself `Storage Blob Data Contributor` at the
subscription level ahead of time and the first run will succeed.

---

## 5. Post-deploy verification

### 5.1 Check all private endpoints are "Approved" and "Succeeded"

```bash
az network private-endpoint list \
  --resource-group iis-core-monitor \
  --query "[].{name:name, state:privateLinkServiceConnections[0].privateLinkServiceConnectionState.status, provisioning:provisioningState}" \
  -o table
```

All should show `Approved` / `Succeeded`. If any show `Pending`, the target
resource owner needs to approve the connection (normally auto-approved because
you created both sides).

### 5.2 Check the Function App is running from the package

```bash
FA_NAME=$(az functionapp list -g iis-core --query "[0].name" -o tsv)
az functionapp config appsettings list \
  --name "$FA_NAME" \
  --resource-group iis-core \
  --query "[?name=='WEBSITE_RUN_FROM_PACKAGE'].value" -o tsv
# Expect: a https://<storage>.blob.core.windows.net/... SAS URL
```

### 5.3 Check the Hybrid Worker has registered

```bash
az automation hrwg list \
  --resource-group iis-core-monitor \
  --automation-account-name <automation-account-name> \
  -o table

az automation hrwg hybrid-runbook-worker list \
  --resource-group iis-core-monitor \
  --automation-account-name <automation-account-name> \
  --hybrid-runbook-worker-group-name default \
  -o table
```

You should see one worker entry with the VM's hostname.

### 5.4 Smoke-test a runbook

```bash
az automation runbook start \
  --resource-group iis-core-monitor \
  --automation-account-name <automation-account-name> \
  --name Invoke-CaptureBaseline \
  --parameters VMName=<vmname> ResourceGroup=iis-core
```

Check job status:

```bash
az automation job list \
  --resource-group iis-core-monitor \
  --automation-account-name <automation-account-name> \
  --query "[0]" -o json
```

Expect `status: Completed`.

### 5.5 Check ADX is receiving data

```bash
ADX_URI=$(az kusto cluster show -g iis-core-monitor -n <adx-cluster-name> --query "uri" -o tsv)
# Run a simple count in the Azure portal's Kusto Explorer, or via kusto CLI:
# VMPerf | summarize count() by bin(TimeGenerated, 1m)
```

You should see rows arriving within 2-3 minutes of VM boot.

---

## 6. Troubleshooting

| Symptom                                                              | Likely cause                                                                     | Fix                                                                                                                                             |
|----------------------------------------------------------------------|----------------------------------------------------------------------------------|-------------------------------------------------------------------------------------------------------------------------------------------------|
| `SubnetNotFound` during deploy                                       | Subnet names in `dev.bicepparam` don't match actual subnet names                 | Re-verify with `az network vnet subnet list`. Names are case-sensitive.                                                                         |
| `SubnetMissingRequiredDelegation`                                    | Function-app integration subnet is not delegated to `Microsoft.Web/serverFarms`  | Network team must add the delegation; cannot be added from v2 because v2 doesn't own the subnet.                                                |
| Function App logs show `FUNCTIONS_WORKER_RUNTIME` errors             | Package zip did not upload or `WEBSITE_RUN_FROM_PACKAGE` is unset                | Re-run deploy.sh; check step 8 output.                                                                                                          |
| Hybrid Worker does not appear in Automation                          | VM can't reach Automation agent endpoint via private DNS                         | From VM: `Resolve-DnsName <automation-account>.agentsvc.azure-automation.net` should return a 10.x IP. If public IP returned, DNS zone not linked. |
| Runbook starts but outputs nothing                                   | Parameter name mismatch (e.g., `vmName` instead of `VMName`)                     | All runbooks require `VMName` and `ResourceGroup` (case-sensitive, mandatory). See memory note.                                                 |
| `Private endpoint is in 'Pending' state`                             | Auto-approval failed (can happen cross-tenant)                                   | Approve manually in portal or via `az network private-endpoint-connection approve`.                                                             |
| ADX data connection deploy fails with `Forbidden`                    | 90s RBAC propagation wait was insufficient                                       | Re-run deploy.sh; the second pass will succeed because RBAC is now propagated.                                                                  |
| Storage upload fails with `AuthorizationPermissionMismatch`          | Deployer missing `Storage Blob Data Contributor` on new storage account          | Wait 5 min after first deploy attempt and re-run; or grant at sub scope beforehand.                                                             |

### 6.1 Useful diagnostic commands

```bash
# Show the current state of private DNS resolution on the VM
az vm run-command invoke \
  --resource-group iis-core \
  --name <vmname> \
  --command-id RunPowerShellScript \
  --scripts "Resolve-DnsName <storage-account>.blob.core.windows.net | Format-Table"

# Test function app private reachability from VM
az vm run-command invoke \
  --resource-group iis-core \
  --name <vmname> \
  --command-id RunPowerShellScript \
  --scripts "(Invoke-WebRequest -Uri https://<fa-name>.azurewebsites.net -UseBasicParsing).StatusCode"
```

---

## 7. Teardown

```bash
bash v2/scripts/teardown.sh
```

Or manually:

```bash
az group delete -n iis-core --yes --no-wait
az group delete -n iis-core-monitor --yes --no-wait
```

The existing VNet and its subnets are **not** deleted (v2 does not own them).
Any private DNS zones created by v2 (when `existingPrivateDnsZonesResourceGroup`
was empty) are deleted with the `iis-core-monitor` RG.

---

## 8. Summary — files to edit before first deploy

1. **`v2/infra/parameters/dev.bicepparam`** — set the 4 `TODO` subnet/RG params (REQUIRED).
2. **`v2/infra/parameters/dev.bicepparam`** — optionally change `projectPrefix`, `location`, ADX SKU.
3. **Environment** — `export VM_ADMIN_PASSWORD='...'` before running deploy.sh.

Nothing else needs editing for a working deploy.
