# v2 — Private network design

Every Azure service in the v2 stack is reachable only through a private
endpoint in the enterprise VNet. The only "public" thing that remains is
Application Insights ingestion/query on the Function App telemetry path
(LAW itself is behind AMPLS).

## Topology

```
 Enterprise VNet: non-prod_vnet-openshift-for-card-service-eastus2-277f
 ├── vmSubnet                 → iisheal-nic (VM NIC, private IP only)
 ├── faIntegrationSubnet      → Function App regional VNet integration
 │                              (Microsoft.Web/serverFarms delegation)
 └── peSubnet                 → all private endpoints land here
     ├── iisheal-pe-ampls                  → AMPLS (LAW + DCE)
     │     zones: monitor, oms, ods, agentsvc, blob
     ├── iisheal-pe-automation-dsc         → Automation [DSCAndHybridWorker]
     │     zones: azure-automation, agentsvc
     ├── iisheal-pe-automation-webhook     → Automation [Webhook]
     │     zones: azure-automation
     ├── iisheal-pe-functionapp            → Function App [sites]
     │     zones: azurewebsites
     ├── iisheal-pe-fa-storage-blob        → FA storage [blob]
     │     zones: blob
     ├── iisheal-pe-fa-storage-file        → FA storage [file]
     │     zones: file
     ├── iisheal-pe-fa-storage-queue       → FA storage [queue]
     │     zones: queue
     ├── iisheal-pe-fa-storage-table       → FA storage [table]
     │     zones: table
     ├── iisheal-pe-eventhubs              → EH namespace [namespace]
     │     zones: servicebus
     ├── iisheal-pe-adx                    → ADX [cluster]
     │     zones: <region>.kusto
     └── iisheal-pe-openai                 → OpenAI [account]
           zones: openai
```

## Private DNS zones (13)

Created by `private_dns.bicep` in the monitor RG by default, or referenced
from a shared-DNS RG when `existingPrivateDnsZonesResourceGroup` is non-empty.
Each zone has exactly one VNet link pointing at the enterprise VNet by
resource ID (`registrationEnabled=false`).

| Zone | Used by |
|---|---|
| `privatelink.azure-automation.net` | Automation (DSC + Webhook) |
| `privatelink.agentsvc.azure-automation.net` | Automation agent traffic, AMPLS |
| `privatelink.azurewebsites.net` | Function App (sites) |
| `privatelink.blob.core.windows.net` | FA storage blob, AMPLS DCE |
| `privatelink.file.core.windows.net` | FA storage file |
| `privatelink.queue.core.windows.net` | FA storage queue |
| `privatelink.table.core.windows.net` | FA storage table |
| `privatelink.monitor.azure.com` | AMPLS (LAW query) |
| `privatelink.oms.opinsights.azure.com` | AMPLS (LAW ingestion) |
| `privatelink.ods.opinsights.azure.com` | AMPLS (LAW diagnostics) |
| `privatelink.servicebus.windows.net` | Event Hubs namespace |
| `privatelink.<region>.kusto.windows.net` | ADX cluster |
| `privatelink.openai.azure.com` | Azure OpenAI |

## Flow summary

- **VM → Function App** (HTTP): caller hits `https://iisheals-func.azurewebsites.net`
  → resolved via `privatelink.azurewebsites.net` → sites PE in peSubnet.
- **Function App → Automation** (webhook trigger + runbook output fetch):
  resolved via `privatelink.azure-automation.net`.
- **Function App → OpenAI, ADX, LAW query, DCE ingest**: all via their
  respective PEs.
- **VM → Event Hubs** (perf counter upload): resolved via
  `privatelink.servicebus.windows.net` → Event Hubs PE.
- **VM → Automation** (Hybrid Worker agent traffic): DSCAndHybridWorker PE +
  agentsvc zone.
- **Deploy host → FA storage** (run-from-package upload): caller IP is briefly
  allowlisted on FA storage; SAS URL bound to that blob is stored in
  `WEBSITE_RUN_FROM_PACKAGE`, and subsequent Function pulls happen from inside
  the integrated VNet via the blob PE.

## Who owns what

| Component | Owner |
|---|---|
| VNet, subnets, NSGs | enterprise network team |
| Subnet delegations (serverFarms) | enterprise network team |
| `privateEndpointNetworkPolicies: Disabled` on peSubnet | enterprise network team |
| Private endpoints | this stack |
| Private DNS zones + VNet links | this stack (or shared-DNS RG) |
| RBAC on VNet for PE creation | granted to deploy principal ahead of time |
