﻿<#
.SYNOPSIS
    Deploys the updated Send-PerfToEventHub.ps1 to the IIS VM via az vm
    run-command.

.DESCRIPTION
    Copies ../vm-scripts/Send-PerfToEventHub.ps1 onto the VM at
    C:\Scripts\Send-PerfToEventHub.ps1.  Does NOT modify the existing
    scheduled task -- the task continues to run on its 60-second interval
    and will pick up the new script on the next fire.

    Uses `az vm run-command invoke` which goes through ARM and the Guest
    Agent -- works with VM private endpoints as long as ARM is reachable.

.PARAMETER VMName
    Name of the existing IIS VM.  Default: iisheals-vm

.PARAMETER ResourceGroup
    Resource group containing the VM.  Default: iis-core

.EXAMPLE
    .\Deploy-VMScript.ps1

.EXAMPLE
    .\Deploy-VMScript.ps1 -VMName 'hardened-vm' -ResourceGroup 'hardened-rg'

.NOTES
    Prereqs:
      - Azure CLI installed and `az login` completed.
      - Caller identity has Virtual Machine Contributor on the VM.
      - Azure VM Guest Agent must be running on the VM (it is by default).

    Current version only changes script content at C:\Scripts -- the existing
    scheduled task SendPerfToEventHub continues unchanged and automatically
    picks up the new file on its next minute-ly run.
#>
[CmdletBinding()]
param(
    [string]$VMName        = 'iisheals-vm',
    [string]$ResourceGroup = 'iis-core'
)

$ErrorActionPreference = 'Stop'

$ScriptDir = Split-Path -Parent $PSCommandPath
$SrcFile   = Resolve-Path (Join-Path $ScriptDir '..\vm-scripts\Send-PerfToEventHub.ps1')

Write-Host "[INFO] VM            : $VMName"        -ForegroundColor Cyan
Write-Host "[INFO] Resource Group: $ResourceGroup" -ForegroundColor Cyan
Write-Host "[INFO] Source        : $SrcFile"       -ForegroundColor Cyan
Write-Host ''

# --- Preflight --------------------------------------------------------------
if (-not (Get-Command az -ErrorAction SilentlyContinue)) {
    throw 'Azure CLI (az) not found on PATH.'
}

$acct = az account show --query name -o tsv 2>$null
if (-not $acct) { throw 'Not logged in.  Run: az login' }
Write-Host "[OK]   Authenticated to subscription: $acct" -ForegroundColor Green

$vmState = az vm get-instance-view --name $VMName --resource-group $ResourceGroup `
    --query "instanceView.statuses[?starts_with(code,'PowerState/')].displayStatus | [0]" -o tsv 2>$null
if (-not $vmState) {
    throw "VM '$VMName' not found in '$ResourceGroup'."
}
Write-Host "[OK]   VM state: $vmState" -ForegroundColor Green
if ($vmState -ne 'VM running') {
    Write-Host "[WARN] VM is not running -- deployment may fail." -ForegroundColor Yellow
}

# --- Encode and push --------------------------------------------------------
$bytes  = [System.IO.File]::ReadAllBytes($SrcFile)
$b64    = [System.Convert]::ToBase64String($bytes)
$target = 'C:\Scripts\Send-PerfToEventHub.ps1'

# Script run ON the VM -- reconstructs the file from base64.
$remoteScript = @"
`$b64 = '$b64'
`$dir = [System.IO.Path]::GetDirectoryName('$target')
if (-not (Test-Path `$dir)) { New-Item -ItemType Directory -Force -Path `$dir | Out-Null }
[System.IO.File]::WriteAllBytes('$target', [System.Convert]::FromBase64String(`$b64))
Write-Output 'DEPLOYED'
"@

# Use a temp file to avoid arg-length limits on the az CLI.
$tmpPs = Join-Path $env:TEMP "deployvm-$(Get-Date -Format 'yyyyMMddHHmmss').ps1"
Set-Content -LiteralPath $tmpPs -Value $remoteScript -Encoding UTF8

Write-Host "[INFO] Pushing to $target via az vm run-command (this takes ~20-40s)..." -ForegroundColor Cyan
try {
    $result = az vm run-command invoke `
        --resource-group $ResourceGroup `
        --name           $VMName `
        --command-id     RunPowerShellScript `
        --scripts        "@$tmpPs" `
        --query          'value[0].message' -o tsv 2>&1
    if ($LASTEXITCODE -ne 0) { throw "run-command failed: $result" }
} finally {
    Remove-Item -Force $tmpPs -ErrorAction SilentlyContinue
}

if ($result -notmatch 'DEPLOYED') {
    Write-Host "[WARN] Unexpected remote output:" -ForegroundColor Yellow
    Write-Host $result
    throw 'Remote script did not report DEPLOYED.'
}

Write-Host "[OK]   Script deployed to $target on $VMName" -ForegroundColor Green
Write-Host ''
Write-Host "[DONE] Scheduled task SendPerfToEventHub will pick up the new script on its next minute-ly run." -ForegroundColor Green
