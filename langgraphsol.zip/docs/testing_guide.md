# IIS Auto-Healing System -- SRE Testing Guide

This guide walks you through end-to-end testing of the IIS auto-healing system. You will inject faults via the Chaos Engineering Console, observe the healing pipeline respond, and validate results across Azure resources.

> **Pipeline version note.** Some descriptive sections below refer to the v2
> dual-path design ("deterministic path", `det_diagnose`, etc.). The test
> procedures (fault injection, expected runbooks, KQL queries) remain valid
> for v3 because the runbook set and alert triggers are unchanged.
> The v3 equivalents are: classify/gather/judge/act/confirm/analyze/summarize
> (single path); `Strategy` + `DecisionAction` columns in `AgentEvents_CL`
> replace the old `RemediationPath` column. See
> [langgraph_pipeline.md](langgraph_pipeline.md) and
> [flow_examples.md](flow_examples.md) for the v3 design.

---

## Table of Contents

1. [Prerequisites](#1-prerequisites)
2. [Environment Access](#2-environment-access)
3. [Quick Health Check](#3-quick-health-check)
4. [Understanding the Two Healing Paths](#4-understanding-the-two-healing-paths)
5. [Test Scenarios](#5-test-scenarios)
6. [Validating Results in Azure Portal](#6-validating-results-in-azure-portal)
7. [KQL Queries for Validation](#7-kql-queries-for-validation)
8. [Automated Test Scripts](#8-automated-test-scripts)
9. [Troubleshooting](#9-troubleshooting)

---

## 1. Prerequisites

Before you start, make sure you have:

- [ ] Azure CLI installed and logged in (`az login`)
- [ ] Contributor access to both `iis-core` and `iis-core-monitor` resource groups
- [ ] The VM public IP (find it in the portal under **iis-core > iisheal-vm > Overview > Public IP address**, or run the command below)
- [ ] A browser for the Chaos Console and Azure Portal
- [ ] (Optional) RDP access to the VM for direct inspection -- username and credentials from whoever deployed the environment

Get the VM public IP from the CLI:
```bash
az vm list-ip-addresses \
  --resource-group iis-core \
  --name iisheal-vm \
  --query "[0].virtualMachine.network.publicIpAddresses[0].ipAddress" \
  --output tsv
```

Throughout this guide, replace `<VM_IP>` with the actual public IP.

---

## 2. Environment Access

| Resource | How to Access |
|----------|--------------|
| **IIS Home Page** | `http://<VM_IP>/` -- should return "Contoso Infrastructure Services" page |
| **Chaos Console** | `http://<VM_IP>/chaos/default.aspx` -- fault injection UI |
| **Function App** | Azure Portal > `iis-core` > `iisheal-func` |
| **Log Analytics** | Azure Portal > `iis-core-monitor` > `iisheal-law` > Logs (agent events, errors, baselines) |
| **ADX Explorer** | Azure Portal > `iis-core-monitor` > `{prefix}adx` > Query > `{prefix}-db` (VMPerf, IISPerf, IISLogs, IISLogsParsed, PerformanceBaseline) |
| **Automation Account** | Azure Portal > `iis-core-monitor` > `iisheal-automation` > Jobs |
| **Azure OpenAI** | Azure Portal > `iis-core-monitor` > `iisheal-openai` |
| **IISMonitorPoller logs** | Azure Portal > `iisheal-func` > Log stream (detection runs every 60s, queries ADX) |
| **VM via RDP** | `mstsc /v:<VM_IP>` (port 3389, restricted to deployer IP by NSG) |

---

## 3. Quick Health Check

Before running any chaos tests, verify the system is operational. Run through these checks in order:

### 3a. IIS is serving traffic

Open `http://<VM_IP>/` in a browser. You should see the Contoso Infrastructure Services page. If you get a connection timeout or error, the VM or IIS is down -- resolve that first.

### 3b. Chaos Console is reachable

Open `http://<VM_IP>/chaos/default.aspx`. The page shows a **System Status** panel at the top:
- **Server Hostname** -- should show the VM name
- **W3SVC Service** -- should show **Running** (green)
- **DefaultAppPool** -- should show **Started** (green)

If these are red or show errors, IIS is already in a degraded state.

### 3c. Telemetry is flowing

Telemetry flows through two paths -- both need to be healthy:

**Path 1 -- ADX (telemetry for AI agents):** Go to **Azure Portal > `{prefix}adx`** (in `iis-core-monitor` resource group) > **Query**. Select the `{prefix}-db` database and run:
```kql
VMPerf
| where TimeGenerated > ago(10m)
| count
```

**Path 2 -- LAW (metrics for alert rules):** Go to **Azure Portal > `iisheal-law`** (in `iis-core-monitor` resource group) > **Logs** and run:
```kql
Perf
| where TimeGenerated > ago(10m)
| count
```

If ADX count is 0, the `Send-PerfToEventHub.ps1` scheduled task on the VM may not be running. If LAW count is 0, the Azure Monitor Agent or DCR is misconfigured. Check that the VM is running and AMA is installed.

### 3d. Function App is running

Go to **Azure Portal > iisheal-func > Overview**. Status should be **Running**. You can also verify the function is loaded:
```bash
# Should return HTTP 404 (expects POST with alert payload) — confirms the function is reachable
curl -s -o /dev/null -w "HTTP %{http_code}" https://iisheal-func.azurewebsites.net/api/IISHealingOrchestrator
```

### 3e. (Optional) Run the automated validation script

```bash
cd scripts/
bash validate_agent.sh
```
This checks LAW table counts, Function App health, Automation Account jobs, and OpenAI deployments in one pass.

---

## 4. Understanding the Two Healing Paths

The system routes every alert down one of two paths. Knowing which path a scenario uses tells you what to look for during validation.

| Path | Used For | What Happens | Azure OpenAI Used? |
|------|----------|-------------|-------------------|
| **Deterministic** | Known, safe fixes (service stopped, app pool crash, app pool stopped, disk full, binding missing, CPU spikes) | Direct runbook lookup and execution. No AI reasoning needed -- the alert threshold already confirmed the breach. | No (except performance issues get a post-remediation o4-mini root cause analysis via `det_diagnose`) |
| **AI** | Complex/ambiguous issues (memory leaks, queue floods, worker hangs, high memory/disk I/O) | Queries 30 min of telemetry, compares against baseline, AI selects runbook, AI verifies, AI writes RCA. | Yes |

**Why this matters for testing:** Deterministic scenarios should complete in seconds. AI scenarios take longer (30-90 seconds) because they query telemetry and call Azure OpenAI. If an AI scenario completes instantly, something may be wrong.

**Performance issues on the deterministic path:** `high_cpu` and `high_cpu_w3wp` are routed deterministically (immediate app pool recycle) but after successful remediation, the `det_diagnose` agent runs an o4-mini analysis against 30 minutes of ADX telemetry and the performance baseline. This means these scenarios take slightly longer than other deterministic scenarios but still faster than the full AI path.

---

## 5. Test Scenarios

### General Testing Workflow

For every scenario, the process is the same:

1. **Trigger** the fault via the Chaos Console
2. **Wait** for IISMonitorPoller to detect the threshold breach in ADX (see expected timing per scenario)
3. **Observe** the healing pipeline process the alert (Function App logs, Automation jobs)
4. **Validate** that IIS recovered (hit the home page, check the Chaos Console status panel)
5. **Verify** the event was logged (AgentEvents_CL in Log Analytics)
6. **Wait 5+ minutes** between scenarios for the cooldown period to expire (IISMonitorPoller has a 5-minute cooldown after each healing trigger)

### How Detection Timing Works

Detection uses **IISMonitorPoller**, a timer-triggered Azure Function that queries ADX every 60 seconds. It does **not** use Azure Monitor alert rules. The end-to-end detection pipeline is:

```
Fault occurs → Send-PerfToEventHub.ps1 samples counter (every 60s)
  → Event Hub → ADX ingestion batch closes (30s policy)
  → IISMonitorPoller next tick → KQL breach query → healing triggered
```

The typical detection lag from fault to healing trigger depends on the issue type:

| Issue Type | Detection Guard | Typical Detection Time |
|------------|----------------|----------------------|
| Most issues (CPU, disk, connections, etc.) | Breach in 7-min look-back window | ~2-3 min (1 script cycle + ingestion + poller tick) |
| `w3svc_stopped` | RowCount >= 3 synthetic heartbeat rows | ~3-4 min (3 × 60s script cycles + ingestion) |
| `app_pool_stopped` | >= 3 AppOffline 503 rows in IISHttpErrors | ~3-4 min (similar to w3svc) |
| `app_pool_crash` | Sum of Application Restarts > 2 | ~2-3 min after 3rd crash |
| `high_cpu` | >= 2 high samples (CPU > 85%) | ~2-3 min of sustained spike |

**Don't panic if healing doesn't trigger after 30 seconds.** The poller runs every 60 seconds and data takes ~90 seconds (60s collection + 30s batching) to become queryable in ADX. Also note the **5-minute cooldown**: after each healing trigger, the poller skips all checks for 5 minutes to prevent duplicate healing runs.

### Understanding IIS Auto-Recovery

IIS has built-in self-healing that works independently of this system:

- **Worker Process Recovery:** When a w3wp process crashes, IIS automatically spawns a new one within seconds. A single crash is silently recovered.
- **Rapid Fail Protection:** If a worker process crashes **5 times within 5 minutes** (default), IIS **disables the app pool entirely**. The pool stays stopped and HTTP.sys serves 503 responses with Reason `AppOffline`. The auto-healing system detects this via the `IISHttpErrors` ADX table (>= 3 AppOffline rows in 7 min) and classifies it as `app_pool_stopped`.

The auto-healing system's alert thresholds are designed to detect problems that go **beyond** IIS's built-in recovery -- repeated crashes, sustained resource exhaustion, or services that stay down. This is why some scenarios require triggering the fault multiple times to cross the alert threshold.

### Recommended Test Order

Start with deterministic (fast, predictable) scenarios, then move to AI scenarios. This order gives you progressively longer feedback loops.

---

### DETERMINISTIC PATH SCENARIOS

These skip AI entirely. The classify agent routes them straight to a runbook.

---

#### Scenario 1: App Pool Crash (Repeated Restarts)

| | |
|---|---|
| **What it does** | Calls `Environment.FailFast()` to crash the w3wp worker process. IIS auto-restarts the pool within seconds, so you must trigger this **3+ times within 10 minutes** to cross the alert threshold. |
| **Path** | Deterministic |
| **Expected runbook** | `Invoke-RecycleAppPool` |
| **Alert rule** | `ASP.NET Application Restarts > 2 in 10 min` (evaluates every 1 min) |
| **Detection time** | ~1-2 min after the 3rd crash (next evaluation cycle after threshold is breached) |
| **Recovery time** | 10-30 seconds after runbook executes |

> **Why multiple crashes?** IIS automatically restarts a crashed worker process within seconds (see [Understanding IIS Auto-Recovery](#understanding-iis-auto-recovery) above). A single crash self-heals silently. The alert detects a **pattern of instability** (3+ crashes in 10 minutes), which signals a systemic problem that simple auto-restart can't fix.

> **Bonus — triggering Rapid Fail Protection:** If you crash the app pool **5 times within 5 minutes**, IIS disables the pool entirely. The pool stays stopped, HTTP.sys serves 503 AppOffline responses, and the `app_pool_stopped` issue type fires via `IISHttpErrors` detection -- giving the agent a more severe, compounding scenario to remediate. See the **App Pool Stopped** scenario below.

**Steps:**
1. Open `http://<VM_IP>/chaos/default.aspx`
2. Find **#1 App Pool Crash**, check the confirmation box, click **Trigger Fault**
3. The page responds with a success message, then the w3wp process crashes ~1.5 seconds later
4. Wait ~5 seconds for IIS to auto-restart the pool, then **reload the Chaos Console page**
5. **Repeat steps 2-4 two more times** (3 total crashes within 10 minutes)
6. After the 3rd crash, the `ASP.NET Application Restarts > 2` alert should fire within 1-2 minutes
7. Monitor: Azure Portal > **Monitor** > **Alerts** -- look for a **Fired** alert named `iisheal-alert-aspnet-restarts`
8. Once the alert fires, check **Automation Account > Jobs** for a completed `Invoke-RecycleAppPool` job
9. Check Log Analytics for the AgentEvents_CL record (see KQL section below)

---

#### Scenario 2: W3SVC Stop

| | |
|---|---|
| **What it does** | Stops the W3SVC (World Wide Web Publishing) service. All IIS sites go offline. |
| **Path** | Deterministic |
| **Expected runbook** | `Invoke-RestartW3SVC` |
| **Detection** | `Send-PerfToEventHub.ps1` injects a synthetic `Current Connections = 0` row each cycle when W3SVC is not running. IISMonitorPoller requires `RowCount >= 3` to fire (3 consecutive 60s cycles). |
| **Detection time** | ~3-4 min (3 synthetic heartbeats × 60s + ADX ingestion lag + next poller tick) |
| **Recovery time** | 15-30 seconds after runbook executes |

> **Why synthetic heartbeats?** When W3SVC stops, Windows unregisters the `\Web Service` performance counter object entirely -- it doesn't return 0, it disappears. Without the synthetic row, no data flows for `Current Connections` and the breach KQL never fires. See `docs/w3svc_stopped_flow.md` for the full end-to-end trace.

**Steps:**
1. Trigger **#2 W3SVC Stop** from the Chaos Console
2. Note: after triggering, the Chaos Console itself will become unreachable (IIS is down)
3. Try `http://<VM_IP>/` -- it should fail to connect
4. Wait ~4-5 minutes total for detection and remediation (3 min for 3 synthetic heartbeats + pipeline execution)
5. Refresh `http://<VM_IP>/` until it comes back
6. Validate: Automation Account shows `Invoke-RestartW3SVC` job completed

**Important:** Since IIS is fully down after this fault, the Chaos Console is also down. You can only observe recovery by refreshing the home page externally.

---

#### Scenario 2b: App Pool Stopped (Rapid-Fail Protection)

| | |
|---|---|
| **What it does** | When the app pool crashes **5 times within 5 minutes**, IIS rapid-fail protection permanently stops the pool. HTTP.sys serves 503 AppOffline for every request. This scenario triggers automatically when you crash the app pool enough times (see Scenario 1). |
| **Path** | Deterministic |
| **Expected runbook** | `Invoke-RecycleAppPool` (calls `Start-WebAppPool` to restart the stopped pool) |
| **Detection** | `IISMonitorPoller` queries the `IISHttpErrors` ADX table for 503 responses with `Reason == "AppOffline"`. Fires when >= 3 AppOffline rows appear in the 7-min look-back window. |
| **Detection time** | ~3-4 min after rapid-fail engages (AppOffline rows accumulate as clients hit the stopped pool) |
| **Recovery time** | 10-30 seconds after runbook executes |

> **How this differs from app_pool_crash:** `app_pool_crash` detects a *pattern of instability* (repeated restarts). `app_pool_stopped` detects the *permanent stop* that happens after rapid-fail protection kicks in. Once rapid-fail is engaged, the `Application Restarts` counter stops incrementing (no more restarts can occur), so `app_pool_crash` detection goes silent. `app_pool_stopped` is the only live signal at that point.

**Steps:**
1. Trigger **#1 App Pool Crash** from the Chaos Console **5+ times within 5 minutes**
2. After the 5th crash, IIS rapid-fail protection stops the pool permanently
3. All requests should return 503 errors (the Chaos Console becomes unreachable)
4. Wait ~4-5 minutes for `IISMonitorPoller` to detect AppOffline 503 rows in `IISHttpErrors`
5. Refresh `http://<VM_IP>/` until it comes back
6. Validate: Automation Account shows `Invoke-RecycleAppPool` job completed with the pool restarted
7. Check AgentEvents_CL -- `IssueType` should be `app_pool_stopped`

---

#### Scenario 5: Log Disk Full

| | |
|---|---|
| **What it does** | Writes a 2 GB file (`chaos_fill.dat`) to `C:\inetpub\logs`, filling the C: drive. |
| **Path** | Deterministic |
| **Expected runbook** | `Invoke-ClearIISLogs` |
| **Detection time** | < 2 minutes (C: Drive Free < 5% alert) |
| **Recovery time** | 30-60 seconds |

**Steps:**
1. Trigger **#5 Log Disk Full** from the Chaos Console
2. This one takes longer to detect because the file needs to finish writing and the metric evaluation window is longer
3. Wait 2-3 minutes
4. Check Automation Account for `Invoke-ClearIISLogs` job
5. (Optional) RDP into the VM and check `C:\inetpub\logs` -- the chaos_fill.dat and old log files should be cleaned up

---

#### Scenario 7: HTTP Binding Removal

| | |
|---|---|
| **What it does** | Removes all port 80 HTTP bindings from the Default Web Site. Site becomes unreachable. |
| **Path** | Deterministic |
| **Expected runbook** | `Invoke-FixBindings` |
| **Detection** | IISMonitorPoller detects via `Connection Attempts Failed > 50` in the 7-min look-back window, or synthetic heartbeat rows (connections = 0) if W3SVC stays running. |
| **Detection time** | ~3-4 min |
| **Recovery time** | 15-30 seconds after runbook executes |

**Steps:**
1. Trigger **#7 HTTP Binding Removal** (note: the Chaos Console will become unreachable after this)
2. Try `http://<VM_IP>/` -- should fail
3. Wait ~4-5 minutes for IISMonitorPoller detection and pipeline execution
4. Refresh until the home page returns
5. Validate: Automation Account shows `Invoke-FixBindings` job completed

---

#### Scenario 6: App Pool Identity Corruption

| | |
|---|---|
| **What it does** | Sets DefaultAppPool identity to an invalid user (`INVALID\BadUser`). Pool fails on next start. |
| **Path** | Deterministic |
| **Expected runbook** | `Invoke-FixAppPoolIdentity` |
| **Detection time** | < 15 seconds |
| **Recovery time** | 15-30 seconds |

**Steps:**
1. Trigger **#6 App Pool Identity Corruption**
2. The pool will fail on next restart -- you may not see immediate impact until the pool recycles
3. If the site starts returning 503s, the corruption is active
4. Wait for auto-healing
5. Validate: Automation Account shows `Invoke-FixAppPoolIdentity` job completed

---

#### Scenario 9: Bad File Permissions

| | |
|---|---|
| **What it does** | Removes `IIS_IUSRS` read access from `C:\inetpub\wwwroot`. Requests return 401/500 errors. |
| **Path** | Deterministic |
| **Expected runbook** | `Invoke-FixPermissions` |
| **Detection time** | < 10 seconds |
| **Recovery time** | 15-30 seconds |

**Steps:**
1. Trigger **#9 Bad File Permissions**
2. Refresh `http://<VM_IP>/` -- expect 401 or 500 errors
3. Wait for auto-healing
4. Validate: Automation Account shows `Invoke-FixPermissions` job completed

---

### AI PATH SCENARIOS

These require Azure OpenAI to analyze telemetry and reason about the fix. They take longer but you should see richer incident records in AgentEvents_CL (with root_cause and next_steps populated).

---

#### Scenario 3: High CPU

| | |
|---|---|
| **What it does** | Spawns tight `Math.Sqrt` loops on all CPU cores for 90 seconds. w3wp CPU spikes to ~100%. |
| **Path** | Deterministic (with post-remediation `det_diagnose` o4-mini analysis) |
| **Expected runbook** | `Invoke-RecycleAppPool` (kills the runaway w3wp, IIS starts a fresh worker) |
| **Detection** | IISMonitorPoller checks `HighSamples >= 2` (at least 2 data points with CPU > 85% in the 7-min window) |
| **Detection time** | ~2-3 min (sustained spike across 2+ collection cycles + ingestion lag + poller tick) |
| **Recovery time** | 10-30 seconds after runbook executes |

> **Why deterministic, not AI?** The alert threshold already confirmed the CPU breach. The chaos spike lasts ~90 seconds -- by the time the AI path's `ai_detect` re-validates against live ADX data, the spike has already resolved and gets mis-classified as a false positive. The deterministic path ensures the app pool is always recycled. After successful remediation, `det_diagnose` still runs o4-mini against 30 minutes of VMPerf + IISPerf telemetry to produce a root cause analysis and preventive recommendations.

**Steps:**
1. Trigger **#3 High CPU**
2. You can watch CPU in real time: Azure Portal > iisheal-vm > Monitoring > Metrics > select **Percentage CPU**
3. Wait ~3-4 minutes for IISMonitorPoller to detect the sustained breach and trigger healing
4. Validate: Automation Account shows `Invoke-RecycleAppPool` job
5. Check AgentEvents_CL -- the `RootCause` field should mention the CPU spike, `ReasoningModel` should be `o4-mini` (from the `analyze` node), `Strategy` should be `mechanical`, and `DecisionAction` should be `remediate`

---

#### Scenario 4: Memory Leak

| | |
|---|---|
| **What it does** | Pins 200 MB of byte arrays in memory using GCHandle. w3wp working set grows and stays high. |
| **Path** | AI |
| **Expected runbook** | `Invoke-RecycleAppPool` |
| **Detection time** | ~5 minutes (w3wp Working Set > 1.5 GB alert -- may need to trigger multiple times to reach threshold) |
| **Recovery time** | 30-60 seconds |

**Steps:**
1. Trigger **#4 Memory Leak**
2. Note: a single trigger allocates 200 MB. The alert threshold is 1.5 GB, so you may need to trigger this 4-6 times to cross the threshold, or wait if existing memory pressure is already high
3. Monitor via: Azure Portal > iisheal-vm > Monitoring > Metrics > **Process(w3wp)\Working Set** (under IISPerf custom metrics), or RDP and check Task Manager
4. Wait for the alert to fire and the pipeline to process
5. Validate: Automation Account shows `Invoke-RecycleAppPool`
6. Check AgentEvents_CL for baseline comparison in the analysis

---

#### Scenario 8: Request Queue Flood

| | |
|---|---|
| **What it does** | Spawns 300 threads each holding an HTTP connection open for 30 seconds. ASP.NET request queue fills up. |
| **Path** | AI |
| **Expected runbook** | `Invoke-RecycleAppPool` |
| **Detection time** | ~1-2 minutes (ASP.NET Requests Queued > 100 alert) |
| **Recovery time** | 30-60 seconds |

**Steps:**
1. Trigger **#8 Request Queue Flood**
2. The site may become slow or return 503 for ~30 seconds while threads are active
3. Wait for the alert and pipeline
4. Validate: Automation Account shows `Invoke-RecycleAppPool`

---

#### Scenario 10: Worker Process Hang

| | |
|---|---|
| **What it does** | Sets a flag so the next GET request to the chaos page hangs indefinitely via `Thread.Sleep(MaxValue)`. The w3wp thread count climbs. |
| **Path** | AI |
| **Expected runbook** | `Invoke-RestartWorkerProcess` |
| **Detection time** | ~5 minutes (w3wp Thread Count > 200 alert) |
| **Recovery time** | 30-60 seconds |

**Steps:**
1. Trigger **#10 Worker Process Hang** (this POST sets a flag -- the hang itself happens on the *next* GET)
2. Open `http://<VM_IP>/chaos/default.aspx` in a new tab -- this request will hang
3. The hung thread ties up a worker; subsequent requests may queue, gradually increasing thread count
4. Wait for the alert threshold to be reached and the pipeline to process
5. Validate: Automation Account shows `Invoke-RestartWorkerProcess`

**Note:** This scenario can be slow to trigger the alert because a single hung thread may not be enough. If thread count doesn't reach 200, combine it with Scenario #8 (request queue flood) to push thread count higher.

---

## 6. Validating Results in Azure Portal

After each scenario, check these resources in order.

### 6a. IISMonitorPoller Logs (Detection)

**Where:** Azure Portal > `iisheal-func` > **Log stream** (under Monitoring)

Detection is handled by `IISMonitorPoller` (a timer function that queries ADX every 60 seconds), not Azure Monitor alert rules. Look for these log lines:

- `Poll complete — metrics are within normal thresholds` (normal, no issues)
- `Breaches detected: ['w3svc_stopped']` (breach found, healing will trigger)
- `Cooldown active — Xs remaining, skipping poll.` (healing recently triggered, waiting)
- `Triggering healing — issue_type=... url=...` (POST sent to orchestrator)
- `No data found in VMPerf or IISPerf...` (telemetry pipeline may be down -- investigate `Send-PerfToEventHub.ps1`)

### 6b. Function App Logs (Invocation History)

**Where:** Azure Portal > `iisheal-func` > **Functions** > **IISHealingOrchestrator** > **Monitor**

- Each healing run appears as an invocation
- Click an invocation to see: HTTP status code, duration, and logs
- Successful healing returns HTTP 200
- Look for log lines like:
  - `ClassifyAgent: alert='...' -> issue_type='...' path='deterministic|ai'`
  - `Incrementing retry_count to 1` (if a retry occurred)
  - `Healing complete -- outcome=success healthy=True duration=XX.Xs`

**For streaming logs:** Go to `iisheal-func` > **Log stream** (under Monitoring) and watch in real time while you trigger a fault.

### 6c. Automation Account Jobs

**Where:** Azure Portal > `iisheal-automation` > **Jobs** (under Process Automation)

- Each remediation attempt creates a job
- Columns to check: **Runbook name**, **Status** (Completed/Failed), **Start time**, **Duration**
- Click into a job and go to the **Output** tab to see the structured result from the runbook:
  - `Success: True/False`
  - `Action: <what was done>`
  - `Detail: <specifics>`
  - `ErrorMessage: <if failed>`

### 6d. Log Analytics -- AgentEvents_CL

**Where:** Azure Portal > `iisheal-law` > **Logs**

This is the most detailed validation. Each completed healing run writes one record to `AgentEvents_CL`. See the KQL section below for specific queries.

### 6e. Log Analytics -- AgentErrors_CL

**Where:** Same as above

If something went wrong during the pipeline, error records appear here. Always check this after a failed or partially-failed run:
```kql
AgentErrors_CL
| where TimeGenerated > ago(1h)
| project TimeGenerated, AgentName_s, ErrorType_s, ErrorMessage_s, RetryCount_d
| order by TimeGenerated desc
```

### 6f. VM Metrics (for AI path scenarios)

**Where:** Azure Portal > `iisheal-vm` > **Monitoring** > **Metrics**

Useful for watching CPU/memory scenarios in real time:
- **Metric namespace:** Virtual Machine Host
- **Metric:** Percentage CPU, Available Memory Bytes
- **Time range:** Last 30 minutes
- **Granularity:** 1 minute

For IIS-specific metrics (request rate, queue length, worker set size), query the **IISPerf** table in ADX -- see section 7.

### 6g. Azure Data Explorer (ADX) -- Telemetry Tables

**Where:** Azure Portal > `iis-core-monitor` resource group > `iishealadx` > **Query**

Select the **`{prefix}-db`** database. ADX stores the raw telemetry that the AI agents query during analysis:

| ADX Table | Contents | Source |
|-----------|----------|--------|
| **VMPerf** | VM performance counters (CPU %, available memory, disk) | `Send-PerfToEventHub.ps1` → Event Hub → ADX |
| **IISPerf** | IIS/ASP.NET counters (requests/sec, queue length, w3wp working set, threads) | `Send-PerfToEventHub.ps1` → Event Hub → ADX |
| **IISLogs** | Raw W3C log lines (staging table — auto-parsed into IISLogsParsed) | DCR → Event Hub → ADX |
| **IISLogsParsed** | Parsed W3C fields (StatusCode, UriStem, TimeTakenMs, ClientIP, etc.) | Auto-populated via ADX update policy from IISLogs |
| **PerformanceBaseline** | Baseline snapshots + summary (Snapshot/Summary records per capture) | `Invoke-CaptureBaseline` → `baseline-eh` → ADX |

> **LAW vs ADX:** Log Analytics Workspace stores *agent pipeline output* (AgentEvents_CL, AgentErrors_CL) and receives perf counters for *alert rule evaluation* (standard `Perf` table via DCR). ADX stores *all telemetry* used by the AI agents: raw counters (`VMPerf`, `IISPerf`), IIS logs (`IISLogs` → auto-parsed into `IISLogsParsed` via update policy), and baseline data (`PerformanceBaseline`). Both receive performance data, but they serve different purposes.

---

## 7. KQL Queries for Validation

Run these in **Azure Portal > iisheal-law > Logs**.

### See all healing events from the last hour

```kql
AgentEvents_CL
| where TimeGenerated > ago(1h)
| project
    TimeGenerated,
    IssueType_s,
    IssueSummary_s,
    RunbookExecuted_s,
    RemediationOutcome_s,
    RootCause_s,
    TotalDurationSeconds_d
| order by TimeGenerated desc
```

### Check if a specific scenario was healed

Replace `w3svc_stopped` with the issue type from the scenario table:

```kql
AgentEvents_CL
| where TimeGenerated > ago(1h)
| where IssueType_s == "w3svc_stopped"
| project
    TimeGenerated,
    RemediationOutcome_s,
    RunbookExecuted_s,
    RootCause_s,
    NextSteps_s,
    TotalDurationSeconds_d
```

**Issue type reference for queries:**

| Scenario | Issue Type |
|----------|-----------|
| #1 App Pool Crash | `app_pool_crash` |
| #2 W3SVC Stop | `w3svc_stopped` |
| #2b App Pool Stopped | `app_pool_stopped` |
| #3 High CPU | `high_cpu_w3wp` or `high_cpu` |
| #4 Memory Leak | `memory_leak` |
| #5 Log Disk Full | `log_disk_full` |
| #6 Identity Corruption | `app_pool_identity` |
| #7 Binding Removal | `binding_missing` |
| #8 Request Queue Flood | `request_queue_flood` |
| #9 Bad Permissions | `bad_permissions` |
| #10 Worker Hang | `worker_process_hang` |

### Check for errors during healing

```kql
AgentErrors_CL
| where TimeGenerated > ago(1h)
| project TimeGenerated, AgentName_s, ErrorType_s, ErrorMessage_s, StackTrace_s
| order by TimeGenerated desc
```

### Check if retries occurred

If `RetryCount` is > 0, the system retried with `Invoke-RestartIIS` as a fallback:

```kql
AgentEvents_CL
| where TimeGenerated > ago(1h)
| where RetryCount_d > 0
| project TimeGenerated, IssueType_s, RetryCount_d, RunbookExecuted_s, RemediationOutcome_s
```

### Verify telemetry is flowing -- LAW (sanity check)

Run in **Azure Portal > `iisheal-law` > Logs**:
```kql
Perf
| where TimeGenerated > ago(10m)
| summarize Count=count() by bin(TimeGenerated, 1m)
| order by TimeGenerated desc
```

### See baseline data (used by AI path)

Run in **Azure Portal > `{prefix}adx` > Query** (select `{prefix}-db`):
```kql
PerformanceBaseline
| where RecordType == "Summary"
| summarize arg_max(TimeGenerated, CaptureId) by MetricName
| project MetricName, MetricValue, CaptureId, TimeGenerated
| order by MetricName asc
```

If this returns 0 rows, the baseline hasn't been captured yet. AI path scenarios will still work but without baseline comparison context. Run `scripts/run_baseline.sh` alongside `scripts/load_test.sh` to capture a baseline (takes 60 minutes).

---

### ADX Queries (Telemetry Used by AI Agents)

Run these in **Azure Portal > `{prefix}adx` > Query** (select the `{prefix}-db` database).

> These are the same tables the AI detection and verification agents query at runtime. Use them to see exactly what the AI sees.

### Verify ADX telemetry is flowing

```kql
VMPerf
| where TimeGenerated > ago(10m)
| summarize Count=count() by bin(TimeGenerated, 1m)
| order by TimeGenerated desc
```

### Check VM perf counters (CPU, memory, disk)

```kql
VMPerf
| where TimeGenerated > ago(30m)
| where CounterName in ("% Processor Time", "Available MBytes", "% Free Space")
| summarize avg(CounterValue) by bin(TimeGenerated, 1m), CounterName
| order by TimeGenerated desc
```

### Check IIS perf counters (requests, queue, worker process)

```kql
IISPerf
| where TimeGenerated > ago(30m)
| where CounterName in ("Requests / Sec", "Requests Queued", "Working Set")
| summarize avg(CounterValue) by bin(TimeGenerated, 1m), CounterName
| order by TimeGenerated desc
```

### Check IIS access logs for errors

```kql
IISLogsParsed
| where TimeGenerated > ago(30m)
| where StatusCode >= 500
| summarize ErrorCount=count() by bin(TimeGenerated, 1m), StatusCode
| order by TimeGenerated desc
```

### See the latest counter value (same query the AI agents use)

Replace `<counter>` with `% Processor Time`, `Working Set`, `Requests Queued`, etc.:
```kql
VMPerf
| where CounterName == "<counter>"
| order by TimeGenerated desc
| take 1
| project TimeGenerated, Computer, CounterName, CounterValue
```

---

## 8. Automated Test Scripts

Two scripts are available for batch testing. Both are in the `scripts/` directory.

### test_chaos.sh -- Trigger All 10 Scenarios Interactively

```bash
# Set the VM IP (or let the script auto-discover from the deployment)
export VM_PUBLIC_IP=<VM_IP>

bash scripts/test_chaos.sh
```

This walks you through each scenario one at a time. It POSTs to the Chaos Console for you and pauses between scenarios so you can verify healing before proceeding.

### validate_agent.sh -- System Health Validation

```bash
bash scripts/validate_agent.sh
```

This checks:
1. LAW agent table row counts (AgentEvents_CL, AgentErrors_CL)
2. ADX baseline summary existence (PerformanceBaseline table)
3. Function App health endpoint
4. Automation Account recent job history
5. Azure OpenAI deployment status
6. ADX telemetry ingestion (VMPerf, IISPerf, IISLogs, IISLogsParsed row counts)

Run this before and after testing to confirm the system is healthy.

---

## 9. Troubleshooting

### IISMonitorPoller detected a breach but no Automation job appeared

- Check the Function App **Log stream** for errors after the `Triggering healing` log line
- The IISHealingOrchestratorInternal HTTP call may have failed -- look for `Failed to trigger healing:` log lines
- The classify agent may have classified the issue differently than expected -- check for `ClassifyAgent:` log output
- If you see `Cooldown active`, a previous healing run is still in cooldown (5 minutes). Wait for it to expire.
- Check Function App > **Diagnose and solve problems** for platform-level errors

### Function App ran but no Automation job appeared

- The classify agent may have classified the issue differently than expected. Check Function App logs for the `ClassifyAgent:` log line to see what `issue_type` and `path` were selected
- For AI path scenarios, the detection agent may have flagged the alert as a false positive (e.g., metrics had already recovered before the pipeline ran). Check AgentEvents_CL for `RemediationOutcome_s == "skipped"` or similar

### Automation job ran but IIS didn't recover

- Check the job **Output** in the Automation Account for error details
- The Hybrid Worker may have lost connectivity to the VM -- check Automation Account > Hybrid Worker Groups to confirm the worker is online
- The runbook may have succeeded but the underlying issue persisted -- the system retries up to 2 times, escalating to `Invoke-RestartIIS` on retry

### AgentEvents_CL has no records

- Data ingestion to custom tables can have a delay of 1-5 minutes in Log Analytics
- Check AgentErrors_CL for ingestion failures
- Verify the DCE (Data Collection Endpoint) is reachable: Azure Portal > `iis-core-monitor` > `iisheal-dce`

### AI path scenario completed too fast (< 5 seconds)

- The classify agent may have routed it down the deterministic path. Check the `remediation_path` in Function App logs
- If the detection agent marked it as invalid (false positive), the pipeline skips to report immediately

### Healing never triggers after injecting a fault

- **Don't panic too early.** IISMonitorPoller runs every 60 seconds, and data takes ~90 seconds to become queryable in ADX. Wait at least 3-4 minutes before investigating. See [How Detection Timing Works](#how-detection-timing-works) above.
- **Check cooldown.** If a previous healing run triggered recently, the 5-minute cooldown blocks new triggers. Look for `Cooldown active` in the Function App log stream.
- **IIS auto-recovery may mask the fault.** For Scenario #1 (App Pool Crash), IIS automatically restarts the worker process within seconds. A single crash won't fire the alert -- you need **3+ crashes within 10 minutes**. See the scenario details above.
- **Threshold might not be reached.** For Scenario #4 (Memory Leak), each trigger allocates 200 MB but the alert threshold is 1.5 GB. Trigger it **4-6 times** to cross the threshold.
- Check that telemetry is flowing in ADX (run in Azure Portal > `{prefix}adx` > Query):
  ```kql
  union
    (VMPerf  | where TimeGenerated > ago(10m) | count | project Source="VMPerf", n=Count),
    (IISPerf | where TimeGenerated > ago(10m) | count | project Source="IISPerf", n=Count)
  ```
- If ADX counts are 0, `Send-PerfToEventHub.ps1` may not be running on the VM. RDP in and check the scheduled task, or check Event Hub message counts in the portal.

### The Chaos Console itself is unreachable

- Some scenarios (2, 7) take IIS fully offline, so the Chaos Console goes down too. This is expected. Wait for auto-healing to restore IIS, then the console will be accessible again.
- If the Chaos Console doesn't come back after 5 minutes, the auto-healing may have failed. RDP into the VM and run `iisreset /restart` manually, then investigate what went wrong.

---

## Appendix: Full Scenario Quick Reference

| # | Scenario | Path | Issue Type | Expected Runbook | Detection | Wait Time |
|---|----------|------|-----------|-----------------|-----------|-----------|
| 1 | App Pool Crash (**trigger 3x**) | Deterministic | `app_pool_crash` | Invoke-RecycleAppPool | ASP.NET Restarts sum > 2 in 7 min | ~2-3 min after 3rd crash |
| 2 | W3SVC Stop | Deterministic | `w3svc_stopped` | Invoke-RestartW3SVC | 3 synthetic heartbeat rows (RowCount >= 3) | ~3-4 min |
| 2b | App Pool Stopped (**trigger crash 5x in 5 min**) | Deterministic | `app_pool_stopped` | Invoke-RecycleAppPool | >= 3 AppOffline 503 rows in IISHttpErrors | ~3-4 min |
| 3 | High CPU | Deterministic + det_diagnose | `high_cpu_w3wp` | Invoke-RecycleAppPool | HighSamples >= 2 (CPU > 85%) | ~2-3 min |
| 4 | Memory Leak (trigger 4-6x) | AI | `memory_leak` | Invoke-RecycleAppPool | w3wp Working Set avg > 1.5 GB | ~2-3 min |
| 5 | Log Disk Full | Deterministic | `log_disk_full` | Invoke-ClearIISLogs | % Free Space avg < 5% | ~2-3 min |
| 6 | Identity Corruption | Deterministic | `app_pool_identity` | Invoke-FixAppPoolIdentity | Failed connections or IIS down | ~3-4 min |
| 7 | Binding Removal | Deterministic | `binding_missing` | Invoke-FixBindings | Failed connections or IIS down | ~3-4 min |
| 8 | Request Queue Flood | AI | `request_queue_flood` | Invoke-RecycleAppPool | ASP.NET Requests Queued avg > 100 | ~2-3 min |
| 9 | Bad Permissions | Deterministic | `bad_permissions` | Invoke-FixPermissions | Failed connections or 404 rate | ~2-3 min |
| 10 | Worker Process Hang | AI | `worker_process_hang` | Invoke-RestartWorkerProcess | w3wp Thread Count avg > 200 | ~2-3 min |
