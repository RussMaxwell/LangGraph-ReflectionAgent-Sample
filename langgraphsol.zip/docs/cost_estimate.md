# IIS Auto-Healing System -- Monthly Cost Estimate

## Resource Cost Breakdown

| Resource | SKU/Tier | Monthly Cost (USD) | Notes |
|----------|----------|-------------------|-------|
| Virtual Machine | Standard_B2ms (2 vCPU, 8 GB RAM) | ~$60.74 | Windows Server 2022, Pay-as-you-go |
| OS Disk | 128 GB Premium SSD (P10) | ~$19.71 | Managed disk |
| Public IP | Static Standard | ~$3.65 | Regional IP |
| Log Analytics Workspace | PerGB2018, 30-day retention | ~$2.00 | AgentEvents_CL + AgentErrors_CL only (healing events, not continuous perf data) |
| Azure Data Explorer | Dev(No SLA)_Standard_D11_v2, 1 node | ~$60.00 | Dev SKU, 90-day retention (7-day hot cache) |
| Event Hub Namespace | Standard, 1 TU | ~$11.16 | 4 hubs (iislogs-eh, vmperf-eh, iisperf-eh, baseline-eh) |
| Azure OpenAI Service -- o4-mini | 10 TPM units, GlobalStandard | ~$2.50 | ~500 events x 2K input + 1K output tokens |
| Azure OpenAI Service -- gpt-4o-mini | 30 TPM units, GlobalStandard | ~$1.50 | ~500 events x 4 agents x 1K tokens avg |
| Function App | B1 App Service Plan (Linux) | ~$13.14 | Always-on |
| Storage Account | Standard LRS | ~$0.50 | Function App storage |
| IISMonitorPoller cooldown (Table Storage) | Standard LRS | ~$0.01 | Negligible -- small cooldown state table |
| Automation Account | Free tier (500 min/month) | $0.00 | Hybrid Worker included |
| Data Collection Endpoint | -- | $0.00 | Included with LAW |
| Data Collection Rules (3) | -- | $0.00 | No per-rule fees |
| Network (VNet, NSG, Subnet) | -- | $0.00 | Free resources |

## Monthly Total

| Category | Cost |
|----------|------|
| Compute (VM) | $60.74 |
| Storage (Disk + Storage Account) | $20.21 |
| Networking (Public IP) | $3.65 |
| Monitoring (LAW healing events only) | ~$2.00 |
| Azure Data Explorer (Dev SKU) | $60.00 |
| Event Hubs (Standard, 1 TU) | $11.16 |
| AI (Azure OpenAI) | $4.00 |
| App Hosting (Function App) | $13.14 |
| **Total Estimated Monthly Cost** | **~$175.00** |

## Cost Savings from Refactor

The original architecture used 15 Azure Monitor scheduledQueryRules for anomaly detection. These carry an evaluation fee of approximately $4.20/rule/month, which was not reflected in earlier cost estimates.

| Item | Old Architecture | New Architecture |
|------|-----------------|-----------------|
| Anomaly detection | 15 scheduledQueryRules (~$63/month) | IISMonitorPoller timer function (~$0) |
| Action Group | HTTP webhook (free, but required) | Eliminated |
| LAW ingestion | ~3 GB/month perf data + healing events (~$6.90) | Healing events only (~$2.00) |
| **Monitoring subtotal** | **~$69.90/month** | **~$2.00/month** |

The true before-refactor monthly cost was approximately **$244/month** (including the $63/month in scheduledQueryRule evaluation fees that were not captured in the original estimate). The refactored architecture brings this to **~$175/month**, a reduction of approximately **$69/month**.

IISMonitorPoller runs as a timer-triggered Azure Function (included in the existing B1 App Service Plan) and queries ADX directly -- no per-query alert evaluation charges apply.

## Dev vs Prod SKU Comparison

The ADX cluster is the largest variable. In dev the system uses the no-SLA Dev SKU; production would use a Standard SKU:

| Component | Dev (current) | Prod |
|-----------|--------------|------|
| ADX Cluster | Dev(No SLA)_Standard_D11_v2, 1 node -- ~$60/mo | Standard_D11_v2, 2 nodes -- ~$450/mo |
| Event Hub | Standard, 1 TU -- ~$11/mo | Standard, 2 TU -- ~$22/mo |
| VM | Standard_B2ms -- ~$61/mo | Standard_D2s_v3 or higher |
| **Estimated Total** | **~$175/mo** | **~$560+/mo** |

## VM SKU Confirmation

- **SKU:** Standard_B2ms
- **Specs:** 2 vCPUs, 8 GB RAM, 16 GB temp storage
- **Monthly cost:** ~$60.74 (East US, Windows, Pay-as-you-go)
- **Requirement:** VM cost under $120/month -- **CONFIRMED** ($60.74 < $120)
- **Memory requirement:** At least 8 GB -- **CONFIRMED** (8 GB)

## Azure OpenAI Token Estimate

Assuming ~500 healing events per month. Deterministic-path events (estimated 60-70% of volume) consume zero tokens **except** for performance issues (`high_cpu`, `high_cpu_w3wp`), which trigger a single o4-mini `det_diagnose` call for post-remediation root cause analysis. Estimated ~50-75 det_diagnose calls/month at ~2K input + 1K output tokens each.

### DetDiagnoseAgent (deterministic path, performance issues only)

| Agent | Model | Events | Avg Input Tokens | Avg Output Tokens | Monthly Tokens |
|-------|-------|--------|-----------------|-------------------|---------------|
| DetDiagnoseAgent | o4-mini | 75 | 2,000 | 1,000 | 225K |

This is a small additional cost (~$0.30/month) on top of the AI-path estimates below.

### AI-path events only (~200/month, worst case)

| Agent | Model | Events | Avg Input Tokens | Avg Output Tokens | Monthly Tokens |
|-------|-------|--------|-----------------|-------------------|---------------|
| DetectionAgent | gpt-4o-mini | 200 | 800 | 200 | 200K |
| AnalysisAgent | o4-mini | 200 | 2,000 | 1,000 | 600K |
| RemediationAgent | gpt-4o-mini | 200 | 600 | 200 | 160K |
| VerificationAgent | gpt-4o-mini | 200 | 500 | 200 | 140K |
| RCAAgent | o4-mini | 200 | 2,000 | 1,000 | 600K |
| ReportingAgent | gpt-4o-mini | 200 | 1,000 | 500 | 300K |

Total: ~2M tokens/month -- well within provisioned capacity.

### Conservative estimate (all 500 events via AI path)

| Agent | Model | Events | Avg Input Tokens | Avg Output Tokens | Monthly Tokens |
|-------|-------|--------|-----------------|-------------------|---------------|
| DetectionAgent | gpt-4o-mini | 500 | 800 | 200 | 500K |
| AnalysisAgent | o4-mini | 500 | 2,000 | 1,000 | 1.5M |
| RemediationAgent | gpt-4o-mini | 500 | 600 | 200 | 400K |
| VerificationAgent | gpt-4o-mini | 500 | 500 | 200 | 350K |
| RCAAgent | o4-mini | 500 | 2,000 | 1,000 | 1.5M |
| ReportingAgent | gpt-4o-mini | 500 | 1,000 | 500 | 750K |

Total: ~5M tokens/month -- still within capacity even at maximum load.

## Cost Optimization Notes

1. **ADX Dev SKU** has no SLA and is suitable for PoC/demo. It is the single largest cost-saving measure (~$390/mo savings vs Standard).
2. **Deterministic path** routes 60-70% of common incidents without Azure OpenAI calls (except performance issues which get a single o4-mini `det_diagnose` call), keeping AI costs under $4.50/month.
3. **IISMonitorPoller** eliminates all scheduledQueryRule evaluation fees by running KQL queries inside the existing Function App timer trigger. No Azure Monitor alert rules are deployed.
4. **Event Hub Standard tier** at 1 TU handles the ingestion volume for a single VM. Scale TUs if adding more VMs.
5. **VM could be deallocated** during non-demo periods to save the ~$61/month compute cost (disk charges still apply).
