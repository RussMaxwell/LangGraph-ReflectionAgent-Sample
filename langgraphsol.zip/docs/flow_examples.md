# IIS Auto-Healing — Flow Examples (v3)

Three end-to-end traces through the single-path pipeline, picked to cover the
full range of behaviours:

1. **`w3svc_stopped`** — mechanical, no LLM, no analyze. Fast restore.
2. **`high_cpu`** — mechanical fix, o4-mini RCA post-fix. The classic "fix
   first, explain after" path.
3. **`http_5xx_flood` (Oracle backend slow)** — reasoned-with-veto. Judge
   refuses to recycle because the cause is downstream.

The graph topology is the same for all three. What differs is the
`IssueProfile` each picks up at `classify` time and therefore what each node
does.

---

## Example 1 — `w3svc_stopped` (mechanical, fast path)

### Trigger

`IISMonitorPoller` detects three consecutive synthetic
`Current Connections = 0` rows in ADX `IISPerf` (the heartbeat signal written
by `Send-PerfToEventHub.ps1` when `W3SVC` is stopped). It POSTs to
`IISHealingOrchestratorInternal`:

```
{ "issue_type": "w3svc_stopped",
  "issue_summary": "IIS Current Connections = 0 for 3 consecutive windows" }
```

### Flow

```
┌─────────────┐
│  classify   │  search_text matches "iis current connections"
│             │  issue_type       = "w3svc_stopped"
│             │  issue_profile    = PROFILES["w3svc_stopped"]
│             │    • gatherers    = (SERVICE_STATE,)
│             │    • strategy     = MECHANICAL
│             │    • default      = Invoke-RestartW3SVC
│             │    • escalation   = Invoke-RestartIIS
│             │    • confirmation = (HTTP_OK,)
│             │    • analyze      = False
└──────┬──────┘  (no LLM)
       ▼
┌─────────────┐
│   gather    │  runs one gatherer:
│             │    SERVICE_STATE → HTTP GET http://<vm>/default.aspx
│             │                    → {status_code: 0, is_healthy: False}
│             │  evidence = { "service_state": {status_code:0, ...} }
└──────┬──────┘  (no LLM)
       ▼
┌─────────────┐
│   judge     │  strategy == MECHANICAL, retry_count == 0
│             │  decision_action    = "remediate"
│             │  decision_runbook   = "Invoke-RestartW3SVC"
│             │  decision_reasoning = "Mechanical issue 'IIS W3SVC...'; alert
│             │                       threshold confirms the breach; running
│             │                       known-safe runbook Invoke-RestartW3SVC."
│             │  decision_confidence = "high"
└──────┬──────┘  (no LLM)
       ▼
┌─────────────┐
│    act      │  start_runbook("Invoke-RestartW3SVC", {...})
│             │  Hybrid Worker executes Stop-Service / Start-Service W3SVC
│             │  Automation job status = "Completed"
│             │  remediation_outcome = "success"
│             │  remediation_runbook = "Invoke-RestartW3SVC"
└──────┬──────┘  (no LLM)
       ▼
┌─────────────┐
│  confirm    │  runs profile.confirmation:
│             │    HTTP_OK → status 200
│             │  is_healthy = True
└──────┬──────┘  (no LLM)
       ▼
┌─────────────┐
│  analyze    │  profile.analyze == False → skipped (no-op)
└──────┬──────┘
       ▼
┌─────────────┐
│ summarize   │  writes AgentEvents_CL row:
│             │    IssueType            = "w3svc_stopped"
│             │    DecisionAction       = "remediate"
│             │    RunbookExecuted      = "Invoke-RestartW3SVC"
│             │    RemediationOutcome   = "success"
│             │    IsHealthy            = true
│             │    ReasoningModel       = "none"
│             │    FastModel            = "none"
│             │    RootCause            = "Known issue type 'w3svc_stopped'
│             │                            handled via mechanical strategy..."
└──────┬──────┘  (no LLM)
       ▼
      END
```

### Totals

- **LLM calls:** 0
- **Runbooks executed:** 1 (`Invoke-RestartW3SVC`)
- **Wall time (typical):** 60–90 s (dominated by Automation job polling)

### What if restart fails

If `confirm` returns `is_healthy = False` and `retry_count < 2`:

```
confirm (unhealthy) → retry (count=1) → judge → act
```

`judge` sees `retry_count == 1` and returns the profile's
`escalation_runbook = "Invoke-RestartIIS"` without an LLM call. `act` runs
`iisreset /restart`. If that fails too (`retry_count == 2`), the pipeline
falls through to `analyze` with `is_healthy = False`. Since
`profile.analyze == False`, analyze is skipped and `summarize` records the
failure.

---

## Example 2 — `high_cpu` (mechanical fix + deep RCA)

### Trigger

`IISMonitorPoller` detects `VMPerf` `% Processor Time > 85` for sustained
windows. POST:

```
{ "issue_type": "high_cpu",
  "issue_summary": "% Processor Time avg=91.2 (threshold: 85)" }
```

### Flow

```
classify  →  issue_type = "high_cpu"
             profile.gatherers    = (ADX_VM_PERF_30M, ADX_IIS_PERF_30M, BASELINE)
             profile.strategy     = MECHANICAL
             profile.default      = Invoke-RecycleAppPool
             profile.confirmation = (HTTP_OK,)
             profile.analyze      = True
  ▼
gather    →  runs three gatherers IN PARALLEL:
               • ADX_VM_PERF_30M  → ~2000 rows of counter values
               • ADX_IIS_PERF_30M → ~2000 rows (w3wp CPU, requests, etc.)
               • BASELINE         → BaselineSummary (p50/p95/p99)
             evidence dict now has all three slots
  ▼
judge     →  MECHANICAL, retry_count == 0
             decision_action   = "remediate"
             decision_runbook  = "Invoke-RecycleAppPool"
             decision_reasoning = "Mechanical issue 'VM CPU critically high';
                                   alert threshold confirms the breach; running
                                   known-safe runbook Invoke-RecycleAppPool."
  ▼
act       →  runbook recycles DefaultAppPool
             runaway w3wp process killed
             fresh w3wp starts, serves HTTP 200
             remediation_outcome = "success"
  ▼
confirm   →  HTTP_OK → 200 → is_healthy = True
  ▼
analyze   →  profile.analyze == True, RUNS
             Reads the SAME evidence dict gather built (VMPerf 30m,
             IISPerf 30m, baseline) plus the act/confirm outcomes.
             Calls o4-mini with ~14KB of truncated evidence and a prompt
             asking for timeline + root cause + next_steps.

             Produces:
               analysis_result = "Between 10:14 and 10:19 UTC, CPU climbed from
                                  ~35% to sustained 91-94%, correlated with a
                                  3x increase in ASP.NET Requests/sec on the
                                  /api/orders endpoint. w3wp working set grew
                                  in lockstep, suggesting a cache-miss storm
                                  after the 10:12 deployment cold-start..."
               root_cause     = "Cold-start cache misses in the order-lookup
                                  path following the 10:12 deployment drove
                                  sustained CPU > 85%. The pool recycle
                                  restored healthy CPU; the pattern will
                                  recur on next deploy without a cache
                                  warmup."
               next_steps     = ["Add a cache-warmup script to deployment",
                                  "Monitor first-15-min CPU after every deploy",
                                  "Consider increasing pool ping limits",
                                  "Review cache eviction policy", ... ]
  ▼
summarize →  writes AgentEvents_CL with full RCA
             ReasoningModel = "o4-mini"
             FastModel      = "none"  (judge was mechanical)
             DecisionAction = "remediate"
```

### Totals

- **LLM calls:** 1 (o4-mini in analyze)
- **Runbooks executed:** 1 (`Invoke-RecycleAppPool`)
- **Wall time (typical):** 90–150 s

### What changed vs v2

In v2, `det_diagnose` produced the RCA, but only for three hardcoded issue
types, only if `det_verify` returned healthy, and only on the deterministic
path. In v3, `analyze` runs for any profile with `analyze: True` — including
failed-fix cases (where the RCA is arguably more valuable). The control lives
in the profile row, not in edge-function frozensets.

---

## Example 3 — `http_5xx_flood` with Oracle backend slowness (veto)

**Note:** `http_5xx_flood` detection is a forward-looking profile. The
pipeline will run the flow below once `IISMonitorPoller` emits this
issue_type. The `Invoke-CaptureIncidentDiagnostics` runbook referenced by the
`CAPTURE_*` gatherers is likewise a forward dependency.

### Trigger (future)

`IISMonitorPoller` detects `IISLogsParsed` 5xx rate exceeding threshold for
multiple windows. POST:

```
{ "issue_type": "http_5xx_flood",
  "issue_summary": "5xx rate 18% over last 5 min (threshold: 5%)" }
```

### Flow

```
classify  →  issue_type = "http_5xx_flood"
             profile.strategy     = REASONED_WITH_VETO
             profile.default      = Invoke-RecycleAppPool
             profile.confirmation = (HTTP_OK, FIVE_XX_RATE_BELOW)
             profile.analyze      = True
             profile.escalation_target = "oncall_webhook"
  ▼
gather    →  parallel:
               • ADX_IIS_LOGS_30M    → recent 5xx-heavy request log rows
               • ADX_IIS_PERF_30M    → worker process + request queue metrics
               • ADX_HTTP_ERRORS_7M  → HTTPERR reason codes (timeouts?)
               • BASELINE            → normal operating range
               (future) CAPTURE_EVENT_LOG    → ASP.NET exceptions
               (future) CAPTURE_NETSTAT      → outbound connection state
               (future) CAPTURE_REQUEST_QUEUE → currently-stuck requests
  ▼
judge     →  REASONED_WITH_VETO, gpt-4o-mini call
             Prompt contains evidence showing:
               - 247 established outbound connections to 10.20.30.40:1521
                 (Oracle listener)
               - low local CPU (~8%) + high w3wp thread count (~180)
               - Stuck requests all hit /api/orders/* with time-elapsed 25-29s
               - HTTPERR showing Timer_ResponseReceived
               - (future) captured event log showing OracleException
                 ORA-12170 TNS timeouts

             LLM returns:
               decision_action    = "escalate_only"
               decision_runbook   = ""
               decision_reasoning = "Evidence shows saturated outbound
                                     connections to Oracle listener with
                                     thread-pool exhaustion. Recycling the
                                     app pool would not fix downstream DB
                                     latency and may worsen impact via cold
                                     connection re-establishment. Recommend
                                     human investigation of Oracle."
               decision_confidence = "high"
  ▼
act       →  action == "escalate_only" → skips runbook
             remediation_runbook = ""
             remediation_outcome = "escalated"
             remediation_detail  = "Judge decision: escalate_only. ...
                                    Escalation target: oncall_webhook
                                    No runbook executed; recycling would not
                                    fix an upstream cause."
  ▼
confirm   →  (skipped — orchestrator routes escalate_only directly to analyze)
  ▼
analyze   →  profile.analyze == True, RUNS
             o4-mini reads the full evidence dict + judge's decision.
             Produces a detailed RCA naming Oracle as the likely cause,
             listing next steps (query Oracle wait events, check DBA
             dashboards, etc.).
  ▼
summarize →  writes AgentEvents_CL:
               DecisionAction     = "escalate_only"
               RunbookExecuted    = ""
               RemediationOutcome = "escalated"
               IsHealthy          = false   (service is still degraded,
                                             but that's the DBA's problem)
               EscalationTarget   = "oncall_webhook"
               RootCause          = "Oracle backend timeouts causing ASP.NET
                                     thread-pool exhaustion..."
               ReasoningModel     = "o4-mini"
               FastModel          = "gpt-4o-mini"
```

### Totals

- **LLM calls:** 2 (gpt-4o-mini in judge, o4-mini in analyze)
- **Runbooks executed:** 0
- **Paging destination:** `oncall_webhook` (delivery itself is out-of-scope
  for the healing pipeline — `summarize` records the intent)

### Why the veto matters

Without `REASONED_WITH_VETO`, the pipeline would have recycled the pool and
the failure would have repeated in seconds — cold connection pool back to
Oracle, same slowness, same 5xx flood. The veto is what lets the system say
*"this isn't my job to fix"* based on evidence, preserving service state for
DBAs to investigate and avoiding counterproductive churn.

---

## Reading these traces in production

The `AgentEvents_CL` table in Log Analytics gets one row per pipeline run.
Two KQL queries cover the common operator needs:

```kql
// All events in the last 24 hours, newest first
AgentEvents_CL
| where TimeGenerated > ago(24h)
| project TimeGenerated, IssueType, DecisionAction, RunbookExecuted,
          RemediationOutcome, IsHealthy, RootCause
| order by TimeGenerated desc
```

```kql
// Vetoes and escalations over the last 7 days
AgentEvents_CL
| where TimeGenerated > ago(7d)
| where DecisionAction in ("escalate_only", "remediate_and_escalate")
| project TimeGenerated, IssueType, DecisionAction, EscalationTarget,
          RootCause, NextSteps
| order by TimeGenerated desc
```

If a decision looks wrong, the full judge reasoning is preserved in
`RemediationDetail`; the evidence that drove it is preserved in whatever the
gatherers wrote (live ADX queries can re-fetch most of it for the same time
window).
