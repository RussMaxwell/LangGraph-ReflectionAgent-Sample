# IIS Auto-Healing System -- Load Testing Guide

This guide explains how to generate realistic external user traffic against the IIS VM while capturing a performance baseline. The load test script simulates unique concurrent users so that IIS W3C logs, ADX telemetry, and baseline metrics reflect genuine multi-user activity.

---

## Table of Contents

1. [Why Load Test During Baseline](#1-why-load-test-during-baseline)
2. [Prerequisites](#2-prerequisites)
3. [Quick Start](#3-quick-start)
4. [Running Baseline + Load Test Together](#4-running-baseline--load-test-together)
5. [Script Reference](#5-script-reference)
6. [Verifying Unique Users in ADX](#6-verifying-unique-users-in-adx)
7. [VM Capacity and Safe Limits](#7-vm-capacity-and-safe-limits)
8. [Tuning the Load Profile](#8-tuning-the-load-profile)
9. [Troubleshooting](#9-troubleshooting)

---

## 1. Why Load Test During Baseline

Performance data flows continuously from the VM to ADX via `Send-PerfToEventHub.ps1` (a scheduled task that runs every 60 seconds, pushing counters to Event Hub → ADX `VMPerf` and `IISPerf` tables). This happens whether or not a baseline capture is running.

The baseline capture script (`scripts/run_baseline.sh`) triggers the `Invoke-CaptureBaseline` runbook, which reads those same counters over a fixed window (default 60 minutes) and produces a **baseline summary** -- aggregated statistics (avg, p50, p95, p99 for CPU, memory, request rate, response time, etc.) that get written to the `PerformanceBaseline` table in ADX (via `baseline-eh` Event Hub). The AI agents compare this summary against live ADX telemetry during incident analysis to detect deviations.

The baseline does **not** generate any traffic on its own. To get meaningful summary statistics, you need real traffic hitting the server while the capture window is open. That's where `scripts/load_test.sh` comes in. It runs from your workstation and generates realistic external user traffic so that both the ADX telemetry stream and the baseline summary reflect real-world conditions.

Each virtual user has:

- A **sticky user-agent** (assigned per session, not randomized per request -- real users don't switch browsers)
- A **unique session ID** (GUID in the `X-Session-ID` header and `sid` query param)
- A **realistic referrer** (Google, Bing, LinkedIn, direct, email, etc.)
- A **cookie jar** (IIS sees a persistent session per user)
- An **Accept-Language header** (15 locale variants)
- **Human-like pacing** (3-8 second random delays between requests)

This means IIS logs show distinct user sessions, and ADX queries can differentiate users by user-agent, session ID, and referrer source.

> **Note:** The baseline runbook (`Invoke-CaptureBaseline`) accepts a `VirtualUsers` parameter that defaults to `0`. If set to a value > 0, it will also spawn localhost load generators on the VM. `run_baseline.sh` always passes `VirtualUsers=0` so that all traffic comes from the external load test.

---

## 2. Prerequisites

- [ ] Bash shell (Git Bash on Windows, or WSL, or macOS/Linux terminal)
- [ ] `curl` installed (built-in on Windows 10+, macOS, Linux)
- [ ] `bc` installed (built-in on macOS/Linux; on Git Bash for Windows, may need to install or skip -- the script falls back gracefully)
- [ ] Network access to the VM's public IP on port 80 (NSG must allow your IP)
- [ ] The VM public IP address

Get the VM public IP:
```bash
az vm list-ip-addresses \
  --resource-group iis-core \
  --name iisheal-vm \
  --query "[0].virtualMachine.network.publicIpAddresses[0].ipAddress" \
  --output tsv
```

---

## 3. Quick Start

The fastest way to run a load test:

```bash
# Set the VM IP
export VM_PUBLIC_IP=<your-vm-ip>

# Run with defaults: 20 users, 60 minutes
bash scripts/load_test.sh
```

That's it. The script will:
1. Verify connectivity to the VM
2. Ramp up 20 virtual users over 30 seconds
3. Print a summary every 30 seconds
4. Save a CSV of all requests to a temp directory
5. Print a final summary on completion or Ctrl+C

---

## 4. Running Baseline + Load Test Together

For the best baseline data, run both scripts simultaneously. The baseline captures server-side metrics while the load test provides external traffic.

### Step-by-step

**Terminal 1 -- Start the baseline capture:**
```bash
cd iis-autohealing/
bash scripts/run_baseline.sh
```
This triggers the `Invoke-CaptureBaseline` runbook via Azure Automation. It runs for 60 minutes on the VM, sampling performance counters every 60 seconds and producing a `PerformanceBaseline` summary record in ADX (via `baseline-eh` Event Hub) at the end.

**Terminal 2 -- Start the external load test:**
```bash
cd iis-autohealing/
export VM_PUBLIC_IP=<your-vm-ip>
bash scripts/load_test.sh -u 20 -d 60
```
This generates 20 concurrent external users for 60 minutes, matching the baseline duration.

### Recommended timeline

```
00:00  Start baseline (Terminal 1)
00:01  Start load test (Terminal 2) -- give baseline ~1 min head start
01:00  Both finish naturally
01:05  Verify data in ADX (see section 6)
```

### What each piece does

| Component | Runs On | Purpose | Data Destination |
|-----------|---------|---------|-----------------|
| `Send-PerfToEventHub.ps1` | VM (scheduled task, always running) | Streams raw perf counters every 60s | ADX `VMPerf` + `IISPerf` (via Event Hub) |
| `run_baseline.sh` | VM (via Automation runbook) | Captures counter snapshots over 60 min, produces aggregated summary | ADX `PerformanceBaseline` (via `baseline-eh` Event Hub) |
| `load_test.sh` | Your workstation | Generates external HTTP traffic so counters reflect real-world load | N/A (traffic only) |

All telemetry lives in ADX. The scheduled task streams raw counters continuously. The baseline adds per-capture snapshots (one row per metric per 60s window) and a summary record the AI agents compare against during incident analysis. The load test provides the traffic that makes both data streams meaningful.

Each baseline run is tagged with a unique `CaptureId` (GUID) so you can query all data from a specific capture.

Run `run_baseline.sh` and `load_test.sh` for the same duration (default 60 minutes).

---

## 5. Script Reference

### Usage

```
scripts/load_test.sh [OPTIONS]
```

### Options

| Flag | Default | Description |
|------|---------|------------|
| `-t, --target IP` | `$VM_PUBLIC_IP` | VM public IP address |
| `-u, --users N` | `20` | Number of concurrent virtual users |
| `-d, --duration MIN` | `60` | Test duration in minutes |
| `-r, --ramp-up SEC` | `30` | Seconds to stagger user launch (avoids thundering herd) |
| `--min-delay SEC` | `3` | Minimum pause between requests per user |
| `--max-delay SEC` | `8` | Maximum pause between requests per user |
| `-o, --output DIR` | Auto-created in `/tmp` | Directory for CSV logs and summary |
| `-q, --quiet` | Off | Only show periodic summaries, not per-request lines |
| `-h, --help` | | Show help |

### Environment variables

| Variable | Maps To |
|----------|---------|
| `VM_PUBLIC_IP` | `--target` |
| `LOAD_TEST_USERS` | `--users` |
| `LOAD_TEST_DURATION` | `--duration` |
| `LOAD_TEST_RAMP_UP` | `--ramp-up` |

### Output files

| File | Description |
|------|------------|
| `requests.csv` | Every request: timestamp, user ID, UA tag, referrer, session ID, HTTP status, response time (ms), response size |
| `summary.txt` | Final summary: totals, success rate, user count, session count |
| `cookies_userN.txt` | Cookie jar per virtual user (IIS session persistence) |

### Examples

```bash
# Quick 5-minute smoke test with 5 users
bash scripts/load_test.sh -t 40.70.240.95 -u 5 -d 5

# Heavy load: 50 users for 60 minutes, quiet mode, custom output dir
bash scripts/load_test.sh -u 50 -d 60 -q -o ./load_test_results

# Match baseline defaults exactly
bash scripts/load_test.sh -u 20 -d 60 -r 30

# Fast ramp, short delay (higher request rate per user)
bash scripts/load_test.sh -u 30 -d 15 -r 5 --min-delay 1 --max-delay 3
```

---

## 6. Verifying Unique Users in ADX

After the load test completes (or during the run), verify that ADX captured the distinct user sessions. Run these queries in **Azure Portal > `iis-core-monitor` > `{prefix}adx` > Query** (select `{prefix}-db`).

> **Note:** These queries use the `IISLogsParsed` table, which is auto-populated from the raw `IISLogs` staging table via an ADX update policy. `IISLogsParsed` provides pre-parsed W3C fields (Method, UriStem, StatusCode, UserAgent, TimeTakenMs, etc.) so you don't need to parse RawData manually.

### Count distinct users by user-agent in IIS logs

```kql
IISLogsParsed
| where TimeGenerated > ago(70m)
| where UriStem == "/default.aspx" or UriStem == "/"
| summarize
    RequestCount = count(),
    DistinctUserAgents = dcount(UserAgent)
```

### Break down traffic by user-agent family

```kql
IISLogsParsed
| where TimeGenerated > ago(70m)
| where UriStem == "/default.aspx" or UriStem == "/"
| extend BrowserFamily = case(
    UserAgent has "Edg/", "Edge",
    UserAgent has "Firefox/", "Firefox",
    UserAgent has "Safari/" and UserAgent !has "Chrome/", "Safari",
    UserAgent has "OPR/", "Opera",
    UserAgent has "Vivaldi/", "Vivaldi",
    UserAgent has "Brave/", "Brave",
    UserAgent has "Chrome/", "Chrome",
    UserAgent has "Trident/", "IE",
    "Other"
)
| summarize Requests = count() by BrowserFamily
| order by Requests desc
```

### Show request volume over time

```kql
IISLogsParsed
| where TimeGenerated > ago(70m)
| where UriStem == "/default.aspx" or UriStem == "/"
| summarize Requests = count() by bin(TimeGenerated, 1m)
| render timechart
```

### See unique session IDs

```kql
IISLogsParsed
| where TimeGenerated > ago(70m)
| where UriStem == "/default.aspx" or UriStem == "/"
| where UriQuery has "sid="
| parse UriQuery with * "sid=" session_id "&" *
| summarize
    Requests = count(),
    FirstSeen = min(TimeGenerated),
    LastSeen = max(TimeGenerated)
    by session_id
| order by Requests desc
| take 50
```

### Referrer source distribution

```kql
IISLogsParsed
| where TimeGenerated > ago(70m)
| where UriStem == "/default.aspx" or UriStem == "/"
| where UriQuery has "ref="
| parse UriQuery with * "ref=" ref_source "&" *
| summarize Requests = count() by ref_source
| order by Requests desc
| render piechart
```

### Response time percentiles

```kql
IISLogsParsed
| where TimeGenerated > ago(70m)
| where UriStem == "/default.aspx" or UriStem == "/"
| summarize
    Requests = count(),
    AvgMs = avg(TimeTakenMs),
    P50Ms = percentile(TimeTakenMs, 50),
    P95Ms = percentile(TimeTakenMs, 95),
    P99Ms = percentile(TimeTakenMs, 99),
    MaxMs = max(TimeTakenMs)
```

---

## 7. VM Capacity and Safe Limits

The dev environment runs on a **Standard_B2ms** (2 vCPUs, 8 GB RAM, burstable). This section explains how the load test interacts with the VM so you can choose safe user counts.

### What happens per request on the server

The root page (`default.aspx`) intentionally performs work to produce realistic baseline metrics:

| Work | CPU Cost | Memory | Wall Clock |
|------|----------|--------|------------|
| SHA-256 x5 on 50 KB payload | ~5-10 ms | ~50 KB transient | ~10 ms |
| Build 500-row DataTable + bind | ~10-20 ms | ~2-3 MB transient (GC'd) | ~15 ms |
| `Thread.Sleep(150)` | 0 (holds thread, no CPU) | ~1 MB thread stack | 150 ms |
| 20 GUIDs + event log (every 10th) | Negligible | Negligible | ~1 ms |
| **Total per request** | **~15-30 ms CPU** | **~3 MB peak (transient)** | **~175-200 ms** |

The 150 ms sleep is the dominant cost -- it holds an IIS thread but uses zero CPU.

### What else is running on the VM

| Process | Typical CPU | Memory |
|---------|-------------|--------|
| IIS w3wp (idle) | ~2-5% | ~200-400 MB |
| Azure Monitor Agent (AMA) | ~2-3% | ~150-200 MB |
| Send-PerfToEventHub.ps1 (every 60 s) | ~5% spike for ~2 s | ~50 MB |
| Hybrid Runbook Worker | ~1% | ~100 MB |
| OS and services | ~5% | ~1.5-2 GB |
| **Total baseline (no traffic)** | **~15-20%** | **~2-3 GB of 8 GB** |

### Safe user limits for Standard_B2ms

| Users | Req/s | Est. CPU | Est. Concurrent Requests | Verdict |
|-------|-------|----------|--------------------------|---------|
| 5 | ~0.9 | ~20% | ~0.2 | Safe -- smoke test |
| **20** | **~3.6** | **~25-30%** | **~0.7** | **Safe -- recommended for baseline** |
| 50 | ~9.1 | ~40-55% | ~1.8 | Safe -- moderate stress |
| 80 | ~14.5 | ~60-70% | ~2.9 | Caution -- monitor for queue buildup |
| 100+ | ~18+ | ~75%+ | ~3.6+ | Risk of 503s as IIS thread pool saturates |

> **Why 20 users is the sweet spot:** At 3.6 req/s the VM sits around 25-30% CPU total, leaving plenty of headroom for the monitoring agents, the Event Hub telemetry task, and OS activity. The ADX telemetry and baseline summary both capture data under a realistic workload without risking alerts from the auto-healing system itself.

---

## 8. Tuning the Load Profile

### How many users should I run?

| Goal | Users | Duration | Notes |
|------|-------|----------|-------|
| Smoke test (verify setup) | 5 | 5 min | Quick check that traffic appears in ADX |
| Baseline capture (standard) | 20 | 60 min | Matches baseline duration, recommended for B2ms |
| Stress test (find limits) | 50 | 15-30 min | Watch for 503s and queue buildup |
| Sustained soak | 10-15 | 4-8 hours | Long-running stability check |

### Request rate math

Each user makes one request every 3-8 seconds (average 5.5 s). So:

| Users | Requests/min | Requests/hour |
|-------|-------------|---------------|
| 5 | ~55 | ~3,270 |
| 20 | ~218 | ~13,090 |
| 50 | ~545 | ~32,727 |
| 100 | ~1,091 | ~65,454 |

### Adjusting pacing

For higher throughput per user without adding more users:
```bash
# 1-2 second delays = ~40 requests/min/user
bash scripts/load_test.sh -u 20 --min-delay 1 --max-delay 2
```

For gentler, more realistic browsing patterns:
```bash
# 5-15 second delays = ~6 requests/min/user (casual browsing)
bash scripts/load_test.sh -u 20 --min-delay 5 --max-delay 15
```

### Scaling to a larger VM

If you move to a larger SKU (e.g., Standard_D2s_v3 or Standard_D4s_v3 with 4 vCPUs / 16 GB), you can safely increase the user count. The bottleneck is the IIS thread pool, not raw CPU -- the 150 ms `Thread.Sleep` per request means each thread is occupied regardless of available cores. Note: the B2ms is burstable -- sustained high CPU may deplete burst credits and throttle performance.

---

## 9. Troubleshooting

### "ERROR: returned HTTP 000. Is the VM running?"

- The VM is unreachable. Check that it's running and your IP is in the NSG allow rule.
- If you just deployed, the NSG only allows the deployer's IP. Update it:
  ```bash
  az network nsg rule update \
    --resource-group iis-core \
    --nsg-name iisheal-nsg \
    --name Allow-HTTP \
    --source-address-prefixes "<your-ip>"
  ```

### Lots of HTTP 503 errors

- You're overwhelming IIS. Reduce `--users` or increase `--min-delay`.
- Check if the app pool has crashed: `http://<VM_IP>/chaos/default.aspx` status panel.

### CSV shows 000 status codes

- curl couldn't connect at all. This is usually a network timeout -- the VM may be overloaded or the NSG is blocking.

### `bc: command not found` warnings

- Git Bash on Windows may not include `bc`. The script falls back to basic math but summary percentages may show `?` instead of values. Install `bc` via your package manager or ignore the warnings -- the CSV data is still accurate.

### No data in ADX IISLogs after the test

- IIS W3C log flushing can lag by 1-5 minutes. Wait and re-query.
- Check that the DCR for IIS logs is configured: Azure Portal > `iis-core-monitor` > Data Collection Rules.
- Verify the Event Hub is receiving data: Azure Portal > `iis-core-monitor` > Event Hub namespace > Overview > Messages chart.

### Response times seem high (> 500 ms)

- Each request has a built-in 150 ms `Thread.Sleep` in the page code-behind, so ~200 ms is the minimum expected server-side time. Add network round-trip on top and 250-400 ms is normal.
- If you see times > 1 s consistently, the VM may be under heavy load. Check CPU in Azure Portal > `iisheal-vm` > Metrics, or reduce `--users`.
- Response times in the CSV are measured client-side (includes network). The ADX `IISLogsParsed` `TimeTakenMs` field is server-side only.
