# IIS Auto-Healing System -- Executive Summary

**Author:** Russell M.
**Date:** April 2026
**Status:** Proof of Concept -- Complete

---

## The Problem

IIS production incidents -- application pool crashes, service outages, memory leaks, disk pressure -- typically require an on-call engineer to be paged, log in, diagnose the issue, run the fix, and verify recovery. Even straightforward problems carry a **15-to-45-minute mean time to resolution (MTTR)** once you factor in alert fatigue, context switching, and manual triage. During business hours that pulls engineers off project work; after hours it degrades quality of life and drives attrition.

## The Solution

The **IIS Auto-Healing System** is an AI-driven, fully automated incident response pipeline built on Azure-native services. When a performance anomaly or service failure is detected, the system classifies the alert, determines the safest remediation path, executes the fix, verifies recovery, performs root-cause analysis, and logs a complete incident record -- all **without human intervention**, typically in **under 90 seconds**.

### How It Works (30-Second Version)

```
IISMonitorPoller queries ADX every 60 seconds
        |
        v
Breach detected → HTTP POST to IISHealingOrchestratorInternal
        |
        v
AI agents classify the alert and pick the right fix
        |
        v
PowerShell runbook executes the fix on the server
        |
        v
System verifies the server is healthy again
        |
        v
Root-cause analysis and full incident report logged automatically
```

---

## Key Design Decisions

### Dual-Path Architecture

Not every incident needs AI reasoning. The system uses an intelligent routing layer that classifies each alert into one of two paths:

| Path | When Used | How It Works |
|------|-----------|--------------|
| **Deterministic** (no AI) | Known, low-risk issues (e.g., IIS service stopped, app pool crash/stop, disk full, CPU spikes) | Direct rule-based lookup -- selects the correct runbook and executes immediately. Fast, predictable, zero token cost. Performance issues (CPU) get a post-remediation o4-mini root cause analysis while remaining on the deterministic path. |
| **AI-Assisted** | Complex or ambiguous issues (e.g., memory leaks, request queue floods, worker hangs) | AI agents query 30 minutes of telemetry, compare against a captured performance baseline, reason about the root cause, and select the appropriate remediation. |

This dual-path approach keeps the system **fast and cost-efficient** for routine incidents while reserving AI reasoning for cases that genuinely need it.

### Built-in Safety

- **Maximum 2 retries** per incident. If the initial fix doesn't resolve the issue, the system escalates to a full IIS restart. If that also fails, it logs the failure for human follow-up rather than continuing to retry.
- **Verification after every fix.** The system performs HTTP health checks and metric validation before declaring an incident resolved.
- **No secrets in code.** All authentication uses Azure Managed Identity and RBAC -- no API keys, no connection strings, no credential rotation burden.

---

## What the System Handles

The system responds to **16 distinct alert conditions** covering the full IIS health surface:

| Category | Alert Conditions |
|----------|-----------------|
| **CPU** | VM CPU > 85%, w3wp CPU > 80%, processor queue depth > 10 |
| **Memory** | Available memory < 512 MB, committed > 90%, w3wp working set > 1.5 GB, excessive paging |
| **IIS Service** | IIS connections drop to zero, failed connections > 50, app pool restarts > 2, app pool stopped by rapid-fail protection (503 AppOffline) |
| **Application** | ASP.NET request queue > 100, w3wp thread count > 200, HTTP 404 spike |
| **Disk** | C: drive free space < 5%, disk queue length > 5 |

Each condition maps to one of **11 purpose-built PowerShell remediation runbooks**, from targeted app pool recycles to full IIS restarts.

---

## Technology Stack

| Component | Technology | Role |
|-----------|-----------|------|
| Orchestration | **LangGraph** (Python 3.12) on Azure Functions | Multi-agent pipeline coordination |
| AI Reasoning | **Azure OpenAI** (o4-mini + gpt-4o-mini) | Alert analysis, root-cause diagnosis |
| Execution | **Azure Automation** (Hybrid Runbook Worker) | PowerShell remediation on the server |
| Telemetry | **Azure Data Explorer** | Real-time and historical metric queries (6 ADX tables) |
| Monitoring | **IISMonitorPoller** (timer function, 60s) | ADX-based anomaly detection across all 16 conditions |
| Streaming | **Event Hubs** (4 hubs) | Performance counter + IIS log + baseline ingestion to ADX |
| Healing event logs | **Log Analytics** (AgentEvents_CL, AgentErrors_CL) | Structured incident records and agent error tracking |
| Infrastructure | **Bicep** (Infrastructure as Code) | Fully reproducible, one-command deployment |

All components are Azure-native, deployed via a single `deploy.sh` script, and torn down cleanly with `teardown.sh`.

---

## Agent Pipeline

The system is built as a **multi-agent pipeline** where each agent has a focused responsibility:

| Step | Agent | What It Does |
|------|-------|--------------|
| 1 | **Classify** | Routes the alert to the deterministic or AI path based on the alert rule name |
| 2 | **Detect / Analyze** | (AI path) Validates the alert against live telemetry and captured baselines to filter false positives |
| 3 | **Remediate** | Selects and executes the appropriate PowerShell runbook via Azure Automation |
| 4 | **Verify** | Confirms the server is healthy through HTTP checks and metric thresholds |
| 5 | **Diagnose / RCA** | Generates a structured root cause analysis. On the deterministic path, `det_diagnose` runs o4-mini for CPU/performance issues; on the AI path, `ai_rca` synthesises the full incident timeline |
| 6 | **Report** | Logs the full incident record to Log Analytics for audit and trend analysis |

---

## Cost Profile

The system runs at approximately **$175/month** in Azure (dev SKU):

| Category | Monthly Cost |
|----------|-------------|
| Compute (VM) | $60.74 |
| Azure Data Explorer (Dev SKU) | $60.00 |
| App Hosting (Function App) | $13.14 |
| Event Hubs (Standard, 1 TU) | $11.16 |
| Storage (Disk + Storage Account) | $20.21 |
| Monitoring (Log Analytics for healing events only) | ~$2.00 |
| AI (Azure OpenAI) | $4.00 |
| Networking | $3.65 |
| **Total** | **~$175/month** |

The monitoring cost dropped from ~$8.40 to ~$2.00 after eliminating 15 Azure Monitor scheduledQueryRules (~$63/month in evaluation fees that were not captured in the original estimate). The true before-refactor cost was ~$244/month; the refactor reduced it to ~$175/month.

The AI cost is notably low ($4/month at ~500 events) because deterministic routing handles the most common incidents without consuming any tokens.

---

## Testing and Validation

The system includes a built-in **Chaos Engineering Console** -- a web application hosted on the IIS server that can inject 10 different fault scenarios on demand (app pool crashes, memory pressure, disk exhaustion, etc.). This allows the full pipeline to be tested end-to-end in a controlled environment.

All 17 automated validation checks pass, covering infrastructure compilation, code syntax, RBAC correctness, security (zero hardcoded secrets), and cross-component consistency.

---

## Potential Impact

| Metric | Before (Manual) | After (Auto-Healing) |
|--------|-----------------|---------------------|
| Mean Time to Resolution | 15--45 minutes | < 90 seconds |
| Engineer involvement per incident | Required | None (for known issues) |
| After-hours pages for routine issues | Frequent | Eliminated |
| Incident documentation | Inconsistent / manual | Automatic, structured, every time |
| False positive noise | Manual triage | Filtered by AI before any action |

---

## What This Demonstrates

1. **AI where it adds value, rules where they suffice.** The dual-path architecture avoids the common trap of using AI for everything. Simple problems get simple fixes; complex problems get intelligent analysis.

2. **End-to-end automation with guardrails.** The system doesn't just detect problems -- it fixes them, verifies the fix, explains the root cause, and documents everything. Built-in retry limits and escalation paths prevent runaway automation.

3. **Azure-native, production-grade patterns.** Managed Identity, RBAC, Infrastructure as Code, structured logging, and a clean separation of concerns. No shortcuts, no hardcoded credentials, no manual deployment steps. A single `deploy.sh` script automates everything including ADX table creation, PowerShell 7 installation, Hybrid Worker registration, and scheduled task setup.

4. **Low operational cost.** At ~$175/month (dev SKU), the system costs less than a single after-hours page when you factor in engineer time and context-switching overhead. The ADX Dev SKU (~$60/mo) is the largest single cost -- production would use a Standard SKU.

---

## Next Steps

- Extend to multi-server environments (scale-out to VM Scale Sets or multiple IIS hosts)
- Add Slack/Teams notification integration for resolved incidents
- Build a dashboard on top of AgentEvents_CL for incident trend visualization
- Evaluate for other workloads beyond IIS (SQL Server, custom Windows services)

---

*For technical details, see [architecture.md](architecture.md) and [cost_estimate.md](cost_estimate.md).*
