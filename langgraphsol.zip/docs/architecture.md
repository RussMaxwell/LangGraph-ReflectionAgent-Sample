# IIS Auto-Healing System -- Architecture Document

## Resource Groups

The system deploys across two resource groups:

| Resource Group | Purpose |
|---|---|
| `iis-core` | VM, networking, Function App |
| `iis-core-monitor` | LAW, ADX, Event Hubs, DCRs, Automation, OpenAI |

Subscription-scoped deployment via `infra/main.bicep`.

## Resource Map

### iis-core

| Resource | Type | SKU/Plan | Purpose |
|----------|------|----------|---------|
| {prefix}-vnet | Virtual Network | 10.0.0.0/16 | Network isolation |
| {prefix}-subnet | Subnet | 10.0.1.0/24 | VM subnet |
| {prefix}-nsg | Network Security Group | -- | Firewall rules |
| {prefix}-pip | Public IP | Static | VM public access |
| {prefix}-vm | Virtual Machine | Standard_B2ms | Windows Server 2022 + IIS |
| {prefix}-func-plan | App Service Plan | B1 Linux | Function App hosting |
| {prefix}-func | Function App | Python 3.12 | LangGraph dual-path orchestrator |
| {prefix}funcsa | Storage Account | Standard_LRS | Function App storage + cooldown table |

### iis-core-monitor

| Resource | Type | SKU/Plan | Purpose |
|----------|------|----------|---------|
| {prefix}-law | Log Analytics Workspace | PerGB2018 | Healing event logs (AgentEvents_CL, AgentErrors_CL) |
| {prefix}-dce | Data Collection Endpoint | -- | Custom table ingestion endpoint |
| {prefix}-dcr-iislogs | Data Collection Rule | -- | IIS W3C logs -> Event Hub |
| iisheal-dcr-agent-events | Data Collection Rule | -- | Function App -> LAW AgentEvents_CL |
| iisheal-dcr-agent-errors | Data Collection Rule | -- | Function App -> LAW AgentErrors_CL |
| {prefix}adx | Azure Data Explorer | Dev(No SLA)_Standard_D11_v2 | Fast telemetry queries (Kusto) |
| {prefix}-eh | Event Hub Namespace | Standard (1 TU) | Ingestion pipeline to ADX |
| {prefix}-openai | Azure OpenAI Service | S0 | AI reasoning (o4-mini + gpt-4o-mini) |
| {prefix}-auto | Automation Account | -- | Runbook execution via Hybrid Worker |

## Network Topology

```
┌──────────────────────────────────────────────────────────────────┐
│                     iis-core  Resource Group                     │
│                                                                  │
│  ┌──────────────────────────────────────────────────────────┐   │
│  │              VNet 10.0.0.0/16                             │   │
│  │  ┌──────────────────────────────────────────────────┐    │   │
│  │  │        Subnet 10.0.1.0/24                         │    │   │
│  │  │                                                   │    │   │
│  │  │  ┌─────────────────────────────────────────┐     │    │   │
│  │  │  │  Windows Server 2022 VM                  │     │    │   │
│  │  │  │  (Standard_B2ms — 2vCPU, 8GB)            │     │    │   │
│  │  │  │                                          │     │    │   │
│  │  │  │  ├─ IIS 10 (Default Web Site)            │     │    │   │
│  │  │  │  │  ├─ / (default.aspx)                  │     │    │   │
│  │  │  │  │  └─ /chaos/ (chaos engineering console)│     │    │   │
│  │  │  │  ├─ Hybrid Runbook Worker Agent          │     │    │   │
│  │  │  │  └─ Send-PerfToEventHub.ps1 (scheduled)  │     │    │   │
│  │  │  └─────────────────────────────────────────┘     │    │   │
│  │  └──────────────────────────────────────────────────┘    │   │
│  └──────────────────────────────────────────────────────────┘   │
│                                                                  │
│  NSG Rules:                                                      │
│  ├─ ALLOW TCP/80   FROM Internet                                 │
│  ├─ ALLOW TCP/3389 FROM <deployer IP>                            │
│  └─ DENY ALL ELSE INBOUND                                        │
│                                                                  │
│  ┌──────────────────────────────────────────────────────────┐   │
│  │  Function App (Python 3.12, B1 Linux)                     │   │
│  │                                                           │   │
│  │  IISHealingOrchestrator (HTTP, external)                  │   │
│  │  IISMonitorPoller (timer, 60s)                            │   │
│  │  IISHealingOrchestratorInternal (HTTP, internal)          │   │
│  │                                                           │   │
│  │  LangGraph Single-Path Orchestrator (v3)                   │   │
│  │  ├─ classify    (no LLM — alert text → IssueProfile)      │   │
│  │  ├─ gather      (no LLM — parallel evidence collection)   │   │
│  │  ├─ judge       (gpt-4o-mini — decides action)            │   │
│  │  ├─ act         (no LLM — executes runbook)               │   │
│  │  ├─ confirm     (no LLM — runs health checks)             │   │
│  │  ├─ analyze     (o4-mini — deep RCA on evidence)          │   │
│  │  └─ summarize   (no LLM — writes AgentEvents_CL)          │   │
│  │                                                           │   │
│  │  + IssueProfile registry (agents/profiles.py) — single    │   │
│  │    source of truth for per-issue behaviour                │   │
│  │                                                           │   │
│  │  Auth: Managed Identity + RBAC                            │   │
│  └──────────────────────────────────────────────────────────┘   │
└──────────────────────────────────────────────────────────────────┘

┌──────────────────────────────────────────────────────────────────┐
│                iis-core-monitor  Resource Group                   │
│                                                                  │
│  ┌──────────────┐  ┌───────────────┐  ┌──────────────────────┐  │
│  │ Log Analytics │  │ Azure OpenAI  │  │  Automation Account  │  │
│  │  Workspace    │  │   Service     │  │                      │  │
│  │              │  │               │  │  11 Runbooks         │  │
│  │ 2 Tables:    │  │ o4-mini       │  │  Hybrid Worker Group │  │
│  │ AgentEvents  │  │ gpt-4o-mini   │  │                      │  │
│  │ AgentErrors  │  │               │  │  Auth: MI+RBAC       │  │
│  │              │  │ Auth: MI+RBAC │  └──────────────────────┘  │
│  └──────────────┘  └───────────────┘                             │
│                                                                  │
│  ┌──────────────────────┐  ┌─────────────────────────────────┐  │
│  │  Event Hub Namespace  │  │  Azure Data Explorer Cluster    │  │
│  │  (Standard, 1 TU)    │  │  (Dev SKU, 1 node)              │  │
│  │                      │  │                                  │  │
│  │  iislogs-eh          │  │  Database: {prefix}-db           │  │
│  │  vmperf-eh           │  │  Tables: IISLogs, IISLogsParsed,│  │
│  │  iisperf-eh          │  │    VMPerf, IISPerf,             │  │
│  │  baseline-eh         │  │    PerformanceBaseline,         │  │
│  │                      │  │    IISHttpErrors                │  │
│  │                      │  │  Retention: 90d (hot: 7d)       │  │
│  │                      │  │                                  │  │
│  │  Auth: MI+RBAC       │  │  Auth: MI+RBAC                  │  │
│  └──────────────────────┘  └─────────────────────────────────┘  │
└──────────────────────────────────────────────────────────────────┘
```

## Data Flow Diagram

```
┌─────────────────────────────┐
│  Windows Server 2022 VM      │
│  Hybrid Worker               │
│  Send-PerfToEventHub.ps1     │
└──────┬──────────┬────────────┘
       │          │
       │          └─── DCR (dcr.bicep)
       │               IIS W3C log files
       │                      │
       │                      ▼
       │             ┌──────────────────┐
       │             │  iislogs-eh       │
       │             └────────┬─────────┘
       │                      │
       ├── vmperf-eh ◄─────────┤
       ├── iisperf-eh ◄────────┤  Send-PerfToEventHub.ps1
       │                      │  (perf counters every 60s)
       │                      │
       ▼                      ▼
┌────────────────────────────────────────┐
│           Event Hubs                   │
│  iislogs-eh / vmperf-eh / iisperf-eh  │
│  baseline-eh ◄── run_baseline.ps1      │
└───────────────┬────────────────────────┘
                │  ADX data connections
                ▼
┌──────────────────────────────────┐
│  Azure Data Explorer             │
│                                  │
│  IISLogs (staging)               │
│  IISLogsParsed (update policy)   │
│  VMPerf / IISPerf                │
│  PerformanceBaseline             │
└──────────────┬───────────────────┘
               │
               │  KQL queries every 60s (16 conditions)
               ▼
┌──────────────────────────────────┐
│  IISMonitorPoller                 │
│  (Timer trigger, NCRONTAB 60s)   │
│  Cooldown state: Table Storage   │
│  (healingcooldown table)         │
└──────────────┬───────────────────┘
               │ breach detected
               │ HTTP POST {"issue_type", "issue_summary"}
               ▼
┌──────────────────────────────────┐
│  IISHealingOrchestratorInternal  │
│  (HTTP trigger, internal)        │
│  Builds synthetic AlertPayload   │
└──────────────┬───────────────────┘
               │
               ▼
┌──────────────────────────────────────────────────────────────────┐
│  Function App (LangGraph Single-Path Orchestrator v3)            │
│                                                                  │
│  classify → gather → judge → act → confirm → analyze → summarize │
│                                                                  │
│  • classify  (no LLM)  alert → issue_type → IssueProfile         │
│  • gather    (no LLM)  runs profile.gatherers in parallel        │
│  • judge     (strategy-dependent)                                │
│       MECHANICAL          → no LLM                               │
│       REASONED            → gpt-4o-mini                          │
│       REASONED_WITH_VETO  → gpt-4o-mini (can refuse to remediate)│
│  • act       (no LLM)  executes the chosen runbook               │
│  • confirm   (no LLM)  runs profile.confirmation checks          │
│       on failure & retry_count<2 → back to judge (retry++)       │
│  • analyze   (o4-mini) runs only if profile.analyze              │
│  • summarize (no LLM)  writes AgentEvents_CL                     │
│                                                                  │
│  Behavioural variance per issue_type → IssueProfile row          │
└──────────────┬────────────────────────────────────────────────── ┘
               │
               ├── Start runbook (REST API)
               │          ▼
               │   ┌──────────────────────────────┐
               │   │  Azure Automation Account    │
               │   │  11 PowerShell runbooks      │
               │   │  Hybrid Worker Group         │
               │   └──────────────┬───────────────┘
               │                  │ Executes on VM
               │                  ▼
               │   ┌──────────────────────────────┐
               │   │  Windows Server 2022 VM      │
               │   │  (remediation applied)       │
               │   └──────────────────────────────┘
               │
               └── LogsIngestionClient + DCRs
                          ▼
               ┌─────────────────────────────┐
               │  Log Analytics Workspace    │
               │  AgentEvents_CL             │
               │  AgentErrors_CL             │
               └─────────────────────────────┘

Baseline Capture Flow:
  scripts/run_baseline.sh --> VM (Hybrid Worker) --> run_baseline.ps1
      | 60 min perfmon capture (external load via load_test.sh)
      ▼
  baseline-eh (Event Hub) --> ADX PerformanceBaseline table
      |
      ▼
  AnalysisAgent + RCAAgent compare live metrics against baseline
```

## Single-Path Agent Pipeline (v3)

```
START → classify → gather → judge → act → confirm ──► analyze → summarize → END
                              ▲                  │
                              │                  │ !healthy & retry<2
                              └──── retry ◄──────┘  (retry_count++)
```

Every alert walks the same six nodes. Behavioural variance per `issue_type`
lives in an `IssueProfile` row loaded by `classify` from
`agents/profiles.py`. The profile declares:

- **gatherers** — which evidence `gather` collects (parallel).
- **strategy** — how `judge` decides (`MECHANICAL`, `REASONED`, or
  `REASONED_WITH_VETO`).
- **default_runbook / escalation_runbook** — which runbook `act` executes
  (the latter on retry).
- **confirmation** — which checks `confirm` must all pass for `is_healthy`.
- **analyze** — whether to run deep RCA.

Retry loops back to `judge` (not `act`) so the decision itself can change on
retry — typically escalating to `Invoke-RestartIIS`.

See [langgraph_pipeline.md](langgraph_pipeline.md) for the full design.

### Issue → Profile Snapshot

| issue_type | Strategy | Default runbook | Analyze |
|---|---|---|---|
| `w3svc_stopped` | MECHANICAL | `Invoke-RestartW3SVC` | No |
| `app_pool_stopped` | MECHANICAL | `Invoke-RecycleAppPool` | No |
| `app_pool_crash` | MECHANICAL | `Invoke-RecycleAppPool` | Yes |
| `log_disk_full` | MECHANICAL | `Invoke-ClearIISLogs` | No |
| `binding_missing` | MECHANICAL | `Invoke-FixBindings` | No |
| `app_pool_identity` | MECHANICAL | `Invoke-FixAppPoolIdentity` | No |
| `bad_permissions` | MECHANICAL | `Invoke-FixPermissions` | No |
| `high_cpu` / `high_cpu_w3wp` | MECHANICAL | `Invoke-RecycleAppPool` | Yes |
| `memory_leak` | REASONED | `Invoke-RecycleAppPool` | Yes |
| `worker_process_hang` | REASONED | `Invoke-RestartWorkerProcess` | Yes |
| `request_queue_flood` | REASONED | `Invoke-RecycleAppPool` | Yes |
| `bad_http_errors` | REASONED | `Invoke-RecycleAppPool` | Yes |
| `high_memory` | REASONED | `Invoke-RecycleAppPool` | Yes |
| `high_disk_io` | REASONED | `Invoke-ClearIISLogs` | Yes |
| `http_5xx_flood` | REASONED_WITH_VETO | `Invoke-RecycleAppPool` | Yes |
| `unknown` | REASONED | `Invoke-RestartIIS` | Yes |

Every profile's `escalation_runbook` is `Invoke-RestartIIS` — retries always
use the bigger hammer.

`REASONED_WITH_VETO` is the strategy for issues where recycling the pool can
make things worse if the cause is upstream (e.g. backend database latency
causing an HTTP 5xx flood). `judge` can return `escalate_only` to refuse
remediation while still flagging the incident for human follow-up.

## RBAC Matrix

### iis-core scope

| Principal | Role | Target |
|-----------|------|--------|
| Function App MI | Virtual Machine Contributor | VM |
| Automation Account MI | Virtual Machine Contributor | VM |

### iis-core-monitor scope

| Principal | Role | Target |
|-----------|------|--------|
| Function App MI | Log Analytics Contributor | LAW |
| Function App MI | Monitoring Metrics Publisher | DCR (iisheal-dcr-agent-events) |
| Function App MI | Monitoring Metrics Publisher | DCR (iisheal-dcr-agent-errors) |
| Function App MI | Automation Contributor | Automation Account |
| Function App MI | Cognitive Services OpenAI User | Azure OpenAI |
| Function App MI | ADX Database Viewer (Kusto native) | ADX Database |
| Automation Account MI | Log Analytics Contributor | LAW |
| ADX Cluster MI | Event Hubs Data Receiver | iislogs-eh |
| ADX Cluster MI | Event Hubs Data Receiver | vmperf-eh |
| ADX Cluster MI | Event Hubs Data Receiver | iisperf-eh |
| ADX Cluster MI | Event Hubs Data Receiver | baseline-eh |
| VM MI | Event Hubs Data Sender | iislogs-eh |
| VM MI | Event Hubs Data Sender | vmperf-eh |
| VM MI | Event Hubs Data Sender | iisperf-eh |
| VM MI | Event Hubs Data Sender | baseline-eh |

All authentication uses Managed Identity -- zero secrets in code or config.

## Data Collection Rules

| DCR | Source | Destination | Deployed In |
|-----|--------|-------------|-------------|
| {prefix}-dcr-iislogs | IIS W3C log files (C:\inetpub\logs\...) | Event Hub iislogs-eh -> ADX | dcr.bicep |
| iisheal-dcr-agent-events | Function App (LogsIngestionClient) | LAW AgentEvents_CL | loganalytics.bicep |
| iisheal-dcr-agent-errors | Function App (LogsIngestionClient) | LAW AgentErrors_CL | loganalytics.bicep |

VM perf counters (CPU, memory, disk, IIS, ASP.NET, w3wp) are sent to ADX via `Send-PerfToEventHub.ps1` (scheduled task on the VM) through vmperf-eh and iisperf-eh Event Hubs. IISMonitorPoller queries ADX directly for anomaly detection across all 15 conditions.

Note: `infra/modules/dcr_alerts.bicep` and `infra/modules/monitoring.bicep` are present in the repository but marked deprecated and are not deployed.

## LAW Table Schemas

### AgentEvents_CL
| Column | Type | Description |
|--------|------|-------------|
| TimeGenerated | datetime | Event timestamp |
| VMHostname | string | Target VM hostname |
| AlertId | string | Alert GUID |
| IssueType | string | Classified issue type |
| IssueSummary | string | One-sentence summary |
| DetectionTime | datetime | When issue was detected |
| MitigationSteps | dynamic | Array of steps taken |
| RunbookExecuted | string | Runbook name |
| RemediationOutcome | string | Success/Failed/Partial |
| RootCause | string | RCA paragraph |
| NextSteps | dynamic | Recommendations array |
| ReasoningModel | string | o4-mini |
| FastModel | string | gpt-4o-mini |
| AgentVersion | string | 1.0.0 |
| TotalDurationSeconds | real | End-to-end duration |

### AgentErrors_CL
| Column | Type | Description |
|--------|------|-------------|
| TimeGenerated | datetime | Error timestamp |
| AgentName | string | Agent class name |
| ModelUsed | string | Deployment name |
| ErrorType | string | Exception class |
| ErrorMessage | string | Error message |
| StackTrace | string | Full stack trace |
| AlertId | string | Related alert GUID |
| RetryCount | int | Retry attempt number |
| Resolved | bool | Whether error was resolved |

## ADX Table Schemas

### IISLogs (staging table)
| Column | Type | Source |
|--------|------|--------|
| TimeGenerated | datetime | DCR transform |
| Computer | string | DCR transform (vmHostname) |
| FilePath | string | Log file path |
| RawData | string | W3C log line |

> **Note:** IISLogs is a staging table. Raw W3C lines are auto-parsed into the `IISLogsParsed` table via an ADX update policy. AI agents query `IISLogsParsed` for structured log fields (StatusCode, UriStem, TimeTakenMs, etc.).

### VMPerf / IISPerf
| Column | Type | Source |
|--------|------|--------|
| TimeGenerated | datetime | Send-PerfToEventHub.ps1 |
| Computer | string | VM hostname |
| ObjectName | string | Perf counter object |
| CounterName | string | Counter name |
| InstanceName | string | Counter instance |
| CounterValue | real | Counter value |

### IISHttpErrors (ADX — auto-populated via update policy)
| Column | Type | Description |
|--------|------|-------------|
| TimeGenerated | datetime | Error event timestamp |
| Computer | string | VM hostname |
| StatusCode | int | HTTP status code (e.g. 503) |
| Reason | string | HTTP.sys error reason (e.g. AppOffline, ConnLimit) |
| RawData | string | Original HTTPERR log line |

Populated from HTTP.sys HTTPERR log entries (`C:\Windows\System32\LogFiles\HTTPERR\`). `Send-PerfToEventHub.ps1` tails the HTTPERR log alongside the W3C access log and sends entries to the `iisperf-eh` Event Hub. An ADX update policy parses the raw lines into structured columns. Used by `IISMonitorPoller` to detect `app_pool_stopped` (503 AppOffline rows from rapid-fail protection).

### IISLogsParsed (ADX — auto-populated via update policy)
| Column | Type | Description |
|--------|------|-------------|
| TimeGenerated | datetime | Original IISLogs ingestion timestamp |
| Computer | string | VM hostname |
| SiteName | string | IIS site name (e.g. W3SVC1) |
| ServerIP | string | Server IP address |
| Method | string | HTTP method (GET, POST, etc.) |
| UriStem | string | Request URI path |
| UriQuery | string | Query string |
| Port | int | Server port |
| Username | string | Authenticated user (- if anonymous) |
| ClientIP | string | Client IP address |
| HttpVersion | string | HTTP protocol version |
| UserAgent | string | Browser user-agent (decoded) |
| Cookie | string | Cookie header |
| Referer | string | Referer header |
| Host | string | Host header |
| StatusCode | int | HTTP status code |
| SubStatus | int | IIS sub-status code |
| Win32Status | int | Win32 error code |
| TimeTakenMs | int | Server-side time taken in milliseconds |
| BytesSent | int | Response bytes sent |
| BytesReceived | int | Request bytes received |

Populated automatically: an ADX update policy runs `ParseIISLogs()` on every new batch ingested into `IISLogs`, parsing the W3C `RawData` into structured columns.

### PerformanceBaseline (ADX)
| Column | Type | Description |
|--------|------|-------------|
| TimeGenerated | datetime | Record timestamp |
| Computer | string | VM hostname |
| RecordType | string | Snapshot (per-window reading) or Summary (aggregated) |
| MetricName | string | Metric identifier (e.g., CpuPercent, MemoryAvailableMB) |
| MetricValue | real | Metric value |
| CaptureId | string | GUID grouping all records from a single baseline run |
| WindowIndex | int | 60-second window index within the capture |

Ingestion: `run_baseline.ps1` on VM -> `baseline-eh` Event Hub -> ADX data connection (MULTIJSON format).

## AI Model Tier Assignment

| Agent | Model Deployment | Tier | Reasoning Effort | Purpose |
|-------|-----------------|------|-----------------|---------|
| ClassifyAgent | -- | -- | -- | Deterministic rule-based routing |
| DetRemediationAgent | -- | -- | -- | Deterministic runbook lookup |
| DetVerificationAgent | -- | -- | -- | Deterministic HTTP + metric check |
| DetDiagnoseAgent | o4-mini | Tier 1 | medium | Post-remediation RCA for performance issues (high_cpu, high_cpu_w3wp, memory_leak) |
| DetReportAgent | -- | -- | -- | Deterministic event logging |
| DetectionAgent | gpt-4o-mini | Tier 2 | -- | Validate alert against ADX telemetry |
| AnalysisAgent | o4-mini | Tier 1 | medium | Multi-step diagnostic + baseline deviation |
| RemediationAgent | gpt-4o-mini | Tier 2 | -- | Map issue to runbook, trigger execution |
| VerificationAgent | gpt-4o-mini | Tier 2 | -- | Evaluate health check results |
| RCAAgent | o4-mini | Tier 1 | medium | Root cause analysis with baseline context |
| ReportingAgent | gpt-4o-mini | Tier 2 | -- | Format and write event summary |

**o4-mini config:** `reasoning_effort="medium"`, `temperature=1`, `max_tokens=4096`
**gpt-4o-mini config:** `temperature=0`, `max_tokens=2048`
