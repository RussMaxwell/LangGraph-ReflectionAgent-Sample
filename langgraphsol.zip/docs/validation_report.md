# Validation Report — IIS Auto-Healing Multi-Agent System

Generated: 2026-04-07 (updated 2026-04-09)

## Check Results

| # | Check | Result | Notes |
|---|-------|--------|-------|
| 1 | `az bicep build infra/main.bicep` | PASS | Compiles successfully (warnings only: unused params in vm.bicep, listKeys secret warning) |
| 2 | `python -m py_compile` all Python files (25 files) | PASS | All 25 files pass syntax check (added det_diagnose_agent.py) |
| 3 | `bash -n` all shell scripts (5 files) | PASS | deploy.sh, teardown.sh, run_baseline.sh, test_chaos.sh, validate_agent.sh |
| 4 | PowerShell syntax check all runbooks (13 files) | PASS | All 11 runbooks + 2 baseline scripts present |
| 5 | RBAC roleDefinitionId GUIDs match built-in roles | PASS | All 5 GUIDs verified: Log Analytics Contributor (92aaf0da), Monitoring Metrics Publisher (3913510d), Automation Contributor (f353d9bd), VM Contributor (9980e02c), Cognitive Services OpenAI User (5e0bd9bd) |
| 6 | requirements.txt contains all packages | PASS | All 13 packages present with pinned versions (added requests==2.32.3 and azure-data-tables==12.6.0) |
| 7 | Table names consistent across Bicep/Python/runbooks | PASS | LAW: AgentEvents_CL, AgentErrors_CL; ADX: IISLogs, IISLogsParsed, VMPerf, IISPerf, PerformanceBaseline |
| 8 | Security sweep: no API keys | PASS | Zero results for ANTHROPIC_API_KEY, OPENAI_API_KEY, api_key=, subscription_key |
| 9 | azure_openai_client.py uses azure_ad_token_provider | PASS | Token provider via DefaultAzureCredential confirmed |
| 10 | openai.bicep endpoint wired into functionapp.bicep | PASS | AZURE_OPENAI_ENDPOINT app setting uses openaiEndpoint parameter |
| 11 | baseline_client.py imported in analysis_agent.py and rca_agent.py | PASS | Fixed: both agents now import from tools.baseline_client |
| 12 | PerformanceBaseline table defined in adx.bicep | PASS | Normalized schema (MetricName/MetricValue) with ingestion mapping, ingested via baseline-eh Event Hub |
| 13 | run_baseline.ps1 and Invoke-CaptureBaseline.ps1 exist | PASS | Both files present in baseline/ and runbooks/ directories |
| 14 | /default.aspx exists with server-side CPU/memory simulation | PASS | Page_Load performs SHA-256 hashing, DataTable binding, Thread.Sleep, GUID generation, event logging |
| 15 | /chaos/default.aspx exists with all 10 POST handlers and confirmation gate | PASS | All 10 scenarios implemented, JavaScript confirmation gate present |
| 16 | get_reasoning_llm() used in analysis_agent.py, rca_agent.py, and det_diagnose_agent.py | PASS | Tier 1 o4-mini used in all 3 reasoning agents |
| 17 | get_fast_llm() used in detection, remediation, verification, reporting agents | PASS | Tier 2 gpt-4o-mini used in all 4 operational agents |

## Fixes Applied During Validation

| Issue | Fix |
|-------|-----|
| analysis_agent.py used custom `_get_latest_baseline()` querying wrong table name `Baselines_{host}_CL` | Replaced with import from `tools.baseline_client.get_latest_baseline` which queries ADX `PerformanceBaseline` table |
| rca_agent.py did not import baseline_client | Added import of `get_latest_baseline` from `tools.baseline_client`; added fallback baseline fetch when not in state |

## File Inventory

### Documentation (9 files)
- `docs/architecture.md` — Resource map, network topology, RBAC matrix, data flow, table schemas, AI tier table
- `docs/cost_estimate.md` — Monthly cost breakdown (~$175/mo dev), VM SKU confirmation ($60.74 < $120), cost savings from refactor
- `docs/executive_summary.md` — Non-technical overview, dual-path architecture, cost profile, potential impact
- `docs/testing_guide.md` — SRE testing guide with 11 chaos scenarios (including app_pool_stopped), KQL queries, troubleshooting
- `docs/load_testing_guide.md` — External load testing with baseline capture, IISLogsParsed KQL queries
- `docs/langgraph_pipeline.md` — Full LangGraph pipeline documentation: node/edge map, state fields, issue routing, retry logic, output schema
- `docs/w3svc_stopped_flow.md` — End-to-end trace of w3svc_stopped from fault to recovery, including synthetic heartbeat explanation
- `docs/validation_report.md` — This file: automated check results, file inventory
- `project_structure.txt` — Complete file/folder tree

### Bicep Infrastructure (16 files)
- `infra/main.bicep` — Root module orchestrating all resources
- `infra/parameters/dev.bicepparam` — Development environment parameters
- `infra/modules/networking.bicep` — VNet, subnet, NSG, public IP
- `infra/modules/vm.bicep` — Windows Server 2022 VM, IIS setup, DCR associations (no AMA)
- `infra/modules/loganalytics.bicep` — LAW, DCE, 2 custom tables (AgentEvents_CL, AgentErrors_CL) + 2 DCRs (iisheal-dcr-agent-events, iisheal-dcr-agent-errors)
- `infra/modules/openai.bicep` — Azure OpenAI with o4-mini and gpt-4o-mini deployments
- `infra/modules/automation.bicep` — Automation Account, Hybrid Worker Group, 11 runbooks
- `infra/modules/functionapp.bicep` — Storage, App Service Plan, Function App with all settings
- `infra/modules/adx.bicep` — ADX cluster, database, 5 tables (IISLogs, VMPerf, IISPerf, PerformanceBaseline, IISLogsParsed), ingestion mappings, ParseIISLogs() function + update policy
- `infra/modules/adx_connections.bicep` — ADX Event Hub data connections (depends on RBAC)
- `infra/modules/eventhubs.bicep` — Event Hub namespace + 4 hubs (iislogs-eh, vmperf-eh, iisperf-eh, baseline-eh)
- `infra/modules/dcr.bicep` — DCR for IIS W3C logs → Event Hub
- `infra/modules/dcr_alerts.bicep` — [DEPRECATED -- not deployed]
- `infra/modules/rbac.bicep` — Role assignments for Function App and Automation Account MIs (iis-core scope)
- `infra/modules/rbac_monitor.bicep` — Role assignments for ADX, VM, Event Hub MIs (iis-core-monitor scope)
- `infra/modules/monitoring.bicep` — [DEPRECATED -- not deployed]

### PowerShell Runbooks (11 files)
- `runbooks/Invoke-RecycleAppPool.ps1`
- `runbooks/Invoke-RestartIIS.ps1`
- `runbooks/Invoke-ClearIISLogs.ps1`
- `runbooks/Invoke-FixAppPoolIdentity.ps1`
- `runbooks/Invoke-EnableIIS.ps1`
- `runbooks/Invoke-RestartW3SVC.ps1`
- `runbooks/Invoke-FixBindings.ps1`
- `runbooks/Invoke-ClearASPNETCache.ps1`
- `runbooks/Invoke-FixPermissions.ps1`
- `runbooks/Invoke-RestartWorkerProcess.ps1`
- `runbooks/Invoke-CaptureBaseline.ps1`

### Chaos Web Application (5 files)
- `chaos-app/default.aspx` — Contoso Infrastructure Services normal content page
- `chaos-app/default.aspx.cs` — Code-behind with CPU/memory simulation
- `chaos-app/Web.config` — Root web.config
- `chaos-app/chaos/default.aspx` — Chaos Engineering Console
- `chaos-app/chaos/default.aspx.cs` — 10 fault scenario handlers

### Baseline System (2 files)
- `baseline/run_baseline.ps1` — 60-minute perfmon capture, sends snapshots + summary to baseline-eh Event Hub → ADX PerformanceBaseline
- `baseline/Get-BaselineSummary.ps1` — Query baseline summary from ADX PerformanceBaseline table

### Function App (25 files)
- `function-app/host.json`
- `function-app/requirements.txt`
- `function-app/local.settings.json.example`
- `function-app/IISHealingOrchestrator/__init__.py` — HTTP trigger entry point (external)
- `function-app/IISHealingOrchestrator/function.json`
- `function-app/IISMonitorPoller/__init__.py` — Timer trigger, ADX poller, 15 conditions, Table Storage cooldown
- `function-app/IISMonitorPoller/function.json`
- `function-app/IISHealingOrchestratorInternal/__init__.py` — HTTP trigger (internal), synthetic alert builder
- `function-app/IISHealingOrchestratorInternal/function.json`
- `function-app/agents/__init__.py`
- `function-app/agents/orchestrator.py` — LangGraph StateGraph (12 nodes including det_diagnose)
- `function-app/agents/classify_agent.py` — Deterministic classify (app_pool_stopped added)
- `function-app/agents/det_remediation_agent.py` — Deterministic runbook lookup (high_cpu/high_cpu_w3wp added)
- `function-app/agents/det_verification_agent.py` — Deterministic HTTP + metric check
- `function-app/agents/det_diagnose_agent.py` — Tier 1 o4-mini post-remediation RCA for performance issues (NEW)
- `function-app/agents/det_report_agent.py` — Deterministic event logging (det_diagnose output support)
- `function-app/agents/detection_agent.py` — Tier 2
- `function-app/agents/analysis_agent.py` — Tier 1 + baseline
- `function-app/agents/remediation_agent.py` — Tier 2
- `function-app/agents/verification_agent.py` — Tier 2
- `function-app/agents/rca_agent.py` — Tier 1 + baseline
- `function-app/agents/reporting_agent.py` — Tier 2
- `function-app/tools/__init__.py`
- `function-app/tools/azure_openai_client.py` — get_reasoning_llm() + get_fast_llm()
- `function-app/tools/law_client.py` — LAW query functions
- `function-app/tools/law_ingestion_client.py` — LAW write functions
- `function-app/tools/automation_client.py` — Runbook trigger
- `function-app/tools/vm_client.py` — VM status + HTTP health check
- `function-app/tools/adx_client.py` — ADX (Kusto) query client (IISLogsParsed, VMPerf, IISPerf, PerformanceBaseline)
- `function-app/tools/baseline_client.py` — Baseline summary fetch from ADX
- `function-app/models/__init__.py`
- `function-app/models/alert_payload.py`
- `function-app/models/agent_state.py`
- `function-app/models/healing_result.py`
- `function-app/models/baseline_summary.py`

### Scripts (8 files)
- `scripts/deploy.sh` — Full deployment automation (ADX tables, PS7 install, Hybrid Worker registration, scheduled tasks)
- `scripts/teardown.sh` — Resource group deletion
- `scripts/run_baseline.sh` — Trigger baseline capture runbook via Azure Automation
- `scripts/load_test.sh` — External load test: concurrent virtual users with unique sessions/UAs
- `scripts/test_chaos.sh` — Test all 10 chaos scenarios interactively
- `scripts/validate_agent.sh` — Validate deployed system (LAW, ADX, Function App, Automation, OpenAI)
- `scripts/Send-PerfToEventHub.ps1` — VM scheduled task: streams perf counters + IIS logs to Event Hub every 60s
- `scripts/setup-iis.ps1` — IIS installation script (loaded by vm.bicep)

## Summary

**Total files: 75+**
**All 17 validation checks: PASS**
**Fixes applied: 2** (baseline_client imports in analysis_agent.py and rca_agent.py)

### Changes Since Initial Validation (2026-04-07)

| Change | Files Affected |
|--------|---------------|
| PerformanceBaseline moved from LAW to ADX (via baseline-eh Event Hub) | loganalytics.bicep, adx.bicep, eventhubs.bicep, baseline_client.py, Get-BaselineSummary.ps1 |
| IISLogsParsed table added with ADX update policy auto-parsing from IISLogs | adx.bicep, adx_client.py, deploy.sh |
| AI agents updated to query IISLogsParsed instead of raw IISLogs | adx_client.py |
| Send-PerfToEventHub.ps1 counter name parsing fixed | Send-PerfToEventHub.ps1 |
| deploy.sh fully automated: PS7 install, Hybrid Worker registration, ADX table creation, schtasks | deploy.sh |
| BaselineSummary model fields all made Optional (supports perfmon-only baselines) | baseline_summary.py |
| All docs updated to reflect ADX table changes, correct costs, IISLogsParsed queries | All docs/ files |
| HealingState alias added for backward compatibility with AI-path agents | agent_state.py |
| tools/__init__.py imports fixed (perf queries moved from law_client to adx_client) | tools/__init__.py |
| Function App Python version upgraded 3.11 → 3.12, remote build via SCM_DO_BUILD_DURING_DEPLOYMENT | functionapp.bicep, deploy.sh |
| Agent DCR creation automated (AgentEvents_CL, AgentErrors_CL) with RBAC + app settings | deploy.sh |
| WEBSITE_RUN_FROM_PACKAGE replaced with SCM_DO_BUILD_DURING_DEPLOYMENT (fixes Linux wheel mismatch) | functionapp.bicep, deploy.sh |
| Eliminated 15 Azure Monitor scheduledQueryRules and Action Group; replaced with IISMonitorPoller timer function querying ADX directly | monitoring.bicep (deprecated), IISMonitorPoller/__init__.py, IISMonitorPoller/function.json |
| IISHealingOrchestratorInternal added: HTTP-triggered internal entry point that builds synthetic AlertPayload and feeds LangGraph pipeline | IISHealingOrchestratorInternal/__init__.py, IISHealingOrchestratorInternal/function.json |
| Cooldown state moved to Azure Table Storage (healingcooldown table via AzureWebJobsStorage) | IISMonitorPoller/__init__.py |
| Removed VMPerf_{host}_CL and IISPerf_{host}_CL LAW tables; perf data stays in ADX only | loganalytics.bicep |
| dcr_alerts.bicep marked deprecated (not deployed); {prefix}-dcr-vmperf-alerts and {prefix}-dcr-iisperf-alerts removed | dcr_alerts.bicep |
| Two new DCRs added to loganalytics.bicep: iisheal-dcr-agent-events and iisheal-dcr-agent-errors | loganalytics.bicep |
| RBAC for Monitoring Metrics Publisher moved from LAW scope to per-DCR scope (agent-events, agent-errors) | rbac_monitor.bicep |
| Azure Monitor Agent (AMA) VM extension removed (orphaned after DCR alerts removal) | vm.bicep |
| event_log_writer.py deleted (dead code, never imported) | function-app/tools/ |
| requirements.txt updated: added requests==2.32.3 and azure-data-tables==12.6.0 (13 packages total) | requirements.txt |
| Send-PerfToEventHub.ps1 extended with 8 additional perf counters (memory paging, disk queue, processor queue, disk free space, failed connections, requests queued, thread count, 404 rate) | Send-PerfToEventHub.ps1 |
| App settings added: DCR_AGENT_EVENTS_RULE_ID, DCR_AGENT_ERRORS_RULE_ID, HYBRID_WORKER_GROUP_NAME, ADX_CLUSTER_URI, ADX_DATABASE, AUTOMATION_RESOURCE_GROUP_NAME | functionapp.bicep |
| Code deployment changed from func CLI to zip via Kudu REST API (/api/zipdeploy) with Oryx remote build | deploy.sh |
| ADX connections deployment now retries up to 4 attempts (60s apart) after 150s RBAC propagation wait | deploy.sh |

### Changes Since 2026-04-08 Update

| Change | Files Affected |
|--------|---------------|
| DetDiagnoseAgent added: post-remediation o4-mini RCA for performance issues (high_cpu, high_cpu_w3wp, memory_leak) on the deterministic path | det_diagnose_agent.py (NEW), orchestrator.py |
| `app_pool_stopped` issue type added: detects IIS rapid-fail protection via IISHttpErrors ADX table (503 AppOffline rows) | classify_agent.py, det_remediation_agent.py, IISMonitorPoller/__init__.py |
| CPU issues (high_cpu, high_cpu_w3wp) moved from AI path to deterministic path to prevent false-positive classification when transient spikes resolve before ai_detect re-validates | classify_agent.py, det_remediation_agent.py, det_verification_agent.py |
| IISHttpErrors KQL breach query added to IISMonitorPoller (queries HTTP.sys HTTPERR log data for 503 AppOffline) | IISMonitorPoller/__init__.py |
| Orchestrator updated: det_diagnose node wired after det_verify for DIAGNOSE_ISSUES; conditional edge _route_after_det_verify updated | orchestrator.py |
| det_report_agent updated to surface det_diagnose output (analysis_result, root_cause, next_steps) when available | det_report_agent.py |
| Det verification agent updated: high_cpu/high_cpu_w3wp added to _HTTP_ONLY_ISSUES (transient spikes resolve before ADX data is available) | det_verification_agent.py |
| Two new documentation files added | docs/langgraph_pipeline.md, docs/w3svc_stopped_flow.md |
| All existing docs updated to reflect new agents, issue types, and detection mechanisms | docs/architecture.md, docs/testing_guide.md, docs/executive_summary.md, docs/cost_estimate.md, docs/load_testing_guide.md, docs/validation_report.md |
