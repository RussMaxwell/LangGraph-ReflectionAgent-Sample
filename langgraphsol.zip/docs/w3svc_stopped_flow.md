# W3SVC Stopped — End-to-End Flow

This document traces every step the auto-healing system takes from the moment the
World Wide Web Publishing Service (W3SVC) stops to the moment IIS is restored and
the event is recorded in Azure Monitor.

> **Pipeline version note.** The orchestration sections below describe the v3
> single-path LangGraph pipeline. Nodes are `classify` → `gather` → `judge` →
> `act` → `confirm` → `analyze` → `summarize`; the `w3svc_stopped` profile is
> MECHANICAL with `analyze=False`, so the LLM is not involved at all for this
> issue. See [langgraph_pipeline.md](langgraph_pipeline.md) for the full graph
> and [flow_examples.md](flow_examples.md) for side-by-side traces of this and
> two other scenarios.

---

## Table of Contents

1. [Overview](#1-overview)
2. [Timeline at a Glance](#2-timeline-at-a-glance)
3. [Step-by-Step Flow](#3-step-by-step-flow)
   - Steps 1–6: Detection (VM script → Event Hub → ADX → KQL → poller)
   - Steps 7–11: Orchestration (entry point → classify → runbook selection → execution)
   - Steps 12–13: Verification and recording
4. [Detection Deep-Dive](#4-detection-deep-dive)
5. [Healing Deep-Dive](#5-healing-deep-dive)
6. [Observability](#6-observability)
7. [Cooldown Behaviour](#7-cooldown-behaviour)
8. [Why the Synthetic Heartbeat Exists](#8-why-the-synthetic-heartbeat-exists)

---

## 1. Overview

W3SVC can stop for several reasons: a manual `net stop w3svc`, a service crash, a
runaway script calling `Stop-Service`, or rapid-fail protection engaging on the
DefaultAppPool (see `app_pool_stopped` flow for that last case).

When W3SVC stops:

- HTTP.sys deregisters the listening URLs — all inbound HTTP requests immediately fail
- All w3wp.exe worker processes are terminated
- The `\Web Service` Windows performance counter object is **unregistered by the OS**
  (it does not return 0 — it becomes unavailable entirely)

That last point is the most important for detection: a naive `Current Connections == 0`
check would never fire because the counter object disappears. See
[Section 8](#8-why-the-synthetic-heartbeat-exists) for the full explanation and fix.

---

## 2. Timeline at a Glance

```
T+0s    W3SVC stops — site goes dark                                    [Step 1]
T+60s   Send-PerfToEventHub.ps1 injects synthetic Current Connections=0 [Step 2]
T+~90s  ADX ingestion batch closes (30s policy), row queryable          [Step 3]
T+120s  Second synthetic row arrives                                     [Step 4]
T+180s  Third synthetic row — RowCount >= 3 now satisfied               [Step 4]
T+~180s IISMonitorPoller tick: KQL returns IssueType=w3svc_stopped      [Step 5]
T+~181s Cooldown written to Table Storage, POST → orchestrator          [Step 6]
T+~182s Orchestrator: issue_type → alert name (_ISSUE_TO_ALERT_NAME)    [Step 7]
T+~182s classify: alert text → w3svc_stopped, loads MECHANICAL profile  [Step 8]
T+~182s gather:  SERVICE_STATE gatherer runs (HTTP probe)               [Step 8b]
T+~183s judge:   MECHANICAL, retry=0 → Invoke-RestartW3SVC (no LLM)     [Step 9]
T+~185s act:     Azure Automation job submitted to Hybrid Worker        [Step 10]
T+~185s Invoke-RestartW3SVC runs on VM — Stop-Service / Start-Service   [Step 11]
T+~220s Runbook completes — W3SVC Running                               [Step 11]
T+~221s confirm: HTTP_OK check → 200 → is_healthy=True                  [Step 12]
T+~221s analyze: profile.analyze=False → skipped                        [Step 12b]
T+~221s summarize: AgentEvents_CL written via DCR ingestion pipeline    [Step 13]
T+5m    Cooldown expires — normal polling resumes
```

Typical wall-clock time from fault to recovery: **~35–40 seconds** for the runbook
itself; **~3 minutes** to first detection (dominated by the RowCount >= 3 guard).

---

## 3. Step-by-Step Flow

### Step 1 — Fault occurs (T+0)

W3SVC stops by any means.  IIS worker processes are immediately killed.  The site
returns connection refused / timeout to clients.

### Step 2 — Send-PerfToEventHub.ps1 runs (T+60s)

A Windows Scheduled Task (SYSTEM account, every 60 seconds) executes
`C:\Scripts\Send-PerfToEventHub.ps1`.

**Normal path (W3SVC running):**
`Get-Counter '\Web Service(_Total)\Current Connections'` returns the live connection
count.  The row is included in the `$iisRows` batch and sent to `iisperf-eh`.

**W3SVC stopped path:**
The `\Web Service` counter object is unregistered by Windows.  `Get-Counter` returns
nothing for that path.  After collecting whatever counters are available, the script
explicitly checks the service state:

```powershell
$w3svcStatus = (Get-Service -Name 'W3SVC' -ErrorAction SilentlyContinue).Status
if ($w3svcStatus -ne 'Running') {
    $iisRows.Add(@{
        TimeGenerated = (Get-Date).ToUniversalTime().ToString('o')
        Computer      = $Computer
        ObjectName    = 'Web Service'
        CounterName   = 'Current Connections'
        InstanceName  = '_Total'
        CounterValue  = 0
    })
}
```

One synthetic `Current Connections = 0` row is appended to the batch and sent to
`iisperf-eh` as part of the normal IISPerf payload.

### Step 3 — Event Hub → ADX ingestion (T+60s to T+~90s)

The `iisperf-eh` Event Hub receives the JSON batch.  ADX ingests it via a data
connection.  The ingestion batching policy on the `IISPerf` table is set to
**30 seconds** (reduced from the default 5 minutes), so the row is queryable within
~30 seconds of arrival.

### Step 4 — Rows accumulate (T+120s, T+180s)

`Send-PerfToEventHub.ps1` runs again at T+120s and T+180s, adding a second and
third synthetic row.  After three cycles there are at least 3 rows with
`CounterName = 'Current Connections'` and `CounterValue = 0` inside the 7-minute
look-back window.

### Step 5 — IISMonitorPoller detects the breach (T+~180s)

The `IISMonitorPoller` Azure Function fires every 60 seconds.  On whichever tick
falls after T+180s it runs the IISPerf KQL query:

```kql
let iis3m =
    IISPerf
    | where Computer == hostname and TimeGenerated >= ago(7m)
    | where CounterName in ("Current Connections", ...)
    | summarize
        AvgValue = avg(CounterValue),
        MaxValue = max(CounterValue),
        RowCount  = count()
      by CounterName, ObjectName, InstanceName
    | extend
        IsBreached = case(
            CounterName == "Current Connections" and ObjectName == "Web Service"
                and MaxValue == 0 and RowCount >= 3,   true,
            ...
        ),
        IssueType = case(
            CounterName == "Current Connections", "w3svc_stopped",
            ...
        )
    | where IsBreached
    | project IssueType, Summary
```

The three synthetic rows satisfy `MaxValue == 0 and RowCount >= 3`.
`IssueType = "w3svc_stopped"` is returned.

`w3svc_stopped` is the highest-priority issue type in `_PRIORITY` (index 0), so
`_pick_top_breach()` selects it even if other conditions are also breached.

### Step 6 — Cooldown written, healing triggered (T+~181s)

The poller:
1. Writes `LastTriggerTime = now()` to the `healingcooldown` Azure Table Storage
   table before firing — this blocks any concurrent poller instances immediately.
2. POSTs to `IISHealingOrchestratorInternal` (same Function App, internal HTTP):

```json
{
  "issue_type": "w3svc_stopped",
  "issue_summary": "Current Connections value=0.0"
}
```

The POST uses a 10-second timeout.  Because the orchestrator runs for ~35 seconds
the read timeout fires — this is expected.  The request was received and processing
has started.

### Step 7 — Orchestrator entry point: issue_type → alert name (T+~182s)

`IISHealingOrchestratorInternal` (`IISHealingOrchestratorInternal/__init__.py`)
receives the POST and immediately maps `issue_type` to a human-readable alert name
via a lookup dict:

```python
_ISSUE_TO_ALERT_NAME = {
    "w3svc_stopped": "IIS Current Connections = 0 (IIS Down)",
    "app_pool_stopped": "IIS App Pool Stopped (Rapid-Fail Protection)",
    ...
}
```

This builds a synthetic alert object (`alertId`, `alertName`, `severity`,
`firedDateTime`) that looks identical to what Azure Monitor would have sent.  The
object is placed into the initial LangGraph state and the graph is invoked.

### Step 8 — Classify node: alert text → issue_type + path (T+~182s)

The `classify` node (`agents/classify_agent.py`) concatenates the alert name, rule
slug, and description into a single lowercase search string, then walks a
priority-ordered pattern list looking for the first substring match:

```python
_ALERT_TO_ISSUE = [
    ("iis current connections", "w3svc_stopped"),
    ("iis down",                "w3svc_stopped"),
    ...
]
```

`"iis current connections"` matches the synthetic alert name immediately.  The node
writes `issue_type = "w3svc_stopped"` into state and loads the corresponding
`IssueProfile` from the registry:

```python
"w3svc_stopped": IssueProfile(
    gatherers          = (Gatherer.SERVICE_STATE,),
    strategy           = Strategy.MECHANICAL,
    default_runbook    = "Invoke-RestartW3SVC",
    escalation_runbook = "Invoke-RestartIIS",
    confirmation       = (Check.HTTP_OK,),
    analyze            = False,
)
```

No LLM is called — the `MECHANICAL` strategy means `judge` picks the runbook
directly from the profile.

### Step 8b — Gather node: SERVICE_STATE probe (T+~182s)

`gather` runs the profile's one gatherer, which performs an HTTP GET against
the VM's public IP.  The result (connection refused while W3SVC is down) is
stored in `state.evidence["service_state"]`.

### Step 9 — Judge node: profile → runbook (T+~183s)

`judge` reads `profile.strategy == MECHANICAL` and `retry_count == 0`, then
returns `profile.default_runbook` directly:

```
decision_action    = "remediate"
decision_runbook   = "Invoke-RestartW3SVC"
decision_reasoning = "Mechanical issue 'IIS W3SVC service stopped'; alert
                      threshold confirms the breach; running known-safe
                      runbook Invoke-RestartW3SVC."
decision_confidence = "high"
```

No LLM is called.  On any retry (`retry_count > 0`), `judge` returns
`profile.escalation_runbook = "Invoke-RestartIIS"` instead — a broader
full-IIS reset.

### Step 10 — Runbook submitted to Azure Automation (T+~185s)

`start_runbook()` (`tools/automation_client.py`) calls the Azure Automation REST API
via the `azure-mgmt-automation` SDK:

```python
client.job.create(
    resource_group_name = AUTOMATION_RESOURCE_GROUP_NAME,
    automation_account_name = AUTOMATION_ACCOUNT_NAME,
    job_name = "Invoke-RestartW3SVC-{timestamp}-{uuid}",
    parameters = {
        "properties": {
            "runbook":    {"name": "Invoke-RestartW3SVC"},
            "parameters": {"VMName": VM_NAME, "ResourceGroup": RESOURCE_GROUP_NAME},
            "runOn":      HYBRID_WORKER_GROUP,   # "IIS-HybridWorkers"
        }
    },
)
```

The function then polls the job status every 10 seconds (up to 5 minutes) until the
job reaches a terminal state: `Completed`, `Failed`, `Stopped`, or `Suspended`.

### Step 11 — Invoke-RestartW3SVC executes on the VM (T+~185s–220s)

The Hybrid Worker agent running on the VM picks up the job and executes
`Invoke-RestartW3SVC.ps1` locally.  The runbook has direct access to the Windows
Service Control Manager:

```powershell
Stop-Service -Name W3SVC -Force -ErrorAction SilentlyContinue
Start-Service -Name W3SVC
# Polls Get-Service W3SVC up to 30s for Running state
```

On success it returns a structured JSON result with `Success`, `StartTimeUtc`, and
`EndTimeUtc`.  The Hybrid Worker is required because Azure Automation cloud workers
cannot reach the VM's local service control manager.

### Step 12 — Confirm node runs profile.confirmation (T+~221s)

After the runbook completes, `confirm` runs the checks declared in the
profile.  For `w3svc_stopped` the profile declares only one:

```
confirmation = (Check.HTTP_OK,)
```

`HTTP_OK` is an HTTP GET against the VM's public IP that passes if the
response is 200.  This single check is sufficient here because:

- `Current Connections > 0` is not a reliable health signal; a healthy server
  with no active clients legitimately has 0 connections.
- ADX has a ~90-second lag (60s script cycle + 30s batching), so counter data
  would not be present at the moment `confirm` runs.
- A 200 response directly proves W3SVC is running and serving requests.

`is_healthy = True` is returned.

### Step 12b — Analyze node skipped

`profile.analyze == False` for `w3svc_stopped` — the orchestrator's `analyze`
wrapper detects this and returns without calling o4-mini.  An LLM-based RCA
for a simple service-stop has nothing meaningful to add; the report will
record this as a deterministic recovery.

### Step 13 — Summarize node writes the event (T+~221s)

The orchestrator receives the verification result and writes a structured event to
`AgentEvents_CL` via the DCR ingestion pipeline (`LogsIngestionClient.upload`).
Key fields written:

| Field | Value |
|---|---|
| `IssueType` | `w3svc_stopped` |
| `RunbookExecuted` | `Invoke-RestartW3SVC` |
| `RemediationOutcome` | `success` |
| `DecisionAction` | `remediate` |
| `DecisionConfidence` | `high` |
| `Strategy` | `mechanical` |
| `ReasoningModel` | `none` |
| `FastModel` | `none` |
| `TotalDurationSeconds` | ~35–40 |
| `IsHealthy` | `true` |

---

## 4. Detection Deep-Dive

### Why RowCount >= 3?

The guard prevents false positives in two scenarios:

1. **IIS startup lag** — when IIS is starting up, a brief gap in counter data may
   appear before the Web Service counter object is registered.  A single missing row
   should not trigger healing of a service that is about to start successfully.

2. **ADX batch gap** — with a 30-second batching policy and a 60-second collection
   interval, there is always at most one batch per collection cycle.  Three rows
   means three consecutive collection cycles (≥ 3 minutes) with no connections —
   definitively not a transient gap.

### The 7-minute look-back window

The KQL uses `ago(7m)`.  The window is deliberately longer than the 5-minute cooldown
period so that a breach that occurs while the poller is cooling down is still visible
when polling resumes.  With the 30-second ADX batch policy and 60-second script
interval, data is queryable within ~90 seconds of collection.  Three synthetic rows
accumulate in ~3 minutes and remain visible in the 7-minute window until they age out.

### Priority ordering

`w3svc_stopped` is at index 0 in `_PRIORITY` — it is checked before all other
issue types including `app_pool_crash` (index 2) and `high_cpu` (index 7).  If W3SVC
is stopped and CPU also appears elevated (because a runaway process caused the stop),
`w3svc_stopped` wins and the correct runbook is dispatched.

---

## 5. Healing Deep-Dive

### Runbook: Invoke-RestartW3SVC

Located at `runbooks/Invoke-RestartW3SVC.ps1`.  Runs on the Hybrid Worker.

Key steps:
1. Calls `Stop-Service -Name W3SVC -Force` (idempotent if already stopped)
2. Calls `Start-Service -Name W3SVC`
3. Polls `Get-Service W3SVC` up to 30 seconds for `Running` state
4. Returns a structured JSON result including `Success`, `StartTimeUtc`, `EndTimeUtc`

### Why the Hybrid Worker?

`Invoke-RestartW3SVC` controls a Windows service on the VM directly.  Azure
Automation cloud workers cannot reach the VM's service control manager.  The Hybrid
Worker agent runs on the VM itself under a service account with local admin rights,
giving it the necessary access.

---

## 6. Observability

### During healing

| Where | What to look for |
|---|---|
| Function App log stream | `IISMonitorPoller` — `Breaches detected: ['w3svc_stopped']` |
| Function App log stream | `IISHealingOrchestratorInternal` — runbook job ID |
| Azure Automation → Jobs | `Invoke-RestartW3SVC` job — Output tab shows start/stop timestamps |
| VM Event Log | Source `IISChaosApp` Event ID 9002 (if fault was injected via chaos app) |

### After healing

**AgentEvents_CL (Log Analytics):**
```kql
AgentEvents_CL
| where IssueType == "w3svc_stopped"
| order by TimeGenerated desc
| take 5
```

**ADX IISPerf — synthetic rows:**
```kql
IISPerf
| where CounterName == "Current Connections"
| where CounterValue == 0
| order by TimeGenerated desc
| take 10
```

**ADX IISPerf — recovery (connections > 0 again):**
```kql
IISPerf
| where CounterName == "Current Connections"
| where CounterValue > 0
| order by TimeGenerated desc
| take 5
```

---

## 7. Cooldown Behaviour

After healing triggers, the poller persists `LastTriggerTime` to the
`healingcooldown` Azure Table Storage table.  The cooldown is **5 minutes**
(`COOLDOWN_SECONDS = 300`).

During cooldown, every poller tick logs:

```
Cooldown active — Xs remaining, skipping poll.
```

**Why 5 minutes and not shorter?**

- Healing completes in ~35–40 seconds
- `Send-PerfToEventHub.ps1` at T+60s may send one final synthetic `Current
  Connections = 0` row with `TimeGenerated ≈ T+60s`
- The 3-minute look-back window at T+5m covers T+2m → T+5m
- The T+60s row is outside that window — safely excluded
- At T+4m the T+60s row would still be inside the window — risky

After the 5-minute cooldown, the first poller tick queries ADX.  W3SVC is running,
the `\Web Service` counter object is registered again, and `Send-PerfToEventHub.ps1`
sends real `Current Connections > 0` rows.  No breach is detected.  Healing does not
re-trigger.

---

## 8. Why the Synthetic Heartbeat Exists

When W3SVC stops, Windows unregisters the `\Web Service` performance counter object.
`Get-Counter '\Web Service(_Total)\Current Connections'` does not return `0` — it
returns an error that is suppressed by `-ErrorAction SilentlyContinue`.  The counter
simply disappears from the sample set.

**Before the fix:** no rows were sent for `Current Connections` during a W3SVC outage.
The KQL `RowCount >= 3` guard was never satisfied.  The poller detected no breach.
VMPerf data was still flowing (VM counters are independent of W3SVC), so
`_check_data_present()` returned `true` and the poller logged
_"metrics are within normal thresholds"_ — completely misleading.  **Healing never
triggered.**

**After the fix:** `Send-PerfToEventHub.ps1` calls `Get-Service W3SVC` after
counter collection.  If the service is not `Running`, a synthetic row
(`CounterValue = 0`, `ObjectName = 'Web Service'`, `CounterName = 'Current
Connections'`) is appended to the IISPerf batch.  Three consecutive synthetic rows
(one per 60-second script cycle) satisfy `RowCount >= 3` and the KQL breach fires
as intended.

The synthetic row is structurally identical to a real counter row so the KQL,
dashboards, and any downstream consumers require no changes.
