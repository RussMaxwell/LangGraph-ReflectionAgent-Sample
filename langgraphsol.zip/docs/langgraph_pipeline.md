# IIS Auto-Healing — LangGraph Pipeline (v3)

## Overview

The IIS auto-healing system is an Azure Function App that responds to IIS
issues detected by `IISMonitorPoller` (or forwarded from Azure Monitor). When
an alert arrives, a LangGraph state machine routes it through **six nodes**
that classify, gather evidence, decide, act, confirm, analyze, and report.

v3 replaces the previous dual-path (deterministic / AI) design with a
**single path, profile-driven** architecture:

- **Every alert walks the same six nodes.**
- Behavioural variance per issue type lives in an `IssueProfile` row loaded
  from `agents/profiles.py`, not in graph topology.
- The `judge` node owns every decision — it may choose to remediate, do
  nothing, escalate-only, or both remediate and escalate.
- Deep RCA (`analyze`) runs for any issue whose profile opts in —
  independent of whether the fix succeeded or failed.

## Why the rewrite

The previous dual-path graph duplicated five logical steps across two
branches (`det_remediate` / `ai_remediate`, etc.), encoded domain knowledge
(`DIAGNOSE_ISSUES`) in conditional edge functions, and gated the AI path
behind an `ai_detect` node that caused CPU spikes to be misclassified as
false positives. See the RCA notes in the section "What changed and why" at
the end of this document.

---

## LangGraph Node Map

```
                         ┌────────────────────────────────────────────┐
                         │  Alert arrives (Azure Monitor HTTP POST    │
                         │   or IISMonitorPoller internal trigger)    │
                         └──────────────────────┬─────────────────────┘
                                                ▼
                         ┌────────────────────────────────────────────┐
                         │  classify                                  │
                         │  • Substring-match alert text              │
                         │    → issue_type → IssueProfile             │
                         │  • No LLM                                  │
                         └──────────────────────┬─────────────────────┘
                                                ▼
                         ┌────────────────────────────────────────────┐
                         │  gather                                    │
                         │  • Runs profile.gatherers in parallel      │
                         │  • Produces the evidence dict              │
                         │  • No LLM                                  │
                         └──────────────────────┬─────────────────────┘
                                                ▼
                         ┌────────────────────────────────────────────┐
                         │  judge                                     │
                         │  • Dispatches on profile.strategy:         │
                         │      MECHANICAL          → no LLM          │
                         │      REASONED            → gpt-4o-mini     │
                         │      REASONED_WITH_VETO  → gpt-4o-mini     │
                         │                                            │
                         │  • Output: decision_action ∈               │
                         │     remediate | no_action |                │
                         │     escalate_only | remediate_and_escalate │
                         │    plus decision_runbook + reasoning       │
                         └──────────────────────┬─────────────────────┘
                                                ▼
                         ┌────────────────────────────────────────────┐
                         │  act                                       │
                         │  • remediate / remediate_and_escalate:     │
                         │     run runbook via Azure Automation       │
                         │  • no_action / escalate_only:              │
                         │     record decision, no runbook executed   │
                         │  • No LLM                                  │
                         └──────────────────────┬─────────────────────┘
                         decision == remediate /│
                         remediate_and_escalate │
                                                │                decision == no_action /
                                                │                escalate_only
                                                ▼                       │
                         ┌────────────────────────────────────────────┐ │
                         │  confirm                                   │ │
                         │  • Runs profile.confirmation checks        │ │
                         │  • All must pass for is_healthy = True     │ │
                         │  • No LLM                                  │ │
                         └──────────┬───────────────┬─────────────────┘ │
                                    │               │                   │
                              is_healthy        !is_healthy             │
                                    │            & retry_count < 2      │
                                    │               │                   │
                                    │               ▼                   │
                                    │        ┌──────────────┐           │
                                    │        │ retry        │           │
                                    │        │ (count += 1) │           │
                                    │        └──────┬───────┘           │
                                    │               │                   │
                                    │               └──► back to judge  │
                                    │                                   │
                                    ▼                                   │
                         ┌────────────────────────────────────────────┐ │
                         │  analyze                                   │◄┘
                         │  • Runs only if profile.analyze == True    │
                         │  • o4-mini RCA on preserved evidence       │
                         │  • Produces analysis_result + root_cause   │
                         │    + next_steps                            │
                         └──────────────────────┬─────────────────────┘
                                                ▼
                         ┌────────────────────────────────────────────┐
                         │  summarize                                 │
                         │  • Writes AgentEvents_CL record            │
                         │  • No LLM                                  │
                         └──────────────────────┬─────────────────────┘
                                                ▼
                                               END
```

Legend — reading the diagram:
- **classify** resolves alert text → `issue_type` → `IssueProfile`. Everything
  downstream is driven by that profile.
- **gather** runs the profile's declared gatherers in parallel. Each gatherer
  is a pure function (ADX query, baseline fetch, HTTP probe). Gathering is
  non-destructive.
- **judge** is the sole decision authority. No other node chooses *what* to
  do — they execute what judge chose.
- The **retry loop goes back to judge**, not to act. Rationale: on retry the
  decision itself may change (bigger hammer, veto, escalate).
- **analyze** runs *after* the healing attempt, on preserved evidence — the
  report gets the real root cause even when the fix was "recycle the pool."

---

## The IssueProfile Registry

`agents/profiles.py` is the single source of truth for per-issue behaviour.
Adding a new issue type = adding one row. No new agents, no new edges.

```python
IssueProfile = dataclass(
    label              = str,                    # human-readable
    gatherers          = tuple[Gatherer, ...],   # what evidence to collect
    strategy           = Strategy,               # how judge decides
    default_runbook    = str,                    # first-attempt runbook
    escalation_runbook = str,                    # retry runbook (bigger hammer)
    confirmation       = tuple[Check, ...],      # which checks = "healthy"
    analyze            = bool,                   # run deep RCA?
    escalation_target  = str,                    # paging destination (future)
)
```

### Strategies

| Strategy | Calls LLM? | Judge can return |
|---|---|---|
| `MECHANICAL` | No | `remediate` only (picks `default_runbook` or `escalation_runbook`) |
| `REASONED` | Yes (gpt-4o-mini) | `remediate`, `no_action` |
| `REASONED_WITH_VETO` | Yes (gpt-4o-mini) | `remediate`, `no_action`, `escalate_only`, `remediate_and_escalate` |

### Gatherers

| Gatherer | Source | Typical cost |
|---|---|---|
| `SERVICE_STATE` | HTTP probe (`vm_client.check_http_health`) | < 1s |
| `ADX_VM_PERF_5M` / `_30M` | `VMPerf` ADX table | 1–3s |
| `ADX_IIS_PERF_5M` / `_30M` | `IISPerf` ADX table | 1–3s |
| `ADX_IIS_LOGS_30M` | `IISLogsParsed` ADX table | 1–5s |
| `ADX_HTTP_ERRORS_7M` | `IISHttpErrors` ADX table | 1–3s |
| `BASELINE` | `PerformanceBaseline` ADX + `baseline_client` | 1–3s |
| `CAPTURE_*` | Hybrid-Worker capture runbook (*forward-looking*) | 10–30s |

### Confirmation Checks

| Check | What it verifies |
|---|---|
| `HTTP_OK` | HTTP GET returns 200 |
| `CPU_BELOW_THRESHOLD` | VMPerf `% Processor Time` < 85 |
| `DISK_FREE_ABOVE_THRESHOLD` | VMPerf `% Free Space` > 5 |
| `FIVE_XX_RATE_BELOW` | `IISLogsParsed` 5xx/total < 5% over last 5 min |
| `W3WP_RUNNING` | `IISPerf` w3wp heartbeat in last 3 min |

### Current Registry at a glance

| issue_type | Strategy | Default runbook | Analyze? |
|---|---|---|---|
| `w3svc_stopped` | MECHANICAL | `Invoke-RestartW3SVC` | No |
| `app_pool_stopped` | MECHANICAL | `Invoke-RecycleAppPool` | No |
| `app_pool_crash` | MECHANICAL | `Invoke-RecycleAppPool` | Yes |
| `log_disk_full` | MECHANICAL | `Invoke-ClearIISLogs` | No |
| `binding_missing` | MECHANICAL | `Invoke-FixBindings` | No |
| `app_pool_identity` | MECHANICAL | `Invoke-FixAppPoolIdentity` | No |
| `bad_permissions` | MECHANICAL | `Invoke-FixPermissions` | No |
| `high_cpu` | MECHANICAL | `Invoke-RecycleAppPool` | Yes |
| `high_cpu_w3wp` | MECHANICAL | `Invoke-RecycleAppPool` | Yes |
| `memory_leak` | REASONED | `Invoke-RecycleAppPool` | Yes |
| `worker_process_hang` | REASONED | `Invoke-RestartWorkerProcess` | Yes |
| `request_queue_flood` | REASONED | `Invoke-RecycleAppPool` | Yes |
| `bad_http_errors` | REASONED | `Invoke-RecycleAppPool` | Yes |
| `high_memory` | REASONED | `Invoke-RecycleAppPool` | Yes |
| `high_disk_io` | REASONED | `Invoke-ClearIISLogs` | Yes |
| `http_5xx_flood` | REASONED_WITH_VETO | `Invoke-RecycleAppPool` | Yes |
| `unknown` | REASONED | `Invoke-RestartIIS` | Yes |

`escalation_runbook` defaults to `Invoke-RestartIIS` for every profile — a
retry always uses the bigger hammer.

---

## Shared State (AgentState)

State is grouped by phase, with a single writer per field. Downstream nodes
read what upstream nodes wrote.

| Group | Writer | Fields |
|---|---|---|
| Input | orchestrator | `alert_payload` |
| Classify | `classify` | `issue_type`, `issue_summary`, `issue_profile` |
| Gather | `gather` | `evidence` |
| Judge | `judge` | `decision_action`, `decision_runbook`, `decision_reasoning`, `decision_confidence` |
| Act | `act` | `remediation_runbook`, `remediation_outcome`, `remediation_detail` |
| Confirm | `confirm` | `is_healthy`, `confirm_detail` |
| Analyze | `analyze` | `analysis_result`, `root_cause`, `next_steps`, `baseline_summary` |
| Control | retry node / any | `retry_count`, `errors` |
| Output | `summarize` | `event_log_entry` |

Field names map 1:1 to the columns in `AgentEvents_CL`, so existing LAW
dashboards and alerts keep working without change.

---

## Retry Behaviour

- `_MAX_RETRIES = 2`
- Retry loops from `confirm` → `retry` (increment counter) → **`judge`** (not
  `act`).
- On retry, `judge` reads `retry_count > 0` and escalates to
  `profile.escalation_runbook` without calling the LLM — this keeps retry
  cheap even for mechanical profiles and consistent for reasoned profiles.
- Retries exhausted (`retry_count >= 2`) → falls through to `analyze` with
  `is_healthy = False`. The RCA is still produced and written; the outcome in
  `AgentEvents_CL` reports the failure so ops can see it.

---

## Evidence Flow (why judge and analyze share data)

```
gather  ──►  evidence dict  ──►  judge    (subset reasoning: "should I act?")
                │
                └──────────────►  analyze  (full RCA: "what happened and why?")
```

`gather` collects once. `judge` uses it to decide the action. `analyze` uses
the *same* dict, plus the act/confirm outcomes, to produce deep RCA. No node
outside gather queries ADX — this avoids double-fetching and ensures judge
and analyze reason from identical evidence.

For forward-looking profiles like `http_5xx_flood`, `gather` will include
capture-runbook output (`CAPTURE_EVENT_LOG`, `CAPTURE_NETSTAT`,
`CAPTURE_REQUEST_QUEUE`) — volatile live state preserved *before* the pool is
recycled, so `analyze` can still reason about it after the fact.

---

## What changed from v2

| Concern | v2 | v3 |
|---|---|---|
| Paths | Dual: deterministic + AI | Single |
| Duplication | `det_remediate`/`ai_remediate`, `det_verify`/`ai_verify`, `det_report`/`ai_report`, `det_diagnose`/`rca_agent` | One each: `act`, `confirm`, `summarize`, `analyze` |
| Behaviour variance | Graph topology | `IssueProfile` row |
| Domain knowledge | `DIAGNOSE_ISSUES` frozenset in edge function, `ISSUE_RUNBOOK_MAP` in remediate agent, `_METRIC_CHECKS` dict in verify agent | Consolidated per-issue in one profile row |
| False-positive handling | `ai_detect` gate (caused CPU misclassification) | `judge` returns `no_action` if evidence doesn't confirm — no gate node |
| Veto authority | None | `REASONED_WITH_VETO` strategy lets judge refuse to remediate when cause is upstream |
| Retry target | `det_remediate` / `ai_remediate` via shared `increment_retry` router | Always back to `judge`, which picks `escalation_runbook` |
| Adding a new issue | Touch 4–5 files | One row in `profiles.py` |

---

## Extending

### Add a new issue type

1. Add a substring → issue_type entry in `agents/classify_agent.py` `_ALERT_TO_ISSUE`.
2. Add a new row to `PROFILES` in `agents/profiles.py`.

No new agents, no graph changes. The pipeline picks up the new issue on the
next request.

### Add a new gatherer

1. Add an entry to the `Gatherer` enum in `models/issue_profile.py`.
2. Implement the function in `agents/gather_agent.py` and register it in
   `_GATHERER_IMPL`.
3. Reference it from any profile that needs it.

### Add a new confirmation check

1. Add an entry to the `Check` enum.
2. Implement the check in `agents/confirm_agent.py` and register it in
   `_run_check`.
3. Reference it from any profile that needs it.

### Add a new decision strategy

Unlikely, but: add an enum value to `Strategy`, implement in
`agents/judge_agent.py`.

---

## AgentEvents_CL Schema (unchanged from v2)

| Field | Description |
|---|---|
| `TimeGenerated` | UTC timestamp of summarize |
| `VMHostname` | Target VM |
| `AlertId`, `AlertName`, `Severity` | Source alert |
| `IssueType`, `IssueSummary` | `classify` output |
| `DetectionTime` | When the alert fired |
| `AnalysisResult` | `analyze` narrative (or deterministic default) |
| `MitigationSteps` | Bullet-point summary built by `summarize` |
| `RunbookExecuted` | `act` runbook |
| `RemediationOutcome` | `success` / `failed` / `skipped` / `escalated` / `no_action` |
| `RemediationDetail` | Runbook job output + judge rationale |
| `IsHealthy` | `confirm` result |
| `RetryCount` | Attempts used |
| `RootCause` | `analyze` output (or deterministic default) |
| `NextSteps` | JSON array of preventive actions |
| `ReasoningModel` | `o4-mini` if analyze ran, else `none` |
| `FastModel` | `gpt-4o-mini` if judge reasoned, else `none` |
| `AgentVersion` | `3.0.0` |
| `TotalDurationSeconds` | End-to-end wall time |
| `DecisionAction` *(new)* | judge's chosen action |
| `DecisionConfidence` *(new)* | `high` / `medium` / `low` |
| `Strategy` *(new)* | profile strategy used |
| `EscalationTarget` *(new)* | paging destination if `escalate_*` action |
