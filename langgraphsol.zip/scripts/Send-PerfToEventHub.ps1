<#
.SYNOPSIS
    Collects VM/IIS performance counters and tails IIS W3C log files, sending
    all data to Azure Event Hubs via the VM managed identity (IMDS token).
    Runs as a Windows scheduled task (SYSTEM account) every 60 seconds.

.PARAMETER EventHubNamespace
    The Event Hub namespace name (e.g. iisheal-eh).  The .servicebus.windows.net
    suffix is appended automatically.

.NOTES
    Authentication: VM managed identity via IMDS endpoint.
    Destinations:   vmperf-eh   (VMPerf rows)
                    iisperf-eh  (IISPerf rows)
                    iislogs-eh  (IISLogs rows — tailed from disk)
    Format:         MULTIJSON — JSON array per message; ADX parses each element
                    as one row in the respective table.
    State file:     C:\Scripts\iislog_state.json — tracks byte offset per log
                    file so lines are never re-sent after a restart.
#>
param(
    [Parameter(Mandatory)]
    [string]$EventHubNamespace
)

Set-StrictMode -Version Latest
$ErrorActionPreference = 'SilentlyContinue'

# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------
$VmPerfHub    = 'vmperf-eh'
$IisPerfHub   = 'iisperf-eh'
$IisLogsHub   = 'iislogs-eh'
$EhBaseUri    = "https://${EventHubNamespace}.servicebus.windows.net"
$Computer     = $env:COMPUTERNAME
$IisLogDir    = 'C:\inetpub\logs\LogFiles\W3SVC1'
# HTTP.sys kernel-level error log — captures 503s from app pool crashes/stops,
# queue floods, and other failures that never reach the IIS W3C access log.
$HttpErrDir   = 'C:\Windows\System32\LogFiles\HTTPERR'
$StateFile    = 'C:\Scripts\iislog_state.json'
$MaxRowsPerMsg = 500   # keep Event Hub messages under ~1 MB

# ---------------------------------------------------------------------------
# Acquire bearer token from IMDS (VM Managed Identity)
# ---------------------------------------------------------------------------
function Get-ImdsToken {
    try {
        $response = Invoke-RestMethod `
            -Uri     'http://169.254.169.254/metadata/identity/oauth2/token?api-version=2018-02-01&resource=https%3A%2F%2Feventhubs.azure.net%2F' `
            -Headers @{ Metadata = 'true' } `
            -Method  Get
        return $response.access_token
    }
    catch {
        Write-Warning "IMDS token request failed: $_"
        return $null
    }
}

# ---------------------------------------------------------------------------
# Send a JSON array body to an Event Hub
# ---------------------------------------------------------------------------
function Send-ToEventHub {
    param(
        [string]$Token,
        [string]$HubName,
        [string]$Body
    )
    try {
        $uri = "${EhBaseUri}/${HubName}/messages"
        Invoke-RestMethod `
            -Uri         $uri `
            -Method      Post `
            -Headers     @{ Authorization = "Bearer $Token" } `
            -ContentType 'application/json' `
            -Body        $Body | Out-Null
    }
    catch {
        Write-Warning "Failed to send to ${HubName}: $_"
    }
}

# ---------------------------------------------------------------------------
# Helper: convert a CounterSample to a row hashtable
# ---------------------------------------------------------------------------
function ConvertTo-Row {
    param($Sample, [string]$ObjectName)
    # Get-Counter returns PerformanceCounterSample objects whose counter name
    # is embedded in the Path property:  \\server\object(instance)\countername
    # Parse the counter name from the last segment after the final backslash.
    $counterName = ($Sample.Path -split '\\')[-1]
    @{
        TimeGenerated = (Get-Date).ToUniversalTime().ToString('o')
        Computer      = $Computer
        ObjectName    = $ObjectName
        CounterName   = $counterName
        InstanceName  = if ($Sample.InstanceName) { $Sample.InstanceName } else { '_Total' }
        CounterValue  = [math]::Round($Sample.CookedValue, 4)
    }
}

# ---------------------------------------------------------------------------
# Acquire token — shared by all three Event Hubs
# ---------------------------------------------------------------------------
$token = Get-ImdsToken
if (-not $token) { exit 1 }

# ---------------------------------------------------------------------------
# 1. VM-level counters  →  vmperf-eh
# ---------------------------------------------------------------------------
$vmCounterPaths = @(
    '\Processor(_Total)\% Processor Time'
    '\Memory\Available MBytes'
    '\Memory\% Committed Bytes In Use'
    '\Memory\Pages/sec'
    '\LogicalDisk(C:)\% Free Space'
    '\LogicalDisk(_Total)\Disk Reads/sec'
    '\LogicalDisk(_Total)\Disk Writes/sec'
    '\PhysicalDisk(_Total)\Avg. Disk Queue Length'
    '\System\Processor Queue Length'
    '\Network Interface(*)\Bytes Total/sec'
)

$vmRows = [System.Collections.Generic.List[object]]::new()
try {
    # 3 samples 10 seconds apart (20s total).  Sending multiple samples per
    # collection cycle lets the KQL count how many consecutive 10-second windows
    # were above threshold — a 1-second transient spike produces at most 1 high
    # sample, while a 20+ second sustained spike produces 2 or more.
    #
    # IMPORTANT: Get-Counter -MaxSamples 3 returns an array of PerformanceCounterSampleSet
    # objects.  Accessing .CounterSamples via member-access enumeration on that array
    # produces a *jagged* array (array-of-arrays), not a flat array.  A plain
    # foreach over a jagged array iterates over the inner arrays — each $s would
    # be a 10-element array rather than a single sample, corrupting every row.
    # Use explicit nested foreach loops to unambiguously process each sample set
    # and each individual counter sample within it.
    $sampleSets = Get-Counter -Counter $vmCounterPaths -SampleInterval 10 -MaxSamples 3 `
                      -ErrorAction SilentlyContinue
    foreach ($sampleSet in @($sampleSets)) {
        foreach ($s in $sampleSet.CounterSamples) {
            # break after first match prevents double-assignment when a path
            # contains multiple object keywords (e.g. \System\Processor Queue
            # Length matches both *\Processor* and *\System*).
            # *\System* is listed before *\Processor* so that Processor Queue
            # Length (object=System) is correctly labelled 'System', while
            # \Processor(_Total)\% Processor Time (no \System\ in path) still
            # falls through to *\Processor*.
            $obj = switch -Wildcard ($s.Path) {
                '*\Memory*'            { 'Memory';            break }
                '*\LogicalDisk*'       { 'LogicalDisk';       break }
                '*\PhysicalDisk*'      { 'PhysicalDisk';      break }
                '*\Network Interface*' { 'Network Interface'; break }
                '*\System*'            { 'System';            break }
                '*\Processor*'         { 'Processor';         break }
                default                { 'System' }
            }
            $vmRows.Add((ConvertTo-Row -Sample $s -ObjectName $obj))
        }
    }
}
catch { Write-Warning "VM counter collection failed: $_" }

if ($vmRows.Count -gt 0) {
    $body = $vmRows | ConvertTo-Json -Compress -Depth 3
    if (-not $body.StartsWith('[')) { $body = "[$body]" }
    Send-ToEventHub -Token $token -HubName $VmPerfHub -Body $body
}

# ---------------------------------------------------------------------------
# 2. IIS / ASP.NET / w3wp counters  →  iisperf-eh
# ---------------------------------------------------------------------------
$iisCounterPaths = @(
    '\Web Service(_Total)\Current Connections'
    '\Web Service(_Total)\Connection Attempts Failed'
    '\Web Service(_Total)\Not Found Errors/sec'
    '\Web Service(_Total)\Bytes Total/sec'
    '\Web Service(_Total)\Get Requests/sec'
    '\Web Service(_Total)\Post Requests/sec'
    '\ASP.NET\Application Restarts'
    '\ASP.NET\Requests Queued'
    '\ASP.NET\Request Wait Time'
    '\ASP.NET Applications(__Total__)\Requests/Sec'
    '\ASP.NET Applications(__Total__)\Errors Total/Sec'
    '\ASP.NET Applications(__Total__)\Request Execution Time'
    '\Process(w3wp*)\% Processor Time'
    '\Process(w3wp*)\Working Set'
    '\Process(w3wp*)\Thread Count'
    '\Process(w3wp*)\Handle Count'
)

$iisRows = [System.Collections.Generic.List[object]]::new()
try {
    $iisSamples = (Get-Counter -Counter $iisCounterPaths -SampleInterval 1 -MaxSamples 1 `
                       -ErrorAction SilentlyContinue).CounterSamples
    foreach ($s in $iisSamples) {
        $obj = switch -Wildcard ($s.Path) {
            '*\Web Service*'          { 'Web Service';          break }
            '*\ASP.NET Applications*' { 'ASP.NET Applications'; break }
            '*\ASP.NET\*'             { 'ASP.NET';              break }
            '*\Process(w3wp*)*'       { 'Process';              break }
            default                   { 'IIS' }
        }
        $iisRows.Add((ConvertTo-Row -Sample $s -ObjectName $obj))
    }
}
catch { Write-Warning "IIS counter collection failed: $_" }

# ---------------------------------------------------------------------------
# W3SVC synthetic heartbeat — inject a "Current Connections = 0" row when
# W3SVC is not running so the IISMonitorPoller KQL can detect the stopped
# service.  When W3SVC is stopped the \Web Service performance counter object
# is unregistered by Windows and Get-Counter returns nothing (not 0) for
# those paths, so without this row the RowCount >= 3 guard in the KQL would
# never be satisfied and healing would never trigger.
# ---------------------------------------------------------------------------
$w3svcStatus = (Get-Service -Name 'W3SVC' -ErrorAction SilentlyContinue).Status
if ($w3svcStatus -ne 'Running') {
    $iisRows.Add(@{
        TimeGenerated = (Get-Date).ToUniversalTime().ToString('o')
        Computer      = $Computer
        ObjectName    = 'Web Service'
        CounterName   = 'Current Connections'
        InstanceName  = '_Total'
        CounterValue  = 0
    })
}

if ($iisRows.Count -gt 0) {
    $body = $iisRows | ConvertTo-Json -Compress -Depth 3
    if (-not $body.StartsWith('[')) { $body = "[$body]" }
    Send-ToEventHub -Token $token -HubName $IisPerfHub -Body $body
}

# ---------------------------------------------------------------------------
# 3. IIS W3C log files (tail)  →  iislogs-eh
#
# State file tracks the last byte offset read per log file so no line is
# sent twice, even across script restarts or log file rollovers.
# ---------------------------------------------------------------------------
try {
    # Load or initialise state
    $state = @{}
    if (Test-Path $StateFile) {
        try {
            $loaded = Get-Content $StateFile -Raw | ConvertFrom-Json
            $loaded.PSObject.Properties | ForEach-Object { $state[$_.Name] = $_.Value }
        }
        catch { $state = @{} }
    }

    if (Test-Path $IisLogDir) {
        $logFiles = Get-ChildItem "$IisLogDir\*.log" -ErrorAction SilentlyContinue |
                    Sort-Object LastWriteTime

        foreach ($logFile in $logFiles) {
            $key     = $logFile.Name
            $lastPos = if ($state.ContainsKey($key)) { [long]$state[$key] } else { 0L }

            # Skip files that haven't grown since last run
            if ($logFile.Length -le $lastPos) { continue }

            $newLines = [System.Collections.Generic.List[string]]::new()
            $newPos   = $lastPos

            try {
                $fs = [System.IO.File]::Open(
                    $logFile.FullName,
                    [System.IO.FileMode]::Open,
                    [System.IO.FileAccess]::Read,
                    [System.IO.FileShare]::ReadWrite
                )
                $fs.Seek($lastPos, [System.IO.SeekOrigin]::Begin) | Out-Null
                $reader = [System.IO.StreamReader]::new($fs, [System.Text.Encoding]::UTF8)

                while (-not $reader.EndOfStream) {
                    $line = $reader.ReadLine()
                    # Skip W3C header lines and blank lines
                    if ($line -and -not $line.StartsWith('#')) {
                        $newLines.Add($line)
                    }
                }
                $newPos = $fs.Position
                $reader.Close()
                $fs.Close()
            }
            catch { Write-Warning "Error reading $($logFile.Name): $_" }

            # Send in batches capped at $MaxRowsPerMsg to stay under EH 1 MB limit
            if ($newLines.Count -gt 0) {
                $now = (Get-Date).ToUniversalTime().ToString('o')
                for ($i = 0; $i -lt $newLines.Count; $i += $MaxRowsPerMsg) {
                    $batch = $newLines | Select-Object -Skip $i -First $MaxRowsPerMsg
                    $rows  = $batch | ForEach-Object {
                        @{
                            TimeGenerated = $now
                            Computer      = $Computer
                            FilePath      = $logFile.FullName
                            RawData       = $_
                        }
                    }
                    $body = $rows | ConvertTo-Json -Compress -Depth 3
                    if (-not $body.StartsWith('[')) { $body = "[$body]" }
                    Send-ToEventHub -Token $token -HubName $IisLogsHub -Body $body
                }
            }

            $state[$key] = $newPos
        }
    }

    # Persist updated state
    $stateObj = [ordered]@{}
    $state.GetEnumerator() | ForEach-Object { $stateObj[$_.Key] = $_.Value }
    $stateObj | ConvertTo-Json | Set-Content $StateFile -Encoding UTF8
}
catch {
    Write-Warning "IIS log tailing failed: $_"
}

# ---------------------------------------------------------------------------
# 4. HTTP.sys error logs (HTTPERR)  →  iislogs-eh
#
# HTTP.sys logs kernel-level failures (503 app pool crash/stop, queue flood,
# binding errors) to C:\Windows\System32\LogFiles\HTTPERR\httperr*.log.
# These NEVER appear in the IIS W3C access log (Section 3 above), so 503s
# from chaos scenarios 1, 2, 6, 8, and 10 would otherwise be invisible.
#
# Rows are sent with LogType='HTTPERR' so the ADX update policy can
# distinguish them from W3C entries and populate IISLogsParsed correctly.
# HTTPERR field order: date time c-ip c-port s-ip s-port cs-version cs-verb
#                      cs-uri sc-status s-siteid s-reason s-queuename
# ---------------------------------------------------------------------------
try {
    $errState = @{}
    $errStateFile = 'C:\Scripts\httperr_state.json'
    if (Test-Path $errStateFile) {
        try {
            $loaded = Get-Content $errStateFile -Raw | ConvertFrom-Json
            $loaded.PSObject.Properties | ForEach-Object { $errState[$_.Name] = $_.Value }
        }
        catch { $errState = @{} }
    }

    if (Test-Path $HttpErrDir) {
        $errFiles = Get-ChildItem "$HttpErrDir\httperr*.log" -ErrorAction SilentlyContinue |
                    Sort-Object LastWriteTime

        foreach ($errFile in $errFiles) {
            $key     = $errFile.Name
            $lastPos = if ($errState.ContainsKey($key)) { [long]$errState[$key] } else { 0L }

            if ($errFile.Length -le $lastPos) { continue }

            $newLines = [System.Collections.Generic.List[string]]::new()
            $newPos   = $lastPos

            try {
                $fs = [System.IO.File]::Open(
                    $errFile.FullName,
                    [System.IO.FileMode]::Open,
                    [System.IO.FileAccess]::Read,
                    [System.IO.FileShare]::ReadWrite
                )
                $fs.Seek($lastPos, [System.IO.SeekOrigin]::Begin) | Out-Null
                $reader = [System.IO.StreamReader]::new($fs, [System.Text.Encoding]::UTF8)

                while (-not $reader.EndOfStream) {
                    $line = $reader.ReadLine()
                    # Skip header/comment lines and blank lines
                    if ($line -and -not $line.StartsWith('#')) {
                        $newLines.Add($line)
                    }
                }
                $newPos = $fs.Position
                $reader.Close()
                $fs.Close()
            }
            catch { Write-Warning "Error reading $($errFile.Name): $_" }

            if ($newLines.Count -gt 0) {
                $now = (Get-Date).ToUniversalTime().ToString('o')
                for ($i = 0; $i -lt $newLines.Count; $i += $MaxRowsPerMsg) {
                    $batch = $newLines | Select-Object -Skip $i -First $MaxRowsPerMsg
                    $rows  = $batch | ForEach-Object {
                        @{
                            TimeGenerated = $now
                            Computer      = $Computer
                            FilePath      = $errFile.FullName
                            LogType       = 'HTTPERR'
                            RawData       = $_
                        }
                    }
                    $body = $rows | ConvertTo-Json -Compress -Depth 3
                    if (-not $body.StartsWith('[')) { $body = "[$body]" }
                    Send-ToEventHub -Token $token -HubName $IisLogsHub -Body $body
                }
            }

            $errState[$key] = $newPos
        }
    }

    $errStateObj = [ordered]@{}
    $errState.GetEnumerator() | ForEach-Object { $errStateObj[$_.Key] = $_.Value }
    $errStateObj | ConvertTo-Json | Set-Content $errStateFile -Encoding UTF8
}
catch {
    Write-Warning "HTTPERR log tailing failed: $_"
}
