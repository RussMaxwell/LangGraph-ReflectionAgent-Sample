#!/usr/bin/env bash
set -euo pipefail

###############################################################################
# deploy.sh - Full deployment for IIS Auto-Healing (subscription scope)
#
# Creates two resource groups and deploys everything into them:
#   iis-core         — VM, networking, Function App
#   iis-core-monitor — LAW, ADX, Event Hubs, Automation, OpenAI, alerts
#
# After infrastructure is ready this script also:
#   - Deploys the chaos web app files to the VM
#   - Publishes Function App code (if func CLI is installed)
#   - Uploads and publishes all runbooks to the Automation Account
#
# Usage:
#   export VM_ADMIN_PASSWORD='YourP@ssw0rd!'
#   bash scripts/deploy.sh
#
# Optional overrides:
#   export DEPLOY_LOCATION='eastus2'    # defaults to eastus2
#   export SUBSCRIPTION_ID='...'       # override active subscription
###############################################################################

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_ROOT="$(cd "$SCRIPT_DIR/.." && pwd)"

DEPLOY_LOCATION="${DEPLOY_LOCATION:-eastus2}"
CORE_RG="iis-core"
MONITOR_RG="iis-core-monitor"

# ── Colour helpers ─────────────────────────────────────────────────────────────
RED='\033[0;31m'; GREEN='\033[0;32m'; YELLOW='\033[1;33m'; CYAN='\033[0;36m'; NC='\033[0m'
info()  { echo -e "${CYAN}[INFO]${NC}  $*"; }
ok()    { echo -e "${GREEN}[OK]${NC}    $*"; }
warn()  { echo -e "${YELLOW}[WARN]${NC}  $*"; }
die()   { echo -e "${RED}[ERROR]${NC} $*" >&2; exit 1; }

# ── 1. Prerequisites ───────────────────────────────────────────────────────────
info "Checking prerequisites..."

[[ -z "${VM_ADMIN_PASSWORD:-}" ]] && die "VM_ADMIN_PASSWORD is not set. Export it before running."
command -v az     >/dev/null 2>&1 || die "Azure CLI (az) not found."
command -v base64 >/dev/null 2>&1 || die "base64 not found."

if ! command -v jq &>/dev/null; then
    info "jq not found — attempting to install..."
    if command -v apt-get &>/dev/null; then
        sudo apt-get install -y jq
    elif command -v brew &>/dev/null; then
        brew install jq
    elif command -v winget &>/dev/null; then
        winget install jqlang.jq --silent
    else
        die "jq not found and could not be auto-installed. Install manually: https://stedolan.github.io/jq/download/"
    fi
    command -v jq &>/dev/null || die "jq installation failed."
    ok "jq installed."
fi

if ! az account show --output none 2>/dev/null; then
    warn "Not logged in. Launching az login..."
    az login --output none
fi
ok "Azure CLI authenticated."

if [[ -n "${SUBSCRIPTION_ID:-}" ]]; then
    az account set --subscription "$SUBSCRIPTION_ID"
    ok "Subscription set to $SUBSCRIPTION_ID."
fi

az account show --query "{Subscription:name, Id:id}" --output table

info "Ensuring Bicep CLI is installed..."
az bicep install 2>/dev/null || true
ok "Bicep CLI ready: $(az bicep version --only-show-errors 2>&1 | head -1)"

echo ""

# ── 2. (Deployer-IP detection removed)  ───────────────────────────────────────
# The VM no longer has a public IP.  RDP goes through Azure Bastion, so no NSG
# rule needs the deployer's public IP.  Kept commented here for history.

EXTRA_PARAMS=""

# ── 3. Deploy infrastructure (subscription scope) ──────────────────────────────
info "Deploying infrastructure at subscription scope (this takes ~15-25 minutes)..."
info "  Core RG     : $CORE_RG"
info "  Monitor RG  : $MONITOR_RG"
info "  Location    : $DEPLOY_LOCATION"
echo ""

DEPLOYMENT_NAME="iis-autohealing-$(date +%Y%m%d%H%M%S)"

az deployment sub create \
    --name           "$DEPLOYMENT_NAME" \
    --location       "$DEPLOY_LOCATION" \
    --template-file  "$PROJECT_ROOT/infra/main.bicep" \
    --parameters     "$PROJECT_ROOT/infra/parameters/dev.bicepparam" \
    --parameters     adminPassword="$VM_ADMIN_PASSWORD" $EXTRA_PARAMS \
    --output none || true

# Verify provisioning state (az CLI can swallow some output on success)
PROV_STATE=$(az deployment sub show \
    --name "$DEPLOYMENT_NAME" \
    --query "properties.provisioningState" \
    --output tsv 2>/dev/null || echo "NotFound")

[[ "$PROV_STATE" != "Succeeded" ]] \
  && die "Deployment did not succeed (state: $PROV_STATE). Check the Azure portal for details."

ok "Infrastructure deployment complete."

# ── 4. Capture deployment outputs ─────────────────────────────────────────────
info "Capturing deployment outputs..."
OUTPUTS=$(az deployment sub show \
    --name   "$DEPLOYMENT_NAME" \
    --query  "properties.outputs" \
    --output json)

get_out() { echo "$OUTPUTS" | jq -r ".$1.value // empty"; }

VM_NAME=$(get_out vmName)
VM_IP=$(get_out vmPrivateIp)
BASTION_NAME=$(get_out bastionName)
LAW_ID=$(get_out lawWorkspaceId)
LAW_CUSTOMER_ID=$(get_out lawWorkspaceCustomerId)
DCE_ENDPOINT=$(get_out dceEndpoint)
FUNC_APP_NAME=$(get_out functionAppName)
FUNC_APP_HOST=$(get_out functionAppHostname)
AUTO_ACCOUNT=$(get_out automationAccountName)
OPENAI_ENDPOINT=$(get_out openaiEndpoint)
OPENAI_NAME=$(get_out openaiName)
ADX_URI=$(get_out adxClusterUri)
ADX_DB=$(get_out adxDatabaseName)
EH_NAMESPACE=$(get_out eventHubNamespaceName)

ok "Outputs captured."

# ── 4b. Deploy ADX data connections (after RBAC propagation delay) ────────────
# Azure RBAC role assignments can take 2-5 minutes to replicate through the auth
# system.  Deploying ADX Event Hub data connections before the ADX cluster MSI
# holds EventHubs Data Receiver results in BadInput / Internal Server Error.
# We wait 150 s here; the ADX table-creation REST calls below add another 30-60 s
# of buffer, giving ~3.5 minutes before the first connection-deployment attempt.
# A retry loop covers the rare case where propagation takes longer.
info "Waiting 150 seconds for RBAC role assignments to propagate..."
sleep 150

ADX_NAME=$(get_out adxClusterName)

# Look up resource IDs via az — avoids Git Bash mangling paths that start with /
info "Looking up ADX and Event Hub resource IDs..."
ADX_CLUSTER_ID=$(az kusto cluster show \
    --name "$ADX_NAME" --resource-group "$MONITOR_RG" \
    --query id --output tsv)
IISLOGS_EH_ID=$(az eventhubs eventhub show \
    --name iislogs-eh --namespace-name "$EH_NAMESPACE" --resource-group "$MONITOR_RG" \
    --query id --output tsv)
VMPERF_EH_ID=$(az eventhubs eventhub show \
    --name vmperf-eh --namespace-name "$EH_NAMESPACE" --resource-group "$MONITOR_RG" \
    --query id --output tsv)
IISPERF_EH_ID=$(az eventhubs eventhub show \
    --name iisperf-eh --namespace-name "$EH_NAMESPACE" --resource-group "$MONITOR_RG" \
    --query id --output tsv)
BASELINE_EH_ID=$(az eventhubs eventhub show \
    --name baseline-eh --namespace-name "$EH_NAMESPACE" --resource-group "$MONITOR_RG" \
    --query id --output tsv)

# Ensure all ADX tables and ingestion mappings exist.
# The Bicep script resource (create-iis-tables) is idempotent on first deploy,
# but won't re-run if already provisioned. Creating tables via REST is safe and
# guarantees they exist before the data connections reference them.
ADX_URI="https://${ADX_NAME}.${DEPLOY_LOCATION}.kusto.windows.net"
info "Ensuring ADX tables exist in '$ADX_DB'..."

create_adx_table() {
    local csl="$1"
    az rest --method post \
        --uri "${ADX_URI}/v1/rest/mgmt" \
        --body "{\"db\":\"${ADX_DB}\",\"csl\":\"${csl}\"}" \
        --headers "Content-Type=application/json" \
        --resource "https://kusto.kusto.windows.net" \
        --output none 2>/dev/null || true
}

create_adx_table ".create-merge table IISLogs (TimeGenerated:datetime, Computer:string, FilePath:string, LogType:string, RawData:string)"
create_adx_table ".create-merge table VMPerf (TimeGenerated:datetime, Computer:string, ObjectName:string, CounterName:string, InstanceName:string, CounterValue:real)"
create_adx_table ".create-merge table IISPerf (TimeGenerated:datetime, Computer:string, ObjectName:string, CounterName:string, InstanceName:string, CounterValue:real)"
create_adx_table ".create-merge table PerformanceBaseline (TimeGenerated:datetime, Computer:string, RecordType:string, MetricName:string, MetricValue:real, CaptureId:string, WindowIndex:int)"

create_adx_table ".create-or-alter table IISLogs ingestion json mapping 'IISLogsMapping' '[{\"column\":\"TimeGenerated\",\"path\":\"$.TimeGenerated\",\"datatype\":\"datetime\"},{\"column\":\"Computer\",\"path\":\"$.Computer\",\"datatype\":\"string\"},{\"column\":\"FilePath\",\"path\":\"$.FilePath\",\"datatype\":\"string\"},{\"column\":\"LogType\",\"path\":\"$.LogType\",\"datatype\":\"string\"},{\"column\":\"RawData\",\"path\":\"$.RawData\",\"datatype\":\"string\"}]'"
create_adx_table ".create-or-alter table VMPerf ingestion json mapping 'VMPerfMapping' '[{\"column\":\"TimeGenerated\",\"path\":\"$.TimeGenerated\",\"datatype\":\"datetime\"},{\"column\":\"Computer\",\"path\":\"$.Computer\",\"datatype\":\"string\"},{\"column\":\"ObjectName\",\"path\":\"$.ObjectName\",\"datatype\":\"string\"},{\"column\":\"CounterName\",\"path\":\"$.CounterName\",\"datatype\":\"string\"},{\"column\":\"InstanceName\",\"path\":\"$.InstanceName\",\"datatype\":\"string\"},{\"column\":\"CounterValue\",\"path\":\"$.CounterValue\",\"datatype\":\"real\"}]'"
create_adx_table ".create-or-alter table IISPerf ingestion json mapping 'IISPerfMapping' '[{\"column\":\"TimeGenerated\",\"path\":\"$.TimeGenerated\",\"datatype\":\"datetime\"},{\"column\":\"Computer\",\"path\":\"$.Computer\",\"datatype\":\"string\"},{\"column\":\"ObjectName\",\"path\":\"$.ObjectName\",\"datatype\":\"string\"},{\"column\":\"CounterName\",\"path\":\"$.CounterName\",\"datatype\":\"string\"},{\"column\":\"InstanceName\",\"path\":\"$.InstanceName\",\"datatype\":\"string\"},{\"column\":\"CounterValue\",\"path\":\"$.CounterValue\",\"datatype\":\"real\"}]'"
create_adx_table ".create-or-alter table PerformanceBaseline ingestion json mapping 'BaselineMapping' '[{\"column\":\"TimeGenerated\",\"path\":\"$.TimeGenerated\",\"datatype\":\"datetime\"},{\"column\":\"Computer\",\"path\":\"$.Computer\",\"datatype\":\"string\"},{\"column\":\"RecordType\",\"path\":\"$.RecordType\",\"datatype\":\"string\"},{\"column\":\"MetricName\",\"path\":\"$.MetricName\",\"datatype\":\"string\"},{\"column\":\"MetricValue\",\"path\":\"$.MetricValue\",\"datatype\":\"real\"},{\"column\":\"CaptureId\",\"path\":\"$.CaptureId\",\"datatype\":\"string\"},{\"column\":\"WindowIndex\",\"path\":\"$.WindowIndex\",\"datatype\":\"int\"}]'"

# IISLogsParsed — W3C access log entries parsed via update policy on IISLogs.
# ParseIISLogs() filters out LogType='HTTPERR' rows; those go to IISHttpErrors.
create_adx_table ".create-merge table IISLogsParsed (TimeGenerated:datetime, Computer:string, SiteName:string, ServerIP:string, Method:string, UriStem:string, UriQuery:string, Port:int, Username:string, ClientIP:string, HttpVersion:string, UserAgent:string, Cookie:string, Referer:string, Host:string, StatusCode:int, SubStatus:int, Win32Status:int, TimeTakenMs:int, BytesSent:int, BytesReceived:int)"

create_adx_table ".create-or-alter function ParseIISLogs() { IISLogs | where (isempty(LogType) or LogType != 'HTTPERR') and RawData !startswith \"#\" and isnotempty(RawData) | parse RawData with LogDate:string \" \" LogTime:string \" \" SiteName:string \" \" Computer2:string \" \" ServerIP:string \" \" Method:string \" \" UriStem:string \" \" UriQuery:string \" \" Port:int \" \" Username:string \" \" ClientIP:string \" \" HttpVersion:string \" \" UserAgent:string \" \" Cookie:string \" \" Referer:string \" \" Host:string \" \" StatusCode:int \" \" SubStatus:int \" \" Win32Status:int \" \" TimeTakenMs:int \" \" BytesSent:int \" \" BytesReceived:int | project TimeGenerated, Computer, SiteName, ServerIP, Method, UriStem, UriQuery, Port, Username, ClientIP, HttpVersion, UserAgent=replace_string(UserAgent, \"+\", \" \"), Cookie, Referer, Host, StatusCode, SubStatus, Win32Status, TimeTakenMs, BytesSent, BytesReceived }"

# IISHttpErrors — HTTP.sys kernel-level errors (503s) parsed via update policy on IISLogs.
# Captures app pool crash/stop, queue flood, worker hang — events that never reach the W3C log.
# HTTPERR field order: date time c-ip c-port s-ip s-port cs-version cs-verb
#                      cs-uri sc-status s-siteid s-reason s-queuename
create_adx_table ".create-merge table IISHttpErrors (TimeGenerated:datetime, Computer:string, ClientIP:string, ClientPort:int, ServerIP:string, Port:int, HttpVersion:string, Method:string, UriStem:string, StatusCode:int, SiteId:int, Reason:string, QueueName:string)"

# HTTPERR format has 16 fields — streamid and streamid_ex sit between cs-uri and sc-status:
# date time c-ip c-port s-ip s-port cs-version cs-method cs-uri streamid streamid_ex sc-status s-siteid s-reason s-queuename transport
create_adx_table ".create-or-alter function ParseHttpErrors() { IISLogs | where LogType == 'HTTPERR' and isnotempty(RawData) | parse RawData with LogDate:string \" \" LogTime:string \" \" ClientIP:string \" \" ClientPort_s:string \" \" ServerIP:string \" \" Port_s:string \" \" HttpVersion:string \" \" Method:string \" \" UriStem:string \" \" StreamId:string \" \" StreamIdEx:string \" \" StatusCode:int \" \" SiteId_s:string \" \" Reason:string \" \" QueueName:string \" \" Transport:string | project TimeGenerated, Computer, ClientIP, ClientPort=toint(ClientPort_s), ServerIP, Port=toint(Port_s), HttpVersion, Method, UriStem, StatusCode, SiteId=toint(SiteId_s), Reason, QueueName }"

# Set update policies — runs on every batch ingested into IISLogs
az rest --method post \
    --uri "${ADX_URI}/v1/rest/mgmt" \
    --body "{\"db\":\"${ADX_DB}\",\"csl\":\".alter table IISLogsParsed policy update @'[{\\\"IsEnabled\\\": true, \\\"Source\\\": \\\"IISLogs\\\", \\\"Query\\\": \\\"ParseIISLogs()\\\", \\\"IsTransactional\\\": false, \\\"PropagateIngestionProperties\\\": true}]'\"}" \
    --headers "Content-Type=application/json" \
    --resource "https://kusto.kusto.windows.net" \
    --output none 2>/dev/null || true

az rest --method post \
    --uri "${ADX_URI}/v1/rest/mgmt" \
    --body "{\"db\":\"${ADX_DB}\",\"csl\":\".alter table IISHttpErrors policy update @'[{\\\"IsEnabled\\\": true, \\\"Source\\\": \\\"IISLogs\\\", \\\"Query\\\": \\\"ParseHttpErrors()\\\", \\\"IsTransactional\\\": false, \\\"PropagateIngestionProperties\\\": true}]'\"}" \
    --headers "Content-Type=application/json" \
    --resource "https://kusto.kusto.windows.net" \
    --output none 2>/dev/null || true

# Ingestion batching policies — 30 s (ADX minimum for Event Hub connections).
# Default is 5 minutes; capping at 30 s ensures the 60-second IISMonitorPoller
# and Send-PerfToEventHub.ps1 cycles always see the latest ingested data.
# IISLogs drives IISLogsParsed and IISHttpErrors via update policy, so setting
# it here is sufficient for all three derived tables.
# Note: create_adx_table cannot handle the nested JSON quoting required for
# policy commands, so we use temp files with az rest --body @file instead.
for _tbl in IISLogs VMPerf IISPerf; do
    _tmpf=$(mktemp --suffix=.json)
    cat > "$_tmpf" << EOF
{"db":"${ADX_DB}","csl":".alter table ${_tbl} policy ingestionbatching '{\"MaximumBatchingTimeSpan\":\"00:00:30\",\"MaximumNumberOfItems\":500,\"MaximumRawDataSizeMB\":1024}'"}
EOF
    az rest --method post \
        --uri "${ADX_URI}/v1/rest/mgmt" \
        --body "@${_tmpf}" \
        --headers "Content-Type=application/json" \
        --resource "https://kusto.kusto.windows.net" \
        --output none 2>/dev/null || true
    rm "$_tmpf"
done

ok "ADX tables, mappings, IISLogsParsed and IISHttpErrors update policies verified."

info "Deploying ADX Event Hub data connections..."
# Convert the template path to a Windows-native path before setting MSYS_NO_PATHCONV=1.
# MSYS_NO_PATHCONV=1 stops Git Bash converting resource ID strings (which start with /subscriptions/)
# but it also blocks template file path conversion — so we do that conversion here first.
ADX_CONN_TEMPLATE=$(cygpath -w "$PROJECT_ROOT/infra/modules/adx_connections.bicep" 2>/dev/null \
    || echo "$PROJECT_ROOT/infra/modules/adx_connections.bicep")

# Retry loop: ADX validates Event Hub connectivity at creation time, which requires
# the ADX cluster MSI's EventHubs Data Receiver RBAC assignment to be fully
# replicated.  If the first attempt fails with BadInput, we wait 60 s and retry.
_adx_conn_max_attempts=4
_adx_conn_attempt=0
while true; do
    _adx_conn_attempt=$(( _adx_conn_attempt + 1 ))
    info "ADX connections deployment attempt ${_adx_conn_attempt}/${_adx_conn_max_attempts}..."
    if MSYS_NO_PATHCONV=1 az deployment group create \
        --resource-group "$MONITOR_RG" \
        --template-file  "$ADX_CONN_TEMPLATE" \
        --parameters \
            location="$DEPLOY_LOCATION" \
            adxClusterName="$ADX_NAME" \
            adxClusterId="$ADX_CLUSTER_ID" \
            adxDatabaseName="$ADX_DB" \
            iisLogsEventHubId="$IISLOGS_EH_ID" \
            iisLogsConsumerGroupName="adx-consumer" \
            vmPerfEventHubId="$VMPERF_EH_ID" \
            vmPerfConsumerGroupName="adx-consumer" \
            iisPerfEventHubId="$IISPERF_EH_ID" \
            iisPerfConsumerGroupName="adx-consumer" \
            baselineEventHubId="$BASELINE_EH_ID" \
            baselineConsumerGroupName="adx-consumer" \
        --output none 2>&1; then
        ok "ADX data connections deployed (iislogs, vmperf, iisperf, baseline)."
        break
    fi
    if [[ $_adx_conn_attempt -ge $_adx_conn_max_attempts ]]; then
        die "ADX data connections failed after ${_adx_conn_max_attempts} attempts. RBAC may need more time — re-run deploy.sh."
    fi
    warn "ADX connections attempt ${_adx_conn_attempt} failed (RBAC likely not yet propagated). Waiting 60 s before retry..."
    sleep 60
done

# ── 4c. Create Agent Logging DCRs ────────────────────────────────────────────
# The Function App uses DCR-based ingestion (LogsIngestionClient) to write
# healing events and errors to AgentEvents_CL / AgentErrors_CL custom tables
# in Log Analytics.  Each table needs its own Data Collection Rule + RBAC.
info "Configuring agent logging Data Collection Rules..."

# Look up the DCE resource ID (Bicep outputs the endpoint URL, but DCRs need the resource ID)
DCE_ID=$(az monitor data-collection endpoint list \
    --resource-group "$MONITOR_RG" \
    --query "[?starts_with(name,'iisheal')].id | [0]" --output tsv 2>/dev/null)

[[ -z "$DCE_ID" ]] && die "Could not find Data Collection Endpoint in $MONITOR_RG"
ok "DCE resource ID: $DCE_ID"

# Get Function App managed identity principal ID
FUNC_MI_PRINCIPAL=$(az functionapp identity show \
    --name "$FUNC_APP_NAME" --resource-group "$CORE_RG" \
    --query principalId --output tsv 2>/dev/null)

[[ -z "$FUNC_MI_PRINCIPAL" ]] && die "Function App managed identity not found."
ok "Function App MI principal: $FUNC_MI_PRINCIPAL"

SUBSCRIPTION_ID=$(az account show --query id --output tsv)

# Helper: PUT (create or update) a DCR, returns its immutableId.
# Always PUTs so schema stays in sync on every deploy — not just first create.
# cygpath converts the Unix temp path to a Windows-native path so az CLI can
# read the file body correctly when MSYS_NO_PATHCONV=1 is set.
upsert_agent_dcr() {
    local dcr_name="$1" dcr_body_file="$2"
    local win_path
    win_path=$(cygpath -w "$dcr_body_file")
    MSYS_NO_PATHCONV=1 az rest --method PUT \
        --uri "https://management.azure.com/subscriptions/${SUBSCRIPTION_ID}/resourceGroups/${MONITOR_RG}/providers/Microsoft.Insights/dataCollectionRules/${dcr_name}?api-version=2023-03-11" \
        --body "@${win_path}" \
        --headers "Content-Type=application/json" \
        --output none
    az monitor data-collection rule show \
        --name "$dcr_name" --resource-group "$MONITOR_RG" \
        --query immutableId --output tsv
}

# ── AgentEvents_CL DCR (22 columns) ──────────────────────────────────────────
_tmp_dcr=$(mktemp --suffix=.json)
cat > "$_tmp_dcr" << DCREOF
{
  "location": "${DEPLOY_LOCATION}",
  "properties": {
    "dataCollectionEndpointId": "${DCE_ID}",
    "streamDeclarations": {
      "Custom-AgentEvents_CL": {
        "columns": [
          { "name": "TimeGenerated",        "type": "datetime" },
          { "name": "VMHostname",           "type": "string"   },
          { "name": "AlertId",              "type": "string"   },
          { "name": "AlertName",            "type": "string"   },
          { "name": "Severity",             "type": "string"   },
          { "name": "IssueType",            "type": "string"   },
          { "name": "IssueSummary",         "type": "string"   },
          { "name": "DetectionTime",        "type": "datetime" },
          { "name": "AnalysisResult",       "type": "string"   },
          { "name": "MitigationSteps",      "type": "string"   },
          { "name": "RunbookExecuted",      "type": "string"   },
          { "name": "RemediationOutcome",   "type": "string"   },
          { "name": "RemediationDetail",    "type": "string"   },
          { "name": "IsHealthy",            "type": "boolean"  },
          { "name": "RetryCount",           "type": "int"      },
          { "name": "RootCause",            "type": "string"   },
          { "name": "NextSteps",            "type": "string"   },
          { "name": "ReasoningModel",       "type": "string"   },
          { "name": "FastModel",            "type": "string"   },
          { "name": "AgentVersion",         "type": "string"   },
          { "name": "TotalDurationSeconds", "type": "real"     },
          { "name": "DecisionAction",       "type": "string"   },
          { "name": "DecisionConfidence",   "type": "string"   },
          { "name": "Strategy",             "type": "string"   },
          { "name": "EscalationTarget",     "type": "string"   }
        ]
      }
    },
    "destinations": {
      "logAnalytics": [
        {
          "workspaceResourceId": "${LAW_ID}",
          "name": "law-destination"
        }
      ]
    },
    "dataFlows": [
      {
        "streams": ["Custom-AgentEvents_CL"],
        "destinations": ["law-destination"],
        "transformKql": "source",
        "outputStream": "Custom-AgentEvents_CL"
      }
    ]
  }
}
DCREOF
DCR_EVENTS_ID=$(upsert_agent_dcr "iisheal-dcr-agent-events" "$_tmp_dcr")
rm "$_tmp_dcr"
ok "  DCR iisheal-dcr-agent-events (immutableId: $DCR_EVENTS_ID)"

# ── AgentErrors_CL DCR (4 columns) ───────────────────────────────────────────
_tmp_dcr=$(mktemp --suffix=.json)
cat > "$_tmp_dcr" << DCREOF
{
  "location": "${DEPLOY_LOCATION}",
  "properties": {
    "dataCollectionEndpointId": "${DCE_ID}",
    "streamDeclarations": {
      "Custom-AgentErrors_CL": {
        "columns": [
          { "name": "TimeGenerated", "type": "datetime" },
          { "name": "VMHostname",    "type": "string"   },
          { "name": "Agent",         "type": "string"   },
          { "name": "Error",         "type": "string"   }
        ]
      }
    },
    "destinations": {
      "logAnalytics": [
        {
          "workspaceResourceId": "${LAW_ID}",
          "name": "law-destination"
        }
      ]
    },
    "dataFlows": [
      {
        "streams": ["Custom-AgentErrors_CL"],
        "destinations": ["law-destination"],
        "transformKql": "source",
        "outputStream": "Custom-AgentErrors_CL"
      }
    ]
  }
}
DCREOF
DCR_ERRORS_ID=$(upsert_agent_dcr "iisheal-dcr-agent-errors" "$_tmp_dcr")
rm "$_tmp_dcr"
ok "  DCR iisheal-dcr-agent-errors (immutableId: $DCR_ERRORS_ID)"

# Assign Monitoring Metrics Publisher role on both DCRs to Function App MI
METRICS_PUBLISHER_ROLE="3913510d-42f4-4e42-8a64-420c390055eb"

assign_dcr_role() {
    local dcr_name="$1"
    local dcr_scope
    dcr_scope=$(az monitor data-collection rule show \
        --name "$dcr_name" --resource-group "$MONITOR_RG" \
        --query id --output tsv)

    MSYS_NO_PATHCONV=1 az role assignment create \
        --assignee-object-id "$FUNC_MI_PRINCIPAL" \
        --assignee-principal-type ServicePrincipal \
        --role "$METRICS_PUBLISHER_ROLE" \
        --scope "$dcr_scope" \
        --output none 2>/dev/null || true
    ok "  Monitoring Metrics Publisher → $dcr_name"
}

assign_dcr_role "iisheal-dcr-agent-events"
assign_dcr_role "iisheal-dcr-agent-errors"

# Set DCR rule IDs on Function App so law_ingestion_client.py can find them
info "Setting agent logging app settings on '$FUNC_APP_NAME'..."
az functionapp config appsettings set \
    --name "$FUNC_APP_NAME" \
    --resource-group "$CORE_RG" \
    --settings \
        "DCR_AGENT_EVENTS_RULE_ID=$DCR_EVENTS_ID" \
        "DCR_AGENT_ERRORS_RULE_ID=$DCR_ERRORS_ID" \
    --output none
ok "Agent logging DCRs configured and app settings applied."

# ── Update LAW custom table schemas via REST API ──────────────────────────────
# Bicep PUT silently retains existing columns on tables that already have data.
# Direct REST PUT is the only reliable way to apply schema changes on redeploy.
info "Updating AgentEvents_CL and AgentErrors_CL table schemas..."
LAW_WS_RG=$(echo "$LAW_ID" | sed 's|.*/resourceGroups/\([^/]*\)/.*|\1|')
LAW_WS_NAME=$(basename "$LAW_ID")

upsert_law_table() {
    local table_name="$1" body_file="$2"
    local win_path
    win_path=$(cygpath -w "$body_file")
    MSYS_NO_PATHCONV=1 az rest --method PUT \
        --uri "https://management.azure.com/subscriptions/${SUBSCRIPTION_ID}/resourceGroups/${LAW_WS_RG}/providers/Microsoft.OperationalInsights/workspaces/${LAW_WS_NAME}/tables/${table_name}?api-version=2022-10-01" \
        --body "@${win_path}" \
        --headers "Content-Type=application/json" \
        --output none 2>&1 || true
}

# AgentEvents_CL — 25 columns (v3: +DecisionAction/DecisionConfidence/Strategy/EscalationTarget, -RemediationPath)
_tmp_tbl=$(mktemp --suffix=.json)
cat > "$_tmp_tbl" << 'TBLEOF'
{
  "properties": {
    "retentionInDays": 30,
    "schema": {
      "name": "AgentEvents_CL",
      "columns": [
        {"name": "TimeGenerated",        "type": "datetime"},
        {"name": "VMHostname",           "type": "string"},
        {"name": "AlertId",              "type": "string"},
        {"name": "AlertName",            "type": "string"},
        {"name": "Severity",             "type": "string"},
        {"name": "IssueType",            "type": "string"},
        {"name": "IssueSummary",         "type": "string"},
        {"name": "DetectionTime",        "type": "datetime"},
        {"name": "AnalysisResult",       "type": "string"},
        {"name": "MitigationSteps",      "type": "string"},
        {"name": "RunbookExecuted",      "type": "string"},
        {"name": "RemediationOutcome",   "type": "string"},
        {"name": "RemediationDetail",    "type": "string"},
        {"name": "IsHealthy",            "type": "boolean"},
        {"name": "RetryCount",           "type": "int"},
        {"name": "RootCause",            "type": "string"},
        {"name": "NextSteps",            "type": "string"},
        {"name": "ReasoningModel",       "type": "string"},
        {"name": "FastModel",            "type": "string"},
        {"name": "AgentVersion",         "type": "string"},
        {"name": "TotalDurationSeconds", "type": "real"},
        {"name": "DecisionAction",       "type": "string"},
        {"name": "DecisionConfidence",   "type": "string"},
        {"name": "Strategy",             "type": "string"},
        {"name": "EscalationTarget",     "type": "string"}
      ]
    }
  }
}
TBLEOF
upsert_law_table "AgentEvents_CL" "$_tmp_tbl"
rm "$_tmp_tbl"

# AgentErrors_CL — 4 columns
_tmp_tbl=$(mktemp --suffix=.json)
cat > "$_tmp_tbl" << 'TBLEOF'
{
  "properties": {
    "retentionInDays": 30,
    "schema": {
      "name": "AgentErrors_CL",
      "columns": [
        {"name": "TimeGenerated", "type": "datetime"},
        {"name": "VMHostname",    "type": "string"},
        {"name": "Agent",         "type": "string"},
        {"name": "Error",         "type": "string"}
      ]
    }
  }
}
TBLEOF
upsert_law_table "AgentErrors_CL" "$_tmp_tbl"
rm "$_tmp_tbl"
ok "LAW table schemas verified."

# ── 5. Deploy chaos web app files ─────────────────────────────────────────────
info "Deploying chaos web app files to VM '$VM_NAME'..."

deploy_file() {
    local src="$1" dst="$2"
    local b64
    b64=$(base64 -w 0 "$src" 2>/dev/null || base64 "$src" | tr -d '\n')
    # Write a temp PS1 script instead of passing base64 inline — inline
    # hits the OS argument-length limit on large .aspx files.
    local tmp_ps
    tmp_ps=$(mktemp "${TMPDIR:-/tmp}/deploy_XXXXXX.ps1")
    cat > "$tmp_ps" << DEPLOYEOF
\$b64 = '${b64}'
\$dir = [System.IO.Path]::GetDirectoryName('${dst}')
if (-not (Test-Path \$dir)) { New-Item -ItemType Directory -Force -Path \$dir | Out-Null }
[System.IO.File]::WriteAllBytes('${dst}', [System.Convert]::FromBase64String(\$b64))
Write-Output 'OK'
DEPLOYEOF
    az vm run-command invoke \
        --resource-group "$CORE_RG" \
        --name           "$VM_NAME" \
        --command-id     RunPowerShellScript \
        --scripts        @"$tmp_ps" \
        --output none
    rm -f "$tmp_ps"
    ok "  $(basename "$src")  →  $dst"
}

deploy_file "$PROJECT_ROOT/chaos-app/default.aspx"          'C:\inetpub\wwwroot\default.aspx'
deploy_file "$PROJECT_ROOT/chaos-app/default.aspx.cs"       'C:\inetpub\wwwroot\default.aspx.cs'
deploy_file "$PROJECT_ROOT/chaos-app/Web.config"            'C:\inetpub\wwwroot\Web.config'
deploy_file "$PROJECT_ROOT/chaos-app/chaos/default.aspx"    'C:\inetpub\wwwroot\chaos\default.aspx'
deploy_file "$PROJECT_ROOT/chaos-app/chaos/default.aspx.cs" 'C:\inetpub\wwwroot\chaos\default.aspx.cs'
deploy_file "$PROJECT_ROOT/chaos-app/chaos/Web.config"      'C:\inetpub\wwwroot\chaos\Web.config'

info "Restarting IIS..."
az vm run-command invoke \
    --resource-group "$CORE_RG" \
    --name           "$VM_NAME" \
    --command-id     RunPowerShellScript \
    --scripts        "iisreset /restart" \
    --output none
ok "IIS restarted — chaos app is live."

# ── 5b. Install PowerShell 7 (required by Hybrid Worker for PS 7.2 runbooks) ─
info "Ensuring PowerShell 7 is installed on VM '$VM_NAME'..."
PS7_CHECK=$(az vm run-command invoke \
    --resource-group "$CORE_RG" \
    --name           "$VM_NAME" \
    --command-id     RunPowerShellScript \
    --scripts        "if (Test-Path 'C:\Program Files\PowerShell\7\pwsh.exe') { Write-Output 'PS7_EXISTS' } else { Write-Output 'PS7_MISSING' }" \
    --query "value[0].message" --output tsv 2>/dev/null)

if [[ "$PS7_CHECK" == *"PS7_EXISTS"* ]]; then
    ok "PowerShell 7 already installed."
else
    info "Installing PowerShell 7 (this takes ~1 minute)..."
    az vm run-command invoke \
        --resource-group "$CORE_RG" \
        --name           "$VM_NAME" \
        --command-id     RunPowerShellScript \
        --scripts "
\$ErrorActionPreference = 'Stop'
\$msiUrl = 'https://github.com/PowerShell/PowerShell/releases/download/v7.4.6/PowerShell-7.4.6-win-x64.msi'
\$msiPath = 'C:\Temp\pwsh7.msi'
New-Item -ItemType Directory -Force -Path 'C:\Temp' | Out-Null
[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
Invoke-WebRequest -Uri \$msiUrl -OutFile \$msiPath -UseBasicParsing
Start-Process msiexec.exe -ArgumentList '/i', \$msiPath, '/quiet', '/norestart', 'ADD_PATH=1', 'REGISTER_MANIFEST=1' -Wait -NoNewWindow
Remove-Item \$msiPath -Force -ErrorAction SilentlyContinue
if (Test-Path 'C:\Program Files\PowerShell\7\pwsh.exe') { Write-Output 'OK' } else { throw 'PowerShell 7 install failed' }
" \
        --output none
    ok "PowerShell 7 installed."
fi

# ── 5d. Deploy baseline capture script ────────────────────────────────────────
info "Deploying baseline capture script to VM '$VM_NAME'..."
deploy_file "$PROJECT_ROOT/baseline/run_baseline.ps1" 'C:\iis-autohealing\baseline\run_baseline.ps1'
ok "Baseline script deployed (used by Invoke-CaptureBaseline runbook)."

# ── 5e. Deploy perf-to-EventHub scheduled task ────────────────────────────────
info "Deploying Send-PerfToEventHub.ps1 to VM '$VM_NAME'..."

deploy_file "$PROJECT_ROOT/scripts/Send-PerfToEventHub.ps1" 'C:\Scripts\Send-PerfToEventHub.ps1'

info "Registering perf-collection scheduled task (runs every 60 s as SYSTEM)..."
# Use schtasks.exe instead of PowerShell Register-ScheduledTask — the PS cmdlets
# fail silently when invoked via az vm run-command.
az vm run-command invoke \
    --resource-group "$CORE_RG" \
    --name           "$VM_NAME" \
    --command-id     RunPowerShellScript \
    --scripts "schtasks.exe /Delete /TN 'SendPerfToEventHub' /F 2>\$null; schtasks.exe /Create /TN 'SendPerfToEventHub' /SC MINUTE /MO 1 /TR \"powershell.exe -NonInteractive -NoProfile -WindowStyle Hidden -File C:\Scripts\Send-PerfToEventHub.ps1 -EventHubNamespace ${EH_NAMESPACE}\" /RU SYSTEM /RL HIGHEST /F; schtasks.exe /Run /TN 'SendPerfToEventHub'" \
    --output none
ok "Perf-collection scheduled task registered on VM (every 60 s → Event Hub '$EH_NAMESPACE')."

# ── 6. Deploy Function App code ────────────────────────────────────────────────
# Uses Azure Functions Core Tools remote build: packages the function-app
# directory, uploads it, and runs pip install on a remote Linux build agent
# (separate from the app container).  This produces correct manylinux wheels
# without relying on in-container Oryx.
#
# Requires: func CLI (Azure Functions Core Tools v4+) on PATH.

command -v func >/dev/null 2>&1 || die "Azure Functions Core Tools (func) not found. Install from https://aka.ms/azfunc-install"

info "Deploying '$FUNC_APP_NAME' via func azure functionapp publish --build remote..."
(cd "$PROJECT_ROOT/function-app" && \
    func azure functionapp publish "$FUNC_APP_NAME" --build remote) \
    || die "Function App deployment failed."
ok "Function App code deployed to '$FUNC_APP_NAME'."

# ── 7. Upload and publish runbooks ─────────────────────────────────────────────
info "Uploading runbooks to Automation Account '$AUTO_ACCOUNT' (RG: $MONITOR_RG)..."
RUNBOOK_COUNT=0

for rb_file in "$PROJECT_ROOT/runbooks"/*.ps1; do
    [[ -f "$rb_file" ]] || { warn "No runbook files found."; break; }
    rb_name=$(basename "$rb_file" .ps1)
    info "  Uploading: $rb_name"

    az automation runbook replace-content \
        --resource-group          "$MONITOR_RG" \
        --automation-account-name "$AUTO_ACCOUNT" \
        --name                    "$rb_name" \
        --content @"$rb_file" \
        --output none 2>/dev/null || {
            warn "  '$rb_name' not found — creating..."
            az automation runbook create \
                --resource-group          "$MONITOR_RG" \
                --automation-account-name "$AUTO_ACCOUNT" \
                --name                    "$rb_name" \
                --type                    PowerShell \
                --output none
            az automation runbook replace-content \
                --resource-group          "$MONITOR_RG" \
                --automation-account-name "$AUTO_ACCOUNT" \
                --name                    "$rb_name" \
                --content @"$rb_file" \
                --output none
        }

    az automation runbook publish \
        --resource-group          "$MONITOR_RG" \
        --automation-account-name "$AUTO_ACCOUNT" \
        --name                    "$rb_name" \
        --output none

    ok "  Published: $rb_name"
    RUNBOOK_COUNT=$((RUNBOOK_COUNT + 1))
done
ok "Uploaded and published $RUNBOOK_COUNT runbook(s)."

# ── 8. Register Hybrid Runbook Worker ─────────────────────────────────────────
info "Registering VM as Hybrid Runbook Worker..."

VM_ID=$(az vm show --resource-group "$CORE_RG" --name "$VM_NAME" --query id --output tsv)
WORKER_GROUP="IIS-HybridWorkers"

# Check if any workers already exist in the group
EXISTING_WORKERS=$(az automation hrwg hrw list \
    --resource-group "$MONITOR_RG" \
    --automation-account-name "$AUTO_ACCOUNT" \
    --hybrid-runbook-worker-group-name "$WORKER_GROUP" \
    --query "length(@)" --output tsv 2>/dev/null || echo "0")

if [[ "$EXISTING_WORKERS" -gt 0 ]]; then
    ok "Hybrid Worker already registered ($EXISTING_WORKERS worker(s) in '$WORKER_GROUP')."
else
    # Generate a worker ID
    WORKER_ID=$(od -An -tx4 -N16 /dev/urandom | tr -d ' \n' \
        | sed 's/\(.\{8\}\)\(.\{4\}\)\(.\{4\}\)\(.\{4\}\)\(.\{12\}\)/\1-\2-\3-\4-\5/')

    MSYS_NO_PATHCONV=1 az automation hrwg hrw create \
        --resource-group "$MONITOR_RG" \
        --automation-account-name "$AUTO_ACCOUNT" \
        --hybrid-runbook-worker-group-name "$WORKER_GROUP" \
        --hybrid-runbook-worker-id "$WORKER_ID" \
        --vm-resource-id "$VM_ID" \
        --output none
    ok "Hybrid Worker registered (ID: $WORKER_ID)."
fi

# Install the Hybrid Worker extension on the VM if not already present
HW_EXT=$(az vm extension list --resource-group "$CORE_RG" --vm-name "$VM_NAME" \
    --query "[?name=='HybridWorkerForWindows'].provisioningState" --output tsv 2>/dev/null || echo "")

if [[ "$HW_EXT" == "Succeeded" ]]; then
    ok "HybridWorkerForWindows extension already installed."
else
    info "Installing HybridWorkerForWindows extension on VM (this takes ~1 minute)..."
    AA_URL=$(az automation account show \
        --resource-group "$MONITOR_RG" --name "$AUTO_ACCOUNT" \
        --query automationHybridServiceUrl --output tsv 2>/dev/null)

    MSYS_NO_PATHCONV=1 az vm extension set \
        --resource-group "$CORE_RG" \
        --vm-name "$VM_NAME" \
        --name HybridWorkerForWindows \
        --publisher Microsoft.Azure.Automation.HybridWorker \
        --version 1.1 \
        --settings "{\"AutomationAccountURL\":\"${AA_URL}\"}" \
        --output none
    ok "HybridWorkerForWindows extension installed."
fi
echo ""

# ── 9. Summary ────────────────────────────────────────────────────────────────
echo -e "${GREEN}══════════════════════════════════════════════════════════════════${NC}"
echo -e "${GREEN}  DEPLOYMENT SUMMARY${NC}"
echo -e "${GREEN}══════════════════════════════════════════════════════════════════${NC}"
echo ""
printf "  %-28s %s\n" "Core RG:"               "$CORE_RG"
printf "  %-28s %s\n" "Monitor RG:"             "$MONITOR_RG"
printf "  %-28s %s\n" "VM Name:"                "$VM_NAME"
printf "  %-28s %s\n" "VM Private IP:"          "$VM_IP"
printf "  %-28s %s\n" "Bastion (RDP via portal):" "$BASTION_NAME"
printf "  %-28s %s\n" "Main site (from VNet):"  "http://$VM_IP/"
printf "  %-28s %s\n" "Chaos console (from VNet):" "http://$VM_IP/chaos/"
printf "  %-28s %s\n" "Function App:"           "$FUNC_APP_NAME"
printf "  %-28s %s\n" "Automation Account:"     "$AUTO_ACCOUNT"
printf "  %-28s %s\n" "OpenAI Endpoint:"        "$OPENAI_ENDPOINT"
printf "  %-28s %s\n" "ADX Cluster:"            "$ADX_URI"
printf "  %-28s %s\n" "ADX Database:"           "$ADX_DB"
printf "  %-28s %s\n" "Event Hub Namespace:"    "$EH_NAMESPACE"
printf "  %-28s %s\n" "LAW Workspace ID:"       "$LAW_ID"
printf "  %-28s %s\n" "Runbooks Deployed:"      "$RUNBOOK_COUNT"
echo ""
echo -e "${YELLOW}  Next steps:${NC}"
echo "    1. RDP into the VM: Azure Portal -> VM -> Connect -> Bastion (user: azureadmin)"
echo "    2. Start baseline perfmon:  bash scripts/run_baseline.sh"
echo "    3. Trigger chaos manually:  RDP into the VM and use the chaos console at http://$VM_IP/chaos/"
echo "       (test_chaos.sh + load_test.sh hit the VM's HTTP endpoint from the deployer's machine"
echo "        and will NOT work now that the VM has no public IP — run them from inside the VNet,"
echo "        or use 'az vm run-command' based approaches.)"
echo "    4. Watch AgentEvents_CL:    go to Log Analytics workspace in the portal"
echo ""
ok "Deployment complete."
