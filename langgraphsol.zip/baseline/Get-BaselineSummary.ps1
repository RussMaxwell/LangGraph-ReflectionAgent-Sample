<#
.SYNOPSIS
    Retrieves the most recent BaselineSummary record from the
    PerformanceBaseline table in Azure Data Explorer (ADX).

.DESCRIPTION
    Queries the specified ADX cluster/database for the latest Summary
    row matching the given hostname and returns it as a PowerShell
    hashtable.

.PARAMETER AdxCluster
    The ADX cluster URI (e.g. https://iishealadx.eastus2.kusto.windows.net).

.PARAMETER AdxDatabase
    The ADX database name (e.g. iishealdb).

.PARAMETER Hostname
    The VM hostname to filter on (Computer column).

.OUTPUTS
    [hashtable] containing all baseline summary values,
    or $null if no matching record is found.

.EXAMPLE
    $baseline = .\Get-BaselineSummary.ps1 -AdxCluster "https://iishealadx.eastus2.kusto.windows.net" -AdxDatabase "iishealdb" -Hostname "iishealvm"
    $baseline.avg_CpuPercent
#>
[CmdletBinding()]
param(
    [Parameter(Mandatory)]
    [string]$AdxCluster,

    [Parameter(Mandatory)]
    [string]$AdxDatabase,

    [Parameter(Mandatory)]
    [string]$Hostname
)

Set-StrictMode -Version Latest
$ErrorActionPreference = "Stop"

$kql = @"
let latest_capture = toscalar(
    PerformanceBaseline
    | where Computer == '$Hostname'
    | where RecordType == 'Summary'
    | summarize arg_max(TimeGenerated, CaptureId)
    | project CaptureId
);
PerformanceBaseline
| where CaptureId == latest_capture
| where RecordType == 'Summary'
| project TimeGenerated, Computer, MetricName, MetricValue, CaptureId
| order by MetricName asc
"@

# ---------------------------------------------------------------------------
# Query ADX via Azure CLI (az kusto query)
# ---------------------------------------------------------------------------
$jsonOut = az kusto query `
    --cluster $AdxCluster `
    --database $AdxDatabase `
    --query $kql `
    --output json 2>&1

if ($LASTEXITCODE -ne 0) {
    throw "ADX query failed: $jsonOut"
}

$rows = $jsonOut | ConvertFrom-Json

if (-not $rows -or $rows.Count -eq 0) {
    Write-Warning "No baseline Summary record found for hostname '$Hostname' in ADX database '$AdxDatabase'."
    return $null
}

# Build a hashtable keyed by MetricName
$result = @{
    Computer  = $Hostname
    CaptureId = $rows[0].CaptureId
    CapturedAt = $rows[0].TimeGenerated
}

foreach ($row in $rows) {
    $metricName = $row.MetricName
    $metricValue = $row.MetricValue
    if ($null -ne $metricValue) {
        $result[$metricName] = [double]$metricValue
    }
}

Write-Verbose "Baseline summary retrieved successfully (CaptureId: $($result['CaptureId']), captured at $($result['CapturedAt']))."
return $result
