<#
.SYNOPSIS
    Captures a performance baseline for an IIS application by sampling OS/IIS
    performance counters and (optionally) simulating concurrent virtual users.
    Counter snapshots and a final summary are shipped to ADX via Event Hub
    (PerformanceBaseline table).

.PARAMETER DurationMinutes
    How long the capture window runs.  Default 60 minutes.

.PARAMETER VirtualUsers
    Number of concurrent simulated users (PowerShell background jobs).
    Default 0 (perfmon-only mode -- use scripts/load_test.sh for external traffic).

.PARAMETER EventHubNamespace
    Event Hub namespace name.  The .servicebus.windows.net suffix is appended
    automatically.  Authentication uses the VM managed identity (IMDS).
#>
[CmdletBinding()]
param(
    [int]$DurationMinutes      = 60,
    [int]$VirtualUsers         = 0,
    [string]$EventHubNamespace = ""
)

Set-StrictMode -Version Latest
$ErrorActionPreference = "Continue"

# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------
$TargetUrl          = "http://localhost/default.aspx"
$SampleIntervalSec  = 60          # flush / counter-read cadence
$MinDelaySec        = 3           # per-user min pause between requests
$MaxDelaySec        = 8           # per-user max pause between requests
$Hostname           = $env:COMPUTERNAME

# ---------------------------------------------------------------------------
# 50 distinct User-Agent strings for realistic traffic simulation
# ---------------------------------------------------------------------------
$UserAgents = @(
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36"
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:125.0) Gecko/20100101 Firefox/125.0"
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 14_4_1) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.4 Safari/605.1.15"
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/123.0.0.0 Safari/537.36 Edg/123.0.0.0"
    "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36"
    "Mozilla/5.0 (X11; Ubuntu; Linux x86_64; rv:125.0) Gecko/20100101 Firefox/125.0"
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 14_4_1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36"
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36 OPR/108.0.0.0"
    "Mozilla/5.0 (iPhone; CPU iPhone OS 17_4_1 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.4 Mobile/15E148 Safari/604.1"
    "Mozilla/5.0 (iPad; CPU OS 17_4_1 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.4 Mobile/15E148 Safari/604.1"
    "Mozilla/5.0 (Linux; Android 14; Pixel 8 Pro) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Mobile Safari/537.36"
    "Mozilla/5.0 (Linux; Android 14; SM-S928U) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Mobile Safari/537.36"
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36 Vivaldi/6.7.3329.35"
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36 Brave/124"
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 14_4_1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36 Edg/124.0.0.0"
    "Mozilla/5.0 (X11; Linux x86_64; rv:125.0) Gecko/20100101 Firefox/125.0"
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:124.0) Gecko/20100101 Firefox/124.0"
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 14.4; rv:125.0) Gecko/20100101 Firefox/125.0"
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/121.0.0.0 Safari/537.36"
    "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/123.0.0.0 Safari/537.36"
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 14_3) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.3 Safari/605.1.15"
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36"
    "Mozilla/5.0 (Linux; Android 14; SM-A546B) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Mobile Safari/537.36"
    "Mozilla/5.0 (iPhone; CPU iPhone OS 17_3_1 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.3 Mobile/15E148 Safari/604.1"
    "Mozilla/5.0 (Windows NT 10.0; WOW64; Trident/7.0; rv:11.0) like Gecko"
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36 SamsungBrowser/24.0"
    "Mozilla/5.0 (Linux; Android 14; Pixel 7a) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Mobile Safari/537.36"
    "Mozilla/5.0 (X11; CrOS x86_64 14541.0.0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36"
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36 Whale/3.25.232.19"
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 14_4_1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36 OPR/108.0.0.0"
    "Mozilla/5.0 (Windows NT 10.0; ARM64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36"
    "Mozilla/5.0 (Linux; Android 13; RMX3630) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Mobile Safari/537.36"
    "Mozilla/5.0 (iPad; CPU OS 17_4 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) CriOS/124.0.6367.88 Mobile/15E148 Safari/604.1"
    "Mozilla/5.0 (iPhone; CPU iPhone OS 17_4_1 like Mac OS X) AppleWebKit/605.1.15 (KHTML, like Gecko) CriOS/124.0.6367.88 Mobile/15E148 Safari/604.1"
    "Mozilla/5.0 (Linux; Android 14; moto g84 5G) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Mobile Safari/537.36"
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/118.0.0.0 Safari/537.36"
    "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36"
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 13_6_6) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/16.6 Safari/605.1.15"
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:123.0) Gecko/20100101 Firefox/123.0"
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 14.4; rv:124.0) Gecko/20100101 Firefox/124.0"
    "Mozilla/5.0 (X11; Fedora; Linux x86_64; rv:125.0) Gecko/20100101 Firefox/125.0"
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/119.0.0.0 Safari/537.36"
    "Mozilla/5.0 (Linux; Android 14; V2322) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Mobile Safari/537.36"
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 14_2) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/17.2 Safari/605.1.15"
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36 AtContent/95.5.5462.0"
    "Mozilla/5.0 (Linux; Android 13; 22101316G) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Mobile Safari/537.36"
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36 UCBrowser/15.5.6.10432"
    "Mozilla/5.0 (Linux; Android 14; CPH2579) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Mobile Safari/537.36"
    "Mozilla/5.0 (X11; Linux aarch64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36"
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36 Yowser/2.5"
)

$RefSources = @("google", "bing", "direct", "email", "social", "partner", "campaign", "organic", "referral", "news",
                 "reddit", "twitter", "linkedin", "facebook", "instagram", "newsletter", "slack", "teams", "intranet", "bookmark")

# ---------------------------------------------------------------------------
# Event Hub ingestion — sends MULTIJSON to baseline-eh via VM managed identity
# ---------------------------------------------------------------------------
$BaselineHub = 'baseline-eh'
$EhBaseUri   = if ($EventHubNamespace) { "https://${EventHubNamespace}.servicebus.windows.net" } else { "" }
$CaptureId   = [guid]::NewGuid().ToString("N")   # groups all records from this run

function Get-ImdsToken {
    try {
        $response = Invoke-RestMethod `
            -Uri     'http://169.254.169.254/metadata/identity/oauth2/token?api-version=2018-02-01&resource=https%3A%2F%2Feventhubs.azure.net%2F' `
            -Headers @{ Metadata = 'true' } `
            -Method  Get
        return $response.access_token
    }
    catch {
        Write-Warning "IMDS token request failed: $_"
        return $null
    }
}

function Send-ToEventHub {
    param(
        [Parameter(Mandatory)][array]$Records
    )

    if ([string]::IsNullOrWhiteSpace($EventHubNamespace)) {
        Write-Warning "EventHubNamespace not configured -- skipping ingestion for $($Records.Count) records."
        return
    }

    $token = Get-ImdsToken
    if (-not $token) {
        Write-Warning "No IMDS token -- cannot send to Event Hub."
        return
    }

    $body = $Records | ConvertTo-Json -Depth 10 -Compress
    if ($Records.Count -eq 1) {
        $body = "[$body]"
    }

    try {
        $uri = "${EhBaseUri}/${BaselineHub}/messages"
        Invoke-RestMethod `
            -Uri         $uri `
            -Method      Post `
            -Headers     @{ Authorization = "Bearer $token" } `
            -ContentType 'application/json' `
            -Body        $body | Out-Null
        Write-Host "[Ingest] Sent $($Records.Count) records to $BaselineHub"
    }
    catch {
        Write-Warning "[Ingest] Failed to send to ${BaselineHub}: $_"
    }
}

# ---------------------------------------------------------------------------
# Helper: Read performance counters safely
# ---------------------------------------------------------------------------
function Get-SafeCounter {
    param([string]$CounterPath)
    try {
        $sample = Get-Counter -Counter $CounterPath -ErrorAction Stop
        return [math]::Round($sample.CounterSamples[0].CookedValue, 2)
    }
    catch {
        Write-Warning "Counter unavailable: $CounterPath"
        return $null
    }
}

function Get-PerfSnapshot {
    $snapshot = @{
        CpuPercent                = Get-SafeCounter '\Processor(_Total)\% Processor Time'
        MemoryAvailableMB         = Get-SafeCounter '\Memory\Available MBytes'
        MemoryCommittedPercent    = Get-SafeCounter '\Memory\% Committed Bytes In Use'
        W3wpCpuPercent            = Get-SafeCounter '\Process(w3wp)\% Processor Time'
        W3wpWorkingSetBytes       = Get-SafeCounter '\Process(w3wp)\Working Set'
        W3wpThreadCount           = Get-SafeCounter '\Process(w3wp)\Thread Count'
        IISCurrentConnections     = Get-SafeCounter '\Web Service(_Total)\Current Connections'
        IISGetRequestsPerSec      = Get-SafeCounter '\Web Service(_Total)\Get Requests/sec'
        AspNetRequestsQueued      = Get-SafeCounter '\ASP.NET\Requests Queued'
    }
    return $snapshot
}

# ---------------------------------------------------------------------------
# Virtual-user job scriptblock
# ---------------------------------------------------------------------------
$VirtualUserScript = {
    param(
        [int]$UserId,
        [string]$TargetUrl,
        [string[]]$UserAgents,
        [string[]]$RefSources,
        [int]$MinDelaySec,
        [int]$MaxDelaySec,
        [int]$DurationSeconds
    )

    $results  = [System.Collections.ArrayList]::new()
    $deadline = (Get-Date).AddSeconds($DurationSeconds)
    $rng      = [System.Random]::new($UserId * 31 + [System.Environment]::TickCount)

    while ((Get-Date) -lt $deadline) {
        $ua        = $UserAgents[$rng.Next($UserAgents.Count)]
        $sessionId = [guid]::NewGuid().ToString("N")
        $ref       = $RefSources[$rng.Next($RefSources.Count)]
        $urlWithQs = "{0}?sessionId={1}&ref={2}" -f $TargetUrl, $sessionId, $ref

        $status       = 0
        $responseSize = 0
        $elapsed      = [TimeSpan]::Zero
        $timestamp    = (Get-Date).ToUniversalTime().ToString("o")

        try {
            $elapsed = Measure-Command {
                $resp = Invoke-WebRequest -Uri $urlWithQs -UserAgent $ua `
                            -UseBasicParsing -TimeoutSec 30 -ErrorAction Stop
                $status       = [int]$resp.StatusCode
                $responseSize = if ($resp.Content) { [System.Text.Encoding]::UTF8.GetByteCount($resp.Content) } else { 0 }
            }
        }
        catch {
            if ($_.Exception.Response) {
                $status = [int]$_.Exception.Response.StatusCode
            } else {
                $status = -1
            }
            $elapsed = [TimeSpan]::FromMilliseconds(0)
        }

        [void]$results.Add([PSCustomObject]@{
            TimeGenerated    = $timestamp
            VirtualUserId    = $UserId
            HttpStatus       = $status
            ResponseTimeMs   = [math]::Round($elapsed.TotalMilliseconds, 2)
            ResponseSizeBytes = $responseSize
        })

        $sleepMs = $rng.Next($MinDelaySec * 1000, $MaxDelaySec * 1000)
        Start-Sleep -Milliseconds $sleepMs
    }

    return $results
}

# ---------------------------------------------------------------------------
# Main execution
# ---------------------------------------------------------------------------
Write-Host "=== IIS Performance Baseline Capture ==="
Write-Host "Duration       : $DurationMinutes minutes"
Write-Host "Virtual Users  : $VirtualUsers"
if ($VirtualUsers -eq 0) {
    Write-Host "Mode           : Perfmon capture only (no local load generation)"
    Write-Host "                 Use scripts/load_test.sh from your workstation for external traffic."
} else {
    Write-Host "Target         : $TargetUrl"
}
Write-Host "Hostname       : $Hostname"
Write-Host "Event Hub NS   : $(if ($EventHubNamespace) { $EventHubNamespace } else { '(not configured)' })"
Write-Host "ADX Table      : PerformanceBaseline"
Write-Host "Capture ID     : $CaptureId"
Write-Host "Start Time     : $(Get-Date -Format 'u')"
Write-Host "========================================="

$totalDurationSec = $DurationMinutes * 60
$startTime        = Get-Date
$allRequestData   = [System.Collections.ArrayList]::new()
$windowIndex      = 0

# Start virtual-user background jobs (skip if VirtualUsers is 0)
$jobs = @()
if ($VirtualUsers -gt 0) {
    for ($i = 1; $i -le $VirtualUsers; $i++) {
        $job = Start-Job -ScriptBlock $VirtualUserScript -ArgumentList @(
            $i,
            $TargetUrl,
            $UserAgents,
            $RefSources,
            $MinDelaySec,
            $MaxDelaySec,
            $totalDurationSec
        )
        $jobs += $job
        Write-Host "  Started virtual user $i (Job $($job.Id))"
    }
} else {
    Write-Host "  Skipping virtual user jobs (perfmon-only mode)."
}

# ---------------------------------------------------------------------------
# Sampling loop -- every $SampleIntervalSec seconds, read counters and
# harvest whatever results the jobs have produced so far.
# ---------------------------------------------------------------------------
$captureEnd = $startTime.AddMinutes($DurationMinutes)

while ((Get-Date) -lt $captureEnd) {
    $sleepRemaining = [math]::Max(1, [math]::Min($SampleIntervalSec, ($captureEnd - (Get-Date)).TotalSeconds))
    Start-Sleep -Seconds $sleepRemaining

    $windowIndex++
    $windowTimestamp = (Get-Date).ToUniversalTime().ToString("o")

    # Collect performance counters
    $perf = Get-PerfSnapshot

    # Harvest completed request data from jobs via Receive-Job (skip if no jobs)
    $batchRequests = @()
    if ($jobs.Count -gt 0) {
        foreach ($job in $jobs) {
            $partial = Receive-Job -Job $job -ErrorAction SilentlyContinue
            if ($partial) {
                foreach ($item in $partial) {
                    [void]$allRequestData.Add($item)
                    $batchRequests += $item
                }
            }
        }
    }

    # Build normalized rows for ADX (one row per metric per snapshot)
    $snapshotRows = @()
    $counterMap = @{
        CpuPercent             = $perf.CpuPercent
        MemoryAvailableMB      = $perf.MemoryAvailableMB
        MemoryCommittedPercent = $perf.MemoryCommittedPercent
        W3wpCpuPercent         = $perf.W3wpCpuPercent
        W3wpWorkingSetBytes    = $perf.W3wpWorkingSetBytes
        W3wpThreadCount        = $perf.W3wpThreadCount
        IISCurrentConnections  = $perf.IISCurrentConnections
        IISGetRequestsPerSec   = $perf.IISGetRequestsPerSec
        AspNetRequestsQueued   = $perf.AspNetRequestsQueued
    }
    foreach ($entry in $counterMap.GetEnumerator()) {
        if ($null -ne $entry.Value) {
            $snapshotRows += @{
                TimeGenerated = $windowTimestamp
                Computer      = $Hostname
                RecordType    = "Snapshot"
                MetricName    = $entry.Key
                MetricValue   = [double]$entry.Value
                CaptureId     = $CaptureId
                WindowIndex   = $windowIndex
            }
        }
    }

    Write-Host "[Window $windowIndex] Counters: $($snapshotRows.Count) | CPU: $($perf.CpuPercent)% | Mem Available: $($perf.MemoryAvailableMB) MB"

    if ($snapshotRows.Count -gt 0) {
        Send-ToEventHub -Records $snapshotRows
    }
}

# ---------------------------------------------------------------------------
# Wait for all jobs to finish and collect remaining data
# ---------------------------------------------------------------------------
if ($jobs.Count -gt 0) {
    Write-Host "`nWaiting for virtual user jobs to complete..."
    $jobs | Wait-Job -Timeout 120 | Out-Null

    foreach ($job in $jobs) {
        $remaining = Receive-Job -Job $job -ErrorAction SilentlyContinue
        if ($remaining) {
            foreach ($item in $remaining) {
                [void]$allRequestData.Add($item)
            }
        }
        Remove-Job -Job $job -Force -ErrorAction SilentlyContinue
    }

    Write-Host "Total requests collected: $($allRequestData.Count)"
} else {
    Write-Host "`nPerfmon capture complete. No virtual user jobs to collect."
}

# ---------------------------------------------------------------------------
# Compute summary statistics
# ---------------------------------------------------------------------------
function Get-Percentile {
    param([double[]]$SortedValues, [double]$Percentile)
    if ($SortedValues.Count -eq 0) { return 0 }
    $index = [math]::Ceiling($Percentile / 100.0 * $SortedValues.Count) - 1
    $index = [math]::Max(0, [math]::Min($index, $SortedValues.Count - 1))
    return [math]::Round($SortedValues[$index], 2)
}

# Build summary metrics as normalized rows for ADX
$summaryTimestamp = (Get-Date).ToUniversalTime().ToString("o")
$summaryMetrics = @{
    DurationMinutes = $DurationMinutes
    VirtualUsers    = $VirtualUsers
}

if ($allRequestData.Count -gt 0) {
    $responseTimes = $allRequestData | ForEach-Object { $_.ResponseTimeMs } | Sort-Object
    $responseSizes = $allRequestData | ForEach-Object { $_.ResponseSizeBytes } | Sort-Object

    $successCount = ($allRequestData | Where-Object { $_.HttpStatus -ge 200 -and $_.HttpStatus -lt 400 }).Count
    $errorCount   = ($allRequestData | Where-Object { $_.HttpStatus -ge 400 -or $_.HttpStatus -lt 0 }).Count

    $summaryMetrics["TotalRequests"]         = $allRequestData.Count
    $summaryMetrics["SuccessCount"]          = $successCount
    $summaryMetrics["ErrorCount"]            = $errorCount
    $summaryMetrics["SuccessRate"]           = [math]::Round(($successCount / $allRequestData.Count) * 100, 2)
    $summaryMetrics["ResponseTimeAvgMs"]     = [math]::Round(($responseTimes | Measure-Object -Average).Average, 2)
    $summaryMetrics["ResponseTimeMinMs"]     = [math]::Round(($responseTimes | Measure-Object -Minimum).Minimum, 2)
    $summaryMetrics["ResponseTimeMaxMs"]     = [math]::Round(($responseTimes | Measure-Object -Maximum).Maximum, 2)
    $summaryMetrics["ResponseTimeP50Ms"]     = Get-Percentile -SortedValues $responseTimes -Percentile 50
    $summaryMetrics["ResponseTimeP75Ms"]     = Get-Percentile -SortedValues $responseTimes -Percentile 75
    $summaryMetrics["ResponseTimeP90Ms"]     = Get-Percentile -SortedValues $responseTimes -Percentile 90
    $summaryMetrics["ResponseTimeP95Ms"]     = Get-Percentile -SortedValues $responseTimes -Percentile 95
    $summaryMetrics["ResponseTimeP99Ms"]     = Get-Percentile -SortedValues $responseTimes -Percentile 99
    $summaryMetrics["ResponseSizeAvgBytes"]  = [math]::Round(($responseSizes | Measure-Object -Average).Average, 2)
    $summaryMetrics["RequestsPerSecond"]     = [math]::Round($allRequestData.Count / ($DurationMinutes * 60), 2)
} else {
    Write-Host "No local request data (perfmon-only mode). Counter snapshots were ingested during capture."
}

# Emit one ADX row per summary metric
$summaryRows = @()
foreach ($entry in $summaryMetrics.GetEnumerator()) {
    $summaryRows += @{
        TimeGenerated = $summaryTimestamp
        Computer      = $Hostname
        RecordType    = "Summary"
        MetricName    = $entry.Key
        MetricValue   = [double]$entry.Value
        CaptureId     = $CaptureId
        WindowIndex   = 0
    }
}

Write-Host "`n=== Baseline Summary ==="
foreach ($entry in ($summaryMetrics.GetEnumerator() | Sort-Object Name)) {
    Write-Host ("  {0,-35} : {1}" -f $entry.Name, $entry.Value)
}
Write-Host "  CaptureId                         : $CaptureId"

Send-ToEventHub -Records $summaryRows

Write-Host "`n=== Baseline capture complete ==="
Write-Host "End Time: $(Get-Date -Format 'u')"
