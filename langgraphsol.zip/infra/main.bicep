targetScope = 'subscription'

// =============================================================================
// IIS Auto-Healing — Subscription-scope entry point
//
// Creates two resource groups and deploys all modules into them:
//
//   iis-core            VM, networking, Function App
//   iis-core-monitor    LAW, ADX, Event Hubs, DCRs, Automation, OpenAI, alerts
//
// Data flow:
//   VMPerf / IISPerf  → ADX VMPerf + IISPerf (Send-PerfToEventHub.ps1 → Event Hub)
//                       Polled every 60s by IISMonitorPoller Azure Function.
//   IIS W3C logs      → ADX IISLogs (dcr.bicep → Event Hub)
//   Baseline          → ADX PerformanceBaseline (Invoke-CaptureBaseline → Event Hub)
//
// Deploy with:
//   az deployment sub create \
//     --location eastus2 \
//     --template-file infra/main.bicep \
//     --parameters infra/parameters/dev.bicepparam
// =============================================================================

// ─── Resource Group names ─────────────────────────────────────────────────────
@description('Name of the core resource group (VM + Function App)')
param coreRgName string = 'iis-core'

@description('Name of the monitoring resource group (LAW, ADX, Event Hubs, etc.)')
param monitorRgName string = 'iis-core-monitor'

// ─── Shared parameters ────────────────────────────────────────────────────────
@description('Azure region for all resources')
param location string = 'eastus2'

@description('Project prefix for resource naming')
param projectPrefix string = 'iisheal'

@description('VM admin username')
param adminUsername string = 'azureadmin'

@description('VM admin password')
@secure()
param adminPassword string

@description('VM hostname')
param vmHostname string = 'iishealvm'

@description('Azure OpenAI location (must support o4-mini)')
param openaiLocation string = 'eastus2'

@description('ADX cluster SKU name')
@allowed([
  'Dev(No SLA)_Standard_D11_v2'
  'Standard_D11_v2'
  'Standard_D12_v2'
  'Standard_D13_v2'
])
param adxSkuName string = 'Dev(No SLA)_Standard_D11_v2'

@description('ADX cluster SKU tier')
@allowed(['Basic', 'Standard'])
param adxSkuTier string = 'Basic'

@description('ADX cluster node capacity')
param adxCapacity int = 1

// ─── Resource Groups ──────────────────────────────────────────────────────────
resource coreRg 'Microsoft.Resources/resourceGroups@2024-03-01' = {
  name: coreRgName
  location: location
}

resource monitorRg 'Microsoft.Resources/resourceGroups@2024-03-01' = {
  name: monitorRgName
  location: location
}

// ─── iis-core-monitor modules ─────────────────────────────────────────────────

module loganalytics 'modules/loganalytics.bicep' = {
  name: 'loganalytics'
  scope: monitorRg
  params: {
    location: location
    projectPrefix: projectPrefix
  }
}

module openai 'modules/openai.bicep' = {
  name: 'openai'
  scope: monitorRg
  params: {
    location: openaiLocation
    projectPrefix: projectPrefix
  }
}

module eventhubs 'modules/eventhubs.bicep' = {
  name: 'eventhubs'
  scope: monitorRg
  params: {
    location: location
    projectPrefix: projectPrefix
  }
}

module adx 'modules/adx.bicep' = {
  name: 'adx'
  scope: monitorRg
  params: {
    location: location
    projectPrefix: projectPrefix
    adxSkuName: adxSkuName
    adxSkuTier: adxSkuTier
    adxCapacity: adxCapacity
  }
}

module automation 'modules/automation.bicep' = {
  name: 'automation'
  scope: monitorRg
  params: {
    location: location
    projectPrefix: projectPrefix
  }
}

// ─── iis-core modules ─────────────────────────────────────────────────────────

module networking 'modules/networking.bicep' = {
  name: 'networking'
  scope: coreRg
  params: {
    location: location
    projectPrefix: projectPrefix
  }
}

// Bastion provides browser-based RDP into the VM — the VM no longer has a
// public IP of its own.  See modules/bastion.bicep for SKU choice.
module bastion 'modules/bastion.bicep' = {
  name: 'bastion'
  scope: coreRg
  params: {
    location: location
    projectPrefix: projectPrefix
    bastionSubnetId: networking.outputs.bastionSubnetId
  }
}

module vm 'modules/vm.bicep' = {
  name: 'vm'
  scope: coreRg
  params: {
    location: location
    projectPrefix: projectPrefix
    subnetId: networking.outputs.subnetId
    adminUsername: adminUsername
    adminPassword: adminPassword
    vmHostname: vmHostname
  }
}

module functionapp 'modules/functionapp.bicep' = {
  name: 'functionapp'
  scope: coreRg
  params: {
    location: location
    projectPrefix: projectPrefix
    lawWorkspaceId: loganalytics.outputs.workspaceId
    lawWorkspaceCustomerId: loganalytics.outputs.workspaceCustomerId
    automationAccountName: automation.outputs.automationAccountName
    automationAccountId: automation.outputs.automationAccountId
    vmName: vm.outputs.vmName
    vmHostname: vmHostname
    openaiEndpoint: openai.outputs.openaiEndpoint
    dceEndpoint: loganalytics.outputs.dceEndpoint
    resourceGroupName: coreRgName
    automationResourceGroupName: monitorRgName
    adxClusterUri: adx.outputs.clusterUri
    adxDatabase: adx.outputs.databaseName
    dcrAgentEventsImmutableId: loganalytics.outputs.dcrAgentEventsImmutableId
    dcrAgentErrorsImmutableId: loganalytics.outputs.dcrAgentErrorsImmutableId
  }
}

// ─── RBAC — split by target resource group ───────────────────────────────────

module rbacCore 'modules/rbac_core.bicep' = {
  name: 'rbacCore'
  scope: coreRg
  params: {
    functionAppPrincipalId: functionapp.outputs.functionAppPrincipalId
    automationPrincipalId: automation.outputs.automationPrincipalId
    vmId: vm.outputs.vmId
  }
}

module rbacMonitor 'modules/rbac_monitor.bicep' = {
  name: 'rbacMonitor'
  scope: monitorRg
  params: {
    functionAppPrincipalId: functionapp.outputs.functionAppPrincipalId
    automationPrincipalId: automation.outputs.automationPrincipalId
    vmPrincipalId: vm.outputs.vmPrincipalId
    lawWorkspaceId: loganalytics.outputs.workspaceId
    automationAccountId: automation.outputs.automationAccountId
    openaiId: openai.outputs.openaiId
    adxClusterId: adx.outputs.clusterId
    adxDatabaseName: adx.outputs.databaseName
    adxClusterPrincipalId: adx.outputs.clusterPrincipalId
    iisLogsEventHubId: eventhubs.outputs.iisLogsEventHubId
    vmPerfEventHubId: eventhubs.outputs.vmPerfEventHubId
    iisPerfEventHubId: eventhubs.outputs.iisPerfEventHubId
    baselineEventHubId: eventhubs.outputs.baselineEventHubId
    dcrAgentEventsId: loganalytics.outputs.dcrAgentEventsId
    dcrAgentErrorsId: loganalytics.outputs.dcrAgentErrorsId
  }
}

// NOTE: ADX data connections (adx_connections.bicep) are deployed separately
// from deploy.sh after a 90-second RBAC propagation wait.  Deploying them here
// with dependsOn: [rbacMonitor] is insufficient because Azure RBAC role
// assignments can take 60-90 s to replicate before ADX can validate them.

// ─── Outputs ─────────────────────────────────────────────────────────────────
output coreResourceGroup      string = coreRgName
output monitorResourceGroup   string = monitorRgName
output vmName                 string = vm.outputs.vmName
output vmPrivateIp            string = vm.outputs.vmPrivateIp
output bastionName            string = bastion.outputs.bastionName
output lawWorkspaceId         string = loganalytics.outputs.workspaceId
output lawWorkspaceCustomerId string = loganalytics.outputs.workspaceCustomerId
output dceEndpoint            string = loganalytics.outputs.dceEndpoint
output functionAppName        string = functionapp.outputs.functionAppName
output functionAppHostname    string = functionapp.outputs.functionAppDefaultHostname
output automationAccountName  string = automation.outputs.automationAccountName
output openaiEndpoint         string = openai.outputs.openaiEndpoint
output openaiName             string = openai.outputs.openaiName
output adxClusterUri          string = adx.outputs.clusterUri
output adxClusterName         string = adx.outputs.clusterName
output adxDatabaseName        string = adx.outputs.databaseName
output eventHubNamespaceName  string = eventhubs.outputs.namespaceName
