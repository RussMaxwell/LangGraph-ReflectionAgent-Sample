using '../main.bicep'

param coreRgName            = 'iis-core'
param monitorRgName         = 'iis-core-monitor'
param location              = 'eastus2'
param projectPrefix         = 'iisheals'
param adminUsername         = 'azureadmin'
param adminPassword         = readEnvironmentVariable('VM_ADMIN_PASSWORD', '')
param vmHostname            = 'iishealvm'
param openaiLocation        = 'eastus2'

// ADX: Dev SKU for development (~$60/month, no SLA, single node)
// For production change to: Standard_D11_v2 / Standard / 2
param adxSkuName    = 'Dev(No SLA)_Standard_D11_v2'
param adxSkuTier    = 'Basic'
param adxCapacity   = 1
