@description('Azure region for all resources')
param location string

@description('Project prefix used for naming resources')
param projectPrefix string

// ─── Naming ───────────────────────────────────────────────────────────────────
var vnetName    = '${projectPrefix}-vnet'
var vmSubnetName = '${projectPrefix}-subnet'           // VM sits here
var bastionSubnetName = 'AzureBastionSubnet'           // MUST be this exact name
var nsgName     = '${projectPrefix}-nsg'

// ─── Network Security Group (VM subnet) ──────────────────────────────────────
// The VM no longer has a public IP.  All inbound access is restricted to
// traffic that originates inside the VNet (Bastion sessions, Hybrid Worker
// callbacks, intra-VM).  No rules for internet HTTP or deployer-IP RDP.
//
// We still allow RDP (3389) and HTTP (80) from the VirtualNetwork tag so that:
//   - Azure Bastion (which sits in AzureBastionSubnet within the same VNet)
//     can open RDP sessions to the VM.
//   - A future jumphost or management VM in the VNet can reach the chaos app
//     on port 80.
//   - The default Deny-All-Inbound rule below ensures nothing else gets in.
resource nsg 'Microsoft.Network/networkSecurityGroups@2023-11-01' = {
  name: nsgName
  location: location
  properties: {
    securityRules: [
      {
        name: 'Allow-HTTP-VNet'
        properties: {
          priority: 100
          direction: 'Inbound'
          access: 'Allow'
          protocol: 'Tcp'
          sourcePortRange: '*'
          destinationPortRange: '80'
          sourceAddressPrefix: 'VirtualNetwork'
          destinationAddressPrefix: '*'
        }
      }
      {
        name: 'Allow-RDP-VNet'
        properties: {
          priority: 110
          direction: 'Inbound'
          access: 'Allow'
          protocol: 'Tcp'
          sourcePortRange: '*'
          destinationPortRange: '3389'
          sourceAddressPrefix: 'VirtualNetwork'
          destinationAddressPrefix: '*'
        }
      }
      {
        name: 'Deny-All-Inbound'
        properties: {
          priority: 4000
          direction: 'Inbound'
          access: 'Deny'
          protocol: '*'
          sourcePortRange: '*'
          destinationPortRange: '*'
          sourceAddressPrefix: '*'
          destinationAddressPrefix: '*'
        }
      }
    ]
  }
}

// ─── VNet with VM subnet + AzureBastionSubnet ────────────────────────────────
// Bastion requires a subnet named exactly "AzureBastionSubnet" with at least
// a /26 address range.  Bastion manages its own implicit NSG; we MUST NOT
// attach a user-defined NSG to this subnet.
resource vnet 'Microsoft.Network/virtualNetworks@2023-11-01' = {
  name: vnetName
  location: location
  properties: {
    addressSpace: {
      addressPrefixes: [
        '10.0.0.0/16'
      ]
    }
    subnets: [
      {
        name: vmSubnetName
        properties: {
          addressPrefix: '10.0.1.0/24'
          networkSecurityGroup: {
            id: nsg.id
          }
        }
      }
      {
        name: bastionSubnetName
        properties: {
          addressPrefix: '10.0.2.0/26'
          // Intentionally no NSG — Bastion enforces its own.
        }
      }
    ]
  }
}

// ─── Outputs ─────────────────────────────────────────────────────────────────
output vnetId         string = vnet.id
output vnetName       string = vnet.name
output subnetId       string = vnet.properties.subnets[0].id  // VM subnet
output bastionSubnetId string = vnet.properties.subnets[1].id
output nsgId          string = nsg.id
