@description('Azure region for all resources')
param location string

@description('Project prefix for resource naming')
param projectPrefix string

@description('Log Analytics Workspace resource ID')
param lawWorkspaceId string

@description('Log Analytics Workspace customer (workspace) ID')
param lawWorkspaceCustomerId string

@description('Name of the Automation Account')
param automationAccountName string

@description('Resource ID of the Automation Account')
param automationAccountId string

@description('Name of the target VM')
param vmName string

@description('Hostname of the target VM')
param vmHostname string

@description('Azure OpenAI endpoint URL')
param openaiEndpoint string

@description('Data Collection Endpoint URL')
param dceEndpoint string

@description('Name of the iis-core resource group (contains VM)')
param resourceGroupName string

@description('Name of the iis-core-monitor resource group (contains Automation Account)')
param automationResourceGroupName string

@description('ADX cluster URI (https://<name>.<region>.kusto.windows.net)')
param adxClusterUri string

@description('ADX database name')
param adxDatabase string

@description('Immutable ID of the AgentEvents_CL DCR (rule_id for LogsIngestionClient)')
param dcrAgentEventsImmutableId string

@description('Immutable ID of the AgentErrors_CL DCR (rule_id for LogsIngestionClient)')
param dcrAgentErrorsImmutableId string

@description('Name of the Hybrid Worker Group on the Automation Account')
param hybridWorkerGroupName string = 'IIS-HybridWorkers'

var storageAccountName = replace('${projectPrefix}funcsa', '-', '')
var appServicePlanName = '${projectPrefix}-func-plan'
var functionAppName    = '${projectPrefix}-func'
var appInsightsName    = '${projectPrefix}-func-ai'

resource storageAccount 'Microsoft.Storage/storageAccounts@2023-05-01' = {
  name: storageAccountName
  location: location
  sku: {
    name: 'Standard_LRS'
  }
  kind: 'StorageV2'
  properties: {
    supportsHttpsTrafficOnly: true
    minimumTlsVersion: 'TLS1_2'
    allowSharedKeyAccess: true
  }
}

// ─── Application Insights ─────────────────────────────────────────────────────
// Workspace-based (modern) — telemetry is stored in the shared LAW workspace so
// logs, invocations, exceptions, and live metrics are all visible in the portal.

resource appInsights 'Microsoft.Insights/components@2020-02-02' = {
  name: appInsightsName
  location: location
  kind: 'web'
  properties: {
    Application_Type: 'web'
    WorkspaceResourceId: lawWorkspaceId
    RetentionInDays: 30
    publicNetworkAccessForIngestion: 'Enabled'
    publicNetworkAccessForQuery: 'Enabled'
  }
}

resource appServicePlan 'Microsoft.Web/serverfarms@2023-12-01' = {
  name: appServicePlanName
  location: location
  kind: 'linux'
  sku: {
    name: 'B1'
    tier: 'Basic'
  }
  properties: {
    reserved: true
  }
}

resource functionApp 'Microsoft.Web/sites@2023-12-01' = {
  name: functionAppName
  location: location
  kind: 'functionapp,linux'
  identity: {
    type: 'SystemAssigned'
  }
  properties: {
    serverFarmId: appServicePlan.id
    httpsOnly: true
    siteConfig: {
      linuxFxVersion: 'PYTHON|3.12'
      alwaysOn: true
      appSettings: [
        {
          name: 'AzureWebJobsStorage'
          value: 'DefaultEndpointsProtocol=https;AccountName=${storageAccount.name};EndpointSuffix=${environment().suffixes.storage};AccountKey=${storageAccount.listKeys().keys[0].value}'
        }
        {
          name: 'FUNCTIONS_EXTENSION_VERSION'
          value: '~4'
        }
        {
          name: 'FUNCTIONS_WORKER_RUNTIME'
          value: 'python'
        }
        {
          name: 'PYTHON_VERSION'
          value: '3.12'
        }
        {
          name: 'LOG_ANALYTICS_WORKSPACE_ID'
          value: lawWorkspaceCustomerId
        }
        {
          name: 'LOG_ANALYTICS_WORKSPACE_RESOURCE_ID'
          value: lawWorkspaceId
        }
        {
          name: 'AUTOMATION_ACCOUNT_NAME'
          value: automationAccountName
        }
        {
          name: 'AUTOMATION_ACCOUNT_RESOURCE_ID'
          value: automationAccountId
        }
        {
          name: 'VM_NAME'
          value: vmName
        }
        {
          name: 'VM_HOSTNAME'
          value: vmHostname
        }
        {
          name: 'AZURE_OPENAI_ENDPOINT'
          value: openaiEndpoint
        }
        {
          name: 'AZURE_OPENAI_O4_MINI_DEPLOYMENT'
          value: 'o4-mini'
        }
        {
          name: 'AZURE_OPENAI_GPT4O_MINI_DEPLOYMENT'
          value: 'gpt-4o-mini'
        }
        {
          name: 'DCE_ENDPOINT'
          value: dceEndpoint
        }
        {
          name: 'RESOURCE_GROUP_NAME'
          value: resourceGroupName
        }
        {
          name: 'AUTOMATION_RESOURCE_GROUP_NAME'
          value: automationResourceGroupName
        }
        {
          name: 'ADX_CLUSTER_URI'
          value: adxClusterUri
        }
        {
          name: 'ADX_DATABASE'
          value: adxDatabase
        }
        {
          name: 'DCR_AGENT_EVENTS_RULE_ID'
          value: dcrAgentEventsImmutableId
        }
        {
          name: 'DCR_AGENT_ERRORS_RULE_ID'
          value: dcrAgentErrorsImmutableId
        }
        {
          name: 'HYBRID_WORKER_GROUP_NAME'
          value: hybridWorkerGroupName
        }
        {
          name: 'APPLICATIONINSIGHTS_CONNECTION_STRING'
          value: appInsights.properties.ConnectionString
        }
        {
          // Enables the Application Insights site extension for live metrics,
          // dependency tracking, and automatic exception capture on Linux Functions.
          name: 'ApplicationInsightsAgent_EXTENSION_VERSION'
          value: '~3'
        }
      ]
    }
  }
}

@description('Resource ID of the Function App')
output functionAppId string = functionApp.id

@description('Name of the Function App')
output functionAppName string = functionApp.name

@description('Principal ID of the Function App system-assigned managed identity')
output functionAppPrincipalId string = functionApp.identity.principalId

@description('Default hostname of the Function App')
output functionAppDefaultHostname string = functionApp.properties.defaultHostName

@description('Application Insights connection string')
output appInsightsConnectionString string = appInsights.properties.ConnectionString

@description('Application Insights instrumentation key')
output appInsightsInstrumentationKey string = appInsights.properties.InstrumentationKey
