@description('Azure region for all resources')
param location string

@description('Project prefix for resource naming')
param projectPrefix string

var automationAccountName = '${projectPrefix}-automation'
var hybridWorkerGroupName = 'IIS-HybridWorkers'

var runbookNames = [
  'Invoke-RecycleAppPool'
  'Invoke-RestartIIS'
  'Invoke-ClearIISLogs'
  'Invoke-FixAppPoolIdentity'
  'Invoke-EnableIIS'
  'Invoke-RestartW3SVC'
  'Invoke-FixBindings'
  'Invoke-ClearASPNETCache'
  'Invoke-FixPermissions'
  'Invoke-RestartWorkerProcess'
  'Invoke-CaptureBaseline'
]

resource automationAccount 'Microsoft.Automation/automationAccounts@2023-11-01' = {
  name: automationAccountName
  location: location
  identity: {
    type: 'SystemAssigned'
  }
  properties: {
    sku: {
      name: 'Basic'
    }
  }
}

resource hybridWorkerGroup 'Microsoft.Automation/automationAccounts/hybridRunbookWorkerGroups@2023-11-01' = {
  parent: automationAccount
  name: hybridWorkerGroupName
}

resource runbooks 'Microsoft.Automation/automationAccounts/runbooks@2023-11-01' = [
  for runbookName in runbookNames: {
    parent: automationAccount
    name: runbookName
    location: location
    properties: {
      runbookType: 'PowerShell72'
      logVerbose: false
      logProgress: false
      draft: {}
    }
  }
]

@description('Resource ID of the Automation Account')
output automationAccountId string = automationAccount.id

@description('Name of the Automation Account')
output automationAccountName string = automationAccount.name

@description('Principal ID of the Automation Account system-assigned managed identity')
output automationPrincipalId string = automationAccount.identity.principalId
