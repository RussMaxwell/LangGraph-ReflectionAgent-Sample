// =============================================================================
// Azure Bastion — browser-based RDP/SSH into the VM without a public IP.
//
// Basic SKU: supports RDP/SSH via the Azure portal, no tunneling, single session
// per admin.  Sufficient for development / test deployments.  Upgrade to
// Standard SKU later if you need native client support, IP-based connection,
// or port-forwarding.
//
// Bastion requires:
//   - A subnet named exactly "AzureBastionSubnet" with at least a /26 range,
//     and no user-defined NSG (created in networking.bicep).
//   - A Standard-SKU, Static, Regional public IP (created here).
// =============================================================================

@description('Azure region')
param location string

@description('Project prefix used for naming resources')
param projectPrefix string

@description('Resource ID of the AzureBastionSubnet (must be /26 or larger)')
param bastionSubnetId string

var bastionName   = '${projectPrefix}-bastion'
var bastionPipName = '${projectPrefix}-bastion-pip'

// ─── Public IP (for the Bastion host itself) ─────────────────────────────────
// This is the only public IP in the system.  It is attached to the managed
// Bastion service — not to the VM.  Clients connect to Bastion via the Azure
// portal and Bastion brokers the RDP/SSH session over the VNet.
resource bastionPip 'Microsoft.Network/publicIPAddresses@2023-11-01' = {
  name: bastionPipName
  location: location
  sku: {
    name: 'Standard'
    tier: 'Regional'
  }
  properties: {
    publicIPAllocationMethod: 'Static'
    publicIPAddressVersion: 'IPv4'
  }
}

// ─── Bastion Host ─────────────────────────────────────────────────────────────
resource bastion 'Microsoft.Network/bastionHosts@2023-11-01' = {
  name: bastionName
  location: location
  sku: {
    name: 'Basic'
  }
  properties: {
    ipConfigurations: [
      {
        name: 'bastion-ipconfig'
        properties: {
          subnet: {
            id: bastionSubnetId
          }
          publicIPAddress: {
            id: bastionPip.id
          }
        }
      }
    ]
  }
}

output bastionId   string = bastion.id
output bastionName string = bastion.name
