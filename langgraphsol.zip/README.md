# IIS Auto-Healing Multi-Agent System

An AI-driven self-healing pipeline for IIS workloads on Azure. When a performance anomaly or service failure is detected, a LangGraph multi-agent orchestrator analyses telemetry against a captured performance baseline, selects the right PowerShell runbook, executes the fix through Azure Automation Hybrid Worker, verifies the outcome, performs root-cause analysis, and logs every step -- all without human intervention.

---

## Architecture

```
┌──────────────────────────────────────────────────────────────────┐
│                     iis-core  Resource Group                     │
│                                                                  │
│  ┌──────────────────────────────────────────────────────────┐   │
│  │  Windows Server 2022 VM  (Standard_B2ms — 2vCPU, 8GB)    │   │
│  │                                                           │   │
│  │  ├─ IIS 10 (Default Web Site)                             │   │
│  │  │  ├─ / (default.aspx — Contoso Infrastructure page)    │   │
│  │  │  └─ /chaos/ (chaos engineering console)                │   │
│  │  ├─ Hybrid Runbook Worker Agent                           │   │
│  │  └─ Send-PerfToEventHub.ps1 (scheduled task, every 60s)  │   │
│  └──────────────────────────────────────────────────────────┘   │
│                                                                  │
│  ┌──────────────────────────────────────────────────────────┐   │
│  │  Function App (Python 3.12, B1 Linux)                     │   │
│  │                                                           │   │
│  │  IISMonitorPoller (timer, every 60s — queries ADX)        │   │
│  │  IISHealingOrchestratorInternal (HTTP, internal trigger)  │   │
│  │  IISHealingOrchestrator (HTTP, external trigger)          │   │
│  │                                                           │   │
│  │  LangGraph Single-Path Orchestrator (v3)                   │   │
│  │  ├─ classify   (no LLM — alert → IssueProfile)            │   │
│  │  ├─ gather     (no LLM — parallel evidence collection)    │   │
│  │  ├─ judge      (strategy-dependent — picks the action)    │   │
│  │  ├─ act        (no LLM — runs runbook via Automation)     │   │
│  │  ├─ confirm    (no LLM — runs profile.confirmation)       │   │
│  │  ├─ analyze    (o4-mini — deep RCA on evidence)           │   │
│  │  └─ summarize  (no LLM — writes AgentEvents_CL)           │   │
│  │                                                           │   │
│  │  + IssueProfile registry (agents/profiles.py) drives      │   │
│  │    per-issue behaviour                                    │   │
│  │                                                           │   │
│  │  Auth: Managed Identity + RBAC                            │   │
│  └──────────────────────────────────────────────────────────┘   │
└──────────────────────────────────────────────────────────────────┘

┌──────────────────────────────────────────────────────────────────┐
│                iis-core-monitor  Resource Group                   │
│                                                                  │
│  ┌──────────────┐  ┌───────────────┐  ┌──────────────────────┐  │
│  │ Log Analytics │  │ Azure OpenAI  │  │ Automation Account   │  │
│  │ Workspace     │  │ Service       │  │                      │  │
│  │               │  │               │  │  11 Runbooks         │  │
│  │ AgentEvents   │  │ o4-mini       │  │  Hybrid Worker Group │  │
│  │ AgentErrors   │  │ gpt-4o-mini   │  │                      │  │
│  │               │  │               │  │  Auth: MI+RBAC       │  │
│  └──────────────┘  └───────────────┘  └──────────────────────┘  │
│                                                                  │
│  ┌──────────────────────┐  ┌─────────────────────────────────┐  │
│  │ Event Hub Namespace   │  │ Azure Data Explorer Cluster     │  │
│  │ (Standard, 1 TU)     │  │ (Dev SKU, 1 node)               │  │
│  │                       │  │                                  │  │
│  │ iislogs-eh            │  │ Tables: IISLogs, IISLogsParsed, │  │
│  │ vmperf-eh             │  │   VMPerf, IISPerf,              │  │
│  │ iisperf-eh            │  │   IISHttpErrors,                │  │
│  │ baseline-eh           │  │   PerformanceBaseline           │  │
│  │                       │  │                                  │  │
│  │ Auth: MI+RBAC         │  │ Auth: MI+RBAC                   │  │
│  └──────────────────────┘  └─────────────────────────────────┘  │
└──────────────────────────────────────────────────────────────────┘

Detection Flow:
  VM (Send-PerfToEventHub.ps1, 60s) ─── perf counters ──→ Event Hubs ──→ ADX
  VM (DCR) ─── IIS W3C logs ──→ iislogs-eh ──→ ADX
  IISMonitorPoller (60s timer) ─── KQL queries (16 conditions) ──→ ADX
      │ breach detected + cooldown passed
      ▼
  IISHealingOrchestratorInternal ──→ LangGraph pipeline ──→ Runbook ──→ VM

Baseline Capture Flow:
  scripts/run_baseline.sh ──→ VM (Hybrid Worker) ──→ run_baseline.ps1
      │ 60 min perfmon capture (external load via load_test.sh)
      ▼
  baseline-eh (Event Hub) ──→ ADX PerformanceBaseline table
      │
      ▼
  AnalysisAgent + RCAAgent compare live metrics against baseline
```

---

## Single-Path Pipeline (v3)

Every alert walks the same six nodes. Behavioural variance per issue type
lives in an `IssueProfile` row loaded by `classify` from `agents/profiles.py`.

```
START → classify → gather → judge → act → confirm ──► analyze → summarize → END
                              ▲                  │
                              │                  │ !healthy & retry<2
                              └──── retry ◄──────┘  (retry_count++)
```

The profile declares, per issue type:

- **gatherers** — what evidence `gather` collects (parallel).
- **strategy** — how `judge` decides:
  - `MECHANICAL` — no LLM; picks the default_runbook directly.
  - `REASONED` — gpt-4o-mini decides between remediate and no_action.
  - `REASONED_WITH_VETO` — adds escalate_only / remediate_and_escalate (used
    for cases like a 5xx flood where the cause is upstream of IIS).
- **default_runbook** / **escalation_runbook** — which runbook `act` runs
  (escalation is used on retry).
- **confirmation** — which checks must pass for `is_healthy`.
- **analyze** — whether to run deep RCA (o4-mini).

See [docs/langgraph_pipeline.md](docs/langgraph_pipeline.md) for the full
design and [docs/flow_examples.md](docs/flow_examples.md) for three
end-to-end traces.

### Issue Profile Snapshot

| issue_type | Strategy | Default runbook | Analyze |
|---|---|---|---|
| `w3svc_stopped` | MECHANICAL | `Invoke-RestartW3SVC` | No |
| `app_pool_stopped` | MECHANICAL | `Invoke-RecycleAppPool` | No |
| `app_pool_crash` | MECHANICAL | `Invoke-RecycleAppPool` | Yes |
| `log_disk_full` | MECHANICAL | `Invoke-ClearIISLogs` | No |
| `binding_missing` | MECHANICAL | `Invoke-FixBindings` | No |
| `app_pool_identity` | MECHANICAL | `Invoke-FixAppPoolIdentity` | No |
| `bad_permissions` | MECHANICAL | `Invoke-FixPermissions` | No |
| `high_cpu` / `high_cpu_w3wp` | MECHANICAL | `Invoke-RecycleAppPool` | Yes |
| `memory_leak` | REASONED | `Invoke-RecycleAppPool` | Yes |
| `worker_process_hang` | REASONED | `Invoke-RestartWorkerProcess` | Yes |
| `request_queue_flood` | REASONED | `Invoke-RecycleAppPool` | Yes |
| `bad_http_errors` | REASONED | `Invoke-RecycleAppPool` | Yes |
| `high_memory` / `high_disk_io` | REASONED | various | Yes |
| `http_5xx_flood` | REASONED_WITH_VETO | `Invoke-RecycleAppPool` | Yes |
| `unknown` | REASONED | `Invoke-RestartIIS` | Yes |

Every profile's `escalation_runbook` is `Invoke-RestartIIS` — retries always
escalate to the bigger hammer.

---

## Prerequisites

| Tool | Version | Notes |
|------|---------|-------|
| Azure CLI (`az`) | 2.60+ | `az login` must be completed before deploying |
| Python | 3.12 | Used by the Function App runtime |
| Bicep | (auto-installed) | The deploy script runs `az bicep install` automatically |

You also need an Azure subscription with permission to create resource groups and assign RBAC roles (Owner or Contributor + User Access Administrator).

---

## Quickstart

### Step 1 -- Clone and configure

```bash
git clone https://github.com/RussMaxwell/IIS_Heal.git
cd iis-autohealing

# Set the VM admin password (12+ chars, must meet Azure complexity rules)
export VM_ADMIN_PASSWORD='YourStr0ng!Passw0rd'
```

### Step 2 -- Deploy infrastructure

```bash
bash scripts/deploy.sh
```

This script will:
- Create two resource groups (`iis-core` and `iis-core-monitor`)
- Install Bicep if not already present
- Deploy all infrastructure (VM, ADX, Event Hubs, Log Analytics, Azure OpenAI, Automation Account, Function App)
- Create ADX tables (IISLogs, IISLogsParsed, VMPerf, IISPerf, IISHttpErrors, PerformanceBaseline) and data connections
- Install PowerShell 7 on the VM and register the Hybrid Runbook Worker
- Upload runbooks to the Automation Account
- Create scheduled tasks on the VM (`Send-PerfToEventHub.ps1` every 60s)
- Deploy the Python Function App via Kudu zip deploy with Oryx remote build
- Output the VM public IP and Function App hostname

Typical deployment time is 12-18 minutes.

### Step 3 -- Verify VM and IIS

Browse to the VM public IP printed by the deploy script:

```
http://<vm-ip>/
```

You should see the **Contoso Infrastructure Services** page -- a full enterprise website with navigation, service cards, blog previews, testimonials, and a contact form. The page renders server-side via ASP.NET Web Forms and includes the server hostname and UTC timestamp in the footer.

### Step 4 -- Capture performance baseline

```bash
bash scripts/run_baseline.sh
```

**This takes approximately 60 minutes.** The script triggers the `Invoke-CaptureBaseline` runbook on the VM, which samples OS and IIS performance counters every 60 seconds. Results are shipped to the `PerformanceBaseline` table in ADX (via `baseline-eh` Event Hub). Run `scripts/load_test.sh` in a second terminal to generate external traffic during the capture (see `docs/load_testing_guide.md`).

### Step 5 -- Test chaos scenarios

```bash
bash scripts/test_chaos.sh
```

This script triggers one or more chaos scenarios via the web-based chaos console and waits for the auto-healing pipeline to detect, remediate, and verify recovery. Watch the Function App logs and the `AgentEvents_CL` table for real-time progress.

---

## Detection -- IISMonitorPoller

Anomaly detection is built into the `IISMonitorPoller` Azure Function, a timer-triggered function that runs every 60 seconds. It queries the VMPerf, IISPerf, and IISHttpErrors tables in ADX with 7-minute look-back windows and evaluates 16 threshold conditions. When a breach is detected and the 5-minute cooldown has passed, the poller fires an HTTP POST to `IISHealingOrchestratorInternal` with the issue type and summary.

Cooldown state is persisted in Azure Table Storage (`healingcooldown` table via `AzureWebJobsStorage`) so it survives Function App cold starts and is shared across scale-out instances.

### Detection Conditions (16 rules)

| # | Issue Type | Metric / Counter | Threshold | Source Table |
|---|-----------|------------------|-----------|--------------|
| 1 | high_cpu | % Processor Time (_Total) | > 85% avg | VMPerf |
| 2 | high_memory | Available MBytes | < 512 MB avg | VMPerf |
| 3 | high_memory | % Committed Bytes In Use | > 90% avg | VMPerf |
| 4 | log_disk_full | % Free Space (C:) | < 5% min | VMPerf |
| 5 | high_disk_io | Avg. Disk Queue Length | > 5 avg | VMPerf |
| 6 | high_memory | Pages/sec | > 1000 avg | VMPerf |
| 7 | high_cpu | Processor Queue Length | > 10 avg | VMPerf |
| 8 | w3svc_stopped | Current Connections == 0 (synthetic) | for 3+ min | IISPerf |
| 9 | app_pool_crash | Connection Attempts Failed | > 50 sum | IISPerf |
| 10 | request_queue_flood | Requests Queued | > 100 avg | IISPerf |
| 11 | app_pool_crash | Application Restarts | > 2 max | IISPerf |
| 12 | high_cpu_w3wp | % Processor Time (w3wp) | > 80% avg | IISPerf |
| 13 | memory_leak | Working Set (w3wp) | > 1.5 GB avg | IISPerf |
| 14 | worker_process_hang | Thread Count (w3wp) | > 200 avg | IISPerf |
| 15 | bad_http_errors | 404 Errors/sec | > 20 avg | IISPerf |
| 16 | app_pool_stopped | 503 AppOffline rows | >= 3 count | IISHttpErrors |

**Synthetic heartbeat (w3svc_stopped):** When W3SVC stops, Windows unregisters the `\Web Service` counter object entirely, causing an absence of data rather than zero values. `Send-PerfToEventHub.ps1` detects the missing counter and injects synthetic `Current Connections = 0` rows. The KQL query uses case-sensitive `==` to match only these synthetic rows.

---

## Azure OpenAI

### Region availability

The `o4-mini` model is not available in all Azure regions. The infrastructure defaults to `eastus`. Other supported regions include `swedencentral`, `westus3`, and `northcentralus`. Update the `openaiLocation` parameter in `infra/main.bicep` if you need a different region.

### Model deployments

| Deployment | Model | SKU | Used by |
|------------|-------|-----|---------|
| `o4-mini` | o4-mini (2025-04-16) | GlobalStandard 10 TPM | AnalysisAgent, RCAAgent, DetDiagnoseAgent |
| `gpt-4o-mini` | gpt-4o-mini (2024-07-18) | GlobalStandard 30 TPM | DetectionAgent, RemediationAgent, VerificationAgent, ReportingAgent |

**o4-mini** (Tier 1): Multi-step reasoning -- correlating telemetry, comparing against baseline, producing ranked root-cause hypotheses. Config: `reasoning_effort="medium"`, `temperature=1`, `max_tokens=4096`.

**gpt-4o-mini** (Tier 2): High-throughput, low-latency tasks -- alert classification, runbook mapping, health evaluation, report formatting. Config: `temperature=0`, `max_tokens=2048`.

---

## Capturing the Performance Baseline

### When to run

- **After initial deployment** -- once IIS is serving traffic and the Hybrid Worker is registered.
- **After configuration changes** -- whenever you change app pool settings, add sites, or modify the VM size.
- **Periodically** -- to account for organic traffic growth; quarterly is a reasonable cadence.

### Why it matters

The AnalysisAgent compares live telemetry against baseline percentiles (p50, p90, p95, p99) to distinguish genuine anomalies from normal operating patterns. Without a baseline, the agent can still analyse metrics on their own, but it will flag the absence of baseline data and may produce less precise root-cause hypotheses.

### How to re-run after config changes

```bash
bash scripts/run_baseline.sh
```

Each run writes new records to the ADX `PerformanceBaseline` table tagged with a unique `CaptureId` (GUID). The AnalysisAgent always queries the most recent capture, so old baselines are automatically superseded.

---

## Web Application Guide

### Normal page -- `/`

The root URL serves the **Contoso Infrastructure Services** site, a realistic multi-section enterprise page built with ASP.NET Web Forms:

- **Navigation bar** -- Home, Services, About, Blog, Contact
- **Hero section** -- company tagline and call-to-action
- **Services grid** -- six cards (Managed Hosting, Cloud Migration, 24/7 Monitoring, Security Hardening, Disaster Recovery, Performance Tuning)
- **Metrics bar** -- 99.99% uptime SLA, 500+ clients, 15 years experience, 24/7 support
- **Blog previews** -- three article cards
- **Testimonials** -- three client quotes
- **Contact form** -- name, email, company, message fields
- **Footer** -- server hostname and UTC render timestamp

Expected response time under normal load: **< 200 ms**.

### Chaos console -- `/chaos/`

The chaos engineering console is a dark-themed, purpose-built UI for controlled fault injection. It displays four system-status tiles (hostname, W3SVC state, DefaultAppPool state, current time) and ten fault-injection scenario cards:

| # | Scenario | Severity | Effect |
|---|----------|----------|--------|
| 1 | App Pool Crash | Critical | Kills all w3wp.exe processes |
| 2 | W3SVC Stop | Critical | Stops the World Wide Web Publishing Service |
| 3 | High CPU | High | 90-second tight math loop in w3wp |
| 4 | Memory Leak | High | Pins 200 MB of byte arrays via GCHandle |
| 5 | Log Disk Full | Medium | Writes a 2 GB file to the IIS logs directory |
| 6 | App Pool Identity Corruption | High | Sets DefaultAppPool to an invalid user account |
| 7 | HTTP Binding Removal | Critical | Removes all port-80 bindings from Default Web Site |
| 8 | Request Queue Flood | High | Spawns 300 threads each sleeping 30 seconds |
| 9 | Bad File Permissions | High | Removes IIS_IUSRS read access from wwwroot |
| 10 | Worker Process Hang | High | Next request hangs indefinitely via Thread.Sleep |

**Safety gates:** Each scenario requires the operator to check a confirmation checkbox before the "Trigger Fault" button becomes active. The button is disabled and visually dimmed until the gate is passed.

---

## Sample KQL Queries

### VMPerf (ADX) -- CPU trend over time

```kql
VMPerf
| where CounterName == "% Processor Time" and InstanceName == "_Total"
| summarize AvgCpu = avg(CounterValue) by bin(TimeGenerated, 5m)
| order by TimeGenerated asc
| render timechart
```

### IISPerf (ADX) -- w3wp resource usage

```kql
IISPerf
| where InstanceName == "w3wp"
| summarize
    AvgCpu = avgif(CounterValue, CounterName == "% Processor Time"),
    AvgWorkingSetMB = avgif(CounterValue / 1048576, CounterName == "Working Set"),
    AvgThreads = avgif(CounterValue, CounterName == "Thread Count")
  by bin(TimeGenerated, 5m)
| order by TimeGenerated asc
```

### IISLogsParsed (ADX) -- top 10 URIs by request count

```kql
IISLogsParsed
| summarize RequestCount = count() by UriStem
| top 10 by RequestCount desc
```

### IISHttpErrors (ADX) -- recent 503 AppOffline events

```kql
IISHttpErrors
| where StatusCode == 503 and Reason == "AppOffline"
| order by TimeGenerated desc
| take 20
```

### AgentEvents (LAW) -- recent healing events

```kql
AgentEvents_CL
| order by TimeGenerated desc
| take 20
| project TimeGenerated, IssueType, Outcome, RemediationRunbook, IsHealthy, RetriesUsed
```

### AgentErrors (LAW) -- error summary

```kql
AgentErrors_CL
| summarize ErrorCount = count() by Agent, Error
| order by ErrorCount desc
```

### PerformanceBaseline (ADX) -- latest baseline summary

```kql
let latest_capture = toscalar(
    PerformanceBaseline
    | where RecordType == 'Summary'
    | summarize arg_max(TimeGenerated, CaptureId)
    | project CaptureId
);
PerformanceBaseline
| where CaptureId == latest_capture
| where RecordType == 'Summary'
| project TimeGenerated, Computer, MetricName, MetricValue
| order by MetricName asc
```

---

## Runbooks

All runbooks are PowerShell 7.2 scripts executed on the VM via the Hybrid Runbook Worker.

| Runbook | Purpose |
|---------|---------|
| `Invoke-RecycleAppPool.ps1` | Recycles the DefaultAppPool gracefully using overlapped recycling |
| `Invoke-RestartIIS.ps1` | Performs a full `iisreset /restart` of IIS |
| `Invoke-RestartW3SVC.ps1` | Restarts the World Wide Web Publishing Service (W3SVC) |
| `Invoke-RestartWorkerProcess.ps1` | Terminates and restarts the w3wp.exe worker process |
| `Invoke-ClearIISLogs.ps1` | Deletes old IIS log files to reclaim disk space |
| `Invoke-ClearASPNETCache.ps1` | Clears the ASP.NET temporary files and compilation cache |
| `Invoke-FixAppPoolIdentity.ps1` | Resets the DefaultAppPool identity to ApplicationPoolIdentity |
| `Invoke-FixBindings.ps1` | Restores the default HTTP *:80 binding on the Default Web Site |
| `Invoke-FixPermissions.ps1` | Re-grants IIS_IUSRS read/execute on `C:\inetpub\wwwroot` |
| `Invoke-EnableIIS.ps1` | Ensures the W3SVC service is set to Automatic and started |
| `Invoke-CaptureBaseline.ps1` | Triggers the 60-minute performance baseline capture |

---

## Project Structure

```
iis-autohealing/
├── README.md
├── project_structure.txt
├── docs/
│   ├── architecture.md
│   ├── cost_estimate.md
│   ├── executive_summary.md
│   ├── testing_guide.md
│   ├── load_testing_guide.md
│   ├── langgraph_pipeline.md
│   ├── w3svc_stopped_flow.md
│   └── validation_report.md
├── infra/
│   ├── main.bicep
│   ├── parameters/
│   │   └── dev.bicepparam
│   └── modules/
│       ├── networking.bicep
│       ├── vm.bicep
│       ├── loganalytics.bicep
│       ├── openai.bicep
│       ├── automation.bicep
│       ├── functionapp.bicep
│       ├── adx.bicep
│       ├── adx_connections.bicep
│       ├── eventhubs.bicep
│       ├── dcr.bicep
│       ├── rbac.bicep
│       └── rbac_monitor.bicep
├── runbooks/
│   ├── Invoke-RecycleAppPool.ps1
│   ├── Invoke-RestartIIS.ps1
│   ├── Invoke-ClearIISLogs.ps1
│   ├── Invoke-FixAppPoolIdentity.ps1
│   ├── Invoke-EnableIIS.ps1
│   ├── Invoke-RestartW3SVC.ps1
│   ├── Invoke-FixBindings.ps1
│   ├── Invoke-ClearASPNETCache.ps1
│   ├── Invoke-FixPermissions.ps1
│   ├── Invoke-RestartWorkerProcess.ps1
│   └── Invoke-CaptureBaseline.ps1
├── chaos-app/
│   ├── default.aspx
│   ├── default.aspx.cs
│   ├── Web.config
│   └── chaos/
│       ├── default.aspx
│       └── default.aspx.cs
├── baseline/
│   ├── run_baseline.ps1
│   └── Get-BaselineSummary.ps1
├── function-app/
│   ├── host.json
│   ├── requirements.txt
│   ├── local.settings.json.example
│   ├── IISHealingOrchestrator/
│   │   ├── __init__.py
│   │   └── function.json
│   ├── IISMonitorPoller/
│   │   ├── __init__.py
│   │   └── function.json
│   ├── IISHealingOrchestratorInternal/
│   │   ├── __init__.py
│   │   └── function.json
│   ├── agents/
│   │   ├── __init__.py
│   │   ├── orchestrator.py     # 6-node LangGraph state machine
│   │   ├── classify_agent.py   # alert → issue_type → IssueProfile
│   │   ├── gather_agent.py     # parallel evidence collection
│   │   ├── judge_agent.py      # decision: remediate / no_action / escalate_only / remediate_and_escalate
│   │   ├── act_agent.py        # runbook execution
│   │   ├── confirm_agent.py    # health-check verification
│   │   ├── analyze_agent.py    # deep RCA on preserved evidence (o4-mini)
│   │   ├── summarize_agent.py  # writes AgentEvents_CL
│   │   └── profiles.py         # IssueProfile registry (one row per issue type)
│   ├── tools/
│   │   ├── __init__.py
│   │   ├── azure_openai_client.py
│   │   ├── law_client.py
│   │   ├── law_ingestion_client.py
│   │   ├── automation_client.py
│   │   ├── vm_client.py
│   │   ├── adx_client.py
│   │   └── baseline_client.py
│   └── models/
│       ├── __init__.py
│       ├── alert_payload.py
│       ├── agent_state.py
│       ├── healing_result.py
│       └── baseline_summary.py
└── scripts/
    ├── deploy.sh
    ├── teardown.sh
    ├── run_baseline.sh
    ├── load_test.sh
    ├── test_chaos.sh
    ├── validate_agent.sh
    ├── Send-PerfToEventHub.ps1
    └── setup-iis.ps1
```

---

## Troubleshooting

### Baseline not captured

**Symptom:** The AnalysisAgent logs "No baseline data is available" in every healing run.

**Cause:** The baseline capture has not been run, or it ran more than 7 days ago (the query window is 7 days).

**Fix:** Run `bash scripts/run_baseline.sh` (plus `scripts/load_test.sh` in a second terminal for traffic) and wait the full 60 minutes. Verify data arrived in ADX:

```kql
PerformanceBaseline | where RecordType == 'Summary' | order by TimeGenerated desc | take 10
```

### Hybrid Worker not registered

**Symptom:** Runbooks stay in "Queued" status and never execute. The verification agent reports the system is still unhealthy after remediation.

**Cause:** The Hybrid Runbook Worker was not registered on the VM. The deploy script automates this, but registration can fail if the VM is not yet ready.

**Fix:** Verify registration:

```bash
az automation hybrid-runbook-worker list \
  --automation-account-name iisheal-aa \
  --resource-group iis-core-monitor \
  --hybrid-runbook-worker-group-name iisheal-hwg
```

### IISMonitorPoller not detecting issues

**Symptom:** Faults are injected but no healing runs are triggered.

**Possible causes:**
1. **No data in ADX** -- verify `Send-PerfToEventHub.ps1` is running as a scheduled task on the VM. Check ADX: `VMPerf | take 5`.
2. **Cooldown active** -- the poller observes a 5-minute cooldown between triggers. Check the Function App logs for "Cooldown active" messages.
3. **Function App not running** -- check `az functionapp show -n iisheal-func -g iis-core --query state`.
4. **ADX data connection issue** -- verify Event Hub data connections exist in ADX and are in a healthy state.

### Azure OpenAI region not supported

**Symptom:** Deployment fails with a model-not-found error during the `openai` Bicep module.

**Cause:** The `o4-mini` model is not available in the selected region.

**Fix:** Update the `openaiLocation` parameter in `infra/main.bicep` to a supported region (`eastus`, `swedencentral`, `westus3`, `northcentralus`) and re-run `bash scripts/deploy.sh`.

---

## Teardown

To delete all Azure resources created by this project:

```bash
bash scripts/teardown.sh
```

This removes the `iis-core` and `iis-core-monitor` resource groups and all resources within them. The operation is irreversible.
