using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Net;
using System.Runtime.InteropServices;
using System.Security.AccessControl;
using System.Security.Principal;
using System.ServiceProcess;
using System.Threading;
using System.Web.UI;
using Microsoft.Web.Administration;

public partial class ChaosPage : Page
{
    // Static list to hold pinned memory (scenario 4) so it survives GC
    private static readonly List<GCHandle> PinnedHandles = new List<GCHandle>();
    private static readonly List<byte[]> LeakedBuffers = new List<byte[]>();

    // Static flag for worker process hang (scenario 10)
    private static volatile bool HangNextRequest = false;

    protected void Page_Load(object sender, EventArgs e)
    {
        // Check for hang flag before anything else
        if (HangNextRequest && !IsPostBack)
        {
            // Only hang on GET requests (not the POST that sets the flag)
            HangNextRequest = false; // Reset so only one request hangs
            WriteEventLog(9010, "Worker Process Hang activated - request is now hanging indefinitely.");
            Thread.Sleep(int.MaxValue);
        }

        // Populate system status
        PopulateSystemStatus();

        // Handle POST — use HttpMethod check instead of IsPostBack because
        // the page uses plain HTML forms (no __VIEWSTATE), so IsPostBack
        // is always false.
        if (Request.HttpMethod == "POST")
        {
            string scenarioStr = Request.Form["scenario"];
            string confirmed = Request.Form["confirmed"];
            int scenarioNum;

            if (!string.IsNullOrEmpty(scenarioStr) && int.TryParse(scenarioStr, out scenarioNum))
            {
                if (string.IsNullOrEmpty(confirmed) || confirmed != "yes")
                {
                    SetResult("#dc2626", "REJECTED: Confirmation checkbox was not checked. No fault triggered.");
                    return;
                }

                ExecuteScenario(scenarioNum);
            }
        }
    }

    private void PopulateSystemStatus()
    {
        // Hostname
        lblHostname.Text = Environment.MachineName;

        // W3SVC status — ServiceController may throw if the worker
        // process identity lacks permission to query the SCM.
        try
        {
            using (ServiceController sc = new ServiceController("W3SVC"))
            {
                string status = sc.Status.ToString();
                switch (sc.Status)
                {
                    case ServiceControllerStatus.Running:
                        lblW3svc.Text = "<span style='color:#16a34a; font-weight:600;'>" + status + "</span>";
                        break;
                    case ServiceControllerStatus.Stopped:
                        lblW3svc.Text = "<span style='color:#dc2626; font-weight:600;'>" + status + "</span>";
                        break;
                    default:
                        lblW3svc.Text = "<span style='color:#d97706; font-weight:600;'>" + status + "</span>";
                        break;
                }
            }
        }
        catch
        {
            // Fallback: if this page is serving a response, W3SVC must be running.
            lblW3svc.Text = "<span style='color:#16a34a; font-weight:600;'>Running</span>";
        }

        // DefaultAppPool status — ServerManager requires admin-level access to
        // redirection.config.  Fall back to checking for running w3wp processes.
        try
        {
            using (ServerManager mgr = new ServerManager())
            {
                ApplicationPool pool = mgr.ApplicationPools["DefaultAppPool"];
                if (pool != null)
                {
                    string state = pool.State.ToString();
                    switch (pool.State)
                    {
                        case ObjectState.Started:
                            lblAppPool.Text = "<span style='color:#16a34a; font-weight:600;'>" + state + "</span>";
                            break;
                        case ObjectState.Stopped:
                            lblAppPool.Text = "<span style='color:#dc2626; font-weight:600;'>" + state + "</span>";
                            break;
                        default:
                            lblAppPool.Text = "<span style='color:#d97706; font-weight:600;'>" + state + "</span>";
                            break;
                    }
                }
                else
                {
                    lblAppPool.Text = "<span style='color:#dc2626; font-weight:600;'>Not Found</span>";
                }
            }
        }
        catch
        {
            // ServerManager needs elevated access; fall back to process check.
            Process[] workers = Process.GetProcessesByName("w3wp");
            bool alive = workers.Length > 0;
            foreach (Process p in workers) p.Dispose();
            lblAppPool.Text = alive
                ? "<span style='color:#16a34a; font-weight:600;'>Running</span>"
                : "<span style='color:#dc2626; font-weight:600;'>No Workers</span>";
        }

        // Current time
        lblTime.Text = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss UTC") + " (Server Local)";
    }

    private void ExecuteScenario(int scenario)
    {
        try
        {
            switch (scenario)
            {
                case 1:
                    ExecuteAppPoolCrash();
                    break;
                case 2:
                    ExecuteW3svcStop();
                    break;
                case 3:
                    ExecuteHighCpu();
                    break;
                case 4:
                    ExecuteMemoryLeak();
                    break;
                case 5:
                    ExecuteLogDiskFull();
                    break;
                case 6:
                    ExecuteAppPoolIdentityCorruption();
                    break;
                case 7:
                    ExecuteHttpBindingRemoval();
                    break;
                case 8:
                    ExecuteRequestQueueFlood();
                    break;
                case 9:
                    ExecuteBadFilePermissions();
                    break;
                case 10:
                    ExecuteWorkerProcessHang();
                    break;
                default:
                    SetResult("#dc2626", "Unknown scenario number: " + scenario);
                    break;
            }
        }
        catch (Exception ex)
        {
            SetResult("#dc2626", "ERROR executing scenario #" + scenario + ": " + Server.HtmlEncode(ex.GetType().Name + " - " + ex.Message));
            try
            {
                WriteEventLog(9000 + scenario, "Chaos scenario #" + scenario + " FAILED with error: " + ex.ToString());
            }
            catch { }
        }
    }

    // Scenario 1: App Pool Crash - Terminate the w3wp process via FailFast
    //
    // NOTE: Process.Kill() does NOT work here because the DefaultAppPool identity
    // lacks PROCESS_TERMINATE permission.  Environment.FailFast() crashes the
    // current process from within — no elevated permissions required.  IIS will
    // automatically spin up a new worker process and increment the ASP.NET
    // "Application Restarts" counter, which triggers the alert rule.
    private void ExecuteAppPoolCrash()
    {
        WriteEventLog(9001, "Chaos Scenario #1: App Pool Crash - Triggering Environment.FailFast in 1 second.");

        // Flush the response first so the browser sees the confirmation
        SetResult("#b91c1c", "TRIGGERED: Scenario #1 App Pool Crash - Process will terminate in ~1 second via FailFast. 503 errors imminent on next request.");

        // Background thread crashes the process after a short delay,
        // giving ASP.NET time to flush the HTTP response
        Thread crashThread = new Thread(() =>
        {
            Thread.Sleep(1500);
            Environment.FailFast("Chaos Scenario #1: Deliberate App Pool Crash for auto-healing testing.");
        });
        crashThread.IsBackground = true;
        crashThread.Start();
    }

    // Scenario 2: W3SVC Stop - Stop IIS entirely
    //
    // NOTE: net stop w3svc is issued on a background thread with a short delay so
    // the HTTP response returns to the browser before IIS kills the worker process.
    // Running inline (like a normal Process.Start + WaitForExit) causes the w3wp
    // process to be terminated mid-request — the response never reaches the client.
    // Requires ChaosAppPool identity = LocalSystem (set in setup-iis.ps1).
    private void ExecuteW3svcStop()
    {
        WriteEventLog(9002, "Chaos Scenario #2: W3SVC Stop - Stopping World Wide Web Publishing Service in 1.5 seconds.");

        SetResult("#b91c1c", "TRIGGERED: Scenario #2 W3SVC Stop - W3SVC will stop in ~1.5 seconds. IIS connections will drop immediately.");

        Thread stopThread = new Thread(() =>
        {
            Thread.Sleep(1500);
            try
            {
                // Use ServiceController (direct SCM API) rather than spawning net.exe.
                // Process.Start with UseShellExecute=false can fail silently in IIS worker
                // processes where the PATH may not include System32.  ServiceController
                // talks to the SCM directly — no child-process or PATH dependency.
                using (ServiceController svc = new ServiceController("W3SVC"))
                {
                    if (svc.Status != ServiceControllerStatus.Stopped &&
                        svc.Status != ServiceControllerStatus.StopPending)
                    {
                        svc.Stop();
                        // WaitForStatus may be interrupted when w3wp.exe is killed as
                        // part of W3SVC stopping — that is expected and harmless.
                        svc.WaitForStatus(ServiceControllerStatus.Stopped, TimeSpan.FromSeconds(30));
                    }
                }
            }
            catch (Exception ex)
            {
                try { WriteEventLog(9002, "W3SVC stop failed: " + ex.GetType().Name + ": " + ex.Message); }
                catch { }
            }
        });
        stopThread.IsBackground = true;
        stopThread.Start();
    }

    // Scenario 3: High CPU - Tight math loop for 90 seconds
    private void ExecuteHighCpu()
    {
        WriteEventLog(9003, "Chaos Scenario #3: High CPU - Starting tight Math.Sqrt loop for 90 seconds.");

        int threadCount = Environment.ProcessorCount;

        for (int i = 0; i < threadCount; i++)
        {
            Thread cpuThread = new Thread(() =>
            {
                DateTime end = DateTime.UtcNow.AddSeconds(90);
                double result = 0;
                while (DateTime.UtcNow < end)
                {
                    for (int j = 0; j < 1000000; j++)
                    {
                        result = Math.Sqrt(result + 1.0) * Math.Sqrt(result + 2.0);
                    }
                }
            });
            cpuThread.IsBackground = true;
            cpuThread.Priority = ThreadPriority.Highest;
            cpuThread.Start();
        }

        SetResult("#c2410c", "TRIGGERED: Scenario #3 High CPU - Spawned " + threadCount + " tight-loop threads for 90 seconds. CPU will spike.");
    }

    // Scenario 4: Memory Leak - Pin 200MB of byte arrays
    private void ExecuteMemoryLeak()
    {
        WriteEventLog(9004, "Chaos Scenario #4: Memory Leak - Pinning 200MB of byte arrays.");

        int chunkSize = 1024 * 1024; // 1MB per chunk
        int chunkCount = 200;        // 200 chunks = 200MB
        int pinned = 0;

        lock (PinnedHandles)
        {
            for (int i = 0; i < chunkCount; i++)
            {
                byte[] buffer = new byte[chunkSize];
                // Fill with data to ensure physical memory allocation
                for (int j = 0; j < buffer.Length; j += 4096)
                {
                    buffer[j] = (byte)(i & 0xFF);
                }

                GCHandle handle = GCHandle.Alloc(buffer, GCHandleType.Pinned);
                PinnedHandles.Add(handle);
                LeakedBuffers.Add(buffer);
                pinned++;
            }
        }

        SetResult("#c2410c", "TRIGGERED: Scenario #4 Memory Leak - Pinned " + pinned + "MB of byte arrays. Working set will grow. Total pinned handles: " + PinnedHandles.Count);
    }

    // Scenario 5: Log Disk Full - Write 2GB to logs directory
    private void ExecuteLogDiskFull()
    {
        WriteEventLog(9005, "Chaos Scenario #5: Log Disk Full - Writing 2GB to C:\\inetpub\\logs\\chaos_fill.dat.");

        string filePath = @"C:\inetpub\logs\chaos_fill.dat";

        // Run in background thread so the page can return
        Thread fillThread = new Thread(() =>
        {
            try
            {
                byte[] buffer = new byte[1024 * 1024]; // 1MB buffer
                Random rng = new Random();
                rng.NextBytes(buffer);

                long totalBytes = 2L * 1024 * 1024 * 1024; // 2GB
                long written = 0;

                using (FileStream fs = new FileStream(filePath, FileMode.Create, FileAccess.Write, FileShare.None, buffer.Length))
                {
                    while (written < totalBytes)
                    {
                        int writeSize = (int)Math.Min(buffer.Length, totalBytes - written);
                        fs.Write(buffer, 0, writeSize);
                        written += writeSize;
                    }
                    fs.Flush();
                }
            }
            catch (Exception ex)
            {
                try
                {
                    WriteEventLog(9005, "Disk fill write stopped: " + ex.Message);
                }
                catch { }
            }
        });
        fillThread.IsBackground = true;
        fillThread.Start();

        SetResult("#a16207", "TRIGGERED: Scenario #5 Log Disk Full - Background thread writing 2GB to " + Server.HtmlEncode(filePath) + ". Drive C: will fill up.");
    }

    // Scenario 6: App Pool Identity Corruption
    private void ExecuteAppPoolIdentityCorruption()
    {
        WriteEventLog(9006, "Chaos Scenario #6: App Pool Identity Corruption - Setting invalid identity on DefaultAppPool.");

        using (ServerManager mgr = new ServerManager())
        {
            ApplicationPool pool = mgr.ApplicationPools["DefaultAppPool"];
            if (pool == null)
            {
                SetResult("#dc2626", "ERROR: DefaultAppPool not found.");
                return;
            }

            pool.ProcessModel.IdentityType = ProcessModelIdentityType.SpecificUser;
            pool.ProcessModel.UserName = @"INVALID\BadUser";
            pool.ProcessModel.Password = "ThisWillNotWork!";
            mgr.CommitChanges();
        }

        SetResult("#c2410c", "TRIGGERED: Scenario #6 App Pool Identity Corruption - DefaultAppPool identity set to INVALID\\BadUser. Pool will fail on next start.");
    }

    // Scenario 7: HTTP Binding Removal
    private void ExecuteHttpBindingRemoval()
    {
        WriteEventLog(9007, "Chaos Scenario #7: HTTP Binding Removal - Removing port 80 HTTP bindings from Default Web Site.");

        using (ServerManager mgr = new ServerManager())
        {
            Site site = mgr.Sites["Default Web Site"];
            if (site == null)
            {
                SetResult("#dc2626", "ERROR: Default Web Site not found.");
                return;
            }

            List<Binding> toRemove = new List<Binding>();
            foreach (Binding binding in site.Bindings)
            {
                if (binding.Protocol.Equals("http", StringComparison.OrdinalIgnoreCase))
                {
                    string endpoint = binding.EndPoint != null ? binding.EndPoint.Port.ToString() : "";
                    if (endpoint == "80" || binding.BindingInformation.Contains(":80:"))
                    {
                        toRemove.Add(binding);
                    }
                }
            }

            int removed = 0;
            foreach (Binding b in toRemove)
            {
                site.Bindings.Remove(b);
                removed++;
            }

            mgr.CommitChanges();
            SetResult("#b91c1c", "TRIGGERED: Scenario #7 HTTP Binding Removal - Removed " + removed + " port 80 HTTP binding(s) from Default Web Site. Site is now unreachable on HTTP.");
        }
    }

    // Scenario 8: Request Queue Flood - 300 threads sleeping 30s
    private void ExecuteRequestQueueFlood()
    {
        WriteEventLog(9008, "Chaos Scenario #8: Request Queue Flood - Spawning 300 threads with sleeping HTTP requests.");

        int threadCount = 300;
        int started = 0;
        string selfUrl = Request.Url.GetLeftPart(UriPartial.Authority) + "/";

        for (int i = 0; i < threadCount; i++)
        {
            Thread floodThread = new Thread(() =>
            {
                try
                {
                    HttpWebRequest req = (HttpWebRequest)WebRequest.Create(selfUrl);
                    req.Timeout = 60000;
                    req.Method = "GET";
                    // Hold the connection open
                    using (HttpWebResponse resp = (HttpWebResponse)req.GetResponse())
                    {
                        Thread.Sleep(30000); // Sleep 30 seconds while holding the response
                    }
                }
                catch
                {
                    // Expected - connections may fail as queue fills
                }
            });
            floodThread.IsBackground = true;
            floodThread.Start();
            started++;
        }

        SetResult("#c2410c", "TRIGGERED: Scenario #8 Request Queue Flood - Started " + started + " threads holding HTTP requests for 30 seconds. Queue will fill.");
    }

    // Scenario 9: Bad File Permissions - Remove IIS_IUSRS from wwwroot
    private void ExecuteBadFilePermissions()
    {
        WriteEventLog(9009, "Chaos Scenario #9: Bad File Permissions - Removing IIS_IUSRS access from C:\\inetpub\\wwwroot.");

        string wwwroot = @"C:\inetpub\wwwroot";
        DirectoryInfo dirInfo = new DirectoryInfo(wwwroot);
        DirectorySecurity dirSecurity = dirInfo.GetAccessControl();

        // Get IIS_IUSRS identity
        SecurityIdentifier iisUsersSid = new SecurityIdentifier("S-1-5-32-568"); // Well-known SID for IIS_IUSRS
        NTAccount iisUsersAccount;

        try
        {
            iisUsersAccount = (NTAccount)iisUsersSid.Translate(typeof(NTAccount));
        }
        catch
        {
            // Fallback: try by name
            iisUsersAccount = new NTAccount("BUILTIN", "IIS_IUSRS");
        }

        // Remove all access rules for IIS_IUSRS
        dirSecurity.RemoveAccessRuleAll(new FileSystemAccessRule(
            iisUsersAccount,
            FileSystemRights.ReadAndExecute,
            InheritanceFlags.ContainerInherit | InheritanceFlags.ObjectInherit,
            PropagationFlags.None,
            AccessControlType.Allow));

        // Also try purging by identity reference
        AuthorizationRuleCollection rules = dirSecurity.GetAccessRules(true, false, typeof(NTAccount));
        foreach (FileSystemAccessRule rule in rules)
        {
            if (rule.IdentityReference.Value.IndexOf("IIS_IUSRS", StringComparison.OrdinalIgnoreCase) >= 0)
            {
                dirSecurity.RemoveAccessRule(rule);
            }
        }

        dirInfo.SetAccessControl(dirSecurity);

        SetResult("#c2410c", "TRIGGERED: Scenario #9 Bad File Permissions - Removed IIS_IUSRS access from " + Server.HtmlEncode(wwwroot) + ". Requests will return 401/500.");
    }

    // Scenario 10: Worker Process Hang
    private void ExecuteWorkerProcessHang()
    {
        WriteEventLog(9010, "Chaos Scenario #10: Worker Process Hang - Setting hang flag. Next GET request to this page will hang indefinitely.");

        HangNextRequest = true;

        SetResult("#c2410c", "TRIGGERED: Scenario #10 Worker Process Hang - Flag set. The NEXT GET request to this page will call Thread.Sleep(MaxValue) and hang the worker process.");
    }

    // Helper: Write to Windows Event Log
    private void WriteEventLog(int eventId, string message)
    {
        string source = "IISChaosApp";

        try
        {
            if (!EventLog.SourceExists(source))
            {
                EventLog.CreateEventSource(source, "Application");
            }

            EventLog.WriteEntry(source, message, EventLogEntryType.Warning, eventId);
        }
        catch (Exception ex)
        {
            // If we can't write to event log (permissions), log to trace
            System.Diagnostics.Trace.TraceWarning("Failed to write event log (ID {0}): {1} | Original message: {2}", eventId, ex.Message, message);
        }
    }

    // Helper: Set the result label
    private void SetResult(string color, string message)
    {
        lblResult.Text = "<span style='color:" + color + "; font-size:13px;'>" +
                         "<strong>[" + DateTime.Now.ToString("HH:mm:ss") + "]</strong> " +
                         message + "</span>";
    }
}
