<%@ Page Language="C#" AutoEventWireup="true" CodeFile="default.aspx.cs" Inherits="ChaosPage" %>
<!DOCTYPE html>
<html lang="en">
<head runat="server">
    <title>Chaos Engineering Console</title>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <style>
        *, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }
        body { font-family: 'Segoe UI', -apple-system, BlinkMacSystemFont, sans-serif; background: #f0f2f5; color: #1a1a2e; line-height: 1.5; min-height: 100vh; }

        /* ── Header ──────────────────────────────────────────── */
        .header { background: #ffffff; border-bottom: 1px solid #e0e0e0; padding: 0 40px; display: flex; align-items: center; height: 56px; box-shadow: 0 1px 3px rgba(0,0,0,0.06); }
        .header-logo { display: flex; align-items: center; gap: 12px; }
        .header-logo svg { width: 28px; height: 28px; }
        .header-title { font-size: 17px; font-weight: 600; color: #1a1a2e; }
        .header-subtitle { font-size: 12px; color: #6b7280; margin-left: 12px; padding-left: 12px; border-left: 1px solid #e0e0e0; }
        .header-right { margin-left: auto; display: flex; align-items: center; gap: 16px; }

        /* ── Container ───────────────────────────────────────── */
        .container { max-width: 1200px; margin: 0 auto; padding: 28px 40px; }

        /* ── Notice ──────────────────────────────────────────── */
        .notice { background: #fffbeb; border: 1px solid #fbbf24; border-radius: 8px; padding: 12px 20px; margin-bottom: 24px; display: flex; align-items: center; gap: 10px; font-size: 13px; color: #92400e; }
        .notice svg { flex-shrink: 0; width: 18px; height: 18px; color: #d97706; }

        /* ── Status strip ────────────────────────────────────── */
        .status-strip { display: grid; grid-template-columns: repeat(4, 1fr); gap: 16px; margin-bottom: 28px; }
        .status-card { background: #ffffff; border: 1px solid #e5e7eb; border-radius: 10px; padding: 18px 20px; }
        .status-label { font-size: 11px; font-weight: 600; text-transform: uppercase; letter-spacing: 0.6px; color: #9ca3af; margin-bottom: 6px; }
        .status-value { font-size: 18px; font-weight: 600; color: #1a1a2e; }

        /* ── Section titles ───────────────────────────────────── */
        .section-header { display: flex; align-items: center; gap: 10px; margin-bottom: 16px; }
        .section-title { font-size: 15px; font-weight: 600; color: #1a1a2e; }
        .section-badge { font-size: 11px; font-weight: 600; padding: 2px 10px; border-radius: 12px; }
        .badge-det { background: #ede9fe; color: #6d28d9; }
        .badge-ai { background: #dbeafe; color: #1d4ed8; }
        .section-desc { font-size: 12px; color: #9ca3af; margin-left: auto; }

        /* ── Scenario table ───────────────────────────────────── */
        .scenario-table { width: 100%; background: #ffffff; border: 1px solid #e5e7eb; border-radius: 10px; overflow: hidden; margin-bottom: 28px; }
        .scenario-table table { width: 100%; border-collapse: collapse; }
        .scenario-table th { text-align: left; font-size: 11px; font-weight: 600; text-transform: uppercase; letter-spacing: 0.5px; color: #9ca3af; padding: 12px 20px; background: #fafafa; border-bottom: 1px solid #e5e7eb; }
        .scenario-table td { padding: 16px 20px; border-bottom: 1px solid #f3f4f6; font-size: 13px; color: #4b5563; vertical-align: middle; }
        .scenario-table tr:last-child td { border-bottom: none; }
        .scenario-table tr:hover td { background: #f9fafb; }

        .sc-name { font-size: 14px; font-weight: 600; color: #1a1a2e; display: block; }
        .sc-desc { font-size: 12px; color: #9ca3af; margin-top: 2px; display: block; }

        /* ── Severity pills ───────────────────────────────────── */
        .sev { display: inline-block; font-size: 11px; font-weight: 600; padding: 3px 10px; border-radius: 12px; letter-spacing: 0.3px; }
        .sev-critical { background: #fef2f2; color: #dc2626; }
        .sev-high     { background: #fff7ed; color: #ea580c; }
        .sev-medium   { background: #fffbeb; color: #d97706; }

        /* ── Confirm + trigger ────────────────────────────────── */
        .confirm-row { display: flex; align-items: center; gap: 8px; }
        .confirm-row input[type="checkbox"] { width: 16px; height: 16px; accent-color: #6366f1; cursor: pointer; }
        .confirm-row label { font-size: 12px; color: #9ca3af; cursor: pointer; user-select: none; }

        .trigger-btn { background: #ffffff; color: #dc2626; border: 1px solid #fecaca; border-radius: 6px; padding: 7px 16px; font-size: 12px; font-weight: 600; cursor: pointer; transition: all 0.15s ease; }
        .trigger-btn:hover:not(:disabled) { background: #fef2f2; border-color: #dc2626; }
        .trigger-btn:disabled { opacity: 0.35; cursor: not-allowed; }
        .trigger-btn:active:not(:disabled) { transform: scale(0.97); }

        /* ── Result panel ─────────────────────────────────────── */
        .result-panel { background: #ffffff; border: 1px solid #e5e7eb; border-radius: 10px; padding: 20px 24px; margin-bottom: 28px; }
        .result-label { font-size: 11px; font-weight: 600; text-transform: uppercase; letter-spacing: 0.6px; color: #9ca3af; margin-bottom: 10px; }
        .result-content { font-size: 13px; color: #6b7280; min-height: 20px; }

        /* ── Footer ───────────────────────────────────────────── */
        .footer { text-align: center; padding: 20px; font-size: 11px; color: #c0c0c0; }

        /* ── Responsive ───────────────────────────────────────── */
        @media (max-width: 900px) {
            .status-strip { grid-template-columns: repeat(2, 1fr); }
            .container { padding: 20px; }
            .header { padding: 0 20px; }
        }
    </style>
</head>
<body>

    <!-- Header -->
    <div class="header">
        <div class="header-logo">
            <svg viewBox="0 0 24 24" fill="none" stroke="#6366f1" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                <path d="M10.29 3.86L1.82 18a2 2 0 001.71 3h16.94a2 2 0 001.71-3L13.71 3.86a2 2 0 00-3.42 0z"/>
                <line x1="12" y1="9" x2="12" y2="13"/><line x1="12" y1="17" x2="12.01" y2="17"/>
            </svg>
            <span class="header-title">Chaos Engineering Console</span>
        </div>
        <span class="header-subtitle">IIS Auto-Healing Validation</span>
        <div class="header-right">
            <span style="font-size:12px; color:#9ca3af;">
                <asp:Label ID="lblTime" runat="server" Text="--" />
            </span>
        </div>
    </div>

    <div class="container">

        <!-- Notice -->
        <div class="notice">
            <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                <circle cx="12" cy="12" r="10"/><line x1="12" y1="8" x2="12" y2="12"/><line x1="12" y1="16" x2="12.01" y2="16"/>
            </svg>
            Actions on this page inject real faults into IIS. Each scenario triggers an alert that the auto-healing pipeline will detect, remediate, and log. Wait for recovery between scenarios.
        </div>

        <!-- System Status -->
        <div class="status-strip">
            <div class="status-card">
                <div class="status-label">Hostname</div>
                <div class="status-value"><asp:Label ID="lblHostname" runat="server" Text="--" /></div>
            </div>
            <div class="status-card">
                <div class="status-label">W3SVC Service</div>
                <div class="status-value"><asp:Label ID="lblW3svc" runat="server" Text="--" /></div>
            </div>
            <div class="status-card">
                <div class="status-label">DefaultAppPool</div>
                <div class="status-value"><asp:Label ID="lblAppPool" runat="server" Text="--" /></div>
            </div>
            <div class="status-card">
                <div class="status-label">Healing Path</div>
                <div class="status-value" style="font-size:13px; color:#6b7280;">Deterministic + AI</div>
            </div>
        </div>

        <!-- Deterministic Path Scenarios -->
        <div class="section-header">
            <span class="section-title">Deterministic Path</span>
            <span class="section-badge badge-det">No LLM</span>
            <span class="section-desc">Known fixes executed immediately via rule-based routing</span>
        </div>
        <div class="scenario-table">
            <table>
                <thead>
                    <tr>
                        <th style="width:40px;">#</th>
                        <th>Scenario</th>
                        <th style="width:80px;">Severity</th>
                        <th style="width:90px;">Detection</th>
                        <th style="width:200px;">Confirm</th>
                        <th style="width:90px;"></th>
                    </tr>
                </thead>
                <tbody>
                    <!-- 1 -->
                    <tr>
                        <td style="font-weight:600; color:#6366f1;">1</td>
                        <td>
                            <span class="sc-name">App Pool Crash</span>
                            <span class="sc-desc">Kills all w3wp.exe processes, causing immediate 503 errors</span>
                        </td>
                        <td><span class="sev sev-critical">Critical</span></td>
                        <td style="font-size:12px;">&lt; 5 sec</td>
                        <td>
                            <form method="post" action="default.aspx" style="margin:0;" id="form1">
                                <input type="hidden" name="scenario" value="1" />
                                <input type="hidden" name="confirmed" id="confirmed1" value="" />
                                <div class="confirm-row">
                                    <input type="checkbox" id="chk1" />
                                    <label for="chk1">I confirm</label>
                                </div>
                        </td>
                        <td><button type="submit" id="btn1" disabled class="trigger-btn">Inject</button></form></td>
                    </tr>
                    <!-- 2 -->
                    <tr>
                        <td style="font-weight:600; color:#6366f1;">2</td>
                        <td>
                            <span class="sc-name">W3SVC Stop</span>
                            <span class="sc-desc">Stops the World Wide Web Publishing Service entirely</span>
                        </td>
                        <td><span class="sev sev-critical">Critical</span></td>
                        <td style="font-size:12px;">&lt; 10 sec</td>
                        <td>
                            <form method="post" action="default.aspx" style="margin:0;" id="form2">
                                <input type="hidden" name="scenario" value="2" />
                                <input type="hidden" name="confirmed" id="confirmed2" value="" />
                                <div class="confirm-row">
                                    <input type="checkbox" id="chk2" />
                                    <label for="chk2">I confirm</label>
                                </div>
                        </td>
                        <td><button type="submit" id="btn2" disabled class="trigger-btn">Inject</button></form></td>
                    </tr>
                    <!-- 5 -->
                    <tr>
                        <td style="font-weight:600; color:#6366f1;">5</td>
                        <td>
                            <span class="sc-name">Log Disk Full</span>
                            <span class="sc-desc">Writes a 2 GB file to IIS logs, filling the C: drive</span>
                        </td>
                        <td><span class="sev sev-medium">Medium</span></td>
                        <td style="font-size:12px;">&lt; 2 min</td>
                        <td>
                            <form method="post" action="default.aspx" style="margin:0;" id="form5">
                                <input type="hidden" name="scenario" value="5" />
                                <input type="hidden" name="confirmed" id="confirmed5" value="" />
                                <div class="confirm-row">
                                    <input type="checkbox" id="chk5" />
                                    <label for="chk5">I confirm</label>
                                </div>
                        </td>
                        <td><button type="submit" id="btn5" disabled class="trigger-btn">Inject</button></form></td>
                    </tr>
                    <!-- 6 -->
                    <tr>
                        <td style="font-weight:600; color:#6366f1;">6</td>
                        <td>
                            <span class="sc-name">App Pool Identity Corruption</span>
                            <span class="sc-desc">Sets DefaultAppPool identity to an invalid user account</span>
                        </td>
                        <td><span class="sev sev-high">High</span></td>
                        <td style="font-size:12px;">&lt; 15 sec</td>
                        <td>
                            <form method="post" action="default.aspx" style="margin:0;" id="form6">
                                <input type="hidden" name="scenario" value="6" />
                                <input type="hidden" name="confirmed" id="confirmed6" value="" />
                                <div class="confirm-row">
                                    <input type="checkbox" id="chk6" />
                                    <label for="chk6">I confirm</label>
                                </div>
                        </td>
                        <td><button type="submit" id="btn6" disabled class="trigger-btn">Inject</button></form></td>
                    </tr>
                    <!-- 7 -->
                    <tr>
                        <td style="font-weight:600; color:#6366f1;">7</td>
                        <td>
                            <span class="sc-name">HTTP Binding Removal</span>
                            <span class="sc-desc">Removes all port 80 HTTP bindings from Default Web Site</span>
                        </td>
                        <td><span class="sev sev-critical">Critical</span></td>
                        <td style="font-size:12px;">&lt; 10 sec</td>
                        <td>
                            <form method="post" action="default.aspx" style="margin:0;" id="form7">
                                <input type="hidden" name="scenario" value="7" />
                                <input type="hidden" name="confirmed" id="confirmed7" value="" />
                                <div class="confirm-row">
                                    <input type="checkbox" id="chk7" />
                                    <label for="chk7">I confirm</label>
                                </div>
                        </td>
                        <td><button type="submit" id="btn7" disabled class="trigger-btn">Inject</button></form></td>
                    </tr>
                    <!-- 9 -->
                    <tr>
                        <td style="font-weight:600; color:#6366f1;">9</td>
                        <td>
                            <span class="sc-name">Bad File Permissions</span>
                            <span class="sc-desc">Removes IIS_IUSRS read access from C:\inetpub\wwwroot</span>
                        </td>
                        <td><span class="sev sev-high">High</span></td>
                        <td style="font-size:12px;">&lt; 10 sec</td>
                        <td>
                            <form method="post" action="default.aspx" style="margin:0;" id="form9">
                                <input type="hidden" name="scenario" value="9" />
                                <input type="hidden" name="confirmed" id="confirmed9" value="" />
                                <div class="confirm-row">
                                    <input type="checkbox" id="chk9" />
                                    <label for="chk9">I confirm</label>
                                </div>
                        </td>
                        <td><button type="submit" id="btn9" disabled class="trigger-btn">Inject</button></form></td>
                    </tr>
                </tbody>
            </table>
        </div>

        <!-- AI Path Scenarios -->
        <div class="section-header">
            <span class="section-title">AI Path</span>
            <span class="section-badge badge-ai">LLM Required</span>
            <span class="section-desc">Complex issues requiring telemetry analysis and AI reasoning</span>
        </div>
        <div class="scenario-table">
            <table>
                <thead>
                    <tr>
                        <th style="width:40px;">#</th>
                        <th>Scenario</th>
                        <th style="width:80px;">Severity</th>
                        <th style="width:90px;">Detection</th>
                        <th style="width:200px;">Confirm</th>
                        <th style="width:90px;"></th>
                    </tr>
                </thead>
                <tbody>
                    <!-- 3 -->
                    <tr>
                        <td style="font-weight:600; color:#3b82f6;">3</td>
                        <td>
                            <span class="sc-name">High CPU</span>
                            <span class="sc-desc">Spawns tight Math.Sqrt loops on all cores for 90 seconds</span>
                        </td>
                        <td><span class="sev sev-high">High</span></td>
                        <td style="font-size:12px;">~ 5 min</td>
                        <td>
                            <form method="post" action="default.aspx" style="margin:0;" id="form3">
                                <input type="hidden" name="scenario" value="3" />
                                <input type="hidden" name="confirmed" id="confirmed3" value="" />
                                <div class="confirm-row">
                                    <input type="checkbox" id="chk3" />
                                    <label for="chk3">I confirm</label>
                                </div>
                        </td>
                        <td><button type="submit" id="btn3" disabled class="trigger-btn">Inject</button></form></td>
                    </tr>
                    <!-- 4 -->
                    <tr>
                        <td style="font-weight:600; color:#3b82f6;">4</td>
                        <td>
                            <span class="sc-name">Memory Leak</span>
                            <span class="sc-desc">Pins 200 MB of byte arrays via GCHandle, preventing garbage collection</span>
                        </td>
                        <td><span class="sev sev-high">High</span></td>
                        <td style="font-size:12px;">~ 5 min</td>
                        <td>
                            <form method="post" action="default.aspx" style="margin:0;" id="form4">
                                <input type="hidden" name="scenario" value="4" />
                                <input type="hidden" name="confirmed" id="confirmed4" value="" />
                                <div class="confirm-row">
                                    <input type="checkbox" id="chk4" />
                                    <label for="chk4">I confirm</label>
                                </div>
                        </td>
                        <td><button type="submit" id="btn4" disabled class="trigger-btn">Inject</button></form></td>
                    </tr>
                    <!-- 8 -->
                    <tr>
                        <td style="font-weight:600; color:#3b82f6;">8</td>
                        <td>
                            <span class="sc-name">Request Queue Flood</span>
                            <span class="sc-desc">Spawns 300 threads each holding an HTTP connection open for 30 seconds</span>
                        </td>
                        <td><span class="sev sev-high">High</span></td>
                        <td style="font-size:12px;">~ 2 min</td>
                        <td>
                            <form method="post" action="default.aspx" style="margin:0;" id="form8">
                                <input type="hidden" name="scenario" value="8" />
                                <input type="hidden" name="confirmed" id="confirmed8" value="" />
                                <div class="confirm-row">
                                    <input type="checkbox" id="chk8" />
                                    <label for="chk8">I confirm</label>
                                </div>
                        </td>
                        <td><button type="submit" id="btn8" disabled class="trigger-btn">Inject</button></form></td>
                    </tr>
                    <!-- 10 -->
                    <tr>
                        <td style="font-weight:600; color:#3b82f6;">10</td>
                        <td>
                            <span class="sc-name">Worker Process Hang</span>
                            <span class="sc-desc">Next GET request hangs indefinitely via Thread.Sleep(MaxValue)</span>
                        </td>
                        <td><span class="sev sev-high">High</span></td>
                        <td style="font-size:12px;">~ 5 min</td>
                        <td>
                            <form method="post" action="default.aspx" style="margin:0;" id="form10">
                                <input type="hidden" name="scenario" value="10" />
                                <input type="hidden" name="confirmed" id="confirmed10" value="" />
                                <div class="confirm-row">
                                    <input type="checkbox" id="chk10" />
                                    <label for="chk10">I confirm</label>
                                </div>
                        </td>
                        <td><button type="submit" id="btn10" disabled class="trigger-btn">Inject</button></form></td>
                    </tr>
                </tbody>
            </table>
        </div>

        <!-- Result Panel -->
        <div class="result-panel">
            <div class="result-label">Activity Log</div>
            <div class="result-content">
                <asp:Label ID="lblResult" runat="server" Text="No scenario triggered yet. Check a confirmation box and click Inject to begin." />
            </div>
        </div>

        <!-- Footer -->
        <div class="footer">IIS Auto-Healing System &middot; Chaos Engineering Console</div>

    </div>

    <script type="text/javascript">
        document.addEventListener('DOMContentLoaded', function () {
            var ids = [1,2,3,4,5,6,7,8,9,10];
            ids.forEach(function (n) {
                var chk = document.getElementById('chk' + n);
                var btn = document.getElementById('btn' + n);
                var conf = document.getElementById('confirmed' + n);
                if (chk && btn) {
                    chk.addEventListener('change', function () {
                        btn.disabled = !this.checked;
                        if (conf) conf.value = this.checked ? 'yes' : '';
                    });
                }
            });
        });
    </script>

</body>
</html>
