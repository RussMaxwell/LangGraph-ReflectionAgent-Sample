<%@ Page Language="C#" AutoEventWireup="true" CodeFile="default.aspx.cs" Inherits="DefaultPage" %>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Contoso Infrastructure Services - Enterprise IIS Hosting &amp; Management</title>
</head>
<body style="margin:0; padding:0; font-family:'Segoe UI',Tahoma,Geneva,Verdana,sans-serif; color:#333; background:#f8f9fa; line-height:1.6;">

    <form id="form1" runat="server">

    <!-- Navigation -->
    <nav style="background:#1a365d; padding:0 40px; display:flex; align-items:center; justify-content:space-between; height:64px; position:sticky; top:0; z-index:1000; box-shadow:0 2px 8px rgba(0,0,0,0.15);">
        <div style="display:flex; align-items:center; gap:10px;">
            <span style="color:#4da6ff; font-size:28px; font-weight:700;">&#9670;</span>
            <span style="color:#ffffff; font-size:20px; font-weight:600; letter-spacing:-0.5px;">Contoso Infrastructure Services</span>
        </div>
        <div style="display:flex; gap:8px;">
            <a href="#home" style="color:#cbd5e0; text-decoration:none; padding:8px 16px; border-radius:4px; font-size:14px; font-weight:500; transition:color 0.2s;">Home</a>
            <a href="#services" style="color:#cbd5e0; text-decoration:none; padding:8px 16px; border-radius:4px; font-size:14px; font-weight:500;">Services</a>
            <a href="#about" style="color:#cbd5e0; text-decoration:none; padding:8px 16px; border-radius:4px; font-size:14px; font-weight:500;">About</a>
            <a href="#blog" style="color:#cbd5e0; text-decoration:none; padding:8px 16px; border-radius:4px; font-size:14px; font-weight:500;">Blog</a>
            <a href="#contact" style="color:#cbd5e0; text-decoration:none; padding:8px 16px; border-radius:4px; font-size:14px; font-weight:500;">Contact</a>
        </div>
    </nav>

    <!-- Hero Section -->
    <section id="home" style="background:linear-gradient(135deg, #1a365d 0%, #2a4a7f 50%, #1a365d 100%); padding:100px 40px; text-align:center;">
        <h1 style="color:#ffffff; font-size:48px; font-weight:700; margin:0 0 20px 0; letter-spacing:-1px;">Enterprise IIS Hosting &amp; Management</h1>
        <p style="color:#a0c4e8; font-size:20px; margin:0 auto 40px auto; max-width:700px; line-height:1.7;">
            Reliable, secure, and high-performance Windows Server infrastructure managed by certified engineers.
            We keep your applications running so you can focus on your business.
        </p>
        <a href="#contact" style="display:inline-block; background:#4da6ff; color:#ffffff; text-decoration:none; padding:16px 40px; border-radius:6px; font-size:16px; font-weight:600; letter-spacing:0.3px; box-shadow:0 4px 14px rgba(77,166,255,0.4);">Get a Free Assessment</a>
    </section>

    <!-- Services Section -->
    <section id="services" style="padding:80px 40px; max-width:1200px; margin:0 auto;">
        <h2 style="text-align:center; font-size:36px; color:#1a365d; margin:0 0 12px 0;">Our Services</h2>
        <p style="text-align:center; color:#6b7c93; font-size:16px; margin:0 0 50px 0;">Comprehensive infrastructure solutions tailored to enterprise needs</p>
        <div style="display:grid; grid-template-columns:repeat(3, 1fr); gap:30px;">

            <!-- Card 1 -->
            <div style="background:#ffffff; border-radius:10px; padding:36px 28px; box-shadow:0 2px 12px rgba(0,0,0,0.06); border:1px solid #e8ecf1; text-align:center;">
                <div style="font-size:48px; margin-bottom:16px;">&#9881;</div>
                <h3 style="font-size:20px; color:#1a365d; margin:0 0 12px 0;">Managed IIS Hosting</h3>
                <p style="color:#6b7c93; font-size:14px; margin:0 0 16px 0;">Fully managed IIS environments with proactive patching, configuration management, and dedicated support engineers on call around the clock.</p>
                <ul style="list-style:none; padding:0; margin:0; text-align:left;">
                    <li style="color:#4a5568; font-size:13px; padding:4px 0; border-bottom:1px solid #f0f0f0;">&#10003; Application pool management</li>
                    <li style="color:#4a5568; font-size:13px; padding:4px 0; border-bottom:1px solid #f0f0f0;">&#10003; SSL certificate lifecycle</li>
                    <li style="color:#4a5568; font-size:13px; padding:4px 0;">&#10003; Automated deployments</li>
                </ul>
            </div>

            <!-- Card 2 -->
            <div style="background:#ffffff; border-radius:10px; padding:36px 28px; box-shadow:0 2px 12px rgba(0,0,0,0.06); border:1px solid #e8ecf1; text-align:center;">
                <div style="font-size:48px; margin-bottom:16px;">&#9729;</div>
                <h3 style="font-size:20px; color:#1a365d; margin:0 0 12px 0;">Cloud Migration</h3>
                <p style="color:#6b7c93; font-size:14px; margin:0 0 16px 0;">Seamless migration of on-premises IIS workloads to Azure with minimal downtime. Our proven methodology reduces risk and accelerates time-to-cloud.</p>
                <ul style="list-style:none; padding:0; margin:0; text-align:left;">
                    <li style="color:#4a5568; font-size:13px; padding:4px 0; border-bottom:1px solid #f0f0f0;">&#10003; Azure App Service migration</li>
                    <li style="color:#4a5568; font-size:13px; padding:4px 0; border-bottom:1px solid #f0f0f0;">&#10003; Hybrid connectivity setup</li>
                    <li style="color:#4a5568; font-size:13px; padding:4px 0;">&#10003; Cost optimization analysis</li>
                </ul>
            </div>

            <!-- Card 3 -->
            <div style="background:#ffffff; border-radius:10px; padding:36px 28px; box-shadow:0 2px 12px rgba(0,0,0,0.06); border:1px solid #e8ecf1; text-align:center;">
                <div style="font-size:48px; margin-bottom:16px;">&#9888;</div>
                <h3 style="font-size:20px; color:#1a365d; margin:0 0 12px 0;">24/7 Monitoring</h3>
                <p style="color:#6b7c93; font-size:14px; margin:0 0 16px 0;">Real-time health monitoring with intelligent alerting. Our NOC team responds to incidents in under five minutes, ensuring maximum availability for your users.</p>
                <ul style="list-style:none; padding:0; margin:0; text-align:left;">
                    <li style="color:#4a5568; font-size:13px; padding:4px 0; border-bottom:1px solid #f0f0f0;">&#10003; Synthetic transaction testing</li>
                    <li style="color:#4a5568; font-size:13px; padding:4px 0; border-bottom:1px solid #f0f0f0;">&#10003; Custom dashboard &amp; reports</li>
                    <li style="color:#4a5568; font-size:13px; padding:4px 0;">&#10003; Escalation workflows</li>
                </ul>
            </div>

            <!-- Card 4 -->
            <div style="background:#ffffff; border-radius:10px; padding:36px 28px; box-shadow:0 2px 12px rgba(0,0,0,0.06); border:1px solid #e8ecf1; text-align:center;">
                <div style="font-size:48px; margin-bottom:16px;">&#128274;</div>
                <h3 style="font-size:20px; color:#1a365d; margin:0 0 12px 0;">Security Hardening</h3>
                <p style="color:#6b7c93; font-size:14px; margin:0 0 16px 0;">Comprehensive security audits and hardening based on CIS benchmarks. We lock down your servers against OWASP Top 10 and emerging attack vectors.</p>
                <ul style="list-style:none; padding:0; margin:0; text-align:left;">
                    <li style="color:#4a5568; font-size:13px; padding:4px 0; border-bottom:1px solid #f0f0f0;">&#10003; WAF configuration</li>
                    <li style="color:#4a5568; font-size:13px; padding:4px 0; border-bottom:1px solid #f0f0f0;">&#10003; Vulnerability scanning</li>
                    <li style="color:#4a5568; font-size:13px; padding:4px 0;">&#10003; Compliance reporting</li>
                </ul>
            </div>

            <!-- Card 5 -->
            <div style="background:#ffffff; border-radius:10px; padding:36px 28px; box-shadow:0 2px 12px rgba(0,0,0,0.06); border:1px solid #e8ecf1; text-align:center;">
                <div style="font-size:48px; margin-bottom:16px;">&#128260;</div>
                <h3 style="font-size:20px; color:#1a365d; margin:0 0 12px 0;">Disaster Recovery</h3>
                <p style="color:#6b7c93; font-size:14px; margin:0 0 16px 0;">Geo-redundant backup and failover solutions that guarantee rapid recovery. Tested quarterly with documented runbooks so your team is always prepared.</p>
                <ul style="list-style:none; padding:0; margin:0; text-align:left;">
                    <li style="color:#4a5568; font-size:13px; padding:4px 0; border-bottom:1px solid #f0f0f0;">&#10003; RPO under 15 minutes</li>
                    <li style="color:#4a5568; font-size:13px; padding:4px 0; border-bottom:1px solid #f0f0f0;">&#10003; Automated failover</li>
                    <li style="color:#4a5568; font-size:13px; padding:4px 0;">&#10003; DR drill coordination</li>
                </ul>
            </div>

            <!-- Card 6 -->
            <div style="background:#ffffff; border-radius:10px; padding:36px 28px; box-shadow:0 2px 12px rgba(0,0,0,0.06); border:1px solid #e8ecf1; text-align:center;">
                <div style="font-size:48px; margin-bottom:16px;">&#9889;</div>
                <h3 style="font-size:20px; color:#1a365d; margin:0 0 12px 0;">Performance Tuning</h3>
                <p style="color:#6b7c93; font-size:14px; margin:0 0 16px 0;">Deep-dive performance analysis using ETW traces, perfmon counters, and load testing. We identify bottlenecks and deliver measurable throughput gains.</p>
                <ul style="list-style:none; padding:0; margin:0; text-align:left;">
                    <li style="color:#4a5568; font-size:13px; padding:4px 0; border-bottom:1px solid #f0f0f0;">&#10003; Output caching strategy</li>
                    <li style="color:#4a5568; font-size:13px; padding:4px 0; border-bottom:1px solid #f0f0f0;">&#10003; Connection pool tuning</li>
                    <li style="color:#4a5568; font-size:13px; padding:4px 0;">&#10003; Load test &amp; capacity plan</li>
                </ul>
            </div>

        </div>
    </section>

    <!-- Metrics Bar -->
    <section style="background:#1a365d; padding:60px 40px;">
        <div style="max-width:1100px; margin:0 auto; display:grid; grid-template-columns:repeat(4, 1fr); gap:20px; text-align:center;">
            <div>
                <div class="counter" style="font-size:42px; font-weight:700; color:#4da6ff; animation:fadeInUp 1s ease-out;">99.99%</div>
                <div style="color:#a0c4e8; font-size:14px; margin-top:6px; text-transform:uppercase; letter-spacing:1px;">Uptime SLA</div>
            </div>
            <div>
                <div class="counter" style="font-size:42px; font-weight:700; color:#4da6ff; animation:fadeInUp 1.2s ease-out;">500+</div>
                <div style="color:#a0c4e8; font-size:14px; margin-top:6px; text-transform:uppercase; letter-spacing:1px;">Enterprise Clients</div>
            </div>
            <div>
                <div class="counter" style="font-size:42px; font-weight:700; color:#4da6ff; animation:fadeInUp 1.4s ease-out;">15 Years</div>
                <div style="color:#a0c4e8; font-size:14px; margin-top:6px; text-transform:uppercase; letter-spacing:1px;">Industry Experience</div>
            </div>
            <div>
                <div class="counter" style="font-size:42px; font-weight:700; color:#4da6ff; animation:fadeInUp 1.6s ease-out;">24/7</div>
                <div style="color:#a0c4e8; font-size:14px; margin-top:6px; text-transform:uppercase; letter-spacing:1px;">Support Coverage</div>
            </div>
        </div>
    </section>

    <style>
        @keyframes fadeInUp {
            from { opacity: 0; transform: translateY(20px); }
            to { opacity: 1; transform: translateY(0); }
        }
    </style>

    <!-- Blog Preview -->
    <section id="blog" style="padding:80px 40px; max-width:1200px; margin:0 auto;">
        <h2 style="text-align:center; font-size:36px; color:#1a365d; margin:0 0 12px 0;">From the Blog</h2>
        <p style="text-align:center; color:#6b7c93; font-size:16px; margin:0 0 50px 0;">Insights and best practices from our engineering team</p>
        <div style="display:grid; grid-template-columns:repeat(3, 1fr); gap:30px;">

            <div style="background:#ffffff; border-radius:10px; overflow:hidden; box-shadow:0 2px 12px rgba(0,0,0,0.06); border:1px solid #e8ecf1;">
                <div style="background:#2a4a7f; height:8px;"></div>
                <div style="padding:28px;">
                    <span style="display:inline-block; background:#e6f0ff; color:#2a4a7f; font-size:11px; font-weight:600; padding:4px 10px; border-radius:20px; margin-bottom:12px;">IIS Configuration</span>
                    <h3 style="font-size:18px; color:#1a365d; margin:0 0 12px 0;">Optimizing Application Pool Recycling for Zero-Downtime Deployments</h3>
                    <p style="color:#6b7c93; font-size:14px; line-height:1.7; margin:0 0 16px 0;">
                        Application pool recycling is one of the most misunderstood features in IIS. When configured incorrectly, it leads to dropped connections and cold-start latency spikes.
                        In this guide we walk through overlapped recycling, warm-up modules, and the exact settings our team uses to achieve seamless deployments across hundreds of production servers.
                    </p>
                    <div style="display:flex; justify-content:space-between; align-items:center; border-top:1px solid #f0f0f0; padding-top:14px;">
                        <span style="color:#999; font-size:12px;">James Whitfield &middot; Mar 12, 2026</span>
                        <a href="#" style="color:#4da6ff; font-size:13px; font-weight:600; text-decoration:none;">Read more &#8594;</a>
                    </div>
                </div>
            </div>

            <div style="background:#ffffff; border-radius:10px; overflow:hidden; box-shadow:0 2px 12px rgba(0,0,0,0.06); border:1px solid #e8ecf1;">
                <div style="background:#2a4a7f; height:8px;"></div>
                <div style="padding:28px;">
                    <span style="display:inline-block; background:#e6f0ff; color:#2a4a7f; font-size:11px; font-weight:600; padding:4px 10px; border-radius:20px; margin-bottom:12px;">Security</span>
                    <h3 style="font-size:18px; color:#1a365d; margin:0 0 12px 0;">Hardening Windows Server 2025: A Practical CIS Benchmark Walkthrough</h3>
                    <p style="color:#6b7c93; font-size:14px; line-height:1.7; margin:0 0 16px 0;">
                        The CIS benchmark for Windows Server 2025 introduces several new recommendations around Credential Guard and virtualization-based security.
                        We break down each control into actionable PowerShell scripts and Group Policy settings that you can apply today. Our compliance team tested every recommendation against real workloads to flag compatibility issues before they reach your environment.
                    </p>
                    <div style="display:flex; justify-content:space-between; align-items:center; border-top:1px solid #f0f0f0; padding-top:14px;">
                        <span style="color:#999; font-size:12px;">Sarah Nakamura &middot; Feb 28, 2026</span>
                        <a href="#" style="color:#4da6ff; font-size:13px; font-weight:600; text-decoration:none;">Read more &#8594;</a>
                    </div>
                </div>
            </div>

            <div style="background:#ffffff; border-radius:10px; overflow:hidden; box-shadow:0 2px 12px rgba(0,0,0,0.06); border:1px solid #e8ecf1;">
                <div style="background:#2a4a7f; height:8px;"></div>
                <div style="padding:28px;">
                    <span style="display:inline-block; background:#e6f0ff; color:#2a4a7f; font-size:11px; font-weight:600; padding:4px 10px; border-radius:20px; margin-bottom:12px;">Performance</span>
                    <h3 style="font-size:18px; color:#1a365d; margin:0 0 12px 0;">Diagnosing High CPU in ASP.NET Apps with ETW and PerfView</h3>
                    <p style="color:#6b7c93; font-size:14px; line-height:1.7; margin:0 0 16px 0;">
                        High CPU on a production web server is a situation every ops engineer dreads. Traditional perfmon counters only tell you half the story.
                        ETW traces captured with PerfView reveal the exact call stacks consuming cycles. In this post we demonstrate a systematic approach to capturing, analyzing, and resolving a real-world CPU spike caused by excessive regex backtracking in a validation library.
                    </p>
                    <div style="display:flex; justify-content:space-between; align-items:center; border-top:1px solid #f0f0f0; padding-top:14px;">
                        <span style="color:#999; font-size:12px;">David Okonkwo &middot; Feb 10, 2026</span>
                        <a href="#" style="color:#4da6ff; font-size:13px; font-weight:600; text-decoration:none;">Read more &#8594;</a>
                    </div>
                </div>
            </div>

        </div>
    </section>

    <!-- Testimonials -->
    <section style="background:#f0f5fa; padding:80px 40px;">
        <div style="max-width:1200px; margin:0 auto;">
            <h2 style="text-align:center; font-size:36px; color:#1a365d; margin:0 0 12px 0;">What Our Clients Say</h2>
            <p style="text-align:center; color:#6b7c93; font-size:16px; margin:0 0 50px 0;">Trusted by enterprises across North America</p>
            <div style="display:grid; grid-template-columns:repeat(3, 1fr); gap:30px;">

                <div style="background:#ffffff; border-radius:10px; padding:32px; box-shadow:0 2px 12px rgba(0,0,0,0.06); border:1px solid #e8ecf1;">
                    <div style="color:#f5a623; font-size:18px; margin-bottom:16px;">&#9733;&#9733;&#9733;&#9733;&#9733;</div>
                    <p style="color:#4a5568; font-size:14px; line-height:1.7; margin:0 0 20px 0; font-style:italic;">
                        "Contoso migrated our entire e-commerce platform from on-prem IIS to Azure App Service in under three weeks. We saw a 40% reduction in hosting costs and zero unplanned downtime during the transition. Their team's depth of knowledge is unmatched."
                    </p>
                    <div style="border-top:1px solid #f0f0f0; padding-top:16px;">
                        <div style="font-weight:600; color:#1a365d; font-size:14px;">Rachel Torres</div>
                        <div style="color:#999; font-size:12px;">VP of Engineering, Meridian Retail Group</div>
                    </div>
                </div>

                <div style="background:#ffffff; border-radius:10px; padding:32px; box-shadow:0 2px 12px rgba(0,0,0,0.06); border:1px solid #e8ecf1;">
                    <div style="color:#f5a623; font-size:18px; margin-bottom:16px;">&#9733;&#9733;&#9733;&#9733;&#9733;</div>
                    <p style="color:#4a5568; font-size:14px; line-height:1.7; margin:0 0 20px 0; font-style:italic;">
                        "After a security incident with our previous provider, we brought in Contoso to harden our Windows Server fleet. They identified 47 critical vulnerabilities in the first audit and had everything remediated within a week. Outstanding professionalism."
                    </p>
                    <div style="border-top:1px solid #f0f0f0; padding-top:16px;">
                        <div style="font-weight:600; color:#1a365d; font-size:14px;">Michael Chen</div>
                        <div style="color:#999; font-size:12px;">CISO, Apex Financial Services</div>
                    </div>
                </div>

                <div style="background:#ffffff; border-radius:10px; padding:32px; box-shadow:0 2px 12px rgba(0,0,0,0.06); border:1px solid #e8ecf1;">
                    <div style="color:#f5a623; font-size:18px; margin-bottom:16px;">&#9733;&#9733;&#9733;&#9733;&#9733;</div>
                    <p style="color:#4a5568; font-size:14px; line-height:1.7; margin:0 0 20px 0; font-style:italic;">
                        "We have been partnering with Contoso for over six years now. Their 24/7 monitoring caught a failing disk array at 2 AM and had us failed over to the secondary site before our own team even woke up. They are truly an extension of our IT department."
                    </p>
                    <div style="border-top:1px solid #f0f0f0; padding-top:16px;">
                        <div style="font-weight:600; color:#1a365d; font-size:14px;">Linda Johansson</div>
                        <div style="color:#999; font-size:12px;">Director of IT, NorthStar Logistics</div>
                    </div>
                </div>

            </div>
        </div>
    </section>

    <!-- Technology Partners -->
    <section style="padding:60px 40px; text-align:center;">
        <h2 style="font-size:36px; color:#1a365d; margin:0 0 12px 0;">Technology Partners</h2>
        <p style="color:#6b7c93; font-size:16px; margin:0 0 40px 0;">Built on the platforms we know best</p>
        <div style="display:flex; flex-wrap:wrap; justify-content:center; gap:16px; max-width:800px; margin:0 auto;">
            <span style="display:inline-block; background:#e6f0ff; color:#1a365d; font-size:14px; font-weight:600; padding:10px 24px; border-radius:6px; border:1px solid #c3d9f5;">Microsoft</span>
            <span style="display:inline-block; background:#e6f0ff; color:#1a365d; font-size:14px; font-weight:600; padding:10px 24px; border-radius:6px; border:1px solid #c3d9f5;">Azure</span>
            <span style="display:inline-block; background:#e6f0ff; color:#1a365d; font-size:14px; font-weight:600; padding:10px 24px; border-radius:6px; border:1px solid #c3d9f5;">Windows Server</span>
            <span style="display:inline-block; background:#e6f0ff; color:#1a365d; font-size:14px; font-weight:600; padding:10px 24px; border-radius:6px; border:1px solid #c3d9f5;">IIS</span>
            <span style="display:inline-block; background:#e6f0ff; color:#1a365d; font-size:14px; font-weight:600; padding:10px 24px; border-radius:6px; border:1px solid #c3d9f5;">ASP.NET</span>
            <span style="display:inline-block; background:#e6f0ff; color:#1a365d; font-size:14px; font-weight:600; padding:10px 24px; border-radius:6px; border:1px solid #c3d9f5;">PowerShell</span>
        </div>
    </section>

    <!-- Contact Form -->
    <section id="contact" style="background:#f0f5fa; padding:80px 40px;">
        <div style="max-width:640px; margin:0 auto;">
            <h2 style="text-align:center; font-size:36px; color:#1a365d; margin:0 0 12px 0;">Get In Touch</h2>
            <p style="text-align:center; color:#6b7c93; font-size:16px; margin:0 0 40px 0;">Tell us about your infrastructure needs and we will get back to you within one business day.</p>
            <div style="background:#ffffff; border-radius:10px; padding:40px; box-shadow:0 2px 12px rgba(0,0,0,0.06); border:1px solid #e8ecf1;">
                <div style="margin-bottom:20px;">
                    <label style="display:block; font-size:13px; font-weight:600; color:#1a365d; margin-bottom:6px;">Full Name</label>
                    <input type="text" placeholder="John Smith" style="width:100%; padding:12px 14px; border:1px solid #d1d9e6; border-radius:6px; font-size:14px; font-family:inherit; box-sizing:border-box; outline:none;" />
                </div>
                <div style="margin-bottom:20px;">
                    <label style="display:block; font-size:13px; font-weight:600; color:#1a365d; margin-bottom:6px;">Email Address</label>
                    <input type="email" placeholder="john@company.com" style="width:100%; padding:12px 14px; border:1px solid #d1d9e6; border-radius:6px; font-size:14px; font-family:inherit; box-sizing:border-box; outline:none;" />
                </div>
                <div style="margin-bottom:20px;">
                    <label style="display:block; font-size:13px; font-weight:600; color:#1a365d; margin-bottom:6px;">Company</label>
                    <input type="text" placeholder="Acme Corporation" style="width:100%; padding:12px 14px; border:1px solid #d1d9e6; border-radius:6px; font-size:14px; font-family:inherit; box-sizing:border-box; outline:none;" />
                </div>
                <div style="margin-bottom:24px;">
                    <label style="display:block; font-size:13px; font-weight:600; color:#1a365d; margin-bottom:6px;">Message</label>
                    <textarea rows="5" placeholder="Describe your infrastructure requirements..." style="width:100%; padding:12px 14px; border:1px solid #d1d9e6; border-radius:6px; font-size:14px; font-family:inherit; box-sizing:border-box; outline:none; resize:vertical;"></textarea>
                </div>
                <button type="button" style="width:100%; background:#1a365d; color:#ffffff; padding:14px; border:none; border-radius:6px; font-size:16px; font-weight:600; cursor:pointer; font-family:inherit;">Send Message</button>
            </div>
        </div>
    </section>

    <!-- Hidden Repeater for memory allocation -->
    <div style="display:none">
    <asp:Repeater ID="rptTickets" runat="server">
        <ItemTemplate>
            <div>
                <%# Eval("ID") %> - <%# Eval("Title") %> - <%# Eval("Status") %> - <%# Eval("Priority") %> - <%# Eval("Assignee") %> - <%# Eval("CreatedDate") %>
            </div>
        </ItemTemplate>
    </asp:Repeater>
    </div>

    <!-- Footer -->
    <footer style="background:#0f2440; padding:40px 40px 24px 40px;">
        <div style="max-width:1200px; margin:0 auto;">
            <div style="display:grid; grid-template-columns:repeat(4, 1fr); gap:30px; margin-bottom:32px;">
                <div>
                    <div style="color:#ffffff; font-size:16px; font-weight:600; margin-bottom:14px;">Contoso Infrastructure</div>
                    <p style="color:#8899aa; font-size:13px; line-height:1.6; margin:0;">Enterprise-grade IIS hosting and Windows Server management for organizations that demand reliability.</p>
                </div>
                <div>
                    <div style="color:#ffffff; font-size:14px; font-weight:600; margin-bottom:14px;">Services</div>
                    <a href="#" style="display:block; color:#8899aa; font-size:13px; text-decoration:none; padding:3px 0;">Managed Hosting</a>
                    <a href="#" style="display:block; color:#8899aa; font-size:13px; text-decoration:none; padding:3px 0;">Cloud Migration</a>
                    <a href="#" style="display:block; color:#8899aa; font-size:13px; text-decoration:none; padding:3px 0;">Monitoring</a>
                    <a href="#" style="display:block; color:#8899aa; font-size:13px; text-decoration:none; padding:3px 0;">Security</a>
                </div>
                <div>
                    <div style="color:#ffffff; font-size:14px; font-weight:600; margin-bottom:14px;">Company</div>
                    <a href="#" style="display:block; color:#8899aa; font-size:13px; text-decoration:none; padding:3px 0;">About Us</a>
                    <a href="#" style="display:block; color:#8899aa; font-size:13px; text-decoration:none; padding:3px 0;">Careers</a>
                    <a href="#" style="display:block; color:#8899aa; font-size:13px; text-decoration:none; padding:3px 0;">Blog</a>
                    <a href="#" style="display:block; color:#8899aa; font-size:13px; text-decoration:none; padding:3px 0;">Contact</a>
                </div>
                <div>
                    <div style="color:#ffffff; font-size:14px; font-weight:600; margin-bottom:14px;">Legal</div>
                    <a href="#" style="display:block; color:#8899aa; font-size:13px; text-decoration:none; padding:3px 0;">Privacy Policy</a>
                    <a href="#" style="display:block; color:#8899aa; font-size:13px; text-decoration:none; padding:3px 0;">Terms of Service</a>
                    <a href="#" style="display:block; color:#8899aa; font-size:13px; text-decoration:none; padding:3px 0;">SLA Agreement</a>
                    <a href="#" style="display:block; color:#8899aa; font-size:13px; text-decoration:none; padding:3px 0;">Compliance</a>
                </div>
            </div>
            <div style="border-top:1px solid #1e3a5c; padding-top:20px; display:flex; justify-content:space-between; align-items:center;">
                <span style="color:#5a7a99; font-size:12px;">&copy; 2026 Contoso Infrastructure Services. All rights reserved.</span>
                <span style="color:#5a7a99; font-size:12px;">Server: <%= Environment.MachineName %> &middot; Rendered: <%= DateTime.UtcNow.ToString("yyyy-MM-dd HH:mm:ss") %> UTC</span>
            </div>
        </div>
    </footer>

    </form>
</body>
</html>
