using System;
using System.Data;
using System.Text;
using System.Threading;
using System.Diagnostics;
using System.Security.Cryptography;
using System.Web.UI;

public partial class DefaultPage : System.Web.UI.Page
{
    private static int _requestCounter = 0;

    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            // 1. Perform 5 rounds of SHA-256 hashing on a 50KB string
            string payload = new string('X', 50 * 1024);
            using (SHA256 sha256 = SHA256.Create())
            {
                byte[] data = Encoding.UTF8.GetBytes(payload);
                for (int round = 0; round < 5; round++)
                {
                    byte[] hash = sha256.ComputeHash(data);
                    StringBuilder hex = new StringBuilder(hash.Length * 2);
                    foreach (byte b in hash)
                    {
                        hex.AppendFormat("{0:x2}", b);
                    }
                    data = Encoding.UTF8.GetBytes(hex.ToString());
                }
            }

            // 2. Build an in-memory DataTable with 500 rows and bind to Repeater
            DataTable dt = new DataTable("ServiceTickets");
            dt.Columns.Add("ID", typeof(int));
            dt.Columns.Add("Title", typeof(string));
            dt.Columns.Add("Status", typeof(string));
            dt.Columns.Add("Priority", typeof(string));
            dt.Columns.Add("Assignee", typeof(string));
            dt.Columns.Add("CreatedDate", typeof(DateTime));

            string[] statuses = { "Open", "In Progress", "Resolved", "Closed", "Pending" };
            string[] priorities = { "Critical", "High", "Medium", "Low" };
            string[] assignees = { "Alice Martin", "Bob Kumar", "Carol Zhang", "David Okonkwo", "Eva Petrov", "Frank Gomez" };
            string[] titles = {
                "IIS worker process high CPU",
                "SSL certificate expiring soon",
                "Application pool crash on server WEB04",
                "Disk space low on D: drive",
                "Slow response times on /api/orders",
                "Windows Update reboot required",
                "Load balancer health check failing",
                "DNS resolution timeout for internal API",
                "Memory leak in legacy ASMX service",
                "Firewall rule change request"
            };

            Random rng = new Random(42);
            for (int i = 1; i <= 500; i++)
            {
                DataRow row = dt.NewRow();
                row["ID"] = i;
                row["Title"] = titles[rng.Next(titles.Length)] + " #" + i;
                row["Status"] = statuses[rng.Next(statuses.Length)];
                row["Priority"] = priorities[rng.Next(priorities.Length)];
                row["Assignee"] = assignees[rng.Next(assignees.Length)];
                row["CreatedDate"] = DateTime.UtcNow.AddDays(-rng.Next(1, 365)).AddHours(-rng.Next(0, 24));
                dt.Rows.Add(row);
            }

            rptTickets.DataSource = dt;
            rptTickets.DataBind();

            // 3. Simulate latency
            Thread.Sleep(150);

            // 4. Generate 20 random GUIDs
            StringBuilder guidBuilder = new StringBuilder();
            for (int i = 0; i < 20; i++)
            {
                guidBuilder.AppendLine(Guid.NewGuid().ToString());
            }

            // 5. On every 10th request, write to Windows Application Event Log
            int currentCount = Interlocked.Increment(ref _requestCounter);
            if (currentCount % 10 == 0)
            {
                try
                {
                    if (!EventLog.SourceExists("IISChaosApp"))
                    {
                        EventLog.CreateEventSource("IISChaosApp", "Application");
                    }
                    EventLog.WriteEntry("IISChaosApp", "PageLoad request processed", EventLogEntryType.Information, 1000);
                }
                catch
                {
                    // Silently ignore if event log write fails due to permissions
                }
            }
        }
    }
}
